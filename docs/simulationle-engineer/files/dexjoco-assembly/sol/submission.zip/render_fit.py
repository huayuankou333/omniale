import os
os.environ.setdefault('MUJOCO_GL', 'osmesa')
import mujoco
import numpy as np
from scipy.spatial.transform import Rotation
from scipy.optimize import minimize
from scipy.ndimage import gaussian_filter
from vision import cameras, color_masks, component


class ObjectRenderer:
    def __init__(self):
        self.model = mujoco.MjModel.from_xml_string('''<mujoco>
        <include file="/public/assets/industreal_round_peg_8mm.xml"/>
        <include file="/public/assets/industreal_tray_insert_round_peg_8mm.xml"/>
        <visual><headlight diffuse=".4 .4 .4" ambient=".5 .5 .5"/><global offwidth="224" offheight="224"/><quality offsamples="4"/></visual>
        <worldbody><camera name="view" fovy="45"/><light pos="0 0 3" dir="0 0 -1" diffuse="1 1 1" specular=".3 .3 .3"/></worldbody></mujoco>''')
        self.data = mujoco.MjData(self.model)
        self.renderer = mujoco.Renderer(self.model, 224, 224)
        self.options = mujoco.MjvOption()
        self.options.geomgroup[3] = 0
        self.model.geom_rgba[self.model.geom('industreal_tray_insert_round_peg_8mm_visual').id, 3] = 0

    def render(self, position, matrix, camera):
        self.data.qpos[:3] = position
        self.data.qpos[3:7] = Rotation.from_matrix(matrix).as_quat(scalar_first=True)
        mujoco.mj_forward(self.model, self.data)
        self.data.cam_xpos[0] = camera[0]
        self.data.cam_xmat[0] = camera[1].flatten()
        self.model.cam_fovy[0] = np.rad2deg(2 * np.arctan(112 / camera[2]))
        self.renderer.update_scene(self.data, camera=0, scene_option=self.options)
        return self.renderer.render().copy()


def fit_peg(obs, table_height, renderer=None):
    renderer = renderer or ObjectRenderer()
    views = cameras(obs['state'])
    images = [obs[key] for key in ('base','wrist_left','wrist_right')]
    masks = [component(color_masks(image)[0]) for image in images]
    valid = [index for index,mask in enumerate(masks) if mask.sum() > 12]
    crops = []
    targets = []
    for index in valid:
        points = np.argwhere(masks[index])
        lower = np.maximum(points.min(0)-12, 0)
        upper = np.minimum(points.max(0)+13, 224)
        crop = (slice(lower[0],upper[0]),slice(lower[1],upper[1]))
        crops.append(crop)
        image = images[index].astype(float)
        targets.append(gaussian_filter(np.maximum(image[:,:,0]-image[:,:,2],0), .6)[crop])
    def loss(pose):
        if not(-.4<pose[0]<.2 and -.5<pose[1]<0):return 1e6
        matrix = Rotation.from_euler('z',pose[2]).as_matrix() @ Rotation.from_euler('y',np.pi/2).as_matrix()
        result=0.
        for index,crop,target in zip(valid,crops,targets):
            image=renderer.render([pose[0],pose[1],table_height+.01785],matrix,views[index]).astype(float)
            chroma=gaussian_filter(np.maximum(image[:,:,0]-image[:,:,2],0),.6)[crop]
            scale=np.clip((target*chroma).sum()/(np.square(chroma).sum()+1e-6),.3,3)
            result+=np.square(target-chroma*scale).sum() / (np.square(target).sum()+1)
        return result
    fits=[]
    for yaw in (0., .4, -.4):
        fit=minimize(loss,[-.1,-.16,yaw],method='Powell',options={'maxiter':12,'xtol':.0002,'ftol':.0002})
        fits.append(fit)
    fit=min(fits,key=lambda candidate:candidate.fun)
    return fit.x, fit.fun
