# Executable controller

`policy.py` exports `create_policy()`. Its returned controller implements
`infer(obs)` and returns 30 absolute 44-dimensional world-space actions.
Supporting inference modules are `vision.py`, `hand_geometry.py`, and `raster.py`.

The controller segments the colored assembly parts, fits their public mesh
silhouettes to the three RGB views, and uses the observed TCP poses to obtain
wrist-camera projections. It executes observation-driven approach, grasp,
lift, reorientation, tray stabilization, alignment, and insertion phases.
After grasping and stabilizing the tray, the left hand releases and withdraws
outward to provide clearance for the peg and right hand.
Close-range fitting estimates the held peg transform and tray orientation;
static hand kinematics mask robot occlusions. Phase transitions depend on
observed pose/joint convergence rather than assuming each inference call
executes thirty steps. Proprioceptive reset detection supports a persistent
policy server.

Inference uses no development-service calls, network access, hidden state,
or simulation stepping. MuJoCo is used only for forward kinematics of the
public static hand model. OpenCV accelerates raster operations when present;
the included NumPy/SciPy/Pillow implementation is the fallback.

## Development results

- The first `rand_obj` development episode reached 1500 steps without success.
  It demonstrated right-hand grasp/lift and left-hand tray grasp, but exposed
  insertion alignment and hand-clearance problems subsequently revised.
- A `rand_full` reset failed in the development service with
  `KeyError: 'ego'`; the following observation also failed with an assertion.
  No successful `rand_full` rollout is claimed.
- A second complete `rand_obj` episode also ended without success. It reached
  close-range pre-insertion, but reorientation convergence consumed much of
  the episode and hand interference disturbed the held peg.
- A third `rand_obj` episode was stopped at 1260 steps without success after
  an upward left-hand withdrawal disturbed the peg. The withdrawal was
  revised to open the hand first and move outward instead of upward.
- The fourth `rand_obj` episode reached the insertion phase and completed
  1500 steps, but the simulator reported `success: false`. The right TCP
  descended through the insertion motion; sustained hole-bottom contact
  was not verified. No successful development episode is claimed.
- Controller revisions were applied during development rollouts. In
  particular, the final stalled-reorientation transition was introduced
  partway through the fourth rollout; a fresh full rollout of the exact
  final source was not completed within the budget.

## Interface validation

The policy passes Python compilation and a saved-observation smoke test:
the returned action array is finite, float64, and shaped `(30, 44)`.
Persistent-policy reset detection was checked against an initial observation.
The included raster fallback was also exercised on initial localization.
