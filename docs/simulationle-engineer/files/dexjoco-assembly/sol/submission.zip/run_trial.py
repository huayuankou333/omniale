import argparse
import importlib
import json
import pickle
from pathlib import Path
import numpy as np
from dev_client import SimClient,save_images
import vision
import policy as policy_module

parser=argparse.ArgumentParser()
parser.add_argument('--resume',action='store_true')
parser.add_argument('--condition',default='rand_obj')
parser.add_argument('--output',default='trial')
parser.add_argument('--steps',type=int,default=1500)
args=parser.parse_args()
client=SimClient()
if args.resume:
    obs,info=client.observe()
    policy=pickle.load(open('checkpoint.pkl','rb'))
else:
    obs,info=client.reset(args.condition)
    policy=policy_module.create_policy()
save_images(obs,f'{args.output}/step{info["steps"]:04d}')
while info['steps']<args.steps and not info['done']:
    if Path('STOP').exists():break
    vision=importlib.reload(vision)
    policy_module=importlib.reload(policy_module)
    policy.__class__=policy_module.AssemblyPolicy
    output=policy.infer(obs)
    print('POLICY',policy.debug,flush=True)
    with open('checkpoint.pkl','wb') as stream:pickle.dump(policy,stream)
    obs,info=client.step(output['actions'][:min(30,args.steps-info['steps'])])
    print('INFO',info,'STATE',np.round(obs['state'][:14],4).tolist(),'HAND',np.round(obs['state'][14:30],2).tolist(),'LEFT',np.round(obs['state'][30:],2).tolist(),flush=True)
    save_images(obs,f'{args.output}/step{info["steps"]:04d}')
Path(args.output,'result.json').write_text(json.dumps(info,indent=2))
