from dev_client import SimClient, save_images
from policy import create_policy
import json
import numpy as np

client=SimClient()
obs,info=client.observe()
policy=create_policy()
save_images(obs,'grasp_test/start')
for iteration in range(16):
    output=policy.infer(obs)
    print('POLICY',policy.debug,flush=True)
    obs,info=client.step(output['actions'])
    print('INFO',info,'STATE',np.round(obs['state'][:14],4).tolist(),'HAND',np.round(obs['state'][14:30],2).tolist(),flush=True)
    save_images(obs,f'grasp_test/step{info["steps"]:04d}')
    if info['done']:break
