from dev_client import SimClient,save_images
import policy as policy_module
from vision import peg_matrix
import numpy as np
import json
import pickle
import importlib
from pathlib import Path
import time

client=SimClient()
while not Path('grasp_test/step0480').exists():
    time.sleep(2)
obs,info=client.observe()
policy=policy_module.create_policy()
policy.peg=np.load('peg_fast.npy')
policy.tray=np.array([-.2389706413,.2368819856,.9551952013,.1114631273])
policy.configure(obs['state'])
policy.tray=np.load('tray_pose3.npy')
policy.left_grasp_position=policy.tray[:3]+[0.,.075,.175]
policy.stage='close'
for iteration in range(33):
    if Path('STOP').exists():break
    policy_module=importlib.reload(policy_module)
    policy.__class__=policy_module.AssemblyPolicy
    output=policy.infer(obs)
    print('POLICY',policy.debug,flush=True)
    with open('checkpoint.pkl','wb') as stream:pickle.dump(policy,stream)
    obs,info=client.step(output['actions'])
    print('INFO',info,'STATE',np.round(obs['state'][:14],4).tolist(),'HAND',np.round(obs['state'][14:30],2).tolist(),'LEFT',np.round(obs['state'][30:],2).tolist(),flush=True)
    save_images(obs,f'continued/step{info["steps"]:04d}')
    if info['done']:break
