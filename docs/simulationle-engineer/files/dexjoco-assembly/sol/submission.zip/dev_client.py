"""Public development tool. This file contains no policy or solution."""
import base64
import io
import json
from pathlib import Path
import time
import urllib.error
import urllib.request

import numpy as np
from PIL import Image


class SimClient:
    def _request(self, path, payload):
        req = urllib.request.Request('http://simulator:8081'+path,
            data=json.dumps(payload).encode(), headers={'Content-Type':'application/json'})
        try:
            with urllib.request.urlopen(req, timeout=600) as response:
                data = json.load(response)
        except urllib.error.HTTPError as exc:
            raise RuntimeError(exc.read().decode()) from None
        obs = data['obs']
        obs['state'] = np.asarray(obs['state'], dtype=np.float64)
        for k in ('base', 'wrist_left', 'wrist_right'):
            obs[k] = np.asarray(Image.open(io.BytesIO(base64.b64decode(obs[k]))).convert('RGB'))
        return obs, data['info']

    def reset(self, condition='rand_obj'):
        return self._request('/reset', {'condition':condition})

    def observe(self):
        return self._request('/observe', {})

    def step(self, actions):
        return self._request('/step', {'actions':np.asarray(actions).tolist()})


def save_images(obs, directory):
    out = Path(directory)
    out.mkdir(parents=True, exist_ok=True)
    for k in ('base', 'wrist_left', 'wrist_right'):
        Image.fromarray(np.asarray(obs[k], dtype=np.uint8)).save(out/(k+'.png'))
    (out/'state.json').write_text(json.dumps(obs['state'].tolist()))


def rollout(policy, condition='rand_obj', output='dev_rollout', max_steps=1500):
    """Synchronous development rollout; formal evaluation uses official async runner."""
    client = SimClient()
    start = time.monotonic()
    obs, info = client.reset(condition)
    out = Path(output)
    save_images(obs, out/'step0000')
    print(json.dumps(info), flush=True)
    last_save = 0
    while not info['done'] and info['steps'] < max_steps:
        actions = np.asarray(policy.infer(obs)['actions'])
        assert actions.shape == (30,44) and np.isfinite(actions).all()
        n = min(30, max_steps-info['steps'])
        obs, info = client.step(actions[:n])
        print(json.dumps(info), flush=True)
        if info['steps']-last_save >= 90 or info['done']:
            save_images(obs, out/f"step{info['steps']:04d}")
            last_save = info['steps']
    info['wall_seconds'] = time.monotonic()-start
    out.mkdir(parents=True, exist_ok=True)
    (out/'result.json').write_text(json.dumps(info, indent=2))
    return info
