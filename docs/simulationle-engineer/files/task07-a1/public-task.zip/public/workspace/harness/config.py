"""Published force limits for the bin-clearing cell.

The evaluation applies exactly these values; they are echoed in the
`cell_spec` dict your policy receives. Reward weights are not published.
"""

# Sustained (>= DMG_TICKS consecutive control ticks) contact force on a part
# above this counts as damage.
DAMAGE_FORCE_N = 2800.0
DMG_TICKS = 2

# Tool-bin contact above this, sustained BIN_HIT_TICKS consecutive control
# ticks, is a strike; the force must drop for BIN_HIT_REARM_TICKS before
# another can be counted.
BIN_HIT_FORCE_N = 700.0
BIN_HIT_TICKS = 2
BIN_HIT_REARM_TICKS = 5
