"""Independent physical acceptance for oriented, singulated deliveries."""
from __future__ import annotations

import itertools
import mujoco
import numpy as np

from . import parts, spec

CORNERS = np.asarray(list(itertools.product((-1., 1.), repeat=3)))


def state(model, data, n):
    positions, rotations, bounds, angular = [], [], [], []
    part_of_geom = {}
    for i in range(n):
        body = model.body(parts.part_name(i)).id
        positions.append(data.xpos[body].copy())
        rotations.append(data.xmat[body].reshape(3, 3).copy())
        angular.append(np.linalg.norm(data.joint(parts.part_name(i)).qvel[3:]))
        vertices = []
        for g in range(model.body_geomadr[body], model.body_geomadr[body] + model.body_geomnum[body]):
            part_of_geom[g] = i
            vertices.extend((CORNERS * model.geom_size[g]) @ data.geom_xmat[g].reshape(3, 3).T + data.geom_xpos[g])
        vertices = np.asarray(vertices)
        bounds.append(np.array([vertices.min(axis=0), vertices.max(axis=0)]))
    supports = set()
    touching = [set() for _ in range(n)]
    belt = model.geom('belt').id
    for contact_id,c in enumerate(data.contact):
        if c.dist > 0.0015:
            continue
        a, b = int(c.geom1), int(c.geom2)
        ia, ib = part_of_geom.get(a), part_of_geom.get(b)
        wrench=np.zeros(6)
        mujoco.mj_contactForce(model,data,contact_id,wrench)
        loaded_support = float(wrench[0]) > 0.05
        if ia is not None and b == belt and loaded_support:
            supports.add(ia)
        if ib is not None and a == belt and loaded_support:
            supports.add(ib)
        if ia is not None and ib is not None and ia != ib:
            touching[ia].add(ib)
            touching[ib].add(ia)
    return np.asarray(positions), np.asarray(rotations), np.asarray(bounds), np.asarray(angular), supports, touching


class ReadyTracker:
    def __init__(self, classes, rest_ticks=None):
        self.classes = list(map(int, classes))
        self.n = len(classes)
        self.rest_ticks = int(rest_ticks or round(spec.READY_REST_S * spec.CTRL_HZ))
        self.clear_time = {}
        self.acceptances = []
        self.rejections = []
        self.rework_recovered = set()
        self.rework_initial = set()
        self.mis_sorts = set()
        self._ok = np.zeros(self.n, dtype=int)
        self._attempt = np.zeros(self.n, dtype=int)
        self._latched = set()

    @property
    def cleared(self):
        return len(self.clear_time)

    def update(self, t, positions, speeds, exclude=None, *, rotations, bounds,
               angular, supports, touching):
        held = exclude or set()
        live = set(range(self.n)) - set(self.clear_time)
        occupants = []
        for lo, hi in spec.SORT_NESTS:
            lo, hi = np.asarray(lo), np.asarray(hi)
            occupants.append({i for i in live if np.all(bounds[i, 1, :2] >= lo[:2])
                              and np.all(bounds[i, 0, :2] <= hi[:2])
                              and bounds[i, 0, 2] < spec.BELT_TOP + .12})
        newly = []
        for i in sorted(live):
            resting = i not in held and speeds[i] < spec.CLEAR_SPEED and angular[i] < spec.READY_ANGULAR_SPEED
            zone = next((z for z, ids in enumerate(occupants) if i in ids), None)
            if not resting or zone is None or i not in supports:
                self._attempt[i] = 0
                self._latched.discard(i)
            else:
                self._attempt[i] += 1
            cls = self.classes[i]
            lo, hi = map(np.asarray, spec.SORT_NESTS[cls])
            center = (lo + hi) / 2
            axis = rotations[i][:, 0]
            target = np.array([np.cos(spec.TARGET_YAWS[cls]), np.sin(spec.TARGET_YAWS[cls]), 0.])
            yaw_error = float(np.arccos(np.clip(abs(np.dot(axis[:2], target[:2])) / max(np.linalg.norm(axis[:2]), 1e-9), 0, 1)))
            tilt_error = float(np.arccos(np.clip(rotations[i][2, 2], -1, 1)))
            center_error = float(np.linalg.norm(positions[i, :2] - center[:2]))
            footprint = bool(np.all(bounds[i, 0, :2] >= lo[:2]) and np.all(bounds[i, 1, :2] <= hi[:2]))
            reasons = []
            if zone != cls: reasons.append('wrong_class_station')
            if occupants[cls] != {i} or touching[i] & live: reasons.append('not_singulated')
            if center_error > spec.READY_CENTER_TOL: reasons.append('center')
            if yaw_error > spec.READY_YAW_TOL: reasons.append('yaw')
            if tilt_error > spec.READY_TILT_TOL: reasons.append('upright')
            if not footprint: reasons.append('footprint')
            if i not in supports: reasons.append('no_belt_support')
            if not resting: reasons.append('not_released_at_rest')
            good = not reasons
            self._ok[i] = self._ok[i] + 1 if good else 0
            if self._ok[i] >= self.rest_ticks:
                self.clear_time[i] = float(t)
                newly.append(i)
                if i in self.rework_initial:
                    self.rework_recovered.add(i)
                self.acceptances.append(dict(t=float(t), part_id=i, class_id=cls,
                    center_error_m=center_error, yaw_error_deg=float(np.rad2deg(yaw_error)),
                    tilt_error_deg=float(np.rad2deg(tilt_error)), speed_mps=float(speeds[i]),
                    angular_speed_radps=float(angular[i]), dwell_s=spec.READY_REST_S,
                    belt_supported=True, footprint_inside=True, released=True, singulated=True))
            elif reasons and self._attempt[i] >= self.rest_ticks and i not in self._latched:
                self.rejections.append(dict(t=float(t), part_id=i, station=zone, reasons=reasons))
                self._latched.add(i)
                if zone != cls:
                    self.mis_sorts.add((i, zone))
        return newly
