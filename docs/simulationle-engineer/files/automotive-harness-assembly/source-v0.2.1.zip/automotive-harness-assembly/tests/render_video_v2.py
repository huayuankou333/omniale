"""Render only verifier-owned states; videos never contribute to the score."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

import mujoco
import numpy as np
from PIL import Image, ImageDraw


def render_video(cell, output, sample_seconds=.4, fps=10):
    output=Path(output)
    encoder=shutil.which('ffmpeg')
    if encoder is None:
        raise RuntimeError('The verifier image is missing its ffmpeg video encoder')
    # These states are recorded by Cell._tick during this independent replay.
    # A separate MjData prevents rendering from changing the accepted episode.
    data=mujoco.MjData(cell.m)
    width,height=640,480
    path=output/'verification.mp4'
    process=subprocess.Popen([
        encoder,'-nostdin','-hide_banner','-loglevel','error','-y',
        '-f','rawvideo','-pix_fmt','rgb24','-s',f'{2*width}x{height}',
        '-r',str(fps),'-i','pipe:0','-an','-c:v','libx264',
        '-preset','veryfast','-threads','2','-crf','23','-pix_fmt','yuv420p',
        '-movflags','+faststart',str(path)
    ],stdin=subprocess.PIPE,stderr=subprocess.PIPE)
    frames=0
    next_time=0.
    try:
        with mujoco.Renderer(cell.m,height,width) as renderer:
            option=mujoco.MjvOption()
            option.sitegroup[:]=0
            rows=cell.trace or [dict(t=float(cell.d.time),q=cell.d.qpos.tolist(),phase=cell.phase)]
            for index,row in enumerate(rows):
                if row['t']+1e-8<next_time and index!=len(rows)-1:
                    continue
                next_time=row['t']+sample_seconds
                data.qpos[:]=row['q']
                data.time=row['t']
                mujoco.mj_kinematics(cell.m,data)
                mujoco.mj_comPos(cell.m,data)
                mujoco.mj_camlight(cell.m,data)
                mujoco.mj_flex(cell.m,data)
                views=[]
                for camera in ['overview','metrology']:
                    renderer.update_scene(data,camera=camera,scene_option=option)
                    views.append(renderer.render().copy())
                frame=Image.fromarray(np.concatenate(views,axis=1))
                draw=ImageDraw.Draw(frame)
                draw.rectangle((0,0,2*width,28),fill=(15,20,26))
                draw.text((10,8),f'Independent nominal replay | seed {cell.seed} | t={row["t"]:.3f} s | {row["phase"]} | {sample_seconds*fps:g}x playback',fill='white')
                process.stdin.write(np.asarray(frame).tobytes())
                if frames==0:
                    frame.save(output/'first-frame.png')
                frames+=1
            if frames:
                frame.save(output/'last-frame.png')
        process.stdin.close()
        error=process.stderr.read().decode(errors='replace')
        returncode=process.wait(timeout=60)
        if returncode or not frames:
            raise RuntimeError(f'Verifier video encoding failed ({returncode}): {error[-2000:]}')
    finally:
        if process.poll() is None:
            process.kill()
            process.wait()
        if not process.stdin.closed:
            process.stdin.close()
        process.stderr.close()
    receipt=dict(file=path.name,bytes=path.stat().st_size,
                 sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
                 frames=frames,fps=fps,simulated_sample_seconds=sample_seconds,
                 source='This independent verifier replay trace; no candidate log or animation',
                 scientific_score_source=False)
    (output/'video.json').write_text(json.dumps(receipt,indent=2)+'\n')
    return receipt
