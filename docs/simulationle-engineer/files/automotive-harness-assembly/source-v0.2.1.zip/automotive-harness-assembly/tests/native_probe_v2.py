"""Run only inside the unprivileged submission sandbox."""
import json,sys
from pathlib import Path
import numpy as np
import mujoco
manifest=json.loads(Path('submission.json').read_text());m=mujoco.MjModel.from_xml_path(str(Path(manifest['native_model']).resolve()));d=mujoco.MjData(m)
direct={int(m.actuator_trnid[i,0]) for i in range(m.nu)
        if m.actuator_trntype[i] in (mujoco.mjtTrn.mjTRN_JOINT,mujoco.mjtTrn.mjTRN_JOINTINPARENT)}
for arm in ['left','right']:
 if any(m.joint(name).id not in direct for name in manifest['robot_joint_names'][arm]):
  raise ValueError('Every arm joint must have a physical joint actuator in the native model')
request=json.loads(sys.stdin.readline());rows=[]
for configuration in request['configurations']:
 for arm in ['left','right']:
  names=manifest['robot_joint_names'][arm]
  if not isinstance(names,list) or len(names)!=6 or len(set(names))!=6:raise ValueError('Six distinct arm joints are required')
  for n,q in zip(names,configuration[arm]):
   if m.joint(n).type[0]!=mujoco.mjtJoint.mjJNT_HINGE:raise ValueError('Arm joints must be revolute')
   d.joint(n).qpos[0]=q
 mujoco.mj_kinematics(m,d)
 result={}
 for arm in ['left','right']:
  site=d.site(manifest['robot_tcp_sites'][arm]);result[arm]={'position_m':site.xpos.tolist(),'rotation':site.xmat.reshape(3,3).tolist()}
 rows.append(result)
print(json.dumps(dict(revolute_joints=int((m.jnt_type==mujoco.mjtJoint.mjJNT_HINGE).sum()),free_joints=int((m.jnt_type==mujoco.mjtJoint.mjJNT_FREE).sum()),actuators=m.nu,configurations=rows)),flush=True)
