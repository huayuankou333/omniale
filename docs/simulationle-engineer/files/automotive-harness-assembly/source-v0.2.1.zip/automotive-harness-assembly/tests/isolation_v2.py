"""Freeze regular artifacts and execute controllers under an unprivileged UID."""
import ctypes
import hashlib
import json
import os
from pathlib import Path
import resource
import selectors
import select
import shutil
import signal
import stat
import subprocess
import tempfile
import time

class SubmissionError(ValueError):pass

def freeze(source,destination):
    source=Path(source);destination=Path(destination);destination.mkdir()
    total=0;hashes={}
    if not source.is_dir() or source.is_symlink():raise SubmissionError('Missing submission directory')
    for p in sorted(source.rglob('*')):
        rel=p.relative_to(source);s=p.lstat()
        if stat.S_ISDIR(s.st_mode):(destination/rel).mkdir(exist_ok=True);continue
        if not stat.S_ISREG(s.st_mode) or s.st_nlink!=1:raise SubmissionError('Only regular, non-linked artifacts are accepted')
        total+=s.st_size
        if total>200_000_000 or len(hashes)>=2000:raise SubmissionError('Submission exceeds 200 MB / 2000 files')
        data=p.read_bytes();out=destination/rel;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(data);out.chmod(0o555 if s.st_mode&0o111 else 0o444)
        hashes[str(rel)]=hashlib.sha256(data).hexdigest()
    for required in ('submission.json','assembly_plan.json','calibration.json','deployment.json','commissioning.md'):
        if required not in hashes:raise SubmissionError('Missing '+required)
    try:manifest=json.loads((destination/'submission.json').read_text())
    except (ValueError,OSError,RecursionError) as e:raise SubmissionError('Malformed submission.json') from e
    if not isinstance(manifest,dict):raise SubmissionError('submission.json must be an object')
    if manifest.get('schema_version')!=2:raise SubmissionError('Unsupported submission schema')
    for key in ('controller',):
        args=manifest.get(key)
        if not isinstance(args,list) or not 1<=len(args)<=12 or any(not isinstance(x,str) or len(x)>256 for x in args):raise SubmissionError('Invalid '+key+' argv')
        if args[0] not in ('python','python3','sh') and not (args[0].startswith('./') and '..' not in args[0].split('/')):raise SubmissionError('Use python3, sh or a local executable')
    model=manifest.get('native_model')
    if not isinstance(model,str) or Path(model).is_absolute() or '..' in Path(model).parts or model not in hashes:raise SubmissionError('native_model must identify an included regular MJCF file')
    for key in ('robot_joint_names','robot_tcp_sites'):
        if not isinstance(manifest.get(key),dict) or set(manifest[key])!={'left','right'}:raise SubmissionError('Missing '+key)
    return manifest,hashes

def drop():
    os.setsid();resource.setrlimit(resource.RLIMIT_CPU,(600,600));resource.setrlimit(resource.RLIMIT_AS,(3*1024**3,3*1024**3))
    resource.setrlimit(resource.RLIMIT_NPROC,(64,64));resource.setrlimit(resource.RLIMIT_NOFILE,(64,64));resource.setrlimit(resource.RLIMIT_FSIZE,(20_000_000,20_000_000))
    resource.setrlimit(resource.RLIMIT_CORE,(0,0));os.setgroups([]);os.setgid(60005);os.setuid(60005)
    libc=ctypes.CDLL(None);libc.prctl(38,1,0,0,0);libc.prctl(4,0,0,0,0)

class Program:
    def __init__(self,submission,public,args,extra=None):
        if os.geteuid()!=0:raise RuntimeError('Trusted verifier must start as root')
        for folder in ('/tests','/logs/verifier'):
            if os.stat(folder).st_mode&0o077:raise RuntimeError('Unprotected trusted directory: '+folder)
        self.temporary=tempfile.TemporaryDirectory(prefix='o5-worker-');self.root=Path(self.temporary.name);self.root.chmod(0o755)
        shutil.copytree(submission,self.root/'submission');shutil.copytree(public,self.root/'engineering')
        if extra:shutil.copyfile(extra,self.root/'submission/_native_probe.py')
        for p in self.root.rglob('*'):p.chmod(0o555 if p.is_dir() or p.stat().st_mode&0o111 else 0o444)
        scratch=self.root/'scratch';scratch.mkdir();os.chown(scratch,60005,60005);scratch.chmod(0o700)
        env=dict(PATH='/usr/local/bin:/usr/bin:/bin',HOME=str(scratch),TMPDIR=str(scratch),ENGINEERING_DIR=str(self.root/'engineering'),PYTHONHASHSEED='0',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',LP_NUM_THREADS='1',MUJOCO_GL='osmesa')
        self.log=(self.root/'stderr.log').open('wb')
        self.proc=subprocess.Popen(args,cwd=self.root/'submission',env=env,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=self.log,preexec_fn=drop,close_fds=True)
        os.set_blocking(self.proc.stdout.fileno(),False);os.set_blocking(self.proc.stdin.fileno(),False);self.selector=selectors.DefaultSelector();self.selector.register(self.proc.stdout,selectors.EVENT_READ);self.buffer=b'';self.calls=0
    def exchange(self,value,timeout=3):
        raw=memoryview((json.dumps(value,allow_nan=False)+'\n').encode())
        end=time.monotonic()+(max(timeout,60) if self.calls==0 else timeout);self.calls+=1
        try:
            while raw:
                remaining=end-time.monotonic()
                if remaining<=0 or not select.select([], [self.proc.stdin], [],remaining)[1]:raise SubmissionError('Worker stopped reading observations')
                try:count=os.write(self.proc.stdin.fileno(),raw)
                except BlockingIOError:continue
                raw=raw[count:]
        except (OSError,ValueError) as e:raise SubmissionError('Worker exited before its response') from e
        while b'\n' not in self.buffer:
            remaining=end-time.monotonic()
            if remaining<=0:raise SubmissionError('Worker response deadline exceeded')
            if not self.selector.select(remaining):raise SubmissionError('Worker response deadline exceeded')
            data=os.read(self.proc.stdout.fileno(),65536)
            if not data:
                self.log.flush();detail=(self.root/'stderr.log').read_text(errors='replace')[-2000:]
                raise SubmissionError('Worker closed stdout: '+detail)
            self.buffer+=data
            if len(self.buffer)>1_000_000:raise SubmissionError('Worker output exceeded 1 MB')
        line,self.buffer=self.buffer.split(b'\n',1)
        try:return json.loads(line)
        except (ValueError,RecursionError) as e:raise SubmissionError('Worker output is not JSON') from e
    def close(self):
        try:os.killpg(self.proc.pid,signal.SIGKILL)
        except ProcessLookupError:pass
        self.proc.wait();self.proc.stdin.close();self.proc.stdout.close();self.selector.close();self.log.close();self.temporary.cleanup()
    def __enter__(self):return self
    def __exit__(self,*args):self.close()
