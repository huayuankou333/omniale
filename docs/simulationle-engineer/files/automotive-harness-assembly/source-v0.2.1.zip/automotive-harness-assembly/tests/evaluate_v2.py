"""Freeze and independently replay an O5 controller. Candidate logs are never scores."""
import hashlib,json,os,sys,traceback,time,shutil
from pathlib import Path
import numpy as np
import mujoco
from cell_v2 import Cell,CommandError
from native_v2 import JOINTS,build
from isolation_v2 import Program,SubmissionError,freeze
from render_video_v2 import render_video

def write(path,value):Path(path).write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')
def native_check(submission,public,manifest,out):
 rng=np.random.default_rng(598125);configs=[{a:rng.uniform([-2.5,-2,-2,-2.5,-2.5,-2.5],[2.5,-.5,2,2.5,2.5,2.5]).tolist() for a in ['left','right']} for _ in range(16)]
 with Program(submission,public,['python3','-I','_native_probe.py'],Path(__file__).with_name('native_probe_v2.py')) as worker:got=worker.exchange({'configurations':configs},120)
 if not isinstance(got,dict) or got.get('revolute_joints',0)<12 or got.get('free_joints',0)<8 or got.get('actuators',0)<14:raise SubmissionError('Native model lacks the two actuated arms and eight mobile connector bodies')
 path,order=build(out/'native-truth',cables=False,only_part='left_0');m=mujoco.MjModel.from_xml_path(str(path));d=mujoco.MjData(m);position=0.;angular=0.
 try:
  if len(got['configurations'])!=len(configs):raise ValueError('Missing native responses')
  for cfg,response in zip(configs,got['configurations']):
   for arm in cfg:
    for n,q in zip(JOINTS,cfg[arm]):d.joint(arm+'_'+n).qpos[0]=q
   mujoco.mj_kinematics(m,d)
   for arm in cfg:
    expected=d.site(arm+'_gripper_pinch');p=np.asarray(response[arm]['position_m'],float);r=np.asarray(response[arm]['rotation'],float)
    if p.shape!=(3,) or r.shape!=(3,3) or not np.isfinite(p).all() or not np.isfinite(r).all():raise ValueError('Nonfinite native prediction')
    position=max(position,float(np.linalg.norm(p-expected.xpos)));angular=max(angular,float(np.arccos(np.clip((np.trace(expected.xmat.reshape(3,3).T@r)-1)/2,-1,1))))
 except (KeyError,ValueError,TypeError) as exc:raise SubmissionError('Malformed native-model output') from exc
 if position>.0001 or angular>.001:raise SubmissionError(f'Native robot FK does not match the supplied hardware: {position} m / {angular} rad')
 return dict(passed=True,maximum_position_error_m=position,maximum_orientation_error_rad=angular,configurations=len(configs))

def documentation(submission):
 required={'assembly_plan.json':['parts','operations','inspection_conditions'],
           'calibration.json':['base_frames','tool_frames','sensor_frames','joint_order','uncertainty','method'],
           'deployment.json':['hardware_interface','payloads','limits','io_handshake','fault_behavior','unvalidated_assumptions','hardware_validation']}
 for filename,keys in required.items():
  try:doc=json.loads((submission/filename).read_text())
  except (ValueError,OSError) as exc:raise SubmissionError('Malformed '+filename) from exc
  if not isinstance(doc,dict) or any(k not in doc or doc[k] is None for k in keys):raise SubmissionError('Incomplete '+filename)
  if filename=='deployment.json' and doc['hardware_validation']!='not_performed':raise SubmissionError('This case has no hardware test evidence; declare hardware_validation=not_performed')
  if filename=='assembly_plan.json':
   ids={a+'_'+str(j) for a in ['left','right'] for j in range(4)}
   if not isinstance(doc['parts'],list) or len(doc['parts'])!=8 or {p.get('id') for p in doc['parts'] if isinstance(p,dict)}!=ids:raise SubmissionError('The assembly plan must identify all eight parts exactly once')
   if not isinstance(doc['operations'],list) or len(doc['operations'])<8 or not ids<={p.get('part_id') for p in doc['operations'] if isinstance(p,dict)}:raise SubmissionError('The assembly plan must include operations for all parts')
   if not isinstance(doc['inspection_conditions'],list) or not {'released','retention','cover','rework'}<=set(doc['inspection_conditions']):raise SubmissionError('The plan must declare all four inspection phases')
  if filename=='calibration.json':
   for field in ['base_frames','tool_frames','sensor_frames']:
    if not isinstance(doc[field],dict) or (set(doc[field])!={'left','right'} if field!='sensor_frames' else not doc[field]):raise SubmissionError('Calibration requires '+field)
    for a,t in doc[field].items():
     q=np.asarray(t,float)
     if q.shape!=(4,4) or not np.isfinite(q).all() or not np.allclose(q[3],[0,0,0,1]) or not np.allclose(q[:3,:3].T@q[:3,:3],np.eye(3),atol=1e-6) or abs(np.linalg.det(q[:3,:3])-1)>1e-6:raise SubmissionError('Calibration transforms must be rigid 4x4 matrices')
   if not isinstance(doc['sensor_frames'],dict) or not doc['sensor_frames'] or not isinstance(doc['method'],str) or not doc['method'].strip():raise SubmissionError('Record sensor calibration and its method')
   if not isinstance(doc['joint_order'],dict) or set(doc['joint_order'])!={'left','right'} or any(not isinstance(v,list) or len(v)!=6 or len(set(v))!=6 for v in doc['joint_order'].values()):raise SubmissionError('Declare six ordered joints for each arm')
   u=doc['uncertainty']
   if not isinstance(u,dict) or any(type(u.get(k)) not in (int,float) or not np.isfinite(u[k]) or u[k]<0 for k in ['translation_m','rotation_rad']):raise SubmissionError('Calibration uncertainty must be finite and nonnegative')
  if filename=='deployment.json':
   for field in ['hardware_interface','payloads','limits','io_handshake','fault_behavior']:
    if not isinstance(doc[field],dict) or not doc[field]:raise SubmissionError('Deployment must define '+field)
   if not isinstance(doc['unvalidated_assumptions'],list) or not doc['unvalidated_assumptions']:raise SubmissionError('Declare unvalidated hardware assumptions')
   limits=doc['limits']
   for key,maximum in [('joint_slew_rad_s',.65),('mating_force_N',100.)]:
    if type(limits.get(key)) not in (int,float) or not np.isfinite(limits[key]) or not 0<limits[key]<=maximum:raise SubmissionError('Deployment limit outside the simulated equipment envelope: '+key)
 return dict(schema_passed=True,hardware_validation='not_performed')

def replay(submission,public,manifest,out,seed):
 start=time.monotonic();cell=Cell(out,seed=seed);obs=cell.observe();error=None;calls=0;maximum_response=0.
 with Program(submission,public,manifest['controller']) as worker:
  try:
   while not cell.finished:
    response_start=time.monotonic();action=worker.exchange(obs,60);maximum_response=max(maximum_response,time.monotonic()-response_start);obs=cell.step(action);calls+=1
    if calls>24000:raise SubmissionError('Controller exceeded 24000 I/O responses')
    if time.monotonic()-start>14400:raise SubmissionError('Replay controller exceeded its 14400-second episode deadline')
  except (SubmissionError,CommandError,ValueError,TypeError,KeyError) as exc:error=str(exc)
  finally:
   worker.log.flush();shutil.copyfile(worker.root/'stderr.log',out/'controller-stderr.log')
 cell.save();result=cell.result();result.update(controller_error=error,io_calls=calls,maximum_response_wall_seconds=maximum_response,simulation_seconds=float(cell.d.time),wall_seconds=time.monotonic()-start,seed=seed)
 if error:result['full_pass']=False
 write(out/'result.json',result)
 result['video']=render_video(cell,out)
 write(out/'result.json',result);return result

def main():
 out=Path(os.environ.get('O5_EVALUATION_OUT','/logs/verifier'));out.mkdir(parents=True,exist_ok=True);out.chmod(0o700)
 public=Path(os.environ.get('O5_PUBLIC','/opt/engineering'));source=Path(os.environ.get('O5_SUBMISSION','/logs/artifacts'))
 try:
  manifest,hashes=freeze(source,out/'frozen');write(out/'submission-checkpoint.json',hashes)
  try:docs=documentation(out/'frozen')
  except (ValueError,TypeError,KeyError,IndexError,OverflowError,RecursionError) as exc:raise SubmissionError('Invalid engineering documentation: '+str(exc)) from exc
  native=native_check(out/'frozen',public,manifest,out)
  rows=[]
  for seed in [0,731,902]:
   rows.append(replay(out/'frozen',public,manifest,out/f'episode-{seed}',seed));write(out/'progress.json',dict(completed=len(rows),total=3))
  score=float(np.mean([r['score'] if not r['controller_error'] else 0 for r in rows]));summary=dict(score=score,reward=score/100,ArtifactValidity=1,InfrastructureFailure=0,FullContractPass=int(all(r['full_pass'] for r in rows)),EmpiricalHardwareValidation=0)
  write(out/'report.json',dict(status='completed',contract='o5-nominal-contact-v2',native=native,documentation=docs,episodes=rows,summary=summary));write(out/'reward.json',summary)
 except SubmissionError as exc:
  write(out/'report.json',dict(status='invalid_submission',error=str(exc)));write(out/'reward.json',dict(score=0.,reward=0.,ArtifactValidity=0,InfrastructureFailure=0,FullContractPass=0,EmpiricalHardwareValidation=0))

if __name__=='__main__':
 try:main()
 except Exception:
  out=Path(os.environ.get('O5_EVALUATION_OUT','/logs/verifier'));out.mkdir(parents=True,exist_ok=True);write(out/'task-validity.json',dict(status='evaluation_infrastructure_failure',detail=traceback.format_exc()));raise
