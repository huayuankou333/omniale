import unittest
import numpy as np
from geometry_metrics import inspect_phase, measure


class GeometryTests(unittest.TestCase):
    def setUp(self):
        self.points = [[0,0,0],[.02,0,0],[0,.02,0],[0,0,.04]]
        self.expected = [{'id': 'H1-J1', 'world_from_datum': np.eye(4).tolist(), 'witness_points_m': self.points}]
        self.observation = [{'id': 'H1-J1', 'world_from_datum': np.eye(4).tolist(), 'translation_uncertainty_m': 0, 'orientation_uncertainty_rad': 0}]
        self.limits = {'maximum_lateral_datum_error_m': .0005, 'maximum_axial_engagement_error_m': .0003, 'maximum_orientation_error_rad': np.deg2rad(1), 'maximum_functional_witness_point_error_m': .001}

    def result(self):
        return inspect_phase(self.expected, self.observation, self.limits, 'released')

    def test_exact_alignment_cannot_claim_physical_success(self):
        r=self.result(); self.assertTrue(r['all_parts_geometry_pass']); self.assertIsNone(r['physical_assembly_pass']); self.assertIsNone(r['score'])

    def test_06mm_lateral_must_fail(self):
        self.observation[0]['world_from_datum'][0][3]=.0006
        self.assertFalse(self.result()['all_parts_geometry_pass'])

    def test_short_insertion_must_fail(self):
        self.observation[0]['world_from_datum'][2][3]=.0004
        self.assertFalse(self.result()['all_parts_geometry_pass'])

    def test_uncertainty_consumes_tolerance(self):
        self.observation[0]['world_from_datum'][0][3]=.00045
        self.observation[0]['translation_uncertainty_m']=.0001
        self.assertFalse(self.result()['all_parts_geometry_pass'])

    def test_reversed_key_must_fail(self):
        self.observation[0]['world_from_datum'][0][0]=-1
        self.observation[0]['world_from_datum'][1][1]=-1
        self.assertFalse(self.result()['all_parts_geometry_pass'])

    def test_missing_or_duplicate_parts_rejected(self):
        for observations in ([], self.observation*2):
            with self.assertRaises(ValueError): inspect_phase(self.expected, observations, self.limits, 'released')

    def test_nonfinite_and_affine_scaling_rejected(self):
        for value in (float('nan'), 2):
            self.observation[0]['world_from_datum'][0][0]=value
            with self.assertRaises(ValueError):self.result()

    def test_coordinate_frame_invariance(self):
        actual=np.eye(4);actual[:3,3]=[.0002,.0003,.0001]
        common=np.array([[0,-1,0,3],[1,0,0,-2],[0,0,1,1],[0,0,0,1.]])
        one=measure(actual,np.eye(4),self.points)
        two=measure(common@actual,common,self.points)
        for k in one:self.assertAlmostEqual(one[k],two[k],places=11)

    def test_witness_errors_capture_rotation_about_datum(self):
        angle=np.deg2rad(.9);r=np.eye(4);r[:3,:3]=[[np.cos(angle),0,np.sin(angle)],[0,1,0],[-np.sin(angle),0,np.cos(angle)]]
        points=[[0,0,0],[.02,0,0],[0,.02,0],[0,0,.1]]
        measured=measure(r,np.eye(4),points)
        self.assertEqual(measured['axial_error_m'],0)
        self.assertGreater(measured['maximum_witness_error_m'],.001)


if __name__=='__main__': unittest.main()
