"""Rigid assembly metrology for a trusted inspector, not candidate-trace scoring.

This module measures a single inspected phase. It cannot establish physical grasp,
retention, topology, electrical continuity or trace authenticity.
"""
import math
import numpy as np


def transform(value):
    a = np.asarray(value, dtype=float)
    if a.shape != (4, 4) or not np.isfinite(a).all():
        raise ValueError('A finite 4x4 transform is required')
    r = a[:3, :3]
    if not np.allclose(a[3], [0, 0, 0, 1], atol=1e-9, rtol=0):
        raise ValueError('Invalid homogeneous transform')
    if not np.allclose(r.T @ r, np.eye(3), atol=1e-7, rtol=0) or abs(np.linalg.det(r)-1) > 1e-7:
        raise ValueError('Transform rotation must be in SO(3)')
    return a


def measure(actual, target, witness_points_m, axis_index=2):
    actual, target = transform(actual), transform(target)
    points = np.asarray(witness_points_m, dtype=float)
    if points.ndim != 2 or points.shape[1] != 3 or len(points) < 4 or not np.isfinite(points).all():
        raise ValueError('At least four finite functional witness points are required')
    if np.linalg.matrix_rank(points-points.mean(axis=0), tol=1e-9) < 3:
        raise ValueError('Witness points must span three dimensions')
    if axis_index not in (0, 1, 2):
        raise ValueError('Invalid insertion axis')
    relative = np.linalg.solve(target, actual)
    delta = relative[:3, 3]
    angle = math.acos(float(np.clip((np.trace(relative[:3, :3])-1)/2, -1, 1)))
    moved = (actual[:3, :3] @ points.T).T + actual[:3, 3]
    expected = (target[:3, :3] @ points.T).T + target[:3, 3]
    return {
        'lateral_error_m': float(np.linalg.norm(np.delete(delta, axis_index))),
        'axial_error_m': float(abs(delta[axis_index])),
        'orientation_error_rad': angle,
        'maximum_witness_error_m': float(np.linalg.norm(moved-expected, axis=1).max()),
    }


def inspect_phase(expected_parts, observations, limits, phase):
    """Require every expected part. Uncertainty is provided by trusted metrology."""
    ids = [p['id'] for p in expected_parts]
    if len(ids) != len(set(ids)) or not ids:
        raise ValueError('Expected part IDs must be nonempty and unique')
    observed = [p['id'] for p in observations]
    if len(observed) != len(set(observed)) or set(ids) != set(observed):
        raise ValueError('Every expected part must be inspected exactly once')
    by_id = {p['id']: p for p in observations}
    results = []
    for expected in expected_parts:
        o = by_id[expected['id']]
        result = measure(o['world_from_datum'], expected['world_from_datum'], expected['witness_points_m'], expected.get('axis_index', 2))
        u = float(o['translation_uncertainty_m'])
        a = float(o['orientation_uncertainty_rad'])
        if not math.isfinite(u) or not math.isfinite(a) or u < 0 or a < 0:
            raise ValueError('Uncertainty must be finite and nonnegative')
        radius = max(np.linalg.norm(p) for p in expected['witness_points_m'])
        checks = {
            'lateral': result['lateral_error_m']+u <= limits['maximum_lateral_datum_error_m'],
            'axial': result['axial_error_m']+u <= limits['maximum_axial_engagement_error_m'],
            'orientation': result['orientation_error_rad']+a <= limits['maximum_orientation_error_rad'],
            'witness': result['maximum_witness_error_m']+u+2*radius*math.sin(min(a, math.pi)/2) <= limits['maximum_functional_witness_point_error_m'],
        }
        results.append(dict(id=expected['id'], metrics=result, checks=checks, geometry_pass=all(checks.values())))
    return dict(phase=phase, parts=results, all_parts_geometry_pass=all(r['geometry_pass'] for r in results), physical_assembly_pass=None, score=None)
