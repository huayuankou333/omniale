#!/bin/sh
set -eu
mkdir -p /logs/verifier
chmod 700 /tests /logs/verifier
export PYTHONPATH=/runtime
exec python3 /tests/evaluate_v2.py
