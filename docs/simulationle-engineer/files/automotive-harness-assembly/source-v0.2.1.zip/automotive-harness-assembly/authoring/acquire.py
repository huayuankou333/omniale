"""Retrieve exactly the externally licensed input bytes identified by the manifest."""
import argparse
import hashlib
import json
from pathlib import Path
import urllib.request


def verify(path, record):
    data=path.read_bytes()
    if len(data)!=record['bytes'] or hashlib.sha256(data).hexdigest()!=record['sha256']:
        raise ValueError('Asset integrity failure: '+record['path'])


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,required=True);parser.add_argument('--verify-only',action='store_true');args=parser.parse_args()
    task=Path(__file__).resolve().parents[1]
    manifest=json.loads((task/'asset-sources.json').read_text());root=args.output.resolve();root.mkdir(parents=True,exist_ok=True)
    failures=[];verified=[]
    for r in manifest['records']:
        p=(root/r['path']).resolve()
        if not p.is_relative_to(root) or p==root:raise ValueError('Invalid asset path')
        try:
            if not p.exists() and not args.verify_only:
                request=urllib.request.Request(r['source_url'],headers={'User-Agent':'SimulationLE-O5-asset-acquisition/1.0'})
                with urllib.request.urlopen(request,timeout=60) as response:data=response.read(r['bytes']+1)
                if len(data)!=r['bytes'] or hashlib.sha256(data).hexdigest()!=r['sha256']:raise ValueError('Remote bytes do not match pinned asset')
                p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
            verify(p,r);verified.append(r['path'])
        except (OSError,ValueError) as e:failures.append({'path':r['path'],'error':str(e)})
    result={'verified_files':len(verified),'failures':failures,'complete':not failures}
    (root/'ACQUISITION_RECEIPT.json').write_text(json.dumps(result,indent=2))
    print(json.dumps(result,indent=2));raise SystemExit(1 if failures else 0)


if __name__=='__main__':main()
