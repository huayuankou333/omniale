"""Independent sampled mesh-to-exact-BRep distance audit, millimetres."""
from pathlib import Path
import json,time
import numpy as np
import trimesh
import cadquery as cq
from OCP.BRepBuilderAPI import BRepBuilderAPI_MakeVertex
from OCP.BRepExtrema import BRepExtrema_DistShapeShape
from OCP.gp import gp_Pnt

P=Path('/work'); rows=[]
for folder in sorted((P/'components/connectors').glob('c3d-*')):
    source=P/'upstream/amphenol'/(folder.name+'.stp')
    shape=cq.importers.importStep(str(source)).val()
    mesh=trimesh.load(folder/'surface.obj',force='mesh'); mesh.apply_scale(1000)
    np.random.seed(6081); samples,_=trimesh.sample.sample_surface(mesh,600)
    # Area samples plus triangle centroids from a deterministic stratified subset.
    centers=mesh.triangles_center[np.linspace(0,len(mesh.faces)-1,600,dtype=int)]
    points=np.concatenate([samples,centers])
    dist=[]; start=time.monotonic()
    for p in points:
        v=BRepBuilderAPI_MakeVertex(gp_Pnt(*map(float,p))).Vertex()
        e=BRepExtrema_DistShapeShape(v,shape.wrapped);e.Perform()
        if not e.IsDone():raise RuntimeError('Exact distance failed')
        dist.append(e.Value())
    row=dict(part=folder.name,method='mesh surface to exact OCCT BRep minimum distance',samples=len(points),seed=6081,max_sampled_distance_mm=max(dist),p99_sampled_distance_mm=float(np.quantile(dist,.99)),rms_sampled_distance_mm=float(np.sqrt(np.mean(np.square(dist)))),contact_radius_mm=.02,max_sampled_distance_plus_contact_radius_mm=max(dist)+.02,statistical_check_only=True,global_hausdorff_bound_established=False,wall_seconds=time.monotonic()-start)
    rows.append(row); print(row,flush=True)
    (P/'cad-audit/SURFACE_ERROR.json').write_text(json.dumps(rows,indent=2))
