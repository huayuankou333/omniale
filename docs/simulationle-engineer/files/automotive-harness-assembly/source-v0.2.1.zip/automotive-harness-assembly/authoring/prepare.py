"""Prepare public raw engineering inputs; never import author scene or solutions."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil


def main():
    p=argparse.ArgumentParser();p.add_argument('--sources',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    task=Path(__file__).resolve().parents[1];sources=a.sources.resolve();out=a.output.resolve()
    if out.exists():raise SystemExit('Output must be a new directory')
    manifest=json.loads((task/'asset-sources.json').read_text());verified=[]
    # Validate everything before writing a prepared bundle.
    for record in manifest['records']:
        source=(sources/record['path']).resolve()
        if not source.is_relative_to(sources) or not source.is_file():raise ValueError('Missing/invalid source '+record['path'])
        raw=source.read_bytes()
        if len(raw)!=record['bytes'] or hashlib.sha256(raw).hexdigest()!=record['sha256']:raise ValueError('Source integrity failure '+record['path'])
        verified.append(record)
    shutil.copytree(task/'environment/public',out/'public')
    copied=[]
    for record in verified:
        relative=record['path']
        selected=(relative.startswith(('amphenol/','ur-description/','idb/','menagerie/robotiq_2f85/'))
                  and not relative.endswith(('tree.json','.html')))
        if not selected:continue
        source=sources/relative
        # Retain LFS pointer provenance in the manifest, not as usable engineering geometry.
        if source.read_bytes().startswith(b'version https://git-lfs.github.com/spec/v1'):continue
        destination=out/'public'/'sources'/relative;destination.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,destination);copied.append(record)
    for name in ('SOURCE_POLICY.md','source.json'):
        shutil.copyfile(task/name,out/'public'/name)
    (out/'public/source-records.json').write_text(json.dumps({'records':copied},indent=2))
    receipt={'status':'construction_inputs_only','formal_evaluation_ready':False,'verified_source_files':len(verified),'public_records':copied,'author_reference_included':False,'trusted_runtime_included':False}
    (out/'PREPARATION_RECEIPT.json').write_text(json.dumps(receipt,indent=2))
    print(json.dumps({'public_files':len(copied),'output':str(out),'formal_evaluation_ready':False}))


if __name__=='__main__':main()
