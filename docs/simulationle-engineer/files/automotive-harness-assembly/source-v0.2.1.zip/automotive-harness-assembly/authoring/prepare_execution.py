"""Create a byte-verified O5 execution copy with separate public/trusted inputs."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import tarfile
import tempfile


def digest(path):
    result=hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda:stream.read(1024*1024),b''):result.update(block)
    return result.hexdigest()


def prepare(task,assets,output,load_runtime=False):
    task=task.resolve();assets=assets.resolve();output=output.resolve()
    if output.exists() or output.is_relative_to(task):raise ValueError('Use a new output outside the source task')
    manifest=json.loads((task/'assets.json').read_text())
    records=manifest['execution_archives']
    if any(sum(r['role']==role for r in records)!=1 for role in ['public','target','runtime']):
        raise ValueError('Execution requires exactly one public, target and runtime archive')
    for record in records:
        path=assets/record['name']
        if path.stat().st_size!=record['bytes'] or digest(path)!=record['sha256']:
            raise ValueError('External asset differs: '+record['name'])
    if load_runtime:
        runtime=next(r for r in records if r['role']=='runtime')
        subprocess.run(['docker','load','-i',str(assets/runtime['name'])],check=True)
        images=manifest.get('runtime_images',[dict(name=manifest['image_name'],id=manifest['image_id'])])
        for image in images:
            identifier=subprocess.check_output(['docker','image','inspect','--format','{{.Id}}',image['id']],text=True).strip()
            if identifier!=image['id']:raise ValueError('Loaded runtime image differs: '+image['name'])
            subprocess.run(['docker','tag',image['id'],image['name']],check=True)
    with tempfile.TemporaryDirectory(prefix='o5-assets-') as temporary:
        extracted=Path(temporary)
        for record in records:
            if record['role']=='runtime':continue
            with tarfile.open(assets/record['name']) as archive:
                if any(m.issym() or m.islnk() or not (m.isfile() or m.isdir()) for m in archive.getmembers()):
                    raise ValueError('Execution archives must contain only regular files and directories')
                archive.extractall(extracted,filter='data')
        if not all((extracted/p).is_dir() for p in ['public','target/components']):
            raise ValueError('Execution archives need public and target/components')
        shutil.copytree(task,output,ignore=shutil.ignore_patterns('__pycache__','material','target','assets'))
        shutil.copytree(extracted/'public',output/'environment/material')
        shutil.copytree(task/'environment/public',output/'environment/material',dirs_exist_ok=True)
        shutil.copytree(extracted/'target',output/'environment/target')
        shutil.copytree(task/'tests',output/'environment/verifier-tests',
                        ignore=shutil.ignore_patterns('__pycache__'))
        shutil.copyfile(task/'instruction.md',output/'environment/material/instruction.md')
        for name in ['SOURCE_POLICY.md','source.json']:
            shutil.copyfile(task/name,output/'environment/material'/name)
        for role in ['reference','qualification']:
            destination=output/'solution/reference' if role=='reference' else output/'authoring/qualification'
            if (extracted/role).is_dir():shutil.copytree(extracted/role,destination)
    receipt=dict(schema_version=2,contract='o5-nominal-contact-v2',archives=records,
                 runtime_image=manifest['image_id'],
                 runtime_images=manifest.get('runtime_images',[]),
                 source_files={str(p.relative_to(task)):digest(p) for p in sorted(task.rglob('*')) if p.is_file() and '__pycache__' not in p.parts},
                 public_files={str(p.relative_to(output/'environment/material')):digest(p) for p in sorted((output/'environment/material').rglob('*')) if p.is_file()},
                 target_files={str(p.relative_to(output/'environment/target')):digest(p) for p in sorted((output/'environment/target').rglob('*')) if p.is_file()},
                 verifier_files={str(p.relative_to(output/'environment/verifier-tests')):digest(p) for p in sorted((output/'environment/verifier-tests').rglob('*')) if p.is_file()},
                 runtime_files={str(p.relative_to(output/'environment/runtime')):digest(p) for p in sorted((output/'environment/runtime').rglob('*')) if p.is_file()},
                 author_reference_qualified=manifest.get('validated_reference_available',False),hardware_validated=False)
    (output/'PREPARED.json').write_text(json.dumps(receipt,indent=2)+'\n')
    return receipt


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--task',type=Path,default=Path(__file__).resolve().parents[1])
    parser.add_argument('--assets',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--load-runtime',action='store_true')
    args=parser.parse_args();receipt=prepare(args.task,args.assets,args.output,args.load_runtime)
    print(json.dumps(dict(output=str(args.output),public_files=len(receipt['public_files']),author_reference_qualified=receipt['author_reference_qualified'])))
