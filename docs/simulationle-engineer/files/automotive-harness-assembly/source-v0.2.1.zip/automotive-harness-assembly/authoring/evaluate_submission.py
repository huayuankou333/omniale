"""Freeze a finished O5 submission and run the independent three-episode evaluator.

This Linux/Docker host command makes no model requests. It uses a prepared task,
copies the submission into a new container, and collects verifier-owned evidence.
It does not qualify the author's reference or claim hardware validation.
"""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import stat
import subprocess
import time
import uuid


def digest(path):
    result = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            result.update(block)
    return result.hexdigest()


def write(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')


def verify_inventory(root, records, label):
    files = {}
    for path in root.rglob('*'):
        if path.is_symlink():
            raise ValueError('Linked prepared ' + label + ' input')
        if path.is_file():
            files[path.relative_to(root).as_posix()] = digest(path)
    expected = {Path(name).as_posix(): value for name, value in records.items()}
    if files != expected:
        raise ValueError('Prepared ' + label + ' inventory differs; reprepare the task')


def snapshot(source, destination):
    if source.is_symlink() or not source.is_dir():
        raise ValueError('Submission must be a regular directory')
    destination.mkdir()
    total = 0
    records = {}
    for path in sorted(source.rglob('*')):
        relative = path.relative_to(source)
        mode = path.lstat()
        target = destination / relative
        if stat.S_ISDIR(mode.st_mode):
            target.mkdir(exist_ok=True)
            continue
        if not stat.S_ISREG(mode.st_mode) or mode.st_nlink != 1:
            raise ValueError('Submission accepts only regular, non-linked files')
        total += mode.st_size
        if total > 200_000_000 or len(records) >= 2000:
            raise ValueError('Submission exceeds 200 MB / 2000 files')
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(path, target)
        target.chmod(0o555 if mode.st_mode & 0o111 else 0o444)
        records[relative.as_posix()] = digest(target)
    return records


def evaluate(prepared, submission, output):
    prepared = prepared.resolve()
    # Check the supplied path before resolve, so a linked root is rejected too.
    if submission.is_symlink():
        raise ValueError('Submission root cannot be a symbolic link')
    submission = submission.resolve()
    output = output.resolve()
    if output.exists() or output.is_relative_to(submission) or output.is_relative_to(prepared):
        raise ValueError('Use a new output directory outside the task and submission')
    provenance = json.loads((prepared / 'PREPARED.json').read_text())
    if provenance.get('contract') != 'o5-nominal-contact-v2':
        raise ValueError('A prepared O5 nominal-contact-v2 task is required')
    # The build must use the exact source/public bytes recorded by preparation.
    for relative, expected in provenance['source_files'].items():
        path = prepared / relative
        if not path.is_file() or path.is_symlink() or digest(path) != expected:
            raise ValueError('Prepared source differs: ' + relative)
    verify_inventory(prepared / 'environment/material', provenance['public_files'], 'public')
    # Trusted converted geometry has its own preparation inventory.
    if not provenance.get('target_files'):
        raise ValueError('Reprepare this task to record trusted target file hashes')
    verify_inventory(prepared / 'environment/target', provenance['target_files'], 'target')
    if not provenance.get('verifier_files'):
        raise ValueError('Reprepare this task to record independent verifier hashes')
    verify_inventory(prepared / 'environment/verifier-tests', provenance['verifier_files'], 'verifier')
    if not provenance.get('runtime_files'):
        raise ValueError('Reprepare this task to record trusted runtime file hashes')
    verify_inventory(prepared / 'environment/runtime', provenance['runtime_files'], 'runtime')
    images = provenance['runtime_images']
    verifier = next(image for image in images if image['name'] == 'simulationle-o5-verifier:nominal-v2')
    output.mkdir(parents=True)
    output.chmod(0o700)
    hashes = snapshot(submission, output / 'frozen-submission')
    identifier = uuid.uuid4().hex[:16]
    image_name = 'simulationle-o5-submission-eval:' + identifier
    container = 'sle-o5-submission-eval-' + identifier
    receipt = dict(schema_version=1, contract=provenance['contract'],
        status='building', paid_model_calls=False,
        author_reference_qualified=provenance.get('author_reference_qualified', False),
        hardware_validation='not_performed', submission_files=hashes,
        preparation_sha256=digest(prepared / 'PREPARED.json'),
        verifier_base_image=verifier, container=container,
        resources=dict(cpus=4, memory_bytes=8 * 1024**3, network='none'),
        episode_seeds=[0, 731, 902], verifier_wall_limit_s=45000)
    write(output / 'EXECUTION.json', receipt)
    created = False
    base_aliases = {}
    started = time.monotonic()
    try:
        # BuildKit interprets a bare sha256 image ID in FROM as a registry
        # repository/tag. Give each verified local ID a private build alias.
        # Inspect the aliases again after the build and remove only our tags.
        for role, expected in [('clean', provenance['runtime_image']),
                               ('verifier', verifier['id'])]:
            actual = subprocess.check_output(['docker', 'image', 'inspect',
                '--format', '{{.Id}}', expected], text=True).strip()
            if actual != expected:
                raise RuntimeError('Local runtime image differs: ' + role)
            alias = 'simulationle-o5-frozen-base:' + identifier + '-' + role
            subprocess.run(['docker', 'tag', expected, alias], check=True)
            base_aliases[alias] = expected
        receipt['build_base_aliases'] = base_aliases
        write(output / 'EXECUTION.json', receipt)
        with (output / 'build.log').open('wb') as log:
            subprocess.run(['docker', 'build', '--pull=false', '--network', 'none',
                '--target', 'verifier', '--build-arg',
                'O5_CLEAN_RUNTIME=simulationle-o5-frozen-base:' + identifier + '-clean',
                '--build-arg',
                'O5_VERIFIER_RUNTIME=simulationle-o5-frozen-base:' + identifier + '-verifier',
                '-t', image_name, str(prepared / 'environment')],
                stdout=log, stderr=subprocess.STDOUT, timeout=1800, check=True)
        for alias, expected in base_aliases.items():
            actual = subprocess.check_output(['docker', 'image', 'inspect',
                '--format', '{{.Id}}', alias], text=True).strip()
            if actual != expected:
                raise RuntimeError('Build runtime image alias changed: ' + alias)
        image_id = subprocess.check_output(['docker', 'image', 'inspect', '--format', '{{.Id}}', image_name], text=True).strip()
        subprocess.run(['docker', 'create', '--name', container, '--network', 'none',
            '--cpus', '4', '--memory', '8g', '--memory-swap', '8g', '--pids-limit', '128',
            '--security-opt', 'no-new-privileges:true', '--cap-drop', 'ALL',
            '--cap-add', 'SETUID', '--cap-add', 'SETGID', '--cap-add', 'KILL',
            '--cap-add', 'CHOWN', '--cap-add', 'DAC_OVERRIDE', '--cap-add', 'FOWNER',
            image_name, 'sleep', 'infinity'], check=True, stdout=subprocess.DEVNULL)
        created = True
        subprocess.run(['docker', 'start', container], check=True, stdout=subprocess.DEVNULL)
        subprocess.run(['docker', 'exec', container, 'mkdir', '-p', '/logs/artifacts'], check=True)
        subprocess.run(['docker', 'cp', str(output / 'frozen-submission') + '/.',
                        container + ':/logs/artifacts'], check=True)
        inspect = json.loads(subprocess.check_output(['docker', 'inspect', container], text=True))[0]
        if inspect['Mounts'] or inspect['HostConfig']['NetworkMode'] != 'none':
            raise RuntimeError('Independent evaluator must have no host mounts or network')
        receipt.update(status='evaluating', image_id=image_id, author_workspace_mount=False)
        write(output / 'EXECUTION.json', receipt)
        with (output / 'verifier.log').open('wb') as log:
            process = subprocess.run(['docker', 'exec', container, 'sh', '/tests/test.sh'],
                stdout=log, stderr=subprocess.STDOUT, timeout=45000)
        receipt['verifier_returncode'] = process.returncode
        subprocess.run(['docker', 'cp', container + ':/logs/verifier', str(output / 'verifier')], check=True)
        frozen = json.loads((output / 'verifier/submission-checkpoint.json').read_text()) if (output / 'verifier/submission-checkpoint.json').is_file() else None
        if frozen is not None and frozen != hashes:
            raise RuntimeError('Verifier submission differs from the host snapshot')
        if process.returncode:
            raise RuntimeError('Independent verifier failed; inspect verifier.log and verifier evidence')
        report = json.loads((output / 'verifier/report.json').read_text())
        receipt['reward'] = json.loads((output / 'verifier/reward.json').read_text())
        if report.get('status') not in ('completed', 'invalid_submission'):
            raise RuntimeError('Independent verifier did not produce a completed result')
        if receipt['reward'].get('ArtifactValidity') == 1 and frozen is None:
            raise RuntimeError('Valid submission result has no independent freeze receipt')
        receipt['status'] = 'completed'
        return receipt
    except BaseException as exc:
        receipt.update(status='evaluation_failed', InfrastructureFailure=1,
                       error=type(exc).__name__ + ': ' + str(exc))
        raise
    finally:
        if created:
            # Stop the isolated worker before collecting partial evidence.
            subprocess.run(['docker', 'stop', '-t', '1', container], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            if not (output / 'verifier').exists():
                subprocess.run(['docker', 'cp', container + ':/logs/verifier', str(output / 'verifier')], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            subprocess.run(['docker', 'rm', '-f', container], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        for alias in base_aliases:
            subprocess.run(['docker', 'image', 'rm', '--no-prune', alias],
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        receipt['wall_seconds'] = time.monotonic() - started
        write(output / 'EXECUTION.json', receipt)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--prepared', type=Path, required=True)
    parser.add_argument('--submission', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    result = evaluate(args.prepared, args.submission, args.output)
    print(json.dumps(dict(status=result['status'], evidence=str(args.output.resolve()),
                          reward=result.get('reward'), paid_model_calls=False)))
