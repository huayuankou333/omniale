"""Measure and tessellate original STEP in its native millimetre coordinates."""
from pathlib import Path
import hashlib
import json
import cadquery as cq
import numpy as np
import trimesh

ROOT = Path('/work')
OUT = ROOT / 'cad-audit'
OUT.mkdir(exist_ok=True)
report = []
files = sorted((ROOT/'upstream/amphenol').glob('*.stp'))
files += sorted((ROOT/'upstream/idb/resolved/automotive-cable-harness/source').glob('*.step'))
for path in files:
    statements = [''.join(s.split()) for s in path.read_text().split(';') if 'LENGTH_UNIT' in s]
    if not statements or any('SI_UNIT(.MILLI.,.METRE.)' not in s for s in statements):
        raise ValueError('Source length units require explicit review: '+str(path))
    assembly = cq.importers.importStep(str(path))
    shapes = assembly.vals()
    shape = cq.Compound.makeCompound(shapes)
    box = shape.BoundingBox()
    solids = shape.Solids()
    name = path.stem
    folder = OUT / name
    folder.mkdir(exist_ok=True)
    v, f = shape.tessellate(0.01, 0.08)
    mesh = trimesh.Trimesh(vertices=np.array([p.toTuple() for p in v]), faces=f, process=True)
    mesh.export(folder/'surface-mm.ply')
    mesh_m = mesh.copy(); mesh_m.apply_scale(0.001); mesh_m.export(folder/'visual.obj')
    parts = []
    for i, solid in enumerate(solids):
        b = solid.BoundingBox()
        vs, fs = solid.tessellate(0.01, 0.08)
        m = trimesh.Trimesh(vertices=np.array([p.toTuple() for p in vs]), faces=fs, process=True)
        m.export(folder/f'solid-{i:02d}-mm.ply')
        parts.append(dict(index=i,valid=solid.isValid(),volume_mm3=solid.Volume(),center_mm=solid.Center().toTuple(),bounds_mm=[[b.xmin,b.ymin,b.zmin],[b.xmax,b.ymax,b.zmax]],triangles=len(m.faces),watertight=m.is_watertight))
    row=dict(source=str(path.relative_to(ROOT)),sha256=hashlib.sha256(path.read_bytes()).hexdigest(),native_units='mm',valid=shape.isValid(),solid_count=len(solids),bounds_mm=[[box.xmin,box.ymin,box.zmin],[box.xmax,box.ymax,box.zmax]],extent_mm=[box.xlen,box.ylen,box.zlen],volume_mm3=shape.Volume(),tessellation_requested_mm=.01,angular_tolerance_rad=.08,triangles=len(mesh.faces),parts=parts)
    report.append(row)
    print(json.dumps({k:row[k] for k in ('source','valid','solid_count','extent_mm','volume_mm3','triangles')}),flush=True)
(OUT/'CAD_AUDIT.json').write_text(json.dumps(report,indent=2)+'\n')
