"""Asset integration preview. Visual-only parts are intentionally not an evaluator."""
from pathlib import Path
import copy
import xml.etree.ElementTree as ET
import mujoco
import numpy as np
from PIL import Image, ImageDraw

P=Path('/work');C=P/'components';OUT=P/'scene-preview';OUT.mkdir(exist_ok=True)
root=ET.Element('mujoco',model='O5 sourced automotive assembly cell - geometry preview')
ET.SubElement(root,'compiler',angle='radian',autolimits='true')
ET.SubElement(root,'option',timestep='.001',integrator='implicitfast',cone='elliptic',impratio='10')
vis=ET.SubElement(root,'visual');ET.SubElement(vis,'global',offwidth='1440',offheight='1080');ET.SubElement(vis,'headlight',ambient='.3 .3 .3')
asset=ET.SubElement(root,'asset');world=ET.SubElement(root,'worldbody')
ET.SubElement(world,'light',pos='0 -1 2',dir='0 .3 -1')
ET.SubElement(world,'geom',name='floor',type='plane',size='2 2 .1',rgba='.15 .17 .2 1')
ET.SubElement(world,'geom',name='table',type='box',pos='0 .15 .6',size='.68 .48 .025',rgba='.3 .34 .4 1')
refs={'name','class','childclass','mesh','material','joint','joint1','joint2','body1','body2','geom1','geom2','site','tendon'}
for prefix,x,quat in [('left',-.48,'1 0 0 0'),('right',.48,'0 0 0 1')]:
    robot=ET.parse(C/'ur5e-2f85.xml').getroot()
    for mesh in robot.find('asset').findall('mesh'):mesh.set('file',str(C/'robot-assets'/mesh.get('file')))
    for node in robot.iter():
        for k in refs:
            if k in node.attrib:node.set(k,prefix+'_'+node.get(k))
    for tag in ('asset','default','contact','tendon','equality','actuator','sensor'):
        source=robot.find(tag)
        if source is None:continue
        target=root.find(tag)
        if target is None:target=ET.SubElement(root,tag)
        for node in source:target.append(copy.deepcopy(node))
    arm=copy.deepcopy(robot.find('worldbody/body'));arm.set('pos',f'{x} -.20 .625');arm.set('quat',quat);world.append(arm)
panel=P/'cad-audit/base-panel/visual.obj'
ET.SubElement(asset,'mesh',name='idb_panel',file=str(panel))
ET.SubElement(world,'geom',name='source_panel_visual',type='mesh',mesh='idb_panel',pos='0 .22 .625',quat='.707106781 .707106781 0 0',contype='0',conaffinity='0',rgba='.8 .82 .84 1')
positions=[(-.15,.16,'2'),(.15,.16,'2'),(.15,.35,'2'),(-.15,.35,'6')]
for i,(x,y,n) in enumerate(positions):
    for moving in (False,True):
        part=f'c3d-at{6 if moving else 4:02d}-{n}{"s" if moving else "p"}-01-000'
        name=f'part_{i}_{int(moving)}'
        ET.SubElement(asset,'mesh',name=name,file=str(P/'cad-audit'/part/'visual.obj'))
        # These locations are for inspection only; no successful mating is asserted.
        ET.SubElement(world,'geom',name=name,type='mesh',mesh=name,pos=f'{x if not moving else x-.055} {y} .66',quat='.707106781 .707106781 0 0',contype='0',conaffinity='0',rgba='.2 .4 .7 1' if moving else '.75 .65 .25 1')
ET.ElementTree(root).write(OUT/'scene.xml',encoding='unicode')
m=mujoco.MjModel.from_xml_path(str(OUT/'scene.xml'));d=mujoco.MjData(m)
jointnames=['shoulder_pan_joint','shoulder_lift_joint','elbow_joint','wrist_1_joint','wrist_2_joint','wrist_3_joint']
for prefix,q in [('left',[3.0,-1.8,1.8,-1.55,-1.57,0]),('right',[3.0,-1.8,1.8,-1.55,-1.57,0])]:
    for name,v in zip(jointnames,q):d.joint(prefix+'_'+name).qpos[0]=v;d.ctrl[m.actuator(prefix+'_'+name+'_servo').id]=v
mujoco.mj_forward(m,d)
r=mujoco.Renderer(m,1080,1440);cam=mujoco.MjvCamera();cam.lookat[:]=[0,.18,.85];cam.distance=2.0;cam.azimuth=120;cam.elevation=-30
r.update_scene(d,camera=cam);im=Image.fromarray(r.render());draw=ImageDraw.Draw(im);draw.rectangle((0,0,1440,44),fill=(10,15,20));draw.text((20,15),'O5 | Manufacturer UR5e + sourced Robotiq / Amphenol CAD | Geometry integration preview - not an assembly result',fill='white');im.save(OUT/'overview.png');r.close()
print('compiled geometry preview',m.nbody,m.ngeom,flush=True)
