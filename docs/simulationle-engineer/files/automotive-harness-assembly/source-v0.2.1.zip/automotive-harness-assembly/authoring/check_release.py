"""Verify the complete nominal qualification receipt and its evidence bytes."""
import argparse
import hashlib
import json
from pathlib import Path


def digest(path):
    result = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            result.update(block)
    return result.hexdigest()


def check_release(task, receipt_path):
    task = task.resolve()
    receipt_path = receipt_path.resolve()
    plan = json.loads((task / 'authoring/qualification-plan.json').read_text())
    receipt = json.loads(receipt_path.read_text())
    if receipt.get('contract') != plan['contract']:
        raise ValueError('Qualification contract differs')
    if receipt.get('hardware_validation') != 'not_performed':
        raise ValueError('This nominal case has no hardware validation evidence')
    if receipt.get('status') != 'passed':
        raise ValueError('Qualification has not passed')
    gates = receipt.get('gates', {})
    if set(gates) != set(plan['required_gates']):
        raise ValueError('Qualification must contain every required gate exactly once')
    checked = set()
    for name in plan['required_gates']:
        gate = gates[name]
        if gate.get('status') != 'passed' or not gate.get('evidence'):
            raise ValueError('Unqualified gate: ' + name)
        for item in gate['evidence']:
            relative = Path(item['path'])
            path = (receipt_path.parent / relative).resolve()
            if relative.is_absolute() or not path.is_relative_to(receipt_path.parent):
                raise ValueError('Evidence must remain inside the qualification bundle')
            if not path.is_file() or path.is_symlink():
                raise ValueError('Missing regular evidence: ' + item['path'])
            if path.stat().st_size != item['bytes'] or digest(path) != item['sha256']:
                raise ValueError('Evidence differs: ' + item['path'])
            checked.add(path)
    episodes = receipt.get('reference_episodes', [])
    if len(episodes) != 3 or {e.get('seed') for e in episodes} != {0, 731, 902}:
        raise ValueError('Require the three specified fresh reference episodes')
    for episode in episodes:
        path = (receipt_path.parent / episode['result']).resolve()
        if path not in checked:
            raise ValueError('Reference result must be hashed gate evidence')
        result = json.loads(path.read_text())
        if (result.get('seed') != episode['seed'] or not result.get('full_pass')
                or result.get('controller_error') or result.get('violations')
                or result.get('checkpoint_counts') != [8, 8, 8, 8]
                or result.get('wall_seconds', float('inf')) > 14400
                or result.get('simulation_seconds', float('inf')) > 600):
            raise ValueError('Complete reference failed: ' + str(episode['seed']))
    return dict(status='passed', gates=len(gates), evidence_files=len(checked),
                reference_seeds=[0, 731, 902], hardware_validation='not_performed')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--task', type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument('--receipt', type=Path, required=True)
    args = parser.parse_args()
    print(json.dumps(check_release(args.task, args.receipt)))
