"""Host-side boundary checks; these do not qualify physical assembly."""
import importlib.util
import os
from pathlib import Path
import tempfile
import unittest


spec = importlib.util.spec_from_file_location(
    'o5_host_evaluator', Path(__file__).with_name('evaluate_submission.py'))
evaluator = importlib.util.module_from_spec(spec)
spec.loader.exec_module(evaluator)


class EvaluationBoundaryTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        self.source = self.root / 'submission'
        self.source.mkdir()
        (self.source / 'controller.py').write_bytes(b'print("frozen")\n')

    def test_source_changes_do_not_change_frozen_submission(self):
        destination = self.root / 'frozen'
        hashes = evaluator.snapshot(self.source, destination)
        (self.source / 'controller.py').write_bytes(b'print("changed")\n')
        self.assertEqual((destination / 'controller.py').read_bytes(), b'print("frozen")\n')
        self.assertEqual(hashes['controller.py'], evaluator.digest(destination / 'controller.py'))

    def test_hardlinked_artifact_is_rejected(self):
        os.link(self.source / 'controller.py', self.source / 'alias.py')
        with self.assertRaisesRegex(ValueError, 'non-linked'):
            evaluator.snapshot(self.source, self.root / 'frozen')

    def test_symbolic_linked_directory_is_rejected(self):
        external = self.root / 'external'
        external.mkdir()
        (external / 'hidden.py').write_bytes(b'pass\n')
        (self.source / 'linked').symlink_to(external, target_is_directory=True)
        with self.assertRaisesRegex(ValueError, 'non-linked'):
            evaluator.snapshot(self.source, self.root / 'frozen')

    def test_extra_trusted_module_is_rejected(self):
        records = {'controller.py': evaluator.digest(self.source / 'controller.py')}
        (self.source / 'sitecustomize.py').write_bytes(b'pass\n')
        with self.assertRaisesRegex(ValueError, 'inventory differs'):
            evaluator.verify_inventory(self.source, records, 'runtime')

    def test_modified_trusted_module_is_rejected(self):
        records = {'controller.py': evaluator.digest(self.source / 'controller.py')}
        (self.source / 'controller.py').write_bytes(b'pass\n')
        with self.assertRaisesRegex(ValueError, 'inventory differs'):
            evaluator.verify_inventory(self.source, records, 'runtime')


if __name__ == '__main__':
    unittest.main()
