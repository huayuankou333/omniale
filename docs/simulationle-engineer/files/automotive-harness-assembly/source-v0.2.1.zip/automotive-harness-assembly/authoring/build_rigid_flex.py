"""Retain source CAD cavities as rigid flex surfaces; no filled convex hulls."""
from pathlib import Path
import json, time, hashlib
import numpy as np
import cadquery as cq
import trimesh
import mujoco
import xml.etree.ElementTree as E

P=Path('/work'); OUT=P/'components/connectors'; OUT.mkdir(parents=True,exist_ok=True)
records=[]
for number in (2,6):
    for side,letter in ((4,'p'),(6,'s')):
        part=f'c3d-at{side:02}-{number}{letter}-01-000'
        source=P/'upstream/amphenol'/f'{part}.stp'
        shape=cq.importers.importStep(str(source)).val()
        v,f=shape.tessellate(.025,.35)
        mesh=trimesh.Trimesh(np.round(np.array([x.toTuple() for x in v]),4)*.001,f,process=True)
        mesh.update_faces(mesh.nondegenerate_faces()); mesh.update_faces(mesh.unique_faces()); mesh.remove_unreferenced_vertices(); mesh.fix_normals(multibody=True)
        target=OUT/part; target.mkdir(exist_ok=True); mesh.export(target/'surface.obj')
        root=E.Element('mujoco',model=part)
        E.SubElement(root,'option',gravity='0 0 0',timestep='.0005',integrator='implicitfast')
        world=E.SubElement(root,'worldbody'); body=E.SubElement(world,'body',name='component')
        E.SubElement(body,'freejoint',name='component_free')
        # Density is a declared construction assumption, not a supplier mass measurement.
        volume=abs(mesh.volume); mass=volume*1200
        inertia=mesh.moment_inertia*1200
        E.SubElement(body,'inertial',pos=' '.join(map(str,mesh.center_mass)),mass=str(mass),fullinertia=' '.join(map(str,[inertia[0,0],inertia[1,1],inertia[2,2],inertia[0,1],inertia[0,2],inertia[1,2]])))
        deform=E.SubElement(root,'deformable')
        flex=E.SubElement(deform,'flex',name='component_surface',body='component',dim='2',radius='.00002',vertex=' '.join(f'{a:.9g}' for a in mesh.vertices.flatten()),element=' '.join(map(str,mesh.faces.flatten())),rgba='.45 .48 .5 1')
        E.SubElement(flex,'contact',selfcollide='none',internal='false',contype='1',conaffinity='1',condim='3',friction='.4 .005 .0001',solref='.002 1',solimp='.95 .99 .0001')
        E.ElementTree(root).write(target/'component.xml',encoding='unicode')
        start=time.monotonic(); model=mujoco.MjModel.from_xml_path(str(target/'component.xml')); data=mujoco.MjData(model)
        mujoco.mj_step(model,data,nstep=100)
        record=dict(part=part,source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),vertices=len(mesh.vertices),triangles=len(mesh.faces),watertight=bool(mesh.is_watertight),tessellation_requested_mm=.025,vertex_rounding_mm=.0001,surface_radius_mm=.02,collision_method='rigid flex: actual triangles, no convexification',nflex=model.nflex,nq=model.nq,finite=bool(np.isfinite(data.qpos).all()),compile_and_100step_wall_seconds=time.monotonic()-start,mass_kg=mass,mass_basis='assumed homogeneous density 1200 kg/m3; uncalibrated',contact_basis='provisional rigid shell; merged seals/latch are NOT validated',independent_surface_deviation_mm=None)
        (target/'receipt.json').write_text(json.dumps(record,indent=2)); records.append(record); print(record,flush=True)
(OUT/'CONNECTOR_AUDIT.json').write_text(json.dumps(records,indent=2))
