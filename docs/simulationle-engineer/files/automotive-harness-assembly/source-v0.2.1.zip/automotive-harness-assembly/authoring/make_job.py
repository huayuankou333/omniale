"""Build a Harbor job with O5's fixed development and replay budgets."""
import argparse
import json
from pathlib import Path
import tomllib


def make_job(prepared, settings, jobs_dir, name='o5'):
    prepared = prepared.resolve()
    task = tomllib.loads((prepared / 'task.toml').read_text())
    metadata = task['metadata']
    if (metadata['contract_version'] != 'o5-nominal-contact-v2'
            or metadata['model_decision_turns'] != 500
            or metadata['development_wall_seconds'] != 7200
            or task['agent']['timeout_sec'] != 7200
            or task['verifier']['timeout_sec'] != 45000
            or task['environment']['network_mode'] != 'no-network'
            or task['verifier']['environment_mode'] != 'separate'):
        raise ValueError('Prepared task differs from the O5 execution contract')
    if set(settings) != {'model_name', 'model_config'}:
        raise ValueError('Model settings must contain only model_name and model_config; credentials belong in the host environment')
    if not isinstance(settings['model_name'], str) or not settings['model_name'].strip():
        raise ValueError('An explicit deployed model name is required')
    if not isinstance(settings['model_config'], dict) or not settings['model_config']:
        raise ValueError('Supply the deployed model capabilities as model_config')
    return dict(job_name=name, jobs_dir=str(jobs_dir.resolve()),
        n_concurrent_trials=1, n_attempts=1, retry=dict(max_retries=0),
        environment=dict(type='docker'), tasks=[dict(path=str(prepared))],
        agents=[dict(import_path='harness.agent:PiAgent',
            model_name=settings['model_name'], override_timeout_sec=7200,
            max_timeout_sec=7200,
            kwargs=dict(max_turns=500, model_config=settings['model_config']))],
        verifier={})


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--prepared', type=Path, required=True)
    parser.add_argument('--model-settings', type=Path, required=True,
                        help='Host JSON containing model_name and model_config; no credentials')
    parser.add_argument('--jobs-dir', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--name', default='o5')
    args = parser.parse_args()
    config = make_job(args.prepared, json.loads(args.model_settings.read_text()),
                      args.jobs_dir, args.name)
    from harbor.models.job.config import JobConfig
    JobConfig.model_validate(config)
    with args.output.open('x') as stream:
        stream.write(json.dumps(config, indent=2) + '\n')
    print(json.dumps(dict(output=str(args.output.resolve()), model_decisions=500,
                          development_wall_seconds=7200, model_calls_started=False)))
