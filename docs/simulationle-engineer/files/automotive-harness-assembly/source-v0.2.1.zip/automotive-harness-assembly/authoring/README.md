# O5 asset conversion and qualification

Use `acquire.py --output /assets/o5-upstream` to retrieve the pinned source bytes. `--verify-only` checks a provisioned source directory without network access. Source licenses and supplier permissions remain applicable; retrieval is not a redistribution grant.

Run conversion programs in the separately provisioned O5 author image, mounting an author workspace at `/work` with the source tree at `/work/upstream`. `build_robot.py` preserves manufacturer kinematics and checks serialized MJCF against an independent URDF transform chain. `compose_robot.py` adds the sourced gripper and explicitly assumed simulation servos. `inspect_cad.py` imports source STEP and records units and solids. `build_rigid_flex.py` keeps concave connector surfaces as rigid MuJoCo flex triangles; merged latch/seal geometry remains uncalibrated. `measure_surface_error.py` measures sampled distances from the mesh to exact OCCT surfaces; it does not certify a global Hausdorff bound.

`build_scene_preview.py` is a geometry preview only. Its disabled visual contacts are not the deployed cell and cannot supply acceptance evidence. The deployed native backend is in `environment/runtime/`; its source contact components and actual fixture CAD are provisioned separately. Rig characterizations and validation traces belong in external evidence bundles. The author reference is intentionally omitted, and historical manipulation probes are not reference solutions.

Prepare candidate raw inputs with:

```sh
python authoring/prepare.py --sources /assets/o5-upstream --output /runs/o5-inputs
```

This acquisition output includes raw source geometry and engineering documents. It excludes converted author models, reference strategies, hidden data and the rejected Menagerie UR5e approximation. For execution, use `prepare_execution.py` with the exact `execution_archives` in `assets.json`. It constructs a fresh task outside the checkout, verifies archive lengths and digests, places raw sources/drawings in `environment/material` and trusted components in `environment/target`. Reference and private qualification archives are optional; neither is included in the current execution manifest. Large payloads stay outside the release checkout.

`Dockerfile.native` produces a clean scientific runtime from an independently provisioned author dependency image and Python OS image. Record their exact image identities and the resulting package versions before distribution. The current software stack is Python, MuJoCo 3.5, CadQuery 2.6.1/OpenCASCADE, NumPy, SciPy, trimesh, xacro and pycollada. ROS 2, Isaac Sim and Gazebo are not part of the demonstrated runtime. A real robot driver adapter remains a hardware commissioning deliverable.

Submission evaluation uses `evaluate_submission.py` after preparation and does not require an author reference or a full qualification receipt. To check an optional complete nominal qualification claim, the separate evidence plan is `qualification-plan.json`:

```sh
python authoring/check_release.py --receipt /validation/o5/qualification.json
```

A failed or missing gate blocks that complete qualification claim, while model submissions can still be evaluated. Attach file paths and SHA-256 evidence to passed gates. `check_release.py` verifies receipt integrity and completeness; engineering review must still establish that each record proves its claim. The optional full claim includes three fresh complete reference episodes in the same isolated controller boundary used for submitted models. Those episodes are not available and no complete qualification is claimed. The verifier must never mount the author workspace.

The qualification scope is the declared nominal simulation. No connector samples, insertion/withdrawal curves, wire tests or serial-specific robot calibration are available. The gates listed for the optional full claim characterize and test the stated assumptions; they do not mark missing hardware measurements as passed. Complete-task feasibility and complete-cell numerical convergence remain unverified. `hardware_validation` remains `not_performed`. Physical driver integration, measured constitutive identification, fixture inspection and pilot assembly remain prerequisites for hardware transfer. Independent model difficulty and the adequacy of exploration time require separate experiments.
