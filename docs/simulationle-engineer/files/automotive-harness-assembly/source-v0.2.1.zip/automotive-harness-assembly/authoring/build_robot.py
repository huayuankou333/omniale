"""Convert the pinned manufacturer's URDF, retaining its kinematics/inertias."""
from pathlib import Path
import copy
import hashlib
import json
import shutil
import xml.etree.ElementTree as ET
import mujoco
import numpy as np
import trimesh
import xacro
from scipy.spatial.transform import Rotation

ROOT = Path('/work')
UP = ROOT/'upstream/ur-description'
OUT = ROOT/'robot-audit'
OUT.mkdir(exist_ok=True)
derived = OUT/'ur-description'
shutil.copytree(UP, derived, dirs_exist_ok=True)
for path in (derived/'urdf').rglob('*.xacro'):
    path.write_text(path.read_text().replace('$(find ur_description)', str(derived)).replace("$(find ${visual_params['mesh']['package']})", str(derived)))
doc = xacro.process_file(str(derived/'urdf/ur.urdf.xacro'), mappings={'ur_type':'ur5e','name':'ur5e','tf_prefix':'','force_abs_paths':'true'})
urdf = ET.fromstring(doc.toxml())
extension = ET.SubElement(urdf,'mujoco')
ET.SubElement(extension,'compiler',discardvisual='false',fusestatic='false',balanceinertia='false',strippath='false',meshdir=str(OUT))
for link in urdf.findall('link'):
    for role in ('visual','collision'):
        for geom in link.findall(role):
            mesh = geom.find('geometry/mesh')
            if mesh is None:continue
            path = mesh.get('filename').replace('package://ur_description/',str(derived)+'/').replace('file://','')
            p = Path(path)
            if p.suffix.lower()=='.dae':
                output = OUT/(link.get('name')+'-visual.obj')
                scene=trimesh.load(p,force='scene')
                scene.to_geometry().export(output)
                path=str(output)
            else:
                output=OUT/p.name
                shutil.copyfile(p,output)
                path=str(output)
            mesh.set('filename',path)
urdf_path=OUT/'ur5e.urdf'
ET.ElementTree(urdf).write(urdf_path,encoding='unicode')
model=mujoco.MjModel.from_xml_path(str(urdf_path))
mujoco.mj_saveLastXML(str(OUT/'ur5e-native.xml'),model)
model=mujoco.MjModel.from_xml_path(str(OUT/'ur5e-native.xml'))
# Independent forward kinematics from the original URDF joint tree, not MJCF.
def transform(xyz, rpy):
    t=np.eye(4);t[:3,:3]=Rotation.from_euler('xyz',rpy).as_matrix();t[:3,3]=xyz;return t
joints=[]
for j in urdf.findall('joint'):
    origin=j.find('origin');axis=j.find('axis')
    joints.append(dict(name=j.get('name'),type=j.get('type'),parent=j.find('parent').get('link'),child=j.find('child').get('link'),origin=transform([float(x) for x in (origin.get('xyz','0 0 0') if origin is not None else '0 0 0').split()],[float(x) for x in (origin.get('rpy','0 0 0') if origin is not None else '0 0 0').split()]),axis=np.array([float(x) for x in (axis.get('xyz') if axis is not None else '0 0 1').split()])))
def fk(q):
    frames={'world':np.eye(4)};pending=list(joints)
    while pending:
        progress=False
        for j in pending[:]:
            if j['parent'] not in frames:continue
            t=j['origin'].copy()
            if j['type'] in ('revolute','continuous'):
                r=np.eye(4);r[:3,:3]=Rotation.from_rotvec(j['axis']*q[j['name']]).as_matrix();t=t@r
            frames[j['child']]=frames[j['parent']]@t;pending.remove(j);progress=True
        assert progress,'Disconnected URDF tree'
    return frames['tool0']
data=mujoco.MjData(model);rng=np.random.default_rng(52026);errors=[]
for _ in range(100):
    q={mujoco.mj_id2name(model,mujoco.mjtObj.mjOBJ_JOINT,i):float(rng.uniform(-2,2)) for i in range(model.njnt)}
    for name,v in q.items():data.joint(name).qpos[0]=v
    mujoco.mj_forward(model,data);expected=fk(q);b=data.body('tool0')
    errors.append([float(np.linalg.norm(b.xpos-expected[:3,3])),float(Rotation.from_matrix(b.xmat.reshape(3,3).T@expected[:3,:3]).magnitude())])
assert np.max(errors)<1e-5,errors
result=dict(source_revision='0eb1a861f7772fceb38510d90fa2f98ec668070c',source='UniversalRobots/Universal_Robots_ROS2_Description',joint_names=[mujoco.mj_id2name(model,mujoco.mjtObj.mjOBJ_JOINT,i) for i in range(model.njnt)],nq=model.nq,nbody=model.nbody,ngeom=model.ngeom,fk_samples=100,max_position_error_m=float(np.max(np.array(errors)[:,0])),max_orientation_error_rad=float(np.max(np.array(errors)[:,1])),manufacturer_nominal_kinematics_preserved=True,hardware_serial_calibration_available=False,converted_urdf_sha256=hashlib.sha256(urdf_path.read_bytes()).hexdigest())
(OUT/'ROBOT_AUDIT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2),flush=True)
