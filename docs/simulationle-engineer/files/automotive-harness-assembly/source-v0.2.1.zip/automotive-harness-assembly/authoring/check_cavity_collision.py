"""A geometric cavity/contact regression, not a connector insertion solution."""
from pathlib import Path
import copy,json,time
import xml.etree.ElementTree as E
import numpy as np
import mujoco
import cadquery as cq
from OCP.BRepClass3d import BRepClass3d_SolidClassifier
from OCP.TopAbs import TopAbs_IN
from OCP.gp import gp_Pnt

P=Path('/work');base=P/'components/connectors/c3d-at04-2p-01-000';results=[]
shape=cq.importers.importStep(str(P/'upstream/amphenol/c3d-at04-2p-01-000.stp')).val();classifier=BRepClass3d_SolidClassifier(shape.wrapped)
for representation in ('rigid_triangles','single_convex_hull'):
    for dt in (.0005,.00025):
        root=E.parse(base/'component.xml').getroot();root.find('option').set('timestep',str(dt))
        component=root.find('worldbody/body');component.remove(component.find('freejoint'))
        if representation=='single_convex_hull':
            root.remove(root.find('deformable'));asset=E.SubElement(root,'asset');E.SubElement(asset,'mesh',name='filled_hull',file=str(base/'surface.obj'));E.SubElement(component,'geom',type='mesh',mesh='filled_hull')
        probe=E.SubElement(root.find('worldbody'),'body',name='probe',pos='0 .010 0')
        E.SubElement(probe,'joint',name='translation',type='slide',axis='1 0 0',damping='1')
        E.SubElement(probe,'geom',name='ball',type='sphere',size='.0004',mass='.02',solref='.002 1',solimp='.95 .99 .0001')
        act=E.SubElement(root,'actuator');E.SubElement(act,'position',name='drive',joint='translation',kp='10',forcerange='-.1 .1')
        m=mujoco.MjModel.from_xml_string(E.tostring(root,encoding='unicode'));d=mujoco.MjData(m);mujoco.mj_forward(m,d);initial=d.ncon
        d.ctrl[0]=.012;maxcon=0;start=time.monotonic()
        for _ in range(round(.5/dt)):
            mujoco.mj_step(m,d);maxcon=max(maxcon,d.ncon)
        center=d.body('probe').xpos*1000;classifier.Perform(gp_Pnt(*map(float,center)),.0001)
        result=dict(representation=representation,timestep_s=dt,initial_cavity_contacts=initial,max_contacts=maxcon,final_displacement_mm=float(d.qpos[0]*1000),final_center_inside_exact_solid=classifier.State()==TopAbs_IN,finite=bool(np.isfinite(d.qpos).all()),wall_seconds=time.monotonic()-start)
        results.append(result); print(result,flush=True)
tri=[r for r in results if r['representation']=='rigid_triangles']
passed=all(r['initial_cavity_contacts']==0 and r['max_contacts']>0 and not r['final_center_inside_exact_solid'] and 0<r['final_displacement_mm']<10 for r in tri) and abs(tri[0]['final_displacement_mm']-tri[1]['final_displacement_mm'])<.1
report=dict(test='single 0.8-mm diameter sphere inside AT04-2P cavity, driven laterally into wall',results=results,cavity_contact_regression_passed=passed,connector_mating_or_latch_validated=False)
(P/'cad-audit/CAVITY_COLLISION.json').write_text(json.dumps(report,indent=2))
if not passed:raise SystemExit('Cavity regression failed')
