"""Make a relocatable manufacturer-kinematics UR5e plus sourced gripper component."""
from pathlib import Path
import copy
import hashlib
import json
import shutil
import xml.etree.ElementTree as ET
import mujoco
import numpy as np
from PIL import Image

P=Path('/work');OUT=P/'components';OUT.mkdir(exist_ok=True)
assets=OUT/'robot-assets';assets.mkdir(exist_ok=True)
robot=ET.parse(P/'robot-audit/ur5e-native.xml').getroot()
robot.find('compiler').set('meshdir','robot-assets')
for mesh in robot.find('asset').findall('mesh'):
    old=Path(mesh.get('file'));new=assets/('ur-'+old.name)
    shutil.copyfile(old,new);mesh.set('file',new.name)
for geom in robot.findall('.//geom'):
    if geom.get('contype')=='0':geom.set('rgba','.65 .72 .78 1')
    else:geom.set('group','3')
gripper=ET.parse(P/'upstream/menagerie/robotiq_2f85/2f85.xml').getroot()
for mesh in gripper.find('asset').findall('mesh'):
    old=P/'upstream/menagerie/robotiq_2f85/assets'/mesh.get('file');new=assets/('gripper-'+old.name)
    mesh.set('name',old.stem)
    shutil.copyfile(old,new);mesh.set('file',new.name)
refs={'name','class','childclass','mesh','material','joint','joint1','joint2','body1','body2','geom1','geom2','site','tendon'}
for node in gripper.iter():
    for k in refs:
        if k in node.attrib:node.set(k,'gripper_'+node.get(k))
for tag in ('asset','default','contact','tendon','equality','actuator'):
    source=gripper.find(tag)
    if source is None:continue
    target=robot.find(tag)
    if target is None:target=ET.SubElement(robot,tag)
    for node in source:target.append(copy.deepcopy(node))
tool=robot.find(".//body[@name='tool0']")
tool.append(copy.deepcopy(gripper.find('worldbody/body')))
for name in ['shoulder_link','upper_arm_link','forearm_link','wrist_1_link','wrist_2_link','wrist_3_link','gripper_base']:
    robot.find(f".//body[@name='{name}']").set('gravcomp','1')
ET.SubElement(tool,'site',name='flange_wrench',size='.001')
sensor=ET.SubElement(robot,'sensor')
ET.SubElement(sensor,'force',name='wrist_force',site='flange_wrench')
ET.SubElement(sensor,'torque',name='wrist_torque',site='flange_wrench')
act=robot.find('actuator')
names=['shoulder_pan_joint','shoulder_lift_joint','elbow_joint','wrist_1_joint','wrist_2_joint','wrist_3_joint']
for i,name in enumerate(names):
    j=robot.find(f".//joint[@name='{name}']");j.set('damping','1');j.set('armature','.05')
    j.set('actuatorgravcomp','true')
    force=150 if i<3 else 28
    ET.SubElement(act,'position',name=name+'_servo',joint=name,kp='4000' if i<3 else '1500',kv='160' if i<3 else '60',ctrlrange=j.get('range'),forcerange=f'-{force} {force}')
ET.SubElement(robot,'option',timestep='.001',integrator='implicitfast',cone='elliptic',impratio='10',iterations='80',tolerance='1e-10')
visual=ET.SubElement(robot,'visual');ET.SubElement(visual,'global',offwidth='900',offheight='700')
# Adjacent wrist/gripper mounting solids intersect at the designed attachment.
contact=robot.find('contact')
ET.SubElement(contact,'exclude',body1='wrist_3_link',body2='gripper_base_mount')
ET.SubElement(contact,'exclude',body1='wrist_3_link',body2='gripper_base')
ET.ElementTree(robot).write(OUT/'ur5e-2f85.xml',encoding='unicode')
model=mujoco.MjModel.from_xml_path(str(OUT/'ur5e-2f85.xml'));d=mujoco.MjData(model)
q=[0,-1.4,1.8,-1.95,-1.57,0]
for name,v in zip(names,q):d.joint(name).qpos[0]=v;d.ctrl[model.actuator(name+'_servo').id]=v
mujoco.mj_forward(model,d)
initial=d.site('gripper_pinch').xpos.copy()
for _ in range(2000):mujoco.mj_step(model,d)
assert np.isfinite(d.qpos).all()
receipt=dict(robot_source='UniversalRobots nominal UR5e',gripper_source='ROS-Industrial derivative via Menagerie',nq=model.nq,nv=model.nv,ngeom=model.ngeom,actuators=model.nu,unloaded_hold_drift_m=float(np.linalg.norm(d.site('gripper_pinch').xpos-initial)),finite=True,servo_gains='SLE simulation commissioning parameters; not measured vendor firmware',sha256=hashlib.sha256((OUT/'ur5e-2f85.xml').read_bytes()).hexdigest())
(OUT/'COMPONENT_AUDIT.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2),flush=True)
renderer=mujoco.Renderer(model,700,900);cam=mujoco.MjvCamera();cam.lookat[:]=[.15,0,.3];cam.distance=1.7;cam.azimuth=130;cam.elevation=-25
renderer.update_scene(d,camera=cam);Image.fromarray(renderer.render()).save(OUT/'robot.png');renderer.close()
