"""Harbor collect hook: quiesce candidate processes before artifact copying."""
import hashlib
import json
import os
from pathlib import Path
import signal
import stat
import time

if os.geteuid()!=0:
    raise SystemExit('The submission collect hook requires root')
def candidate_pids():
    found=[]
    for proc in Path('/proc').iterdir():
        if not proc.name.isdigit():continue
        try:
            uid_line=next(line for line in (proc/'status').read_text().splitlines() if line.startswith('Uid:'))
            if 1000 in [int(x) for x in uid_line.split()[1:]]:found.append(int(proc.name))
        except (FileNotFoundError,ProcessLookupError,StopIteration):pass
    return found
deadline=time.monotonic()+5
while pids:=candidate_pids():
    for pid in pids:
        try:os.kill(pid,signal.SIGKILL)
        except ProcessLookupError:pass
    if time.monotonic()>=deadline:raise RuntimeError('Candidate processes did not stop; no valid checkpoint was collected')
    time.sleep(.02)
root=Path('/logs/artifacts')
if not root.is_dir() or root.is_symlink():
    raise SystemExit('Missing regular artifact directory')
records={}
for p in sorted(root.rglob('*')):
    st=p.lstat()
    if stat.S_ISLNK(st.st_mode):
        records[str(p.relative_to(root))]={'invalid':'symbolic_link'}
        continue
    if stat.S_ISREG(st.st_mode):
        with p.open('rb') as stream:sha=hashlib.file_digest(stream,'sha256').hexdigest()
        records[str(p.relative_to(root))]={'bytes':st.st_size,'sha256':sha}
    os.chown(p,0,0)
    # Root ownership prevents candidate writes. Traversable 0755 directories
    # also let Harbor's host-side archive extractor collect their children.
    p.chmod(0o755 if p.is_dir() else 0o555 if st.st_mode&0o111 else 0o444)
os.chown(root,0,0);root.chmod(0o755)
print(json.dumps({'candidate_uid_stopped':1000,'files':records},sort_keys=True))
