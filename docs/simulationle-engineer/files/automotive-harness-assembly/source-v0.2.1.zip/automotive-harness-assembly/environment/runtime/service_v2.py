"""Bounded robot I/O. Only numeric commands reach the trusted physics process."""
import json, os, socket, socketserver, sys
from pathlib import Path
from cell_v2 import Cell,CommandError

class Lab:
 def __init__(self,root='/state',limit=12):
  self.root=Path(root);self.root.mkdir(parents=True,exist_ok=True);self.cell=None;self.resets=0;self.limit=limit;self.used=0.;self.frozen=False
 def request(self,r):
  if not isinstance(r,dict):raise CommandError('Request must be an object')
  op=r.get('op')
  if op=='status':return dict(resets=self.resets,reset_limit=self.limit,simulation_used_s=self.used,simulation_budget_s=7200.,frozen=self.frozen)
  if self.frozen:raise CommandError('Commissioning session is frozen')
  if op=='reset':
   if set(r)-{'op','seed'}:raise CommandError('Unknown reset field')
   if self.resets>=self.limit:raise CommandError('Reset budget exhausted')
   seed=r.get('seed',0)
   if type(seed)!=int or seed not in range(4):raise CommandError('Development seeds are 0,1,2,3')
   if self.cell:self.cell.save()
   self.resets+=1;self.cell=Cell(Path(os.environ.get('O5_EVIDENCE','/evidence'))/f'episode-{self.resets:02}',seed=seed)
   return self.cell.observe()
  if not self.cell:raise CommandError('Reset the cell before use')
  if op=='observe':return self.cell.observe()
  if op=='step':
   if set(r)-{'op','action'}:raise CommandError('Unknown step field')
   if self.used>=7200:raise CommandError('Commissioning simulation budget exhausted')
   start=self.cell.d.time
   try:return self.cell.step(r.get('action',{}))
   finally:self.used+=self.cell.d.time-start
  if op=='camera':return self.cell.camera(r.get('name','overview'))
  if op=='finish':self.cell.save();return dict(saved=True,time_s=self.cell.d.time)
  raise CommandError('Unknown operation')

lab=Lab(os.environ.get('O5_STATE','/state'))
class Handler(socketserver.StreamRequestHandler):
 def handle(self):
  self.connection.settimeout(120)
  while True:
   raw=self.rfile.readline(200001)
   if not raw:return
   try:
    if len(raw)>200000 or not raw.endswith(b'\n'):raise CommandError('Request exceeds 200 kB')
    if (lab.root/'frozen').exists():
     if not lab.frozen and lab.cell:lab.cell.save()
     lab.frozen=True
    result=lab.request(json.loads(raw));reply=dict(ok=True,result=result)
   except (ValueError,TypeError,KeyError,RecursionError) as exc:reply=dict(ok=False,error=str(exc))
   self.wfile.write((json.dumps(reply,allow_nan=False)+'\n').encode());self.wfile.flush()

if __name__=='__main__':
 if len(sys.argv)>1 and sys.argv[1]=='freeze':
  (lab.root/'frozen').touch()
  with socket.socket(socket.AF_UNIX) as client:
   client.settimeout(45);client.connect(os.environ.get('O5_SOCKET','/cell_io/cell.sock'));client.sendall(b'{"op":"status"}\n');reply=json.loads(client.makefile('rb').readline())
  if not reply.get('ok') or not reply['result'].get('frozen'):raise RuntimeError('Commissioning did not acknowledge freeze')
  print('Commissioning closed; trusted evidence flushed');raise SystemExit
 path=Path(os.environ.get('O5_SOCKET','/cell_io/cell.sock'));path.parent.mkdir(parents=True,exist_ok=True);path.unlink(missing_ok=True)
 with socketserver.UnixStreamServer(str(path),Handler) as server:
  os.chmod(path,0o666);(lab.root/'ready').touch();server.serve_forever()
