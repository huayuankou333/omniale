"""Trusted O5 simulator: commands change controls, never part poses or acceptance."""
from native_v2 import *
import base64, io, time
from PIL import Image

class CommandError(ValueError):pass
class Cell:
 def __init__(self,out,seed=0,cables=True,dt=.002,only_part=None):
  self.out=Path(out);self.out.mkdir(parents=True,exist_ok=True)
  path,self.order=build(self.out,seed=seed,cables=cables,dt=dt,only_part=only_part)
  self.m=mujoco.MjModel.from_xml_path(str(path));self.d=mujoco.MjData(self.m);mujoco.mj_resetDataKeyframe(self.m,self.d,self.m.key('loaded').id)
  self.seed=seed;self.rng=np.random.default_rng(seed+8015);self.frames=[];self.trace=[];self.commands=[];self.phase='assembly';self.checkpoints=[];self.violations=[];self.failure=None;self.finished=False;self.renderer=None
  self.grasp_evidence={p['id']:dict(left=False,right=False,moved=False,verified_lift=False) for p in self.order['parts']}
  self.grasp_ticks={p['id']:0 for p in self.order['parts']};self.robot_contact=False;self.camera_calls=0
  self.rework_branch='right_2' if seed%2 else 'left_2';self.rework_active=False;self.rework_disconnected_s=0.;self.rework_preserved=True;self.rework_uncovered=False
  self.rework_monitoring=False;self.rework_release_contact_s=0.
  self.act={};self.qadr={};self.dadr={};self.grip={};self.initial={p['id']:np.array(p['initial_origin_m']) for p in self.order['parts']}
  for arm in ['left','right']:
   names=[arm+'_'+n for n in JOINTS];self.act[arm]=[self.m.actuator(n+'_servo').id for n in names];self.qadr[arm]=[self.m.joint(n).qposadr[0] for n in names];self.dadr[arm]=[self.m.joint(n).dofadr[0] for n in names];self.grip[arm]=self.m.actuator(arm+'_gripper_fingers_actuator').id
   q=np.array(HOME[arm]);self.d.qpos[self.qadr[arm]]=q;self.d.ctrl[self.act[arm]]=q
  self.cover=self.m.actuator('cover_motor').id;self.cover_demand=0.
  self.clamps={a+'_'+j:self.m.actuator(a+'_'+j+'_clamp_motor').id for a in ['left','right'] for j in ['0','1','2','3','rework']} if cables else {}
  self.clamp_carriages={name:self.m.actuator(name+'_clamp_carriage_motor').id for name in self.clamps}
  self.clamp_demands={name:0. for name in self.clamps}
  self.clamp_capture_ready={name:False for name in self.clamps}
  self.formers={arm:{axis:self.m.actuator(arm+'_former_'+axis+'_motor').id for axis in ['advance','shift']} for arm in ['left','right']} if cables else {}
  mujoco.mj_forward(self.m,self.d)
  self.last_cmd={arm:self.d.qpos[self.qadr[arm]].copy() for arm in self.act};self.damage_seconds={p['id']:0. for p in self.order['parts']};self.insert_forces={p['id']:0. for p in self.order['parts']};self.pinch_seconds=0.;self.fixture_collision_seconds=0.
  self.last_capture=-1.;self.peak_forces={p['id']:0. for p in self.order['parts']};self.touch_ticks={p['id']:0 for p in self.order['parts']}
  self.monitor_period=.02;self.monitor_steps=max(1,round(self.monitor_period/self.m.opt.timestep))
  self.solver_warning_start=self.d.warning.number.copy()
  self.reset_state_sha=__import__('hashlib').sha256(self.d.qpos.tobytes()).hexdigest()
  self._index_contacts()

 def _index_contacts(self):
  """Cache immutable collision identities; all live contacts are still inspected."""
  ids=[p['id'] for p in self.order['parts']]
  def metadata(name,body='',fixed=False):
   part=next((p for p in ids if name.startswith(p+'_surface') or name.startswith(p+'_proxy')),None)
   robot=any(body.startswith(a+'_') and any(t in body for t in ['gripper','shoulder','upper_arm','forearm','wrist']) for a in ['left','right'])
   pad=next(((a,j) for a in ['left','right'] for j in ['left','right'] if name.startswith(a+'_gripper_'+j+'_pad')),None)
   cable='_cable_' in name or '_junction' in name or body.endswith('_junction')
   retainer=name.endswith('_clamp_roof') or '_clamp_guard_' in name or '_bend_former_' in name
   fixture=fixed or '_socket_surface' in name or name=='cover_plate' or name.endswith('_release_tip') or retainer
   latch=next((p for p in ids if name.startswith(p+'_latch_proxy') or name.startswith(p+'_surface') and 'latch' in name),None)
   release=next((p for p in ids if name==p+'_release_tip'),None)
   socket=next((p for p in ids if name==p+'_socket_surface'),None)
   return (name,part,robot,pad,cable,fixture,name=='cover_plate',latch,release,socket,retainer)
  self.geom_contacts=[metadata(self.m.geom(i).name or '',self.m.body(int(self.m.geom_bodyid[i])).name or '',self.m.geom_bodyid[i]==0) for i in range(self.m.ngeom)]
  self.flex_contacts=[metadata(mujoco.mj_id2name(self.m,mujoco.mjtObj.mjOBJ_FLEX,i) or '') for i in range(self.m.nflex)]

 def observe(self):
  arms={}
  for arm in ['left','right']:
   force=np.array(self.d.sensor(arm+'_wrist_force').data);torque=np.array(self.d.sensor(arm+'_wrist_torque').data)
   arms[arm]=dict(q_rad=self.d.qpos[self.qadr[arm]].tolist(),qd_rad_s=self.d.qvel[self.dadr[arm]].tolist(),wrist_force_N=(force+self.rng.normal(0,.03,3)).tolist(),wrist_torque_Nm=(torque+self.rng.normal(0,.001,3)).tolist(),gripper_driver_rad=float(self.d.joint(arm+'_gripper_right_driver_joint').qpos[0]))
  public_order=json.loads(json.dumps(self.order))
  for p in public_order['parts']:
   p.pop('grasp_local_m',None)
   p['initial_origin_m'][0:2]=[-.31 if p['arm']=='left' else .31,[.10,.22,.34,.46][int(p['id'][-1])]]
  job=dict(branch=self.rework_branch,new_route_portal_y_m=REWORK_PORTAL_Y,portal_half_width_m=REWORK_PORTAL_HALF) if self.phase=='rework' else None
  return dict(schema_version=2,time_s=float(self.d.time),phase=self.phase,arms=arms,io=dict(cover_encoder_m=float(self.d.joint('cover_slide').qpos[0]),routing_clamp_encoder_m={name:float(self.d.joint(name+'_clamp_slide').qpos[0]) for name in self.clamps},routing_clamp_carriage_encoder_m={name:float(self.d.joint(name+'_clamp_carriage').qpos[0]) for name in self.clamps},bend_former_encoder_m={arm:{axis:float(self.d.joint(arm+'_former_'+axis).qpos[0]) for axis in ['advance','shift']} for arm in self.formers},rework_job=job),work_order=public_order if self.d.time==0 else None,simulation_status='finished' if self.finished else 'running')

 def _contacts(self):
  """Accumulate bilateral pad contacts and actual body displacement."""
  force=np.zeros(6);pidset=set(self.grasp_evidence);pads={p:{a:set() for a in ['left','right']} for p in pidset};self.robot_contact=False;mateforces={p:0. for p in pidset};pinch_force=0.;fixture_force=0.;release_contact=False
  for ci,c in enumerate(self.d.contact):
   a,b=[self.flex_contacts[int(c.flex[k])] if c.flex[k]>=0 else self.geom_contacts[int(c.geom[k])] for k in (0,1)]
   release_pair=self.rework_active and ((a[8]==self.rework_branch and b[7]==self.rework_branch) or (b[8]==self.rework_branch and a[7]==self.rework_branch))
   robot_fixture=(a[2] and b[5]) or (b[2] and a[5]);pinched=((a[6] or a[10]) and b[4]) or ((b[6] or b[10]) and a[4])
   if a[1] or b[1] or release_pair or robot_fixture or pinched:mujoco.mj_contactForce(self.m,self.d,ci,force)
   normal=abs(float(force[0]))
   if (a[2] and (b[1] or b[4])) or (b[2] and (a[1] or a[4])):self.robot_contact=True
   if robot_fixture:fixture_force+=normal
   if pinched:pinch_force+=normal
   if release_pair and normal>.03 and float(self.d.joint(self.rework_branch+'_release_slide').qpos[0])>.004 and abs(float(self.d.joint(self.rework_branch+'_latch_hinge').qpos[0]))>.08:release_contact=True
   for own,other in [(a,b),(b,a)]:
    p=own[1]
    if p:
     self.peak_forces[p]=max(self.peak_forces[p],normal)
     if other[9]==p:mateforces[p]+=abs(float(c.frame[2]*force[0]+c.frame[5]*force[1]+c.frame[8]*force[2]))
     if other[3] and normal>.03:pads[p][other[3][0]].add(other[3][1])
  for p in self.order['parts']:
   name=p['id'];pos=self.d.xpos[self.m.body(name).id]
   if np.linalg.norm(pos-self.initial[name])>.005:self.grasp_evidence[name]['moved']=True
   grasped=False
   for arm in ['left','right']:
    if len(pads[name][arm])==2:self.grasp_evidence[name][arm]=True;grasped=True
   self.grasp_ticks[name]=self.grasp_ticks[name]+1 if grasped and pos[2]-self.initial[name][2]>.010 else 0
   if self.grasp_ticks[name]>=5:self.grasp_evidence[name]['verified_lift']=True
   self.insert_forces[name]=max(self.insert_forces[name],mateforces[name])
   self.damage_seconds[name]=self.damage_seconds[name]+self.monitor_period if mateforces[name]>100. else 0.
   if self.damage_seconds[name]>=.08 and not any(v.get('id')==name for v in self.violations):self.violations.append(dict(id=name,type='excessive_mating_force',time_s=float(self.d.time),force_N=mateforces[name]))
  for key,measured,limit in [('pinch',pinch_force,2.),('fixture_collision',fixture_force,20.)]:
   attr=key+'_seconds';setattr(self,attr,getattr(self,attr)+self.monitor_period if measured>limit else 0.)
   if getattr(self,attr)>=.08 and not any(v.get('type')==key for v in self.violations):self.violations.append(dict(type=key,time_s=float(self.d.time),force_N=measured))
  if self.rework_monitoring:
   branch=next(p for p in self.order['parts'] if p['id']==self.rework_branch)
   if release_contact:self.rework_release_contact_s+=self.monitor_period
   if self.rework_active and self.rework_release_contact_s>=.08 and self.d.joint('cover_slide').qpos[0]>-.002 and np.linalg.norm(self.d.xpos[self.m.body(self.rework_branch).id]-branch['target_origin_m'])>.025:self.rework_disconnected_s+=self.monitor_period
   if any(not r['geometry_pass'] for r in self.metrology() if r['id']!=self.rework_branch):self.rework_preserved=False
   self.rework_uncovered|=self.d.joint('cover_slide').qpos[0]>-.002
  if self.order['cables']:
   for arm,sign in [('left',-1),('right',1)]:
    center=self.d.body(arm+'_junction').xpos
    if (abs(center[0]-sign*.245)>.012 or abs(center[1]-.285)>.012 or not .697<=center[2]<=.731) and not any(v.get('type')=='junction_escape' and v.get('id')==arm for v in self.violations):
     self.violations.append(dict(type='junction_escape',id=arm,time_s=float(self.d.time),center_m=center.tolist()))

 def _tick(self):
  if self.d.time>=600.-self.m.opt.timestep/2:raise CommandError('The 600-second physical episode horizon has ended')
  freeze_file=os.environ.get('O5_COMMISSIONING_FREEZE_FILE')
  if freeze_file and os.path.isfile(freeze_file):raise CommandError('Commissioning session is frozen')
  self.d.ctrl[self.cover]+=np.clip(self.cover_demand-self.d.ctrl[self.cover],-.06*self.m.opt.timestep,.06*self.m.opt.timestep)
  former_ready={}
  for arm,axes in self.formers.items():
   names=[arm+'_2',arm+'_rework']
   requested=next((name for name in names if self.clamp_demands[name]<0),None)
   enc={axis:float(self.d.joint(arm+'_former_'+axis).qpos[0]) for axis in axes}
   parked=lambda name:abs(float(self.d.joint(name+'_clamp_slide').qpos[0]))<.0003 and abs(float(self.d.joint(name+'_clamp_carriage').qpos[0]))<.0003
   if requested:
    shift=FORMER_SHIFT if requested.endswith('_rework') else FORMER_NORMAL_SHIFT
    opposite=next(name for name in names if name!=requested)
    advance=FORMER_ADVANCE if parked(opposite) else self.d.ctrl[axes['advance']]
    shift_goal=shift if parked(opposite) and abs(enc['advance']-FORMER_ADVANCE)<.0003 else 0.
   else:
    shift_goal=0. if all(parked(name) for name in names) else self.d.ctrl[axes['shift']]
    advance=0. if all(parked(name) for name in names) and abs(enc['shift'])<.0003 else self.d.ctrl[axes['advance']]
   for axis,goal in [('advance',advance),('shift',shift_goal)]:
    self.d.ctrl[axes[axis]]+=np.clip(goal-self.d.ctrl[axes[axis]],-FORMER_SPEED*self.m.opt.timestep,FORMER_SPEED*self.m.opt.timestep)
   for name in names:former_ready[name]=requested==name and abs(enc['advance']-FORMER_ADVANCE)<.0003 and abs(enc['shift']-(FORMER_SHIFT if name.endswith('_rework') else FORMER_NORMAL_SHIFT))<.0003
  for name,index in self.clamps.items():
   # A real two-axis tool sequence: traverse while raised, then lower. Opening
   # reverses that sequence, using actual slide encoders to gate each motion.
   carriage=self.clamp_carriages[name]
   if self.clamp_demands[name]<0:
    # Arrival is latched for this closing cycle. Small elastic deflection
    # under a routed cable must not start horizontal withdrawal with a low roof.
    if name not in former_ready or former_ready[name]:self.clamp_capture_ready[name]=True
    ygoal=-CLAMP_PARK_TRAVEL if self.clamp_capture_ready[name] else 0.
    zgoal=self.clamp_demands[name] if abs(float(self.d.joint(name+'_clamp_carriage').qpos[0])+CLAMP_PARK_TRAVEL)<.0003 else 0.
   else:
    self.clamp_capture_ready[name]=False
    zgoal=0.
    ygoal=0. if abs(float(self.d.joint(name+'_clamp_slide').qpos[0]))<.0003 else -CLAMP_PARK_TRAVEL
   self.d.ctrl[carriage]+=np.clip(ygoal-self.d.ctrl[carriage],-CLAMP_PARK_SPEED*self.m.opt.timestep,CLAMP_PARK_SPEED*self.m.opt.timestep)
   self.d.ctrl[index]+=np.clip(zgoal-self.d.ctrl[index],-CLAMP_SPEED*self.m.opt.timestep,CLAMP_SPEED*self.m.opt.timestep)
  mujoco.mj_step(self.m,self.d)
  if not np.isfinite(self.d.qpos).all() or not np.isfinite(self.d.qvel).all():raise RuntimeError('Nonfinite native physics state')
  if np.any(self.d.warning.number>self.solver_warning_start):raise RuntimeError('Native solver warning; run is not valid evidence')
  if int(round(self.d.time/self.m.opt.timestep))%self.monitor_steps==0:self._contacts()
  if self.d.time-self.last_capture>=.099999:
   self.last_capture=self.d.time
   self.trace.append(dict(t=float(self.d.time),q=self.d.qpos.copy().tolist(),ctrl=self.d.ctrl.copy().tolist(),phase=self.phase,ncon=int(self.d.ncon)))
  if self.d.time>600:self.finished=True

 def step(self,action):
  if self.finished:raise CommandError('Episode has ended')
  if not isinstance(action,dict) or set(action)-{'seconds','left','right','cover','routing_clamp','release_plunger','checkpoint','finish','camera'}:raise CommandError('Unsupported action field')
  self.commands.append(dict(time_s=float(self.d.time),action=json.loads(json.dumps(action,allow_nan=False))))
  if action.get('camera'):return self.camera(action['camera'])
  seconds=action.get('seconds',.05)
  if type(seconds) not in (int,float) or not np.isfinite(seconds) or not .001<=seconds<=.25:raise CommandError('seconds must be within [0.001,0.25]')
  count=max(1,round(seconds/self.m.opt.timestep));start={a:self.d.ctrl[self.act[a]].copy() for a in self.act};target={a:start[a].copy() for a in self.act}
  for arm in self.act:
   value=action.get(arm,{})
   if not isinstance(value,dict) or set(value)-{'q_rad','gripper'}:raise CommandError('Arm commands contain q_rad and/or gripper only')
   if 'q_rad' in value:
    q=np.asarray(value['q_rad'],float)
    if q.shape!=(6,) or not np.isfinite(q).all():raise CommandError('q_rad requires six finite joint angles')
    if np.max(np.abs(q-start[arm]))>seconds*.65+1e-8:raise CommandError('Joint setpoint slew exceeds 0.65 rad/s')
    if np.any(q<self.m.actuator_ctrlrange[self.act[arm],0]) or np.any(q>self.m.actuator_ctrlrange[self.act[arm],1]):raise CommandError('Joint limit exceeded')
    target[arm]=q
   if 'gripper' in value:
    g=value['gripper']
    if type(g) not in (int,float) or not np.isfinite(g) or not 0<=g<=255:raise CommandError('gripper must be in [0,255]')
    self.d.ctrl[self.grip[arm]]=g
  if 'cover' in action:
   if type(action['cover']) not in (int,float) or not 0<=action['cover']<=1:raise CommandError('cover must be in [0,1]')
   self.cover_demand=-COVER_TRAVEL*action['cover']
  if 'routing_clamp' in action:
   value=action['routing_clamp']
   if not isinstance(value,dict) or set(value)-set(self.clamps):raise CommandError('Unknown routing clamp')
   proposed=self.clamp_demands.copy()
   for name,stroke in value.items():
    if type(stroke) not in (int,float) or not np.isfinite(stroke) or not 0<=stroke<=1:raise CommandError('Clamp stroke must be in [0,1]')
    proposed[name]=-clamp_travel(name)*stroke
   if any(proposed[a+'_2']<0 and proposed[a+'_rework']<0 for a in self.formers):raise CommandError('Normal and alternate capture tools share a former; open one before closing the other')
   self.clamp_demands=proposed
  if 'release_plunger' in action:
   value=action['release_plunger']
   if not isinstance(value,dict) or set(value)-{p['id'] for p in self.order['parts'] if p['pins']==2}:raise CommandError('Unknown release plunger')
   for name,stroke in value.items():
    if type(stroke) not in (int,float) or not np.isfinite(stroke) or not 0<=stroke<=1:raise CommandError('Plunger stroke must be in [0,1]')
    self.d.ctrl[self.m.actuator(name+'_release_motor').id]=.009*stroke
  for k in range(count):
   for arm in self.act:self.d.ctrl[self.act[arm]]=start[arm]+(target[arm]-start[arm])*(k+1)/count
   self._tick()
  if 'checkpoint' in action:self.inspect(str(action['checkpoint']))
  if action.get('finish'):self.finished=True
  return self.observe()

 def metrology(self):
  rows=[]
  for p in self.order['parts']:
   bid=self.m.body(p['id']).id;delta=self.d.xpos[bid]-p['target_origin_m'];angle=float(np.linalg.norm(R.from_matrix(np.array(p['rotation']).T@self.d.xmat[bid].reshape(3,3)).as_rotvec()))
   lateral=float(np.linalg.norm(delta[:2]));axial=float(abs(delta[2]));u=.00012;au=.001
   witnesses=np.array([[-.007,0,-.005],[.007,0,-.005],[-.007,.024,.005],[.007,.024,-.005]])
   actual=(self.d.xmat[bid].reshape(3,3)@witnesses.T).T+self.d.xpos[bid];expected=(np.array(p['rotation'])@witnesses.T).T+p['target_origin_m'];w=float(np.linalg.norm(actual-expected,axis=1).max());radius=float(np.linalg.norm(witnesses,axis=1).max())
   latch=float(self.d.joint(p['id']+'_latch_hinge').qpos[0])
   checks={k:bool(v) for k,v in dict(lateral=lateral+u<=.0005,axial=axial+u<=.0003,orientation=angle+au<=np.pi/180,witness=w+u+2*radius*np.sin(au/2)<=.001,latch_recovered=abs(latch)<=.035).items()}
   rows.append(dict(id=p['id'],lateral_m=lateral,axial_m=axial,orientation_rad=angle,witness_m=w,latch_deflection_rad=latch,checks=checks,geometry_pass=all(checks.values()),linear_uncertainty_m=u,angular_uncertainty_rad=au))
  return rows

 def inspect(self,phase):
  if phase=='rework_begin':
   if 'cover' not in [p['phase'] for p in self.checkpoints] or self.rework_active:raise CommandError('Rework begins after cover inspection exactly once')
   self.rework_active=True;self.phase='rework';return
  if phase not in ('released','retention','cover','rework'):raise CommandError('Unknown inspection checkpoint')
  if phase in [p['phase'] for p in self.checkpoints]:raise CommandError('Checkpoint already used')
  expected=('released','retention','cover','rework')[len(self.checkpoints)] if len(self.checkpoints)<4 else None
  if phase!=expected:raise CommandError('Checkpoints must run released, retention, cover, rework in order')
  if phase=='rework' and not self.rework_active:raise CommandError('Request rework_begin before the final inspection')
  if phase in ('cover','rework') and abs(self.d.joint('cover_slide').qpos[0]+COVER_TRAVEL)>.0003:raise CommandError('Close the cover before this inspection')
  if any(abs(float(self.d.joint(p['id']+'_release_slide').qpos[0]))>.0002 for p in self.order['parts'] if p['pins']==2):raise CommandError('Retract all latch release tools before inspection')
  self.phase=phase
  # Inspection holds and loads are generated by the trusted test station.
  if any(self.d.ctrl[self.grip[a]]>1 for a in self.grip):raise CommandError('Open both grippers before inspection')
  hold=[];support=False
  for k in range(round(5/self.m.opt.timestep)):
   self._tick()
   support|=self.robot_contact
   if (k+1)%self.monitor_steps==0:hold.append(dict(parts=self.metrology(),robot_contact=self.robot_contact,routing=self.routing()))
  before=self.metrology();during=[]
  if phase=='retention':
   for p in self.order['parts']:self.d.xfrc_applied[self.m.body(p['id']).id,2]=.5
   for k in range(round(1/self.m.opt.timestep)):
    self._tick()
    support|=self.robot_contact
    if (k+1)%self.monitor_steps==0:during.append(self.metrology())
   self.d.xfrc_applied[:]=0
   for k in range(round(1/self.m.opt.timestep)):
    self._tick();support|=self.robot_contact
    if (k+1)%self.monitor_steps==0:during.append(self.metrology())
  row=dict(phase=phase,time_s=float(self.d.time),before=before,after=self.metrology(),during=during,hold=hold,robot_support_during_hold=bool(support),routing=self.routing(),cover_encoder_m=float(self.d.joint('cover_slide').qpos[0]))
  self.checkpoints.append(row);self.phase='assembly' if phase!='cover' else 'rework';self.save()
  if phase=='cover':self.rework_monitoring=True

 def camera(self,name='overview'):
  if name not in ['overview','metrology']+[s+'_'+p['id'] for s in ['stage','stage_back','stage_front','socket','hand','mate','rear','rear_back'] for p in self.order['parts']]:raise CommandError('Unknown camera')
  if self.camera_calls>=160:raise CommandError('Camera acquisition limit is 160 per episode')
  self.camera_calls+=1
  if self.renderer is None:self.renderer=mujoco.Renderer(self.m,960,1280)
  option=mujoco.MjvOption();option.sitegroup[:]=0
  self.renderer.update_scene(self.d,camera=name,scene_option=option);rgb=self.renderer.render();buf=io.BytesIO();Image.fromarray(rgb).save(buf,format='PNG')
  self.renderer.enable_depth_rendering();self.renderer.update_scene(self.d,camera=name,scene_option=option);depth=self.renderer.render().copy();self.renderer.disable_depth_rendering()
  depth+=self.rng.normal(0,.00001,depth.shape).astype('float32');db=io.BytesIO();np.savez_compressed(db,depth_m=depth)
  cid=self.m.camera(name).id;f=float(960/(2*np.tan(np.deg2rad(self.m.cam_fovy[cid])/2)))
  return dict(camera=name,time_s=float(self.d.time),rgb_png_base64=base64.b64encode(buf.getvalue()).decode(),depth_npz_base64=base64.b64encode(db.getvalue()).decode(),calibration=dict(width=1280,height=960,fx=f,fy=f,cx=639.5,cy=479.5,world_from_camera_rotation=self.d.cam_xmat[cid].reshape(3,3).tolist(),world_from_camera_translation_m=self.d.cam_xpos[cid].tolist(),depth_standard_deviation_m=.00001))

 def routing(self):
  if not self.order['cables']:return dict(passed=False,parts=[])
  rows=[];mujoco.mj_rnePostConstraint(self.m,self.d)
  for p in self.order['parts']:
   name=p['arm']+'_cable_'+p['id'][-1];vectors=[];crossings=[];lengths=[];max_tension=0.
   plane=-.17 if p['arm']=='left' else .17
   for j in range(11):
    gid=self.m.geom(name+f'_rod_{j}').id;length=2*self.m.geom_size[gid,1]
    # A capsule is undirected: the compiler may reverse its local Z axis.
    # Material order follows the articulated rod bodies, whose origins are
    # the designed start points. A reversed display axis is not a wire kink.
    a=self.d.xpos[self.m.body(name+f'_{j}').id].copy();b=2*self.d.geom_xpos[gid]-a;vectors.append((b-a)/length);lengths.append(length)
    if abs(b[0]-a[0])>1e-9 and (a[0]-plane)*(b[0]-plane)<=0:crossings.append((a+(b-a)*(plane-a[0])/(b[0]-a[0])).tolist())
    max_tension=max(max_tension,float(np.linalg.norm(self.d.cfrc_int[self.m.body(name+f'_{j}').id,3:])))
   angles=np.arccos(np.clip(np.sum(np.array(vectors[:-1])*np.array(vectors[1:]),axis=1),-1,1));radius=float(np.min((np.array(lengths[:-1])+lengths[1:])/2/np.maximum(angles,1e-9)))
   endpoint=float(np.linalg.norm(self.d.site(name+'_end').xpos-self.d.site(p['id']+'_rear').xpos))
   yc=REWORK_PORTAL_Y if self.rework_active and p['id']==self.rework_branch else p['target_origin_m'][1];half=REWORK_PORTAL_HALF if self.rework_active and p['id']==self.rework_branch else .055
   route=any(abs(q[1]-yc)<=half and .685<=q[2]<=.785 for q in crossings)
   passed=route and radius>=.015 and max_tension<=(20 if p['pins']==6 else 8) and endpoint<=.0003
   rows.append(dict(id=p['id'],portal_pass=bool(route),minimum_bend_radius_m=radius,maximum_segment_tension_N=max_tension,termination_error_m=endpoint,passed=bool(passed)))
  return dict(passed=all(p['passed'] for p in rows),parts=rows)

 def result(self):
  phases={r['phase']:r for r in self.checkpoints};counts=[];phase_pass={}
  for phase in ('released','retention','cover','rework'):
   if phase not in phases:counts.append(0);phase_pass[phase]=False;continue
   row=phases[phase];samples=[row['before'],row['after']]+row['during']+[x['parts'] for x in row['hold']]
   accepted=[all(next(r for r in s if r['id']==p['id'])['geometry_pass'] for s in samples) and self.grasp_evidence[p['id']]['verified_lift'] for p in self.order['parts']]
   if row['robot_support_during_hold']:accepted=[False]*len(accepted)
   count=sum(accepted);counts.append(count);phase_pass[phase]=count==8
  assembly=50*counts[0]/8;retention=10*counts[1]/8
  route_rows=[r['routing'] for r in self.checkpoints]+[h['routing'] for r in self.checkpoints for h in r['hold']];routing=10*min([sum(p['passed'] for p in r['parts'])/8 for r in route_rows],default=0) if counts and counts[0]==8 else 0
  cover=10*counts[2]/8 if 'cover' in phases and abs(phases['cover']['cover_encoder_m']+COVER_TRAVEL)<.0003 else 0
  rework_ok=self.rework_active and self.rework_release_contact_s>=.08 and self.rework_disconnected_s>=.2 and self.rework_preserved and self.rework_uncovered
  rework=10*counts[3]/8 if rework_ok else 0
  deployment=10 if phase_pass['released'] else 0
  if self.violations:assembly=retention=routing=cover=rework=deployment=0.
  score=assembly+retention+routing+cover+rework+deployment
  full=all(phase_pass.values()) and routing==10 and rework==10 and cover==10 and not self.violations
  return dict(contract=self.order['contract'],score=float(score),assembly_points=assembly,retention_points=retention,routing_points=routing,cover_points=cover,rework_points=rework,deployment_points=deployment,grasp_evidence=self.grasp_evidence,peak_mating_force_N=self.insert_forces,checkpoint_counts=counts,phase_pass=phase_pass,rework_evidence=dict(branch=self.rework_branch,release_tool_contact_seconds=self.rework_release_contact_s,disconnected_seconds=self.rework_disconnected_s,other_connections_preserved=bool(self.rework_preserved),cover_opened=bool(self.rework_uncovered)),final_parts=self.metrology(),violations=self.violations,full_pass=bool(full),empirical_hardware_validation=False)

 def save(self):
  (self.out/'commands.jsonl').write_text(''.join(json.dumps(x,allow_nan=False)+'\n' for x in self.commands))
  (self.out/'trace.jsonl').write_text(''.join(json.dumps(x)+'\n' for x in self.trace));(self.out/'checkpoints.json').write_text(json.dumps(self.checkpoints,indent=2));(self.out/'result.json').write_text(json.dumps(self.result(),indent=2))
  np.savez_compressed(self.out/'station-state.npz',qpos=self.d.qpos,qvel=self.d.qvel,ctrl=self.d.ctrl,qacc_warmstart=self.d.qacc_warmstart,time_s=np.array(self.d.time),rng_state=np.array(json.dumps(self.rng.bit_generator.state)))
  (self.out/'routing.json').write_text(json.dumps(self.routing(),indent=2)+'\n')
  if self.renderer:self.renderer.close();self.renderer=None
