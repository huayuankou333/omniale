"""O5 nominal contact cell. Geometry is sourced; constitutive values are assumptions."""
from pathlib import Path
import copy, hashlib, json, math, os, sys
import xml.etree.ElementTree as E
import numpy as np
from scipy.spatial.transform import Rotation as R
import mujoco
from scipy.spatial import ConvexHull
import trimesh

P=Path(os.environ.get('O5_SOURCE_ROOT','/work'))
JOINTS=['shoulder_pan_joint','shoulder_lift_joint','elbow_joint','wrist_1_joint','wrist_2_joint','wrist_3_joint']
RX=R.from_euler('x',90,degrees=True).as_matrix()
ROTS={2:RX@R.from_euler('y',180,degrees=True).as_matrix(),6:R.from_euler('x',-90,degrees=True).as_matrix()}
TOOL_R=np.array([[0.,1.,0.],[1.,0.,0.],[0.,0.,-1.]])
COVER_TRAVEL=.50
REWORK_PORTAL_Y=.425
REWORK_PORTAL_HALF=.012
CLAMP_TRAVEL=.475
CLAMP_SPEED=.060
CLAMP_PARK_TRAVEL=.800
CLAMP_PARK_SPEED=.100
SPLICE_CLEARANCE=.00015
FORMER_ADVANCE=float(np.hypot(.120,.082))
FORMER_X_TRAVEL=.120
FORMER_Y_TRAVEL=.082
FORMER_NORMAL_SHIFT=0.
FORMER_SHIFT=.036
FORMER_SPEED=.050
def clamp_travel(name):
 if name.endswith('_2'):return .200
 if name.endswith('_rework'):return .380
 return CLAMP_TRAVEL
HOME={'left':[-2.59803225646,-1.03424256579,-1.90811792301,-1.77002849159,1.57079632679,-.22723592967],
      'right':[.38286065765,-1.03424256579,-1.90811792301,-1.77002849159,1.57079632679,1.15365698444]}
MARKERS={2:[[-.006,.0290,0],[.006,.0290,0],[0,.0290,.004]],6:[[-.006,-.0007,-.007],[.006,-.0007,-.007],[-.006,-.0007,.007]]}
PROXY_MASK=sum(1<<(i+3) for i in range(8));TIP_MASK=sum(1<<(i+16) for i in range(8));GENERAL_MASK=1|4|PROXY_MASK|TIP_MASK
def vec(v):return ' '.join(f'{x:.12g}' for x in np.ravel(v))
def quat(mat):
 q=R.from_matrix(mat).as_quat();return vec(q[[3,0,1,2]])

def add_robot(root,side,base):
 robot=E.parse(P/'components/ur5e-2f85.xml').getroot()
 refs={'name','class','childclass','mesh','material','joint','joint1','joint2','body1','body2','geom1','geom2','site','tendon'}
 for mesh in robot.find('asset').findall('mesh'):mesh.set('file',str(P/'components/robot-assets'/mesh.get('file')))
 for node in robot.iter():
  for k in refs:
   if k in node.attrib:node.set(k,side+'_'+node.get(k))
 # A removable machined push lip on each original finger transmits insertion
 # force by contact with the rear housing, rather than relying on pad friction.
 # The lip neither locks nor follows a connector; opening the fingers clears it.
 for pad in ['left','right']:
  body=robot.find(f'.//body[@name="{side}_gripper_{pad}_pad"]')
  E.SubElement(body,'geom',name=side+f'_gripper_{pad}_pad_push_lip',type='box',pos='.001 -.0086 .0259',size='.0015 .002 .001',mass='.000065',friction='.4 .005 .0001',solref='.003 1',rgba='.38 .42 .47 1')
  inert=body.find('inertial');mass=float(inert.get('mass'));com=np.fromstring(inert.get('pos'),sep=' ');q=np.fromstring(inert.get('quat','1 0 0 0'),sep=' ');rr=R.from_quat(q[[1,2,3,0]]).as_matrix();ii=rr@np.diag(np.fromstring(inert.get('diaginertia'),sep=' '))@rr.T;extra=.000065;pc=np.array([.001,-.0086,.0259]);nc=(mass*com+extra*pc)/(mass+extra)
  parallel=lambda c:np.dot(c,c)*np.eye(3)-np.outer(c,c)
  ni=ii+mass*parallel(com-nc)+extra*parallel(pc-nc)+np.diag(extra/3*np.array([.002**2+.001**2,.0015**2+.001**2,.0015**2+.002**2]));inert.attrib.clear();inert.set('mass',str(mass+extra));inert.set('pos',vec(nc));inert.set('fullinertia',vec([ni[0,0],ni[1,1],ni[2,2],ni[0,1],ni[0,2],ni[1,2]]))
 for tag in ('asset','default','contact','tendon','equality','actuator','sensor'):
  if robot.find(tag) is None:continue
  dst=root.find(tag)
  if dst is None:dst=E.SubElement(root,tag)
  dst.extend(copy.deepcopy(list(robot.find(tag))))
 arm=copy.deepcopy(robot.find('worldbody/body'));arm.set('pos',vec(base));root.find('worldbody').append(arm)
 # Mounting contacts use the manufacturer's exclusions. No manipulation exclusions.
 E.SubElement(root.find('contact'),'exclude',body1=side+'_base_link_inertia',body2=side+'_shoulder_link')

def add_connector(root,name,n,moving,pos,rot,compliant=True,part_index=0):
 part=f'c3d-at{6 if moving else 4:02}-{n}{"s" if moving else "p"}-01-000'
 comp=E.parse(P/'components/connectors'/part/'component.xml').getroot()
 body=E.SubElement(root.find('worldbody'),'body',name=name,pos=vec(pos),quat=quat(rot))
 if moving:E.SubElement(body,'freejoint',name=name+'_free')
 inert=copy.deepcopy(comp.find('worldbody/body/inertial'));body.append(inert)
 if moving:
  E.SubElement(body,'site',name=name+'_rear',pos=vec([0,.028,0] if n==2 else [0,0,0]),size='.001',rgba='0 1 1 1')
  E.SubElement(body,'site',name=name+'_grasp',pos=vec([0,.0374,0] if n==2 else [0,-.009,0]),size='.001')
 src=comp.find('deformable/flex');v=np.fromstring(src.get('vertex'),sep=' ').reshape(-1,3);f=np.fromstring(src.get('element'),sep=' ',dtype=int).reshape(-1,3)
 # Supplier STEP merges the elastomer seal and spring latch into one solid.
 # Retain all faces, with separate assumed normal compliance for the seal band.
 center=v[f].mean(axis=1)
 seal=((center[:,1]>=.0003)&(center[:,1]<=.0052)) if n==2 else (center[:,1]>=.026)
 latch=((center[:,2]>.006)&(center[:,1]>.007)) if n==2 else ((center[:,2]>.0096)&(center[:,1]<.024))
 if not moving:seal[:]=False;latch[:]=False
 vertex_bodies=np.array([name]*len(v),dtype=object)
 if moving:
  # Eight independently compressible seal sectors retain their CAD surfaces.
  # Springs use N/m and real massive slide DOFs; no state-dependent grasp/mate constraint.
  vertex_seal=((v[:,1]>=.0003)&(v[:,1]<=.0052)) if n==2 else (v[:,1]>=.026)
  vertex_latch=((v[:,2]>.006)&(v[:,1]>.007)) if n==2 else ((v[:,2]>.0096)&(v[:,1]<.024))
  angle=np.arctan2(v[:,2],v[:,0]);sector=np.floor((angle+np.pi)*8/(2*np.pi)).astype(int)%8
  for k in range(8):
   mask=vertex_seal&(sector==k)
   if not mask.any():continue
   bn=name+f'_seal_sector_{k}';a=-np.pi+(k+.5)*2*np.pi/8
   # A seal lip folds toward the wire end while compressing radially. A purely
   # radial slide makes the supplier's square leading lip kinematically jam.
   axis=np.array([np.cos(a),-1 if n==2 else 1,np.sin(a)])/np.sqrt(2)
   patch=E.SubElement(body,'body',name=bn)
   E.SubElement(patch,'inertial',pos=vec(v[mask].mean(axis=0)),mass='.00005',diaginertia='.000000001 .000000001 .000000001')
   E.SubElement(patch,'joint',name=bn+'_compression',type='slide',axis=vec(axis),range='-.0018 .0001',stiffness='800',damping='1.2',armature='.0001')
   vertex_bodies[mask]=bn
  if latch.any():
   bn=name+'_latch';pivot=np.array([0,.007,.006] if n==2 else [0,.024,.0096]);tab=E.SubElement(body,'body',name=bn)
   E.SubElement(tab,'inertial',pos=vec(center[latch].mean(axis=0)),mass='.0002',diaginertia='.000000002 .000000002 .000000002')
   E.SubElement(tab,'joint',name=bn+'_hinge',type='hinge',pos=vec(pivot),axis='1 0 0',range='-.35 .05' if n==2 else '-.05 .35',stiffness='.02',damping='.001',armature='.000002')
   vertex_bodies[vertex_latch]=bn
 if moving:
  # Partition the assumed uniform-density mass instead of adding fictitious mass.
  m0=float(inert.get('mass'));c0=np.fromstring(inert.get('pos'),sep=' ');ii=np.fromstring(inert.get('fullinertia'),sep=' ');I0=np.array([[ii[0],ii[3],ii[4]],[ii[3],ii[1],ii[5]],[ii[4],ii[5],ii[2]]])
  parallel=lambda c:np.dot(c,c)*np.eye(3)-np.outer(c,c)
  mass=m0;first=m0*c0;originI=I0+m0*parallel(c0)
  for sub in body.findall('body/inertial'):
   sm=float(sub.get('mass'));sc=np.fromstring(sub.get('pos'),sep=' ');si=np.diag(np.fromstring(sub.get('diaginertia'),sep=' '));mass-=sm;first-=sm*sc;originI-=si+sm*parallel(sc)
  cc=first/mass;ii=originI-mass*parallel(cc);inert.set('mass',str(mass));inert.set('pos',vec(cc));inert.set('fullinertia',vec([ii[0,0],ii[1,1],ii[2,2],ii[0,1],ii[0,2],ii[1,2]]))
 # Shared vertices give a continuous reduced deformation field. Independent rigid
 # face patches create artificial edges which can wedge in the receptacle mouth.
 # Preserve every triangle and its exact body interpolation, but separate the
 # single-body triangles from the small mixed-body bridge. MuJoCo can treat
 # those groups as rigid flexes instead of building deformation Jacobians for
 # all the housing vertices. Shared boundary coordinates still coincide.
 groups=[]
 if moving:
  fb=vertex_bodies[f];uniform=np.all(fb==fb[:,0,None],axis=1)
  for bn in sorted(set(vertex_bodies)):
   mask=uniform&(fb[:,0]==bn)
   if mask.any():groups.append((bn,mask,True))
  if (~uniform).any():groups.append(('bridge',~uniform,False))
 else:groups=[(name,np.ones(len(f),bool),True)]
 for group,mask,rigid in groups:
  indices,faces=np.unique(f[mask],return_inverse=True);points=v[indices];binding=group if rigid else ' '.join(vertex_bodies[indices]);suffix='_'+group.replace(name,'') if moving else ''
  flex=E.SubElement(root.find('deformable'),'flex',name=name+'_surface'+suffix,body=binding,dim='2',radius='.000005',vertex=vec(points),element=' '.join(map(str,faces.ravel())),rgba='.22 .43 .64 1' if moving else '.67 .63 .48 1')
  E.SubElement(flex,'contact',selfcollide='none',internal='false',contype='2' if moving else '4',conaffinity='4' if moving else str(1|2|TIP_MASK),condim='3',friction='.15 .005 .0001',solref='.002 1',solimp='.95 .99 .0001')
 if moving:
  # Source-preserving collision levels: exact concave surfaces for mating;
  # conservative 3-mm CAD cross-section hulls for supports, fingers and cables.
  # This avoids hundreds of redundant triangle/plane constraints at a flat tray.
  geometry_id=hashlib.sha256(v.tobytes()+f.tobytes()).hexdigest()[:16]
  cache=P/'complete-v2/proxies-with-moving-latch'/part/geometry_id;cache.mkdir(parents=True,exist_ok=True)
  mesh=trimesh.Trimesh(v,f[~latch],process=False);bounds=np.linspace(v[:,1].min(),v[:,1].max(),12)
  for j,(lo,hi) in enumerate(zip(bounds[:-1],bounds[1:])):
   target=cache/f'band-{j}.obj'
   if not target.exists():
    points=v[(v[:,1]>=lo)&(v[:,1]<=hi)&~vertex_latch]
    for y in [lo+1e-9,hi-1e-9]:
     seg=trimesh.intersections.mesh_plane(mesh,plane_origin=[0,y,0],plane_normal=[0,1,0]);points=np.r_[points,seg.reshape(-1,3)]
    points=np.unique(np.round(points,9),axis=0)
    if len(points)<4:continue
    hull=ConvexHull(points);tmp=target.with_name(target.stem+f'-{os.getpid()}.obj');trimesh.Trimesh(points,hull.simplices,process=False).export(tmp);os.replace(tmp,target)
   assetname=name+f'_proxy_{j}';E.SubElement(root.find('asset'),'mesh',name=assetname,file=str(target))
   E.SubElement(body,'geom',name=assetname,type='mesh',mesh=assetname,group='3',contype=str(1<<(part_index+3)),conaffinity=str((1|PROXY_MASK|TIP_MASK)^(1<<(part_index+16))),mass='0',friction='.65 .005 .0001',solref='.003 1',rgba='0 0 0 0')
  if latch.any():
   target=cache/'latch.obj'
   if not target.exists():
    points=v[vertex_latch];hull=ConvexHull(points);tmp=target.with_name(f'latch-{os.getpid()}.obj');trimesh.Trimesh(points,hull.simplices,process=False).export(tmp);os.replace(tmp,target)
   assetname=name+'_latch_proxy';E.SubElement(root.find('asset'),'mesh',name=assetname,file=str(target))
   E.SubElement(tab,'geom',name=assetname,type='mesh',mesh=assetname,group='3',contype=str(1<<(part_index+3)),conaffinity=str(1|PROXY_MASK|TIP_MASK),mass='0',friction='.45 .005 .0001',rgba='0 0 0 0')
 return body

LOADED_ROD_QUATERNIONS={}

def cable_chain(parent,points,name,equality,endpoint_body,endpoint_local,radius,part_index,pins):
 """Straight spring reference; commissioning curvature is a joint configuration."""
 points=np.asarray(points);node=parent;lengths=np.linalg.norm(np.diff(points,axis=0),axis=1)
 ei=.0003 if pins==6 else .0001
 linear_mass=pins*(8960*.823e-6+1200*(np.pi*.001**2-.823e-6))
 previous_frame=np.eye(3)
 for i,(a,b) in enumerate(zip(points[:-1],points[1:])):
  length=lengths[i];tangent=(b-a)/length
  old=previous_frame[:,2];axis=np.cross(old,tangent);s=np.linalg.norm(axis);cos=np.clip(np.dot(old,tangent),-1,1)
  if s<1e-12:
   turn=np.eye(3) if cos>0 else R.from_rotvec(previous_frame[:,0]*np.pi).as_matrix()
  else:turn=R.from_rotvec(axis/s*np.arctan2(s,cos)).as_matrix()
  frame=turn@previous_frame
  q=R.from_matrix(previous_frame.T@frame).as_quat()
  LOADED_ROD_QUATERNIONS[f'{name}_bend_{i}']=q[[3,0,1,2]]
  node=E.SubElement(node,'body',name=f'{name}_{i}',pos=vec(points[0] if i==0 else [0,0,lengths[i-1]]))
  dual=length if i==0 else (lengths[i-1]+length)/2
  E.SubElement(node,'joint',name=f'{name}_bend_{i}',type='ball',damping='.00003',stiffness='0' if i==0 else str(ei/dual),armature='.00000001')
  mass=linear_mass*length;ip=mass*(3*radius**2+length**2)/12;ia=mass*radius**2/2
  E.SubElement(node,'inertial',pos=vec([0,0,length/2]),mass=str(mass),diaginertia=vec([ip,ip,ia]))
  tip=i==len(points)-2
  E.SubElement(node,'geom',name=f'{name}_rod_{i}',type='capsule',fromto=vec([0,0,0,0,0,length]),size=str(radius),mass='0',contype=str(1<<(part_index+16)) if tip else '1',conaffinity=str(GENERAL_MASK^(1<<(part_index+3))) if tip else str(GENERAL_MASK),friction='.5 .003 .0001',solref='.003 1',rgba='.8 .22 .08 1')
  previous_frame=frame
 E.SubElement(node,'site',name=name+'_end',pos=vec([0,0,lengths[-1]]),size='.0005')
 E.SubElement(equality,'connect',name=name+'_termination',site1=name+'_end',site2=endpoint_body+'_rear',solref='.001 1',solimp='.99 .999 .0001')
 E.SubElement(node,'site',name=name+'_crimp_axis',pos=vec([0,0,lengths[-1]-.015]),size='.0005')
 E.SubElement(equality,'connect',name=name+'_termination_axis',site1=name+'_crimp_axis',site2=endpoint_body+'_leadout',solref='.001 1',solimp='.99 .999 .0001')
 return node

def polyline(a,b,slack=.03,count=12,cut_length=None):
 # Preserve the previous declared cut length while replacing its abrupt last
 # hinge by a smooth cubic loading arch and a 20-mm straight lead-out.
 a=np.asarray(a);b=np.asarray(b);t=np.linspace(0,1,count)
 old=(1-t[:,None])*a+t[:,None]*b;old[:,2]+=slack*np.sin(t*np.pi)
 old[-2]=old[-1]+np.array([0.,0.,np.linalg.norm(old[-1]-old[-2])])
 target=np.linalg.norm(np.diff(old,axis=0),axis=1).sum() if cut_length is None else float(cut_length)
 c=b+np.array([0.,0.,.020]);u=np.linspace(0,1,count-1)[:,None]
 def curve(height):
  p=(1-u)**3*a+3*(1-u)**2*u*(a+[0,0,height])+3*(1-u)*u*u*(c+[0,0,height])+u**3*c
  return np.r_[p,b[None]]
 low=0.;high=1.
 for _ in range(60):
  mid=(low+high)/2;p=curve(mid)
  if np.linalg.norm(np.diff(p,axis=0),axis=1).sum()<target:low=mid
  else:high=mid
 return curve((low+high)/2)

def build(out,seed=0,cables=True,only_pair=None,dt=.002,only_part=None):
 out=Path(out);out.mkdir(parents=True,exist_ok=True);LOADED_ROD_QUATERNIONS.clear()
 root=E.Element('mujoco',model='O5 nominal dual UR5e harness assembly')
 E.SubElement(root,'compiler',angle='radian',autolimits='true',balanceinertia='true')
 E.SubElement(root,'option',timestep=str(dt),integrator='implicitfast',cone='elliptic',impratio='10',iterations='100',tolerance='1e-10')
 E.SubElement(root,'size',memory='512M')
 vis=E.SubElement(root,'visual');E.SubElement(vis,'global',offwidth='1280',offheight='960');E.SubElement(vis,'headlight',ambient='.3 .3 .3')
 E.SubElement(root,'asset');world=E.SubElement(root,'worldbody');E.SubElement(root,'deformable')
 default=E.SubElement(root,'default');E.SubElement(default,'geom',contype='1',conaffinity=str(GENERAL_MASK))
 E.SubElement(root,'equality')
 E.SubElement(world,'light',pos='0 .1 2',dir='0 0 -1')
 E.SubElement(world,'geom',name='floor',type='plane',size='2 2 .1',rgba='.15 .17 .2 1')
 E.SubElement(world,'geom',name='table',type='box',pos='0 .25 .575',size='.75 .6 .025',rgba='.3 .34 .4 1')
 E.SubElement(world,'geom',name='panel',type='box',pos='0 .285 .67',size='.22 .26 .01',rgba='.72 .74 .76 1')
 E.SubElement(world,'camera',name='overview',pos='1.35 -1.25 1.65',xyaxes='.68 .73 0 -.40 .37 .84',fovy='46')
 E.SubElement(world,'camera',name='metrology',pos='0 .28 1.55',xyaxes='1 0 0 0 1 0',fovy='52')
 if not only_pair:
  add_robot(root,'left',[-.50,-.13,.6]);add_robot(root,'right',[.50,-.13,.6])
  for side,x in [('left',-.31),('right',.31)]:
   sign=-1 if side=='left' else 1
   # An open inner-front notch provides the low cable-routing approach.
   # The outer strip still supports every original loading nest.
   E.SubElement(world,'geom',name=side+'_tray',type='box',pos=vec([sign*.323,.310,.71]),size='.034 .235 .01',rgba='.43 .45 .48 1')
   E.SubElement(world,'geom',name=side+'_tray_inner',type='box',pos=vec([sign*.276,.3425,.71]),size='.013 .2025 .01',rgba='.43 .45 .48 1')
 rng=np.random.default_rng(seed);parts=[]
 for arm,x in [('left',-.145),('right',.145)]:
  for i,y in enumerate([.10,.22,.34,.46]):
   n=6 if i==0 else 2;name=f'{arm}_{i}'
   if only_part and name!=only_part:continue
   if only_pair and (arm!='left' or n!=only_pair or i!=(0 if n==6 else 1)):continue
   receiver_rot=ROTS[n] if n==6 else RX
   recpos=np.array([x,y,.74 if n==6 else .71])
   target=recpos+receiver_rot@np.array([0,-.0141 if n==6 else .0021,0])
   initial=np.array([-.31 if arm=='left' else .31,y,.75145 if n==6 else .72028])
   if seed:initial[:2]+=rng.uniform(-.0002,.0002,2)
   if only_pair:initial=target+np.array([0,0,.03])
   add_connector(root,name+'_socket',n,False,recpos,receiver_rot)
   # The installed receptacle is clamped above the panel on an authored
   # pedestal. Its top lies 50 um below the source CAD's lowest rear face.
   if not only_pair:
    bottom=recpos[2]-(.0443 if n==6 else .02258)-.00005
    E.SubElement(world,'geom',name=name+'_socket_pedestal',type='box',pos=vec([x,y,(.680+bottom)/2]),size=vec([.012,.014,(bottom-.680)/2]),rgba='.32 .34 .37 1')
   b=add_connector(root,name,n,True,initial,ROTS[n],part_index=len(parts))
   E.SubElement(b,'site',name=name+'_leadout',pos=vec([0,.043,0] if n==2 else [0,-.015,0]),size='.0005')
   if not only_pair:
    # A machined pallet nest locates the lower housing during jaw closure.
    # Walls stay below the grasping band and do not attach the part.
    # The lower flange is wider than the locating band. Start the pocket
    # walls 3 mm above the tray and size them to the CAD sections in that band.
    xmin,xmax=(-.00765,.00765) if n==2 else (-.0093,.0093)
    ymin,ymax=(-.00595,.0092) if n==2 else (-.0093,.0126)
    nominal_x=-.31 if arm=='left' else .31
    for axis,lo,hi in [(0,xmin,xmax),(1,ymin,ymax)]:
     for wall,edge in [(-1,lo),(1,hi)]:
      pos=np.array([nominal_x,y,.728]);pos[axis]+=edge+wall*.0013;size=np.array([max(abs(xmin),abs(xmax))+.003,max(abs(ymin),abs(ymax))+.003,.005]);size[axis]=.001
      E.SubElement(world,'geom',name=name+f'_pallet_nest_{axis}_{wall}',type='box',pos=vec(pos),size=vec(size),rgba='.35 .38 .42 1')
    E.SubElement(world,'camera',name='stage_'+name,pos=vec([nominal_x,y,1.06]),xyaxes='1 0 0 0 1 0',fovy='12')
    E.SubElement(world,'camera',name='socket_'+name,pos=vec([x,y,1.06]),xyaxes='1 0 0 0 1 0',fovy='12')
    # Installation extrinsics stay fixed across randomized loading positions.
    # Calibration must not encode the hidden sampled connector displacement.
    nominal_initial=np.array([nominal_x,y,initial[2]])
    cp=np.array([nominal_x+.12,y+.12,initial[2]+.16]);look=nominal_initial+np.array([0,0,.015]);cz=cp-look;cz/=np.linalg.norm(cz);cx=np.cross([0,0,1],cz);cx/=np.linalg.norm(cx);cy=np.cross(cz,cx)
    E.SubElement(world,'camera',name='stage_back_'+name,pos=vec(cp),xyaxes=vec(np.r_[cx,cy]),fovy='25')
    cp=np.array([nominal_x-.12,y-.12,initial[2]+.16]);cz=cp-look;cz/=np.linalg.norm(cz);cx=np.cross([0,0,1],cz);cx/=np.linalg.norm(cx);cy=np.cross(cz,cx)
    E.SubElement(world,'camera',name='stage_front_'+name,pos=vec(cp),xyaxes=vec(np.r_[cx,cy]),fovy='25')
    for station,px,pz in [('hand',nominal_x,initial[2]+.05),('mate',x,target[2]+.015),('rear',x,target[2]+(.025 if n==2 else .010)),('rear_back',x,target[2]+(.025 if n==2 else .010))]:
     cp=np.array([px,y+(.15 if station=='rear_back' else -.15),target[2]+.16]) if station.startswith('rear') else np.array([px+(.25 if arm=='left' else -.25),y-.45,.8003]) if n==2 else np.array([px+.02,y-.36,.87]);look=np.array([px,y,pz]);cz=cp-look;cz/=np.linalg.norm(cz);cx=np.cross([0,0,1],cz);cx/=np.linalg.norm(cx);cy=np.cross(cz,cx)
     E.SubElement(world,'camera',name=station+'_'+name,pos=vec(cp),xyaxes=vec(np.r_[cx,cy]),fovy='25' if station.startswith('rear') else '20' if station=='mate' else '12')
    if n==2:
     plunger=E.SubElement(world,'body',name=name+'_release_plunger',pos=vec([x,y+.020,target[2]+.023]))
     E.SubElement(plunger,'joint',name=name+'_release_slide',type='slide',axis='0 -1 0',range='0 .009',damping='2')
     E.SubElement(plunger,'geom',name=name+'_release_tip',type='box',size='.003 .002 .002',mass='.015',rgba='.3 .4 .45 1')
     E.SubElement(root.find('actuator'),'position',name=name+'_release_motor',joint=name+'_release_slide',kp='1000',kv='10',ctrlrange='0 .009',forcerange='-6 6')
   # Three noncollinear visible spheres are physical optical targets, not state flags.
   for j,point in enumerate(MARKERS[n]):
    E.SubElement(b,'geom',name=name+f'_marker_{j}',type='sphere',pos=vec(point),size='.0007',contype='0',conaffinity='0',mass='0',rgba=['1 0 .8 1','0 1 .8 1','1 1 0 1'][j])
   hand_markers=[[-.005,.007,-.0073],[.005,.007,-.0073],[0,.014,-.0073]] if n==2 else [[-.006,.017,-.0105],[.006,.017,-.0105],[0,.024,-.0105]]
   for j,point in enumerate(hand_markers):E.SubElement(b,'geom',name=name+f'_hand_marker_{j}',type='sphere',pos=vec(point),size='.0007',contype='0',conaffinity='0',mass='0',rgba=['1 .02 .02 1','.02 1 .02 1','.02 .02 1 1'][j])
   parts.append(dict(id=name,arm=arm,pins=n,initial_origin_m=initial.tolist(),target_origin_m=target.tolist(),rotation=ROTS[n].tolist(),receiver_origin_m=recpos.tolist(),receiver_rotation=receiver_rot.tolist(),grasp_local_m=[0,.0374,0] if n==2 else [0,-.009,0],hand_markers_m=hand_markers,rear_markers_m=MARKERS[n]))
 if cables and not only_pair:
  for arm,sign in [('left',-1),('right',1)]:
   batch=[p for p in parts if p['arm']==arm];a=np.array([sign*.245,.285,.707])
   hub=E.SubElement(world,'body',name=arm+'_junction',pos=vec(a));E.SubElement(hub,'freejoint',name=arm+'_junction_free');E.SubElement(hub,'geom',name=arm+'_junction_housing',type='sphere',size='.008',mass='.003',solref='.004 1',solimp='.99 .999 .0001',rgba='.15 .15 .15 1')
   # The branched termination is held in a physical loading nest. Two keeper
   # rails leave a 7-mm cable slot while retaining the 16-mm junction. The free
   # body can move within the cage; no world equality anchors the harness.
   E.SubElement(world,'geom',name=arm+'_junction_pedestal',type='box',pos=vec([sign*.245,.285,.6475]),size='.014 .014 .0475',rgba='.28 .30 .32 1')
   floor_top=.707-.008-SPLICE_CLEARANCE
   E.SubElement(world,'geom',name=arm+'_junction_nest_floor',type='box',pos=vec([sign*.245,.285,floor_top-.0025]),size='.014 .014 .0025',solref='.004 1',solimp='.99 .999 .0001',rgba='.25 .27 .3 1')
   for axis in [0,1]:
    for wall in [-1,1]:
     pos=np.array([sign*.245,.285,.709]);pos[axis]+=wall*(.008+SPLICE_CLEARANCE+.002);size=np.array([.014,.014,.020]);size[axis]=.002
     E.SubElement(world,'geom',name=arm+f'_nest_wall_{axis}_{wall}',type='box',pos=vec(pos),size=vec(size),solref='.004 1',solimp='.99 .999 .0001',rgba='.25 .27 .3 1')
   keeper_bottom=.707+np.sqrt(.008**2-.0035**2)+SPLICE_CLEARANCE
   for keeper in [-1,1]:
    E.SubElement(world,'geom',name=arm+f'_junction_keeper_{keeper}',type='box',pos=vec([sign*.245+keeper*.00875,.285,keeper_bottom+.0035]),size='.00525 .014 .0035',solref='.004 1',solimp='.99 .999 .0001',rgba='.25 .27 .3 1')
   for p in batch:
    rot=np.array(p['rotation']);rear=np.array([0,.028,0] if p['pins']==2 else [0,0,0]);b=np.array(p['initial_origin_m'])+rot@rear
    # Authored cut lengths include a handling allowance for the captive splice.
    # They are engineering inputs, not measured vehicle production dimensions.
    cut_length={0:.300,1:.190,2:.280,3:.260}[int(p['id'][-1])]
    pts=polyline(a,b,slack=.125 if p['id'].endswith('_2') else .065 if p['pins']==6 else .05,count=12,cut_length=cut_length)-a
    cable_chain(hub,pts,arm+f'_cable_{p["id"][-1]}',root.find('equality'),p['id'],rear,.003 if p['pins']==6 else .002,parts.index(p),p['pins'])
   for j,p in enumerate(batch):
    for q in batch[j+1:]:
     E.SubElement(root.find('contact'),'exclude',body1=arm+f'_cable_{p["id"][-1]}_0',body2=arm+f'_cable_{q["id"][-1]}_0')
  # Routing combs and a shared narrow access corridor have actual contact geometry.
  for x in [-.235,0,.235]:
   for y in [.16,.405]:E.SubElement(world,'geom',name=f'route_post_{x}_{y}',type='cylinder',pos=vec([x,y,.728]),size='.016 .048',rgba='.18 .19 .2 1')
  for side,sign in [('left',-1),('right',1)]:
   for j,y in enumerate([.10,.22,.34,.46]):E.SubElement(world,'geom',name=side+f'_route_saddle_{j}',type='box',pos=vec([sign*.17,.32925 if j==2 else .4775 if j==3 else y,.6875]),size=vec([.012,.040 if j==2 else .035 if j==3 else .045,.0075]),rgba='.32 .33 .35 1')
   # The rounded bend former advances under the unloaded cable before roof
   # closure, and withdraws before robot access. A second slide selects the
   # north-facing support for selective rework. The free cable is never attached.
   former=E.SubElement(world,'body',name=side+'_bend_former',
       pos=vec([sign*.055,.240,.738]),gravcomp='1')
   E.SubElement(former,'joint',name=side+'_former_advance',type='slide',
       axis=vec([sign*FORMER_X_TRAVEL/FORMER_ADVANCE,FORMER_Y_TRAVEL/FORMER_ADVANCE,0]),range=vec([0,FORMER_ADVANCE]),damping='5')
   E.SubElement(former,'joint',name=side+'_former_shift',type='slide',
       axis='0 1 0',range=vec([0,FORMER_SHIFT]),damping='5')
   E.SubElement(former,'geom',name=side+'_bend_former_crown',type='cylinder',
       quat=vec([np.sqrt(.5),0,np.sqrt(.5),0]),size='.016 .009',mass='.035',
       friction='.4 .003 .0001',solref='.004 1',rgba='.32 .35 .38 1')
   E.SubElement(former,'geom',name=side+'_bend_former_pedestal',type='box',
       pos='0 0 -.021',size='.009 .008 .021',mass='.065',
       friction='.4 .003 .0001',solref='.004 1',rgba='.32 .35 .38 1')
   for suffix,travel in [('advance',FORMER_ADVANCE),('shift',FORMER_SHIFT)]:
    E.SubElement(root.find('actuator'),'position',name=side+'_former_'+suffix+'_motor',
        joint=side+'_former_'+suffix,kp='2000',kv='15',ctrlrange=vec([0,travel]),forcerange='-3 3')
   E.SubElement(world,'geom',name=side+'_rework_saddle',type='box',pos=vec([sign*.17,REWORK_PORTAL_Y,.6875]),size=vec([.012,.009,.0075]),rgba='.35 .32 .28 1')
   E.SubElement(world,'geom',name=side+'_rework_diverter',type='cylinder',pos=vec([sign*.1775,.395,.735]),size='.016 .055',rgba='.35 .32 .28 1')
   # Descending side guards capture the elevated loop before roof contact.
   # Contact-operated cable retainers are tooling, not cable attachments. The
   # narrow roof presses a routed wire below the cover envelope and remains
   # independently openable for selective branch rework. Nominal dimensions
   # and a bounded 3-N drive are engineering assumptions, not vendor tooling.
   for label,y,half in [('0',.10,.050),('1',.22,.045),('2',.32925,.04325),('3',.4775,.0375),('rework',REWORK_PORTAL_Y,.011)]:
    name=side+'_'+label
    travel=clamp_travel(name)
    clamp=E.SubElement(world,'body',name=name+'_route_clamp',pos=vec([sign*.17,y+CLAMP_PARK_TRAVEL,(.784 if label=='0' else .778)+travel]),gravcomp='1')
    E.SubElement(clamp,'joint',name=name+'_clamp_carriage',type='slide',axis='0 1 0',range=vec([-CLAMP_PARK_TRAVEL,0]),damping='10')
    capture=label in ('2','rework')
    E.SubElement(clamp,'joint',name=name+'_clamp_slide',type='slide',axis='0 0 1',range=vec([-travel,0]),damping='5' if capture else '10')
    half_x=.055 if label=='2' else .045 if label=='rework' else .013
    E.SubElement(clamp,'geom',name=name+'_clamp_roof',type='box',size=vec([half_x,half,.003]),mass='.070' if capture else '.060',friction='.4 .003 .0001',solref='.004 1',rgba='.35 .40 .43 1')
    if capture:
     for wall in [-1,1]:
      E.SubElement(clamp,'geom',name=name+f'_clamp_guard_{wall}',type='box',
          pos=vec([0,wall*(half+.0015),-.049]),size=vec([half_x,.0015,.049]),
          mass='.040',friction='.4 .003 .0001',solref='.004 1',rgba='.35 .40 .43 1')
    E.SubElement(root.find('actuator'),'position',name=name+'_clamp_motor',joint=name+'_clamp_slide',kp='2000',kv='5' if capture else '25',ctrlrange=vec([-travel,0]),forcerange='-.6 .6' if capture else '-3 3')
    E.SubElement(root.find('actuator'),'position',name=name+'_clamp_carriage_motor',joint=name+'_clamp_carriage',kp='2000',kv='25',ctrlrange=vec([-CLAMP_PARK_TRAVEL,0]),forcerange='-30 30')
 if not only_pair:
  cover=E.SubElement(world,'body',name='cover',pos='0 .285 1.30',gravcomp='1')
  E.SubElement(cover,'joint',name='cover_slide',type='slide',axis='0 0 1',range='-.50 0',damping='20')
  E.SubElement(cover,'geom',name='cover_plate',type='box',size='.21 .25 .006',mass='1',rgba='.6 .65 .7 .3',friction='.4 .003 .0001')
  E.SubElement(root.find('actuator'),'position',name='cover_motor',joint='cover_slide',kp='2000',kv='100',ctrlrange='-.50 0',forcerange='-40 40')
 for site in root.iter('site'):site.set('group','5')
 # Installed receptacles and world fixtures are both immovable. Partition
 # their collision bits so the infinite floor and the bolted mounting solids
 # do not repeatedly traverse every receptacle triangle. Robot/part/cable
 # contacts with fixtures, and every mating contact, remain enabled.
 for geom in world.findall('geom'):
  geom.set('contype',str(1<<25));geom.set('conaffinity',str(GENERAL_MASK&~4))
 # Keep the same effective constraint time constant when halving dt. At the
 # production 2-ms tick MuJoCo's enabled refsafe floor already makes it 4 ms.
 for node in root.iter():
  if node.get('solref'):
   sr=np.fromstring(node.get('solref'),sep=' ')
   if 0<sr[0]<.004:sr[0]=.004;node.set('solref',vec(sr))
 path=out/'scene.xml';E.ElementTree(root).write(path,encoding='unicode')
 # qpos_spring remains the straight XML reference. The loaded keyframe only
 # specifies initial state; it never changes spring rest positions.
 model=mujoco.MjModel.from_xml_path(str(path));data=mujoco.MjData(model)
 for name,q in LOADED_ROD_QUATERNIONS.items():data.joint(name).qpos[:]=q
 for side in ['left','right']:
  if only_pair:continue
  for name,q in zip(JOINTS,HOME[side]):
   data.joint(side+'_'+name).qpos[0]=q;data.ctrl[model.actuator(side+'_'+name+'_servo').id]=q
 E.SubElement(E.SubElement(root,'keyframe'),'key',name='loaded',qpos=vec(data.qpos),ctrl=vec(data.ctrl))
 E.ElementTree(root).write(path,encoding='unicode')
 meta=dict(contract='o5-nominal-contact-v2',dt=dt,parts=parts,robot_bases={'left':[-.5,-.13,.6],'right':[.5,-.13,.6]},cables=cables,empirical_calibration=False)
 (out/'work_order.json').write_text(json.dumps(meta,indent=2)+'\n')
 return path,meta

if __name__=='__main__':
 path,meta=build(P/'complete-v2/cell',cables='--no-cables' not in sys.argv,only_pair=int(sys.argv[sys.argv.index('--pair')+1]) if '--pair' in sys.argv else None)
 m=mujoco.MjModel.from_xml_path(str(path));d=mujoco.MjData(m);mujoco.mj_resetDataKeyframe(m,d,m.key('loaded').id)
 for side in ['left','right']:
  for name,q in zip(JOINTS,HOME[side]):
   if m.joint(side+'_'+name).id>=0:
    d.joint(side+'_'+name).qpos[0]=q;d.ctrl[m.actuator(side+'_'+name+'_servo').id]=q
 mujoco.mj_forward(m,d)
 print(json.dumps(dict(nq=m.nq,nv=m.nv,ngeom=m.ngeom,nflex=m.nflex,nbody=m.nbody,nu=m.nu,ncon=d.ncon)),flush=True)
 r=mujoco.Renderer(m,960,1280);r.update_scene(d,camera='overview')
 from PIL import Image
 Image.fromarray(r.render()).save(path.parent/'initial.png');r.close()
