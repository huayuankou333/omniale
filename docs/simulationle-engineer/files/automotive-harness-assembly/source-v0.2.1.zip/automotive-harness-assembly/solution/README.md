# Author reference

This directory is retained for the repository's standard task layout. The author reference is intentionally left empty: no native model, executable policy or reference engineering documents are supplied, and the execution manifest includes no reference archive.

The solve.sh entry point reports the missing reference and exits unsuccessfully when used with Harbor's oracle agent. It is not a model submission and must not be reported as a successful solution. Historical author diagnostics remain outside the task and are not reference submissions.

Model submissions are evaluated directly by authoring/evaluate_submission.py or the Harbor verifier using independently observed physical and delivery metrics. No reference policy, reference trajectory or full reference qualification is needed. Availability and unverified complete-task feasibility are recorded in assets.json. No empirical hardware validation is claimed.
