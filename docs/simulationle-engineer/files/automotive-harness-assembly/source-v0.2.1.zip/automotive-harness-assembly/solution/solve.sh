#!/bin/sh
set -eu
if ! test -f /solution/reference/submission.json; then
    echo 'The O5 author reference is intentionally omitted. Evaluate a model submission with authoring/evaluate_submission.py; consult assets.json.' >&2
    exit 1
fi
mkdir -p /logs/artifacts
cp -R /solution/reference/. /logs/artifacts/
