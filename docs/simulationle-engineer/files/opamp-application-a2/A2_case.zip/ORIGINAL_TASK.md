Port the analog circuit below from a TSMC 0.18 µm CMOS process to the SkyWater SKY130 process.
The ported circuit will be simulated in ngspice and must meet the specifications listed below.
You may change device sizes, biasing and circuit topology, as long as the interface and test conditions are kept.

## Source design (TSMC 0.18 µm)
Transistor models: tsmc18dN (NMOS) and tsmc18dP (PMOS), BSIM3. Supply VDD = 1.8 V on the global
node `vdd`; ground is node `0`.

```spice
.subckt Cascode_Bias Iin Vbias_1 Vbias_2 Vbias_3 Vbias_4
  MN1 Vbias_4 Vbias_4 0 0 tsmc18dN w=6.66u l=360.0n as=2.997e-12 ad=2.997e-12 ps=14.22u pd=14.22u m=1
  MN0 net4 Vbias_4 0 0 tsmc18dN w=6.66u l=360.0n as=2.997e-12 ad=2.997e-12 ps=14.22u pd=14.22u m=1
  MN3 Vbias_3 Vbias_3 Vbias_4 0 tsmc18dN w=6.66u l=360.0n as=2.997e-12 ad=2.997e-12 ps=14.22u pd=14.22u m=1
  MN2 Vbias_2 Vbias_3 net4 0 tsmc18dN w=6.66u l=360.0n as=2.997e-12 ad=2.997e-12 ps=14.22u pd=14.22u m=1
  MP1 Vbias_1 Vbias_1 vdd vdd tsmc18dP w=12.195u l=360.0n as=5.48775e-12 ad=5.48775e-12 ps=25.29u pd=25.29u m=1
  MP0 Vbias_2 Vbias_2 Vbias_1 vdd tsmc18dP w=12.195u l=360.0n as=5.48775e-12 ad=5.48775e-12 ps=25.29u pd=25.29u m=1
  RR0 Iin Vbias_3 1
.ends Cascode_Bias
.subckt Opamp_2stg Vbias_3 Vbias_4 vm vout vp
  CC0 net012 vout 500f m=1
  RR0 net08 net012 3k m=1
  MP2 vout net08 vdd vdd tsmc18dP w=12.195u l=360.0n as=5.48775e-12 ad=5.48775e-12 ps=25.29u pd=25.29u m=3
  MP0 net08 net9 vdd vdd tsmc18dP w=12.195u l=360.0n as=5.48775e-12 ad=5.48775e-12 ps=25.29u pd=25.29u m=1
  MP1 net9 net9 vdd vdd tsmc18dP w=12.195u l=360.0n as=5.48775e-12 ad=5.48775e-12 ps=25.29u pd=25.29u m=1
  MN5 vout Vbias_3 net1 0 tsmc18dN w=6.66u l=360.0n as=2.997e-12 ad=2.997e-12 ps=14.22u pd=14.22u m=3
  MN4 net1 Vbias_4 0 0 tsmc18dN w=6.66u l=360.0n as=2.997e-12 ad=2.997e-12 ps=14.22u pd=14.22u m=3
  MN2 net9 vm net10 0 tsmc18dN w=6.66u l=360.0n as=2.997e-12 ad=2.997e-12 ps=14.22u pd=14.22u m=1
  MN1 net08 vp net10 0 tsmc18dN w=6.66u l=360.0n as=2.997e-12 ad=2.997e-12 ps=14.22u pd=14.22u m=1
  MN3 net12 Vbias_4 0 0 tsmc18dN w=6.66u l=360.0n as=2.997e-12 ad=2.997e-12 ps=14.22u pd=14.22u m=2
  MN0 net10 Vbias_3 net12 0 tsmc18dN w=6.66u l=360.0n as=2.997e-12 ad=2.997e-12 ps=14.22u pd=14.22u m=2
.ends Opamp_2stg
.subckt dut iref inp inn out
XI0 iref vb1 vb2 vb3 vb4 Cascode_Bias
XI1 vb3 vb4 inn out inp Opamp_2stg
.ends dut
```

## Target technology (SKY130)
- Use only the transistors sky130_fd_pr__nfet_01v8_lvt and sky130_fd_pr__pfet_01v8_lvt.
- They are subcircuits. Instantiate them with an X prefix and the terminals in the order drain gate source
  bulk, followed by the parameters W, L, nf and m, each written as name=value and separated by spaces.
- W is the total gate width and L the gate length, both in micrometres, written as plain numbers without
  unit suffixes. Minimum L: 0.15 µm for nfet_01v8_lvt, 0.35 µm for pfet_01v8_lvt. Minimum W: 0.42 µm.
- Always use nf=1. For a wider transistor, increase W, or use m=k to connect k identical transistors in parallel.
- Sky130 W and L are plain numbers in µm; R and C values keep their SI suffixes (e.g. 2p, 10k).
  The m parameter means the same in both netlists.
- Resistors and capacitors may be ideal SPICE R and C elements.
- Supply: VDD = 1.2 V on the global node `vdd`; ground is node `0`. Both are available inside every
  subcircuit without being ports.
- The ideal reference current must be mirrored: it may not flow directly into the source of a transistor.
  No element may connect `inp` directly to `out`.
- The testbench includes the model library and provides all sources and analyses. Do not add
  `.lib`, `.include`, `.option`, sources or analysis statements.

## Netlist format example
This example only illustrates the syntax; it is not a suggested design.

```spice
.subckt example a b c
XM1 a b 0 0 sky130_fd_pr__nfet_01v8_lvt W=2 L=0.5 nf=1 m=1
XM2 a c vdd vdd sky130_fd_pr__pfet_01v8_lvt W=4 L=0.5 nf=1 m=2
.ends example
```

## Interface
The netlist must define the subcircuit `.subckt dut iref inp inn out`, with exactly these ports in this order.
- `iref`: an ideal bias reference current flows into this node from `vdd`.
- `inp`, `inn`: non-inverting and inverting inputs.
- `out`: output.

## Test conditions (TT corner, 27 °C)
- An ideal 20 µA current source from `vdd` drives `iref`.
- Unity-gain follower: `out` is connected to `inn`; `inp` is held at VCM = 0.9 V DC.
- Load: 1 pF from `out` to ground.
- Loop gain: the feedback loop is broken at the `out`-to-`inn` connection (Middlebrook double injection), AC analysis from 10 Hz to 10 GHz.
- Step response: `inp` is a pulse between 0.8 V and 1.0 V (10 ps edges, 100 ns period), transient analysis for 200 ns.

## Specifications
The requirements below are for this port at VDD = 1.2 V; they are not all derived from the source design's performance.
| Metric | Definition | Requirement | Source design (180 nm, VDD 1.8 V) |
|---|---|---|---|
| dc_gain_dB | loop-gain magnitude at 10 Hz, in dB | ≥ 78.4 | 75.71 |
| ugf_Hz | frequency where the loop-gain magnitude is 1, in Hz | ≥ 8.9e+07 | 8.323e+07 |
| pm_deg | 180° plus the phase at the unity-gain frequency, in degrees | ≥ 60 | 58.6 |
| gm_dB | minus the loop gain in dB at the frequency where the loop-gain phase is -180° | ≥ 10 | 19.8 |
| power_uW | VDD times the total supply current at the DC operating point (bias circuitry included), in µW | ≤ 296.4 | 247 |
| rise_settle_ns | time from the rising input edge until `out` stays within 1 % of the step of its final value, in ns | ≤ 12.24 | 8.16 |
| fall_settle_ns | time from the falling input edge until `out` stays within 1 % of the step of its final value, in ns | ≤ 26.73 | 17.82 |
| n_triode | number of transistors whose drain-source voltage magnitude is below their Vdsat at the DC operating point | ≤ 0 | 2 |

## Output format
Reply with exactly one ```spice code block containing the complete netlist: every .subckt the
design needs, including `dut`. You may add a short explanation outside the code block.
If you conclude that the specifications cannot all be met in SKY130 at this supply, add a line outside the
code block that starts with `INFEASIBLE:` followed by the reason, state the smallest change to the
specifications that would make them achievable, and still give your best design.
