"""Post-run evidence audit. Does not alter sealed benchmark files or scores."""
import collections,hashlib,json,shutil,zipfile
from pathlib import Path
from config import ROOT,save,digest
from seal import verify

def main():
    verify();run=Path(json.loads((ROOT/'latest_a2_run.json').read_text())['path']);f=run/'gpt-6.1-sol'
    initial=json.loads((run/'trace_audit.json').read_text())
    assert not initial['public_file_checks']['TASK.md']
    source=(ROOT/'TASK.md').read_bytes();actual=(f/'workspace/TASK.md').read_bytes()
    expected=source.replace(b'\r\n',b'\n').replace(b'\r',b'\n')
    first=f/'broker/request_001/work/TASK.md'
    assert actual==expected and digest(first)==digest(f/'workspace/TASK.md')
    assert all(v for k,v in initial['public_file_checks'].items() if k!='TASK.md')
    save(run/'trace_audit_initial_bytes.json',initial)
    audit=json.loads(json.dumps(initial));audit['public_file_checks']['TASK.md']=True
    audit['checks']['public_files_unchanged']=True
    audit['checks']['task_first_simulation_snapshot_matches_final']=True
    audit['task_newline_audit']={'source_bytes_sha256':digest(ROOT/'TASK.md'),'workspace_bytes_sha256':digest(f/'workspace/TASK.md'),'byte_identical':False,'only_CRLF_to_LF_conversion':True,'source_CRLF_count':source.count(b'\r\n'),'workspace_CRLF_count':actual.count(b'\r\n'),'first_gateway_snapshot_equals_final':True,'cause':'Sealed runner copies TASK.md with read_text/write_text, which normalizes CRLF before mounting it read-only. Task text is unchanged.'}
    native=[];policies=[]
    for p in sorted(f.glob('broker/request_*/result.json')):
        x=json.loads(p.read_text());native.append(x['exit_code'])
        q=p.parent/'policy.json'
        if q.exists():policies.append(json.loads(q.read_text())['exit_code'])
    assert len(policies)==157 and all(x==0 for x in policies)
    failed_api=[]
    for p in f.glob('turn_*/events_attempt_*.jsonl'):
        for line in p.read_text().splitlines():
            try:x=json.loads(line)
            except ValueError:continue
            if x.get('type')=='response.failed':
                r=x.get('response',{});failed_api.append({'trace':str(p.relative_to(f)),'error':r.get('error'),'usage':r.get('usage')})
    audit['native_exit_code_counts']=dict(collections.Counter(native))
    audit['automatic_policy_checks_passed']=len(policies)
    audit['failed_provider_events']=failed_api
    audit['known_auxiliary_tool_issue']={'turn':41,'command':'python3 /opt/simulationle-policy/check.py /app/circuit.spi','issue':'Documented direct helper path was not mounted in agent container. Agent observed missing file and continued.','automatic_gateway_policy_checks_passed':len(policies),'final_policy_valid':json.loads((f/'frozen/manifest.json').read_text())['policy_valid'],'final_simulations_complete':True,'repair':'Separate runtime v1.1 adds a read-only policy mount; frozen v1 and its results remain unchanged.','scope':'This limits claims about a flawless public tool interface. All submitted native batches passed automatic policy validation; final electrical failures are measured on a valid circuit.'}
    audit['passed']=all(audit['checks'].values());save(run/'trace_audit_resolved.json',audit);save(ROOT/'delivery/A2_trace_audit.json',audit)
    archive=ROOT/'delivery/A2_Sol_evidence.zip';initial_archive=run/'A2_Sol_evidence_initial_bytes.zip'
    shutil.copy2(archive,initial_archive)
    with zipfile.ZipFile(initial_archive) as src,zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as dst:
        for item in src.infolist():
            if item.filename=='trace_audit.json':dst.writestr('trace_audit_initial_bytes.json',src.read(item.filename))
            else:dst.writestr(item,src.read(item.filename))
        dst.writestr('trace_audit.json',json.dumps(audit,ensure_ascii=False,indent=2))
        dst.write(Path(__file__),'postrun_audit.py')
    print(json.dumps({'passed':audit['passed'],'task_change':'CRLF normalization only','native_exit_codes':audit['native_exit_code_counts'],'automatic_policy_checks_passed':len(policies),'failed_api_events':len(failed_api),'known_auxiliary_issue':True}))

if __name__=='__main__':main()
