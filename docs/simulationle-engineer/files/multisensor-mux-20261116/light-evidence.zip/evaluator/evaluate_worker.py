"""Independent native evaluator. Must run after the submitted circuit is frozen."""
import sys,os,argparse,subprocess,time,threading,shutil,concurrent.futures,gzip
from pathlib import Path
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'tools'))
from mux_common import config,scenarios,deck,write_json,digest
from measure_waveform import load_wave,measure
from score import summarize_added,aggregate
ap=argparse.ArgumentParser();ap.add_argument('--out',type=Path,required=True)
ap.add_argument('--original',action='store_true');ap.add_argument('--added',action='store_true')
ap.add_argument('--half-step',action='store_true');ap.add_argument('--jobs',type=int,default=2)
ap.add_argument('--ram-waveforms',action='store_true');ap.add_argument('--case',action='append',dest='cases')
a=ap.parse_args();cfg=config();out=a.out;out.mkdir(parents=True,exist_ok=False)
frozen=out/'submission';frozen.mkdir();shutil.copyfile('/app/circuit.spi',frozen/'circuit.spi');h=digest(frozen/'circuit.spi')
native_attempts={'original':0,'added':0};started=time.monotonic();lock=threading.Lock()
check=subprocess.run([sys.executable,str(ROOT/'tools/check_submission.py'),'--submission',str(frozen)],capture_output=True,text=True,timeout=60)
(out/'preflight.json').write_text(check.stdout);(out/'preflight.stderr').write_text(check.stderr)
if check.returncode:
 infrastructure=check.returncode!=1
 write_json(out/'result.json',{'status':'preflight_infrastructure_failure' if infrastructure else 'candidate_delivery_or_policy_failure',
  'score':None if infrastructure else 0,'official_score_available':not infrastructure,
  'original_passed':0,'added_passed':0,'preflight_returncode':check.returncode,'submission_sha256':h,
  'engineering_measurement_performed':False})
 raise SystemExit(0)
if a.original:
 Path.home().joinpath('.spiceinit').write_text('set num_threads=1\n')
 sys.path.insert(0,str(ROOT/'researcher/original/tests'));import verify
 real_run=verify.run_spice
 def audited(b,work,replacements=None):
  with lock:native_attempts['original']+=1;idx=native_attempts['original']
  dest=out/'original'/f'attempt_{idx:03d}';dest.mkdir(parents=True)
  result=real_run(b,work,replacements)
  shutil.copyfile(Path(work)/b.name,dest/'bench.cir');(dest/'ngspice.log').write_text(result.stdout)
  write_json(dest/'measurements.json',{'returncode':result.returncode,'values':result.values,'nonfinite':result.nonfinite})
  print('original_attempt',idx,result.returncode,flush=True);return result
 verify.run_spice=audited;verify.main()
 shutil.copytree('/logs/verifier',out/'original/logs',dirs_exist_ok=True)
if a.added:
 rows={}
 def one(s):
  assert digest('/app/circuit.spi')==h
  job=out/'added'/s['id'];job.mkdir(parents=True);sp=job/'fixture.cir'
  wave=Path('/tmp')/('wave_'+s['id']+'.tsv') if a.ram_waveforms else job/'waveform.tsv'
  text=deck(cfg,s,'/app/circuit.spi',max_step=cfg['numerics']['max_step_s']/2 if a.half_step else None)
  if a.ram_waveforms:text=text.replace('wrdata waveform.tsv ','wrdata '+str(wave)+' ')
  sp.write_text(text)
  with lock:native_attempts['added']+=1
  row={'scenario_id':s['id'],'status':'measurement_error_unclassified'};t=time.monotonic()
  try:
   with (job/'ngspice.log').open('w') as f:r=subprocess.run(['ngspice','-b',str(sp)],cwd=job,stdout=f,stderr=subprocess.STDOUT,timeout=360)
   if r.returncode:raise ValueError('nonzero simulator return '+str(r.returncode))
   row=measure(load_wave(wave,cfg),cfg,s);row['waveform_sha256']=digest(wave)
   if a.ram_waveforms:
    with wave.open('rb') as source,gzip.open(job/'waveform.tsv.gz','wb',compresslevel=2) as dest:shutil.copyfileobj(source,dest)
    wave.unlink()
  except (ValueError,OSError,subprocess.TimeoutExpired) as e:row.update(status='measurement_error_unclassified',error=str(e))
  row.update(submission_sha256=h,deck_sha256=digest(sp),wall_seconds=time.monotonic()-t)
  write_json(job/'measurements.json',row)
  with lock:
   rows[s['id']]=row
   write_json(out/'progress.json',{'finished_added':len(rows),'native_attempts':native_attempts,'elapsed_seconds':time.monotonic()-started})
  print('added',s['id'],row['status'],row.get('metrics',{}),flush=True)
  return row
 cases=[s for s in scenarios() if not a.cases or s['id'] in a.cases]
 cases.sort(key=lambda s:(s['pvt']!='tt_1p80_40',s['pvt']!='ff_1p98_m10',s['timing_profile']!='skewed',s['scan_order']!='descending',s['sensor_profile']!='high_impedance',s['id']))
 with concurrent.futures.ThreadPoolExecutor(max_workers=a.jobs) as pool:results=list(pool.map(one,cases))
 write_json(out/'added_measurements.json',{'scenarios':results,'native_process_attempts':native_attempts['added'],'submission_sha256':h})
 added=summarize_added(cfg,results);write_json(out/'added_summary.json',added)
if a.original and a.added:
 import json
 original=json.loads((out/'original/logs/new-ctrf.json').read_text());result=aggregate(cfg,original,added)
 result.update(status='completed' if added['all_evidence_complete'] else 'measurement_incomplete',official_score_available=bool(added['all_evidence_complete']),reason='independent native evaluation; reference qualification recorded separately')
 write_json(out/'result.json',result)
assert digest('/app/circuit.spi')==h and digest(frozen/'circuit.spi')==h
write_json(out/'execution.json',{'native_attempts':native_attempts,'wall_seconds':time.monotonic()-started,'submission_sha256':h,'max_step_s':cfg['numerics']['max_step_s']/2 if a.half_step else cfg['numerics']['max_step_s'],'same_frozen_netlist':True})
print('EVALUATION_COMPLETE',flush=True)
