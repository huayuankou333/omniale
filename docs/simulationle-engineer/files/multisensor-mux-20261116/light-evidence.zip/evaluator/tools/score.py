"""Aggregate researcher-produced measurements. Not a standalone authenticity verifier."""
import argparse, math
from pathlib import Path
from mux_common import config, scenarios, slots, write_json, read_json

def finite(x):return isinstance(x,(int,float)) and not isinstance(x,bool) and math.isfinite(x)

def summarize_added(cfg,results):
 expected={s['id']:s for s in scenarios()};seen={}
 for r in results:
  sid=r.get('scenario_id')
  if sid not in expected or sid in seen:raise ValueError('unknown or duplicate application scenario')
  seen[sid]=r
 names={m for g in cfg['added_groups'] for m in g['metrics'] if m!='history_difference_v'}
 complete={}
 for sid,r in seen.items():
  if r.get('status')!='complete':continue
  if not all(finite(r.get('metrics',{}).get(n)) and r['metrics'][n]>=0 for n in names):raise ValueError('complete row has missing, negative or invalid metrics')
  rr=r.get('slots',[]);wanted={(x['repeat'],x['channel']) for x in slots(cfg,expected[sid]) if x['scored']}
  keys=[(x.get('repeat'),x.get('channel')) for x in rr]
  if len(keys)!=len(wanted) or set(keys)!=wanted:raise ValueError('missing or duplicate conversion slots')
  if not all(finite(x.get('sampled_v')) for x in rr):raise ValueError('invalid history sample')
  complete[sid]=r
 pairs={}
 for s in expected.values():pairs.setdefault(s['history_pair_key'],{})[s['scan_order']]=s['id']
 history=[]
 for key,ids in pairs.items():
  if set(ids)!=set(cfg['scan_orders']):raise ValueError('history case manifest incomplete')
  if not all(sid in complete for sid in ids.values()):continue
  a={ (r['repeat'],r['channel']):r['sampled_v'] for r in complete[ids['ascending']]['slots'] }
  b={ (r['repeat'],r['channel']):r['sampled_v'] for r in complete[ids['descending']]['slots'] }
  for rep,ch in sorted(a):history.append({'pair':key,'repeat':rep,'channel':ch,'difference_v':abs(a[rep,ch]-b[rep,ch])})
 metrics={n:max((r['metrics'][n] for r in complete.values()),default=None) for n in names}
 metrics['history_difference_v']=max((r['difference_v'] for r in history),default=None)
 all_present=len(complete)==len(expected);history_complete=len(history)==cfg['coverage']['history_scalar_comparisons']
 groups=[]
 for g in cfg['added_groups']:
  ready=all_present and ('history_difference_v' not in g['metrics'] or history_complete)
  failures=[{'metric':n,'measured':metrics[n],'limit':limit} for n,limit in g['metrics'].items() if metrics[n] is not None and metrics[n]>limit]
  status='passed' if ready and not failures else ('failed' if ready else 'incomplete')
  groups.append({'id':g['id'],'status':status,'complete':ready,'measured_failures':failures})
 return {'case':cfg['case'],'version':cfg['version'],'complete_scenarios':len(complete),'expected_scenarios':len(expected),
         'complete_history_comparisons':len(history),'worst_metrics':metrics,'history':history,'groups':groups,
         'all_evidence_complete':all_present and history_complete,'diagnostic_only':True}

def aggregate(cfg,original,added,attribution='unclassified'):
 # Caller must be a trusted researcher runner using independently frozen artifacts.
 rows=original.get('results',{}).get('tests',[])
 expected=cfg['original']['checks'];names=[x.get('name') for x in rows]
 if len(names)!=len(expected) or set(names)!=set(expected):raise ValueError('all original checks required; blocked must be explicit')
 if any(x.get('status') not in ['passed','failed','blocked'] for x in rows):raise ValueError('invalid original status')
 op=sum(x['status']=='passed' for x in rows)
 groups=added.get('groups',[])
 if [x.get('id') for x in groups]!=[g['id'] for g in cfg['added_groups']]:raise ValueError('added group mismatch')
 if any(x.get('status') not in ['passed','failed','incomplete'] for x in groups):raise ValueError('invalid added status')
 ap=sum(x['status']=='passed' and x.get('complete') is True for x in groups)
 incomplete=not added.get('all_evidence_complete')
 if incomplete and attribution not in ['candidate_numerical_failure','infrastructure','unclassified']:raise ValueError('unknown failure attribution')
 unknown=incomplete and attribution!='candidate_numerical_failure'
 return {'case':cfg['case'],'version':cfg['version'],'status':'draft_diagnostic_only',
         'score':None if unknown else round(100*min(op/len(rows),ap/len(groups)),2),
         'full_pass':not unknown and not incomplete and op==len(rows) and ap==len(groups),
         'original_passed':op,'original_total':len(rows),'added_passed':ap,'added_total':len(groups),
         'missing_measurement_attribution':attribution if incomplete else None,
         'original_measurement_completeness':'read original diagnostic log; upstream blocked reasons retained',
         'official_score_available':False,'reason':'reference, runtime, numerical and budget qualification pending'}

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--measurements',required=True,type=Path)
 p.add_argument('--original-ctrf',type=Path);p.add_argument('--out',required=True,type=Path)
 p.add_argument('--attribution',choices=['unclassified','candidate_numerical_failure','infrastructure'],default='unclassified')
 a=p.parse_args();cfg=config();report=read_json(a.measurements);added=summarize_added(cfg,report['scenarios'])
 result={'added':added}
 if a.original_ctrf:result['combined']=aggregate(cfg,read_json(a.original_ctrf),added,a.attribution)
 write_json(a.out,result)

if __name__=='__main__':main()
