"""SLE D2-II-01 fixed fixture definitions; no simulator execution."""
from pathlib import Path
import hashlib, json

ROOT=Path(__file__).resolve().parents[1]

def read_json(path):return json.loads(Path(path).read_text(encoding='utf-8'))
def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def config():return read_json(ROOT/'contract.json')
def scenarios():return read_json(ROOT/'public/scenarios.json')['scenarios']
def write_json(path,value):Path(path).write_text(json.dumps(value,indent=2,ensure_ascii=False,allow_nan=False)+'\n',encoding='utf-8')
def by_id(items,key):return next(x for x in items if x['id']==key)

def resolve(cfg,case):
 return (by_id(cfg['pvt_rows'],case['pvt']),by_id(cfg['sensor_profiles'],case['sensor_profile']),
         cfg['scan_orders'][case['scan_order']],by_id(cfg['select_timing_profiles'],case['timing_profile']))

def slots(cfg,case):
 p,prof,order,skew=resolve(cfg,case);timing=cfg['timing']
 return [{'index':k,'repeat':k//8,'channel':ch,
          't0_s':timing['warmup_s']+k*timing['period_s'],
          'target_v':prof['voltage_ratios'][ch]*p['vdd_v'],
          'scored':k//8>=timing['discard_repetitions']}
         for k,ch in enumerate(order*timing['repetitions'])]

def source_pairs():
 return [('avdd_v','avdd_i'),*[(f'sel{b}_v',f'sel{b}_i') for b in range(3)],
         *[(f'src{i}_v',f'src{i}_i') for i in range(8)],
         ('pre_v','pre_i'),('acq_v','acq_i'),('reset_v','reset_i')]

def columns():
 return ['vo','sh','avdd_v','avdd_i',
         *[x for b in range(3) for x in (f'sel{b}_v',f'sel{b}_i')],
         *[x for i in range(8) for x in (f'src{i}_v',f'vin{i}',f'src{i}_i')],
         'pre_v','pre_i','acq_v','acq_i','reset_v','reset_i']

def quoted_path(path):
 s=str(path).replace('\\','/')
 if any(x in s for x in ['"','\n','\r']):raise ValueError('SPICE paths cannot contain quotes or newlines')
 return '"'+s+'"'

def pwl(points,stop):
 pts=list(points)
 if pts[-1][0]<stop:pts.append((stop,pts[-1][1]))
 if any(b[0]<=a[0] for a,b in zip(pts,pts[1:])):raise ValueError('PWL times must strictly increase')
 return 'PWL(\n'+'\n'.join(f'+ {t:.15g} {v:.15g}' for t,v in pts)+'\n+ )'

def pulses(event_slots,start,end,edge,low,high):
 points=[(0.0,low)]
 for s in event_slots:
  t=s['t0_s'];points.extend([(t+start,low),(t+start+edge,high),(t+end,high),(t+end+edge,low)])
 return points

def deck(cfg,case,dut='/app/circuit.spi',model=None,max_step=None):
 p,prof,order,edgeprofile=resolve(cfg,case);ti=cfg['timing'];fi=cfg['fixture'];nu=cfg['numerics']
 ss=slots(cfg,case);vdd=p['vdd_v'];stop=ti['warmup_s']+len(ss)*ti['period_s']
 maximum=max_step or nu['max_step_s']
 text=['* SLE D2-II-01 fixed application fixture; eval v0.2',
       f'* scenario {case["id"]}',f'.lib {quoted_path(model or nu["model_path"])} {p["corner"]}',
       f'.include {quoted_path(dut)}',f'.temp {p["temp_c"]}',
       f'VDD_SRC avdd_src 0 {vdd:.12g}',f'R_VDD avdd_src avdd {fi["avdd_series_r_ohm"]}',
       'VSS avss 0 0']
 for b in range(3):
  current=vdd*((order[0]>>b)&1);pts=[(0.0,current)]
  for s in ss:
   new=vdd*((s['channel']>>b)&1)
   if new!=current:
    start=s['t0_s']+edgeprofile['skew_s_by_s0_s1_s2'][b]
    pts.extend([(start,current),(start+ti['select_edge_s'],new)]);current=new
  text.extend([f'VS{b} sel{b}_src 0 '+pwl(pts,stop),f'RS{b} sel{b}_src s{b} {fi["select_series_r_ohm"]}'])
 for i in range(8):
  base=prof['voltage_ratios'][i]*vdd;other=(1-prof['voltage_ratios'][i])*vdd
  pts=pulses([s for s in ss if s['channel']!=i],ti['aggressor_rise_start_s'],ti['aggressor_fall_start_s'],ti['fixture_edge_s'],base,other)
  text.extend([f'VIN{i}_SRC src{i} 0 '+pwl(pts,stop),f'RIN{i} src{i} vin{i} {prof["r_ohm"][i]}',f'CSENSOR{i} vin{i} 0 {prof["c_pin_f"][i]:.12g}'])
 text.extend(['XDUT avdd avss s2 s1 s0 vin7 vin6 vin5 vin4 vin3 vin2 vin1 vin0 vo input_mux_8to1',
              f'CLOAD vo 0 {fi["vo_shunt_c_f"]:.12g}',
              'VACQ acq 0 '+pwl(pulses(ss,ti['acquire_rise_start_s'],ti['acquire_fall_start_s'],ti['fixture_edge_s'],0,vdd),stop),
              'VRESET reset 0 '+pwl(pulses(ss,ti['reset_rise_start_s'],ti['reset_fall_start_s'],ti['fixture_edge_s'],0,vdd),stop),
              f'VPRE pre_src 0 {vdd*prof["precharge_ratio"]:.12g}',f'RPRE pre_src pre {fi["precharge_series_r_ohm"]}',
              f'.model ACQSW SW(Ron={fi["sample_switch_ron_ohm"]} Roff={fi["sample_switch_roff_ohm"]:.12g} Vt={vdd*fi["switch_threshold_vdd_ratio"]:.12g} Vh={fi["switch_hysteresis_v"]})',
              f'.model RSTSW SW(Ron={fi["reset_switch_ron_ohm"]} Roff={fi["reset_switch_roff_ohm"]:.12g} Vt={vdd*fi["switch_threshold_vdd_ratio"]:.12g} Vh={fi["switch_hysteresis_v"]})',
              'SACQ vo sh acq 0 ACQSW','SRESET sh pre reset 0 RSTSW',
              f'CHOLD sh 0 {fi["sample_cap_f"]:.12g}',f'RLEAK sh 0 {fi["sample_leak_r_ohm"]:.12g}',
              f'CFEED acq sh {fi["acquisition_feedthrough_c_f"]:.12g}',
              f'.options reltol={nu["reltol"]} vntol={nu["vntol_v"]} abstol={nu["abstol_a"]} gmin={nu["gmin_s"]}',
              '.control','set num_threads=1','set noaskquit','set wr_singlescale','set wr_vecnames','set numdgt=15',
              f'tran {min(nu["print_step_s"],maximum):.12g} {stop:.12g} 0 {maximum:.12g}'])
 expr={'vo':'v(vo)','sh':'v(sh)','avdd_v':'v(avdd_src)','avdd_i':'i(VDD_SRC)',
       'pre_v':'v(pre_src)','pre_i':'i(VPRE)','acq_v':'v(acq)','acq_i':'i(VACQ)','reset_v':'v(reset)','reset_i':'i(VRESET)'}
 for b in range(3):expr.update({f'sel{b}_v':f'v(sel{b}_src)',f'sel{b}_i':f'i(VS{b})'})
 for i in range(8):expr.update({f'src{i}_v':f'v(src{i})',f'vin{i}':f'v(vin{i})',f'src{i}_i':f'i(VIN{i}_SRC)'})
 text.insert(text.index('.control'),'.save '+' '.join(dict.fromkeys(expr.values())))
 if nu.get('linear_solver')=='klu':text.insert(text.index('.control'),'.options klu')
 for name in columns():text.append(f'let m_{name} = {expr[name]}')
 text.extend(['wrdata waveform.tsv '+' '.join('m_'+x for x in columns()),'quit','.endc','.end'])
 return '\n'.join(text)+'\n'
