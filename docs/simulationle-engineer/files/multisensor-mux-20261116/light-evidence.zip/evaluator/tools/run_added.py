"""Public waveform diagnostics. Native execution uses the audited gateway."""
import argparse, os, shutil, subprocess, sys, time
from pathlib import Path
from mux_common import ROOT, config, scenarios, digest, deck, write_json
from measure_waveform import load_wave, measure
from score import summarize_added

def main():
 p=argparse.ArgumentParser(description=__doc__)
 p.add_argument('--submission',required=True,type=Path);p.add_argument('--out',required=True,type=Path)
 p.add_argument('--case',action='append',dest='cases');p.add_argument('--all',action='store_true')
 p.add_argument('--draft-diagnostic',action='store_true',help=argparse.SUPPRESS)
 p.add_argument('--half-step',action='store_true');p.add_argument('--timeout',type=float,default=420)
 a=p.parse_args()

 if bool(a.cases)==a.all:p.error('choose --case ID (repeatable) or --all')
 if a.timeout<=0:p.error('timeout must be positive')
 cfg=config();allcases=scenarios();chosen=[s for s in allcases if a.all or s['id'] in a.cases]
 if a.cases and set(a.cases)!={s['id'] for s in chosen}:p.error('unknown case ID')
 if a.out.exists():p.error('output must be a fresh directory')
 if not shutil.which('ngspice'):p.error('infrastructure: ngspice is missing')
 if not Path(cfg['numerics']['model_path']).is_file():p.error('infrastructure: pinned SKY130 models are missing')
 a.out.mkdir(parents=True);out=a.out.resolve();frozen=out/'submission';frozen.mkdir()
 shutil.copyfile(a.submission/'circuit.spi',frozen/'circuit.spi');candidate_hash=digest(frozen/'circuit.spi')
 check=subprocess.run([sys.executable,str(ROOT/'tools/check_submission.py'),'--submission',str(frozen)],capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=70)
 (out/'preflight.json').write_text(check.stdout,encoding='utf-8')
 (out/'preflight.stderr.txt').write_text(check.stderr,encoding='utf-8')
 if check.returncode:raise SystemExit('delivery/native legality preflight failed; no solver started')
 result={'case':cfg['case'],'version':cfg['version'],'diagnostic_only':True,'submission_sha256':candidate_hash,
         'contract_sha256':digest(ROOT/'contract.json'),'scenario_manifest_sha256':digest(ROOT/'public/scenarios.json'),
         'tool_hashes':{q.name:digest(q) for q in (ROOT/'tools').glob('*.py')},
         'half_step':a.half_step,'native_process_attempts':0,'elapsed_seconds':0,'scenarios':[]}
 started=time.monotonic();env=dict(os.environ,OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
 for s in chosen:
  if digest(frozen/'circuit.spi')!=candidate_hash:raise RuntimeError('frozen candidate changed')
  job=out/s['id'];job.mkdir();sp=job/'fixture.cir'
  sp.write_text(deck(cfg,s,a.submission.resolve()/'circuit.spi',max_step=cfg['numerics']['max_step_s']/2 if a.half_step else None),encoding='utf-8')
  row={'scenario_id':s['id'],'status':'measurement_error_unclassified'};t=time.monotonic()
  result['native_process_attempts']+=1
  try:
   with (job/'ngspice.log').open('w',encoding='utf-8') as logfile:
    run=subprocess.run(['ngspice','-b',str(sp)],cwd=job,env=env,stdout=logfile,stderr=subprocess.STDOUT,timeout=a.timeout)
   row['returncode']=run.returncode
   if run.returncode!=0:raise ValueError('nonzero simulator return code; inspect log before attribution')
   wave=job/'waveform.tsv';row=measure(load_wave(wave,cfg),cfg,s);row['waveform_sha256']=digest(wave)
  except (ValueError,OSError,subprocess.TimeoutExpired) as e:row.update(status='measurement_error_unclassified',error=str(e))
  row.update(wall_seconds=time.monotonic()-t,deck_sha256=digest(sp),submission_sha256=candidate_hash)
  write_json(job/'measurements.json',row);result['scenarios'].append(row)
  result['elapsed_seconds']=time.monotonic()-started;write_json(out/'measurements.json',result)
  print(s['id'],row['status'],flush=True)
 if digest(frozen/'circuit.spi')!=candidate_hash:raise RuntimeError('frozen candidate changed')
 write_json(out/'added_summary.json',summarize_added(cfg,result['scenarios']))
 print(f'Native simulator attempts: {result["native_process_attempts"]}; diagnostic output: {out}')

if __name__=='__main__':main()
