"""Measure fixed application windows from fresh ngspice output; never trust agent metrics."""
import argparse
from pathlib import Path
import numpy as np
from mux_common import config, scenarios, slots, columns, source_pairs, write_json, digest

integrate_trapezoid=np.trapezoid if hasattr(np,'trapezoid') else np.trapz

def load_wave(path,cfg):
 with Path(path).open(encoding='utf-8') as f:header=f.readline().strip().lower().split()
 expected=['time',*['m_'+x for x in columns()]]
 if header!=expected:raise ValueError(f'waveform columns mismatch: expected {expected}, got {header}')
 data=np.loadtxt(path,skiprows=1,ndmin=2)
 return validate_array(data,cfg)

def validate_array(data,cfg):
 if data.ndim!=2 or data.shape[1]!=1+len(columns()) or data.shape[0]<3:raise ValueError('wrong waveform shape')
 if not np.isfinite(data).all():raise ValueError('nonfinite waveform; never substitute zero')
 t=data[:,0]
 if np.any(np.diff(t)<=0):raise ValueError('time must be strictly increasing')
 stop=cfg['timing']['warmup_s']+8*cfg['timing']['repetitions']*cfg['timing']['period_s']
 if t[0]>1e-15 or t[-1]<stop-1e-15:raise ValueError('incomplete time coverage')
 if np.max(np.diff(t))>cfg['numerics']['max_accepted_sample_gap_s']:raise ValueError('undersampled waveform; peak evidence not adequate')
 return {'time':t,**{name:data[:,i+1] for i,name in enumerate(columns())}}

def window(w,name,a,b):
 t=w['time']
 if a<t[0]-1e-15 or b>t[-1]+1e-15 or b<=a:raise ValueError('invalid or uncovered measurement interval')
 mask=(t>a)&(t<b)
 tt=np.concatenate(([a],t[mask],[b]))
 yy=np.concatenate(([np.interp(a,t,w[name])],w[name][mask],[np.interp(b,t,w[name])]))
 return tt,yy

def max_error(w,name,target,a,b):
 tt,yy=window(w,name,a,b)
 error=np.abs(yy-target);j=int(np.argmax(error))
 return float(error[j]),float(tt[j])

def measure(w,cfg,case):
 ti=cfg['timing'];ss=[s for s in slots(cfg,case) if s['scored']];row_metrics=[]
 for s in ss:
  t=s['t0_s'];target=s['target_v'];ch=s['channel']
  sampled=float(np.interp(t+ti['sample_time_s'],w['time'],w['sh']))
  row={'slot':s['index'],'repeat':s['repeat'],'channel':ch,'target_v':target,'sampled_v':sampled,
       'sample_error_v':abs(sampled-target),'sample_time_s':t+ti['sample_time_s']}
  for metric,name,interval in [
   ('hold_error_v','sh',ti['hold_window_s']),
   ('settling_error_v','sh',ti['settling_window_s']),
   ('aggressor_output_error_v','vo',ti['aggressor_measure_window_s'])]:
   row[metric],row[metric+'_at_s']=max_error(w,name,target,t+interval[0],t+interval[1])
  # Settling requires both output and sampling capacitor to have settled.
  vo_error,vo_time=max_error(w,'vo',target,t+ti['settling_window_s'][0],t+ti['settling_window_s'][1])
  if vo_error>row['settling_error_v']:row.update(settling_error_v=vo_error,settling_error_v_at_s=vo_time)
  for metric,interval in [('off_sensor_peak_error_v',ti['sensor_disturbance_window_s']),('off_sensor_recovery_error_v',ti['sensor_recovery_window_s'])]:
   values=[]
   for i in range(8):
    if i==ch:continue
    # These windows precede the intentional source pulse; subtract the actual source nonetheless.
    tt,vin=window(w,f'vin{i}',t+interval[0],t+interval[1])
    src=np.interp(tt,w['time'],w[f'src{i}_v']);err=np.abs(vin-src);idx=int(np.argmax(err))
    values.append((float(err[idx]),float(tt[idx]),i))
   value,at,i=max(values)
   row.update({metric:value,metric+'_at_s':at,metric+'_channel':i})
  row_metrics.append(row)
 metrics={name:max(r[name] for r in row_metrics) for name in ['sample_error_v','hold_error_v','settling_error_v','aggressor_output_error_v','off_sensor_peak_error_v','off_sensor_recovery_error_v']}
 start=ss[0]['t0_s'];stop=ti['warmup_s']+8*ti['repetitions']*ti['period_s'];duration=stop-start
 energy=[]
 for vname,iname in source_pairs():
  tt,v=window(w,vname,start,stop);_,i=window(w,iname,start,stop);delivered=-v*i
  energy.append({'source':vname.removesuffix('_v'),'signed_energy_j':float(integrate_trapezoid(delivered,tt)),
                 'positive_energy_j':float(integrate_trapezoid(np.maximum(delivered,0),tt))})
 metrics['positive_input_power_w']=sum(e['positive_energy_j'] for e in energy)/duration
 _,avdd_i=window(w,'avdd_i',start,stop);metrics['avdd_peak_abs_current_a']=float(np.max(np.abs(avdd_i)))
 return {'scenario_id':case['id'],'status':'complete','metrics':metrics,'slots':row_metrics,'source_energy':energy,
         'scored_duration_s':duration,'waveform_rows':len(w['time']),'maximum_sample_gap_s':float(np.max(np.diff(w['time'])))}

def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--waveform',required=True,type=Path)
 ap.add_argument('--case',required=True);ap.add_argument('--out',required=True,type=Path);a=ap.parse_args()
 matches=[s for s in scenarios() if s['id']==a.case]
 if len(matches)!=1:ap.error('unknown scenario')
 cfg=config();r=measure(load_wave(a.waveform,cfg),cfg,matches[0]);r['waveform_sha256']=digest(a.waveform)
 write_json(a.out,r)

if __name__=='__main__':main()
