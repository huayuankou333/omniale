"""Public delivery/interface check plus the upstream native legality checker."""
import argparse, json, subprocess, sys
from pathlib import Path
from mux_common import config, digest

def structural(path,cfg):
 errors=[]
 if not path.is_file():return ['required circuit.spi is missing']
 if path.is_symlink():return ['circuit.spi must be a regular file, not a symbolic link']
 raw=path.read_bytes()
 if not raw or len(raw)>cfg['submission']['netlist_max_bytes']:return ['circuit.spi is empty or exceeds 1 MiB']
 try:text=raw.decode('utf-8-sig')
 except UnicodeDecodeError:return ['netlist must be UTF-8 or ASCII']
 logical=[]
 for line in text.splitlines():
  line=line.strip()
  if not line or line.startswith('*'):continue
  if line.startswith('+') and logical:logical[-1]+=' '+line[1:].strip()
  else:logical.append(line)
 tops=[line.split() for line in logical if line.lower().startswith('.subckt ') and len(line.split())>1 and line.split()[1].lower()==cfg['interface']['name']]
 if len(tops)!=1:errors.append('exactly one input_mux_8to1 declaration is required')
 elif [x.lower() for x in tops[0][2:]]!=[x.lower() for x in cfg['interface']['pins']]:errors.append('ordered pins must exactly match TASK.md, including escaped bus names')
 if not any(line[:1].lower()=='x' for line in logical):errors.append('starter/TODO has no device or subcircuit instances')
 return errors

def main():
 p=argparse.ArgumentParser(description=__doc__)
 p.add_argument('--submission',type=Path,required=True,help='directory containing circuit.spi')
 p.add_argument('--structural-only',action='store_true',help='Explicitly skip unavailable native legality check; never proves electrical eligibility')
 p.add_argument('--native-checker',type=Path,default=Path('/opt/analog-arena/check_circuit.py'))
 a=p.parse_args();cfg=config();path=a.submission/'circuit.spi';errors=structural(path,cfg)
 out={'case':cfg['case'],'structural_errors':errors,'native_legality':'not_run','electrical_simulation_performed':False,
      'native_solver_processes':0,'netlist_sha256':digest(path) if path.is_file() else None}
 code=1 if errors else 0
 if not errors and not a.structural_only:
  if not a.native_checker.is_file():out['native_legality']='infrastructure_missing_checker';code=2
  else:
   cmd=[sys.executable,str(a.native_checker),str(path),'--require-subcircuit',cfg['interface']['name'],*cfg['interface']['pins'],'--enforce-sky130-geometry']
   try:
    r=subprocess.run(cmd,text=True,encoding='utf-8',errors='replace',capture_output=True,timeout=60)
    out.update(native_legality='passed' if r.returncode==0 else 'rejected',native_checker_output=r.stdout+r.stderr,native_checker_returncode=r.returncode)
    code=0 if r.returncode==0 else 1
   except (OSError,subprocess.TimeoutExpired) as e:out.update(native_legality='infrastructure_error',error=str(e));code=2
 out['ready_for_electrical_diagnostic']=not errors and out['native_legality']=='passed'
 print(json.dumps(out,ensure_ascii=False,indent=2));return code

if __name__=='__main__':raise SystemExit(main())
