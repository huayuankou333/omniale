"""Generate immutable-config SPICE fixtures; never invokes a solver."""
import argparse
from pathlib import Path
from mux_common import ROOT, config, scenarios, deck, columns, digest, write_json

def main():
 ap=argparse.ArgumentParser(description=__doc__)
 ap.add_argument('--out',required=True,type=Path)
 ap.add_argument('--dut',default='/app/circuit.spi')
 ap.add_argument('--model',default=None)
 ap.add_argument('--case',action='append',dest='cases')
 ap.add_argument('--half-step',action='store_true',help='Researcher convergence variant, not a changed engineering threshold')
 a=ap.parse_args();cfg=config();allcases=scenarios()
 selected=[s for s in allcases if not a.cases or s['id'] in a.cases]
 if a.cases and set(a.cases)!={s['id'] for s in selected}:ap.error('unknown or missing scenario IDs')
 if a.out.exists():ap.error('output directory must not exist, to prevent stale evidence')
 a.out.mkdir(parents=True)
 rows=[]
 for s in selected:
  dest=a.out/s['id'];dest.mkdir()
  path=dest/'fixture.cir';path.write_text(deck(cfg,s,a.dut,a.model,cfg['numerics']['max_step_s']/2 if a.half_step else None),encoding='utf-8')
  rows.append({**s,'deck_path':str(path.relative_to(a.out)),'sha256':digest(path)})
 write_json(a.out/'index.json',{'case':cfg['case'],'version':cfg['version'],'contract_sha256':digest(ROOT/'contract.json'),
  'scenario_manifest_sha256':digest(ROOT/'public/scenarios.json'),'columns':['time',*['m_'+x for x in columns()]],
  'half_step':a.half_step,'generated_only':True,'rows':rows})
 print(f'Generated {len(rows)} fixtures; native solver calls: 0')

if __name__=='__main__':main()
