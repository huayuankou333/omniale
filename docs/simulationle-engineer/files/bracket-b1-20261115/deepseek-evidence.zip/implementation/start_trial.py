"""Launch exactly one durable trial, receiving the credential on a pipe."""
import json
from pathlib import Path
import subprocess
import sys

HERE = Path(__file__).resolve().parent
key = sys.stdin.readline().strip()
assert key
with (HERE/'trial.log').open('xb') as log:
    process = subprocess.Popen([sys.executable, '-u', str(HERE/'run_deepseek.py'), 'run'],
                               cwd=HERE, stdin=subprocess.PIPE, stdout=log, stderr=subprocess.STDOUT,
                               start_new_session=True, close_fds=True)
    process.stdin.write((key+'\n').encode())
    process.stdin.close()
print(json.dumps({'pid': process.pid, 'model': 'deepseek-v4.1-flash-1017', 'trial_limit': 1, 'log': str(HERE/'trial.log')}))
