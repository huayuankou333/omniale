"""Chat protocol adapter; simulator, task prompts and scoring remain unchanged."""
import copy, json, time, urllib.request, urllib.error
from pathlib import Path

MODEL = 'deepseek-v4.1-flash-1017'
ENDPOINT = 'https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions'
DEADLINE = None
class DeadlineReached(TimeoutError): pass

def save(path, data):
    Path(path).write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

def chat_messages(messages, instructions):
    result = [{'role':'system', 'content':instructions}]
    for msg in messages:
        kind = msg.get('type')
        if kind == 'provider_assistant':
            result.append(copy.deepcopy(msg['message']))
        elif kind == 'function_call' and msg.get('in_provider_assistant'):
            continue
        elif kind == 'function_call_output':
            result.append({'role':'tool','tool_call_id':msg['call_id'],'content':msg['output']})
        elif msg.get('role'):
            content = msg.get('content', '')
            if isinstance(content, list):
                converted = []
                for item in content:
                    if item['type'] == 'input_text':
                        converted.append({'type':'text','text':item['text']})
                    elif item['type'] == 'input_image':
                        converted.append({'type':'image_url','image_url':{'url':item['image_url']}})
                    else:
                        raise ValueError('Unsupported message block')
                content = converted
            result.append({'role':msg['role'],'content':content})
        else:
            raise ValueError('Unexpected conversation record')
    return result

def request_body(model, messages, instructions, tools, max_tokens):
    return {'model':model, 'messages':chat_messages(messages,instructions),
        'tools':[{'type':'function','function':{k:v for k,v in t.items() if k not in ['type','strict']}} for t in tools],
        'tool_choice':'auto', 'parallel_tool_calls':False, 'reasoning_effort':'medium',
        'max_tokens':max_tokens, 'stream':True, 'stream_options':{'include_usage':True}}

def collect(response, eventlog):
    if 'text/event-stream' not in response.headers.get('Content-Type',''):
        return json.load(response)
    answer={'role':'assistant','content':''}
    calls={}; usage=None; model=None; finish=None; response_id=None
    while True:
        left=(DEADLINE-time.monotonic()) if DEADLINE else 360
        if left<=0: raise DeadlineReached('Development deadline reached')
        try: response.fp.raw._sock.settimeout(max(.05,min(360,left)))
        except AttributeError: pass
        line=response.readline()
        if not line: break
        line=line.decode('utf-8').strip()
        if not line.startswith('data:'):continue
        data=line[5:].strip()
        if data=='[DONE]':break
        event=json.loads(data)
        eventlog.write(json.dumps(event,ensure_ascii=False)+'\n');eventlog.flush()
        if event.get('error'):raise ConnectionError('Provider stream error: '+json.dumps(event['error'])[:600])
        model=event.get('model',model);response_id=event.get('id',response_id)
        if event.get('usage'):usage=event['usage']
        for choice in event.get('choices',[]):
            delta=choice.get('delta') or {}
            for field in ['content','reasoning_content']:
                if delta.get(field):answer[field]=answer.get(field,'')+delta[field]
            for item in delta.get('tool_calls') or []:
                c=calls.setdefault(item['index'],{'type':'function','id':'','function':{'name':'','arguments':''}})
                if item.get('id'):c['id']=item['id']
                f=item.get('function') or {}
                for field in ['name','arguments']:
                    if f.get(field):c['function'][field]+=f[field]
            finish=choice.get('finish_reason') or finish
    if calls:answer['tool_calls']=[calls[k] for k in sorted(calls)]
    if not finish:raise ConnectionError('Missing completion finish event')
    if not usage:raise ConnectionError('Missing provider usage; refusing unaccounted continuation')
    return {'id':response_id,'model':model,'choices':[{'message':answer,'finish_reason':finish}], 'usage':usage}

def normalize(raw, model):
    if raw.get('model')!=model:raise RuntimeError('Provider-reported model ID differs from exact requested model')
    message=raw['choices'][0]['message']
    output=[{'type':'provider_assistant','provider':'dashscope','message':message}]
    for item in message.get('tool_calls') or []:
        output.append({'type':'function_call','name':item['function']['name'],
            'arguments':item['function']['arguments'],'call_id':item['id'],'in_provider_assistant':True})
    usage=raw.get('usage') or {}
    if 'completion_tokens' not in usage:raise RuntimeError('Missing output token accounting')
    return {'id':raw.get('id'),'model':raw['model'],'status':'completed','output':output,
        'usage':{'input_tokens':usage.get('prompt_tokens',0),'output_tokens':usage['completion_tokens'],
                 'total_tokens':usage.get('total_tokens',0),'provider_usage':usage},
        'finish_reason':raw['choices'][0].get('finish_reason')}

def call(key,model,messages,instructions,tools,folder,max_tokens=None):
    payload=request_body(model,messages,instructions,tools,max_tokens or 32768)
    save(folder/'request.json',payload)
    started=time.monotonic()
    for attempt in range(3):
        try:
            remaining=(DEADLINE-time.monotonic()) if DEADLINE else 360
            if remaining<=0:raise DeadlineReached('Development deadline reached')
            req=urllib.request.Request(ENDPOINT,data=json.dumps(payload).encode(),
                headers={'Authorization':'Bearer '+key,'Content-Type':'application/json'})
            with urllib.request.urlopen(req,timeout=min(360,remaining)) as response:
                with (folder/('events.jsonl' if attempt==0 else f'events-retry-{attempt}.jsonl')).open('w',encoding='utf-8') as log:
                    raw=collect(response,log)
            save(folder/f'provider_response_attempt_{attempt}.json',raw)
            save(folder/'provider-response.json',raw)
            result=normalize(raw,model)
            save(folder/f'response_attempt_{attempt}.json',result)
            save(folder/'response.json',result)
            save(folder/'inference.json',{'requested_model':model,'reported_model':raw['model'],
                'usage':result['usage'],'wall_seconds':time.monotonic()-started,'transport_retry':attempt,
                'endpoint':ENDPOINT,'reasoning_effort_requested':'medium'})
            return result
        except DeadlineReached: raise
        except (urllib.error.URLError,TimeoutError,ConnectionError) as exc:
            if DEADLINE and time.monotonic()>=DEADLINE: raise DeadlineReached('Development deadline reached') from None
            detail={'error':str(exc).replace(key,'[REDACTED]')[:1000]}
            if isinstance(exc,urllib.error.HTTPError):
                detail.update(code=exc.code,body=exc.read().decode(errors='replace').replace(key,'[REDACTED]')[:2000])
            save(folder/f'transport_{attempt}.json',detail)
            # No inference output is treated as a circuit failure or tool feedback.
            if isinstance(exc,urllib.error.HTTPError) and exc.code not in [429,500,502,503,504]:raise
            if attempt==2:raise
            time.sleep(min(5*(attempt+1),max(0,DEADLINE-time.monotonic())) if DEADLINE else 5*(attempt+1))


def models(key):
    request=urllib.request.Request('https://dashscope.aliyuncs.com/compatible-mode/v1/models',headers={'Authorization':'Bearer '+key})
    with urllib.request.urlopen(request,timeout=45) as response:
        return {row['id'] for row in json.load(response)['data']}
