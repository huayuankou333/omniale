"""Versioned group score, preserving all sealed v1 measurement files."""
import argparse
import hashlib
import json
from pathlib import Path

GROUPS = ['geometry_interfaces', 'space_access', 'mass_backbone', 'alignment', 'strength']
INSTANCES = ['B1-01-offset-open', 'B1-02-cross-optical']
VERSION = 'b1-group-convergence-v2-20261115'

def assess(raw, source_hash, model):
    records = {}
    blocking = []
    if raw.get('status') == 'invalid_submission' and raw.get('errors'):
        return dict(scoring_version=VERSION, model=model, score=0, full_pass=False, task_success=0,
                    status='submission_failed', groups={g: {'passed': False, 'points': 0} for g in GROUPS},
                    submission_errors=raw['errors'], source_result_sha256=source_hash,
                    original_score=raw.get('score'), original_status=raw.get('status'))
    for identity in INSTANCES:
        item = raw.get('instances', {}).get(identity, {})
        state = {}
        errors = item.get('errors', [])
        failures = [c for c in item.get('convergence', []) if not c.get('passed')]
        numerical_errors = {c['case'] + ': insufficient mesh convergence for ' + c['metric'] for c in failures}
        unexplained = [e for e in errors if e not in numerical_errors]
        if unexplained:
            blocking.append({'instance': identity, 'errors': unexplained})
        if item.get('status') in ['rebuild_failed', 'invalid_rebuild_artifact']:
            for group in GROUPS:
                state[group] = {'passed': False, 'reasons': [item['status']]}
            records[identity] = state
            continue
        if not item.get('checks'):
            blocking.append({'instance': identity, 'status': item.get('status', 'missing')})
        for group in GROUPS:
            checks = [c for c in item.get('checks', []) if c['group'] == group]
            relevant = [c for c in failures if ('strength' if 'vm_' in c['metric'] else 'alignment') == group]
            reasons = [c['name'] for c in checks if not c['passed']]
            reasons += [c['case'] + ': convergence failed for ' + c['metric'] for c in relevant]
            state[group] = {'passed': bool(checks) and not reasons, 'reasons': reasons,
                            'checked_constraints': len(checks)}
        records[identity] = state
    groups = {g: {'passed': all(records[i][g]['passed'] for i in INSTANCES),
                  'points': 20 if all(records[i][g]['passed'] for i in INSTANCES) else 0} for g in GROUPS}
    if raw.get('frozen_files_unchanged') is False:
        blocking.append({'integrity': 'frozen files changed'})
    score = None if blocking else sum(v['points'] for v in groups.values())
    known_failed = any(not c['passed'] for i in raw.get('instances', {}).values() for c in i.get('checks', []))
    known_failed |= any(not c['passed'] for i in raw.get('instances', {}).values() for c in i.get('convergence', []))
    full_pass = score == 100
    return dict(scoring_version=VERSION, model=model, score=score, full_pass=full_pass,
                task_success=0 if known_failed or (score is not None and score < 100) else (1 if full_pass else None),
                status='evaluation_blocked' if blocking else ('passed' if full_pass else 'failed'),
                groups=groups, instances=records, unresolved_evaluation_errors=blocking,
                source_result_sha256=source_hash, original_score=raw.get('score'), original_status=raw.get('status'),
                interpretation='Each group requires both instances to pass its physical and applicable convergence checks. '
                               'Strength convergence failure earns zero strength points; it does not prove physical overstress.')

if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--result', type=Path, required=True)
    ap.add_argument('--output', type=Path, required=True)
    ap.add_argument('--model', required=True)
    args = ap.parse_args()
    data = args.result.read_bytes()
    result = assess(json.loads(data), hashlib.sha256(data).hexdigest(), args.model)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'score': result['score'], 'task_success': result['task_success'], 'status': result['status']}))
