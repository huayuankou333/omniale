"""One Sol trial after a calibrated pre-run seal. No host design edits."""
import argparse,base64,json,os,shutil,subprocess,sys,time,uuid
from datetime import datetime,timezone
from pathlib import Path
ADAPTER_ROOT=Path(__file__).resolve().parent
CASE_ROOT=ADAPTER_ROOT.parents[1]
sys.path.insert(0,str(CASE_ROOT))
import dashscope_client as api_client
from config import ROOT,BASE_URL,BASE_IMAGE,TOOLS_PATH,LIMITS,MODELS,save,digest,agent_tool_mounts
from native_jobs import Jobs

def function(name,description,properties):
    return {'type':'function','name':name,'description':description,'strict':True,
            'parameters':{'type':'object','properties':properties,'required':list(properties),'additionalProperties':False}}
TOOLS=[
 function('terminal','Run your own shell commands in the persistent isolated Linux CAD container. Edit /app/submission, build using FreeCAD, mesh with Gmsh and plot results. Read asynchronous native job status and result files under /app/development.',
          {'command':{'type':'string'},'timeout_seconds':{'type':'integer','minimum':1,'maximum':180}}),
 function('analyze_design','Snapshot the current STEP and FCStd for one fixed instance and run immutable geometry and optional dual-mesh six-load-case FEA in a native worker. Asynchronous; inspect returned directory via terminal. One active job at a time. Reserves12 solver credits.',
          {'instance':{'type':'string','enum':['B1-01-offset-open','B1-02-cross-optical']},'geometry_only':{'type':'boolean'}}),
 function('solve_deck','Run actual CalculiX on your own .inp deck under /app. Input directory is snapshotted. Asynchronous; returned output folder contains .dat/.frd and logs. Reserves1 solver credit.',
          {'deck_path':{'type':'string'}}),
 function('read_image','Read a PNG/JPEG/WebP you generated under /app.',{'path':{'type':'string'}}),
 function('finish','Stop development and freeze the last submission files currently on disk for independent reconstruction and acceptance.',{'summary':{'type':'string'}})
]

def capture(command,timeout):
    try:
        p=subprocess.run(command,capture_output=True,text=True,errors='replace',timeout=timeout)
        return {'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr}
    except subprocess.TimeoutExpired as exc:
        def text(x):return x.decode(errors='replace') if isinstance(x,bytes) else x or ''
        return {'exit_code':124,'stdout':text(exc.stdout),'stderr':text(exc.stderr)+'\nHost timeout'}

def check_seal():
    seal=json.loads((ROOT/'seal.json').read_text())
    bad=[n for n,h in seal['files'].items() if not (ROOT/n).is_file() or digest(ROOT/n)!=h]
    if bad:raise RuntimeError('Pretrial seal mismatch: '+str(bad))
    external=json.loads((ROOT/seal['external_tools_manifest']).read_text())
    observed={p.relative_to(TOOLS_PATH).as_posix() for p in TOOLS_PATH.rglob('*')
              if '__pycache__' not in p.parts and (p.is_file() or p.is_symlink())}
    if observed!=set(external['files'])|set(external['symlinks']):raise RuntimeError('External tool inventory changed')
    if any(not (TOOLS_PATH/n).is_file() or digest(TOOLS_PATH/n)!=h for n,h in external['files'].items()):raise RuntimeError('External tool file changed')
    if any(not (TOOLS_PATH/n).is_symlink() or os.readlink(TOOLS_PATH/n)!=v for n,v in external['symlinks'].items()):raise RuntimeError('External tool link changed')
    return seal

def initialize(work):
    work.mkdir(parents=True)
    shutil.copytree(ROOT/'starter',work/'submission')
    (work/'submission/engineering_report.json').write_text(json.dumps({'design_summary':'Not implemented','instances':{}})+'\n')
    shutil.copy2(ROOT/'TASK.md',work/'TASK.md')
    protocol=(ROOT/'runtime/AGENT_PROTOCOL.md').read_text().replace('B1 Sol trial','B1 DeepSeek trial')
    (work/'AGENT_PROTOCOL.md').write_text(protocol+'\nScoring supplement: each 20-point group requires both instances to pass its physical checks and relevant mesh convergence. A failed stress convergence check earns zero strength points. Full task success requires all five groups.\n')
    for p in [work]+list(work.rglob('*')):p.chmod(0o777 if p.is_dir() else 0o666)

def one(key,run,image):
    folder=run/'deepseek-v4.1-flash-1017';work=folder/'workspace';initialize(work)
    name='b1-ds-'+uuid.uuid4().hex[:12];jobs=Jobs(folder/'native_jobs',work)
    cmd=['docker','run','-d','--name',name,'--network','none','--read-only','--cpus','2','--memory',f'{LIMITS["memory_gib"]}g',
         '--pids-limit','512','--cap-drop','ALL','--security-opt','no-new-privileges','--user','1000:1000',
         '--tmpfs','/tmp:rw,nosuid,size=1g']+agent_tool_mounts()+['-v',f'{work}:/app',
         '-v',f'{work/"TASK.md"}:/app/TASK.md:ro','-v',f'{work/"AGENT_PROTOCOL.md"}:/app/AGENT_PROTOCOL.md:ro',
         '-v',f'{ROOT/"public"}:/opt/b1/public:ro',image]
    r=capture(cmd,45)
    if r['exit_code']:raise RuntimeError(r['stderr'])
    save(folder/'container.json',json.loads(capture(['docker','inspect',name],20)['stdout'])[0])
    instructions=(work/'AGENT_PROTOCOL.md').read_text()
    messages=[{'role':'user','content':(work/'TASK.md').read_text()+'\n\nRead /app/AGENT_PROTOCOL.md and begin your own CAD design and experiments.'}]
    usage=[];tool_count=0;finished=False;summary=None;response={};stop_reason='reply_budget';started=time.monotonic()
    instructions+='\nYour requested model is deepseek-v4.1-flash-1017. The two calibrated instance contracts and measurement scripts are immutable. Only one trial is run.'
    try:
        for turn in range(1,LIMITS['max_responses']+1):
            used=sum(u['output_tokens'] for u in usage);remaining=LIMITS['max_wall_seconds']-(time.monotonic()-started)
            if used>=LIMITS['max_output_tokens']:stop_reason='output_budget';break
            if tool_count>=LIMITS['max_tool_calls']:stop_reason='tool_budget';break
            if remaining<=0:stop_reason='wall_budget';break
            save(folder/'status.json',{'phase':'inference','turn':turn,'tool_calls':tool_count,'elapsed_seconds':time.monotonic()-started,'native_budget':jobs.budget()})
            out=folder/f'turn_{turn:03d}';out.mkdir()
            api_client.DEADLINE=started+LIMITS['max_wall_seconds']
            try:
                response=api_client.call(key,'deepseek-v4.1-flash-1017',messages,instructions,TOOLS,out,min(LIMITS['max_output_per_response'],LIMITS['max_output_tokens']-used))
            except api_client.DeadlineReached:
                save(out/'deadline_inference.json',{'stopped_at_wall_deadline':True,'usage_may_be_unreported':True})
                stop_reason='wall_budget';break
            if response.get('model')!='deepseek-v4.1-flash-1017':raise RuntimeError('Requested/reported model identity differs')
            u=response.get('usage') or {}
            if 'output_tokens' not in u:raise RuntimeError('Missing output accounting')
            usage.append(u);messages.extend(response.get('output',[]))
            calls=[x for x in response.get('output',[]) if x.get('type')=='function_call']
            print(f'DeepSeek turn={turn} tools={tool_count} output={sum(x["output_tokens"] for x in usage)}',flush=True)
            for k,call in enumerate(calls,1):
                remaining=LIMITS['max_wall_seconds']-(time.monotonic()-started)
                if tool_count>=LIMITS['max_tool_calls'] or remaining<=0:break
                tool_count+=1;image_data=None;args={}
                try:
                    args=json.loads(call['arguments'])
                    if call['name']=='terminal':
                        timeout=max(1,min(int(args['timeout_seconds']),180,int(remaining)))
                        result=capture(['docker','exec','-w','/app',name,'timeout','--signal=TERM','--kill-after=5',str(timeout),
                                        'bash','--noprofile','--norc','-c',args['command']],timeout+10)
                        save(out/f'tool_{k}_full.json',{'name':call['name'],'arguments':args,'result':result})
                        for field in ['stdout','stderr']:
                            if len(result[field])>18000:result[field]=result[field][:9000]+'\n[full output retained]\n'+result[field][-9000:]
                    elif call['name']=='analyze_design':result=jobs.launch('analyze',args)
                    elif call['name']=='solve_deck':result=jobs.launch('solver',args)
                    elif call['name']=='read_image':
                        p=work/args['path'].removeprefix('/app/')
                        if p.is_symlink() or not p.resolve().is_relative_to(work.resolve()) or not p.is_file() or p.stat().st_size>8*1024*1024:raise ValueError('Use a regular image under /app, <=8MiB')
                        mime={'.png':'image/png','.jpg':'image/jpeg','.jpeg':'image/jpeg','.webp':'image/webp'}.get(p.suffix.lower())
                        if not mime:raise ValueError('Use PNG/JPEG/WebP')
                        image_data='data:'+mime+';base64,'+base64.b64encode(p.read_bytes()).decode()
                        result={'path':args['path'],'sha256':digest(p)}
                    elif call['name']=='finish':finished=True;summary=args['summary'];result={'freeze_requested':True}
                    else:raise ValueError('Unknown tool')
                except Exception as exc:result={'error':str(exc)}
                result['budget']={'tools':tool_count,'native':jobs.budget(),'elapsed_seconds':time.monotonic()-started}
                save(out/f'tool_{k}.json',{'name':call['name'],'arguments':args,'result':result})
                messages.append({'type':'function_call_output','call_id':call['call_id'],'output':json.dumps(result,ensure_ascii=False)})
                if image_data:messages.append({'role':'user','content':[{'type':'input_text','text':'Your image:'},{'type':'input_image','image_url':image_data}]})
                print(f'DeepSeek tool={call["name"]} native={jobs.budget()}',flush=True)
                if finished:stop_reason='explicit_finish';break
            checkpoint=out/'source_snapshot';checkpoint.mkdir()
            for f in ['build.py','parameters.json','engineering_report.json']:
                source=work/'submission'/f
                if source.is_file() and not source.is_symlink():shutil.copy2(source,checkpoint/f)
            save(folder/'usage.json',usage);save(folder/'checkpoint.json',{'messages':messages,'usage':usage,'tool_calls':tool_count,'turn':turn})
            if finished:break
            if not calls:messages.append({'role':'user','content':'Continue with your tools or finish the current on-disk submission.'})
            messages.append({'role':'user','content':f'Budget: reply{turn}/48, tools{tool_count}/120, elapsed{time.monotonic()-started:.0f}/7200 seconds, native{jobs.budget()}. Inspect asynchronous job status as needed. Only the last submission will be frozen.'})
        development_wall=time.monotonic()-started
        capture(['docker','stop','-t','2',name],15);jobs.close();check_seal()
        save(folder/'integrity_after_development.json',{'passed':True,'case_seal_sha256':digest(ROOT/'seal.json'),
             'external_tools_unchanged':True,'checked_at':datetime.now(timezone.utc).isoformat()})
        frozen=folder/'frozen';frozen.mkdir();source=work/'submission'
        required=['build.py','parameters.json','engineering_report.json']+[i+'/'+f for i in
                  ['B1-01-offset-open','B1-02-cross-optical'] for f in ['bracket.step','design.FCStd']]
        omitted=[]
        for relative in required:
            p=source/relative
            if p.is_symlink() or not p.is_file() or not p.resolve().is_relative_to(source.resolve()) or p.stat().st_size>20000000:
                omitted.append(relative);continue
            q=frozen/relative;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q)
        hashes={p.relative_to(frozen).as_posix():digest(p) for p in frozen.rglob('*') if p.is_file()}
        save(folder/'frozen_manifest.json',{'files':hashes,'selection':'last on-disk submission after agent stopped; no host repair',
                                         'missing_unsafe_or_oversized_required_files':omitted,
                                         'time':datetime.now(timezone.utc).isoformat()})
        save(folder/'development_summary.json',{'stop_reason':stop_reason,'explicit_finish':finished,'finish_summary':summary,
             'responses':len(usage),'tool_calls':tool_count,'agent_wall_seconds':development_wall,
             'input_tokens':sum(u.get('input_tokens',0) for u in usage),'output_tokens':sum(u.get('output_tokens',0) for u in usage),
             'native_budget':jobs.budget(),'requested_model':'deepseek-v4.1-flash-1017','reported_model':response.get('model')})
        save(folder/'status.json',{'phase':'independent_verifier'})
        command=[sys.executable,str(ROOT/'verifier/verify.py'),'--submission',str(frozen),'--out',str(folder/'final_evaluation'),
                 '--image',BASE_IMAGE]
        result=capture(command,13000);save(folder/'verifier_invocation.json',result)
        target=folder/'final_evaluation/result.json'
        final=json.loads(target.read_text()) if target.exists() else {'status':'verifier_error','score':None,'full_pass':False}
        final['development']=json.loads((folder/'development_summary.json').read_text());save(folder/'result.json',final)
        save(folder/'status.json',{'phase':'completed','score':final.get('score'),'full_pass':final.get('full_pass')})
        print('DEEPSEEK_DONE '+json.dumps({'score':final.get('score'),'full_pass':final.get('full_pass')}),flush=True)
    except Exception as exc:
        save(folder/'infrastructure_error.json',{'error':str(exc).replace(key,'<redacted>')});raise
    finally:
        jobs.close();capture(['docker','rm','-f',name],20)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('mode',choices=['preflight','run']);a=ap.parse_args()
    key=sys.stdin.readline().strip();assert key
    model='deepseek-v4.1-flash-1017'
    if model not in api_client.models(key):raise RuntimeError('Exact DeepSeek model unavailable')
    ready=json.loads((ROOT/'validation/calibration.json').read_text());assert ready['ready']
    seal=check_seal();image=json.loads((ROOT/'runtime/images.json').read_text())['agent_image']
    if a.mode=='preflight':
        folder=ADAPTER_ROOT/'preflight';folder.mkdir(exist_ok=True)
        tool=function('ping','Return the supplied value.',{'value':{'type':'string'}})
        messages=[{'role':'user','content':'Call ping with value ok. After the tool result, reply OK.'}]
        responses=[]
        for turn in [1,2]:
            destination=folder/f'turn_{turn}';destination.mkdir(exist_ok=True)
            result=api_client.call(key,model,messages,'This is an API protocol check without benchmark content.',[tool],destination,32768 if turn==1 else 256)
            responses.append(result);messages.extend(result['output'])
            calls=[x for x in result['output'] if x.get('type')=='function_call']
            if turn==1:
                assert len(calls)==1 and calls[0]['name']=='ping' and json.loads(calls[0]['arguments'])=={'value':'ok'}
                messages.append({'type':'function_call_output','call_id':calls[0]['call_id'],'output':'{"value":"ok"}'})
            else:assert not calls and 'OK' in result['output'][0]['message'].get('content','').upper()
        report={'passed':True,'model':model,'reported_models':[r['model'] for r in responses],
                'tool_round_trip':True,'max_output_32768_accepted':True,'reasoning_effort_medium_accepted':True,
                'case_seal_unchanged':True,'task_inference_started':False,'usage':[r['usage'] for r in responses]}
        save(folder/'report.json',report);print(json.dumps(report));return
    assert json.loads((ADAPTER_ROOT/'preflight/report.json').read_text())['passed']
    with (ADAPTER_ROOT/'trial_claim.json').open('x') as claim:
        json.dump({'model':model,'time':datetime.now(timezone.utc).isoformat(),'trial_limit':1},claim)
    run=ADAPTER_ROOT/'runs'/datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ');run.mkdir(parents=True)
    protocol={'models':[model],'limits':LIMITS,'runs_per_model':1,'api_endpoint':api_client.ENDPOINT,
              'base_image':BASE_IMAGE,'agent_image':image,'pre_run_seal':seal,'tools':[t['name'] for t in TOOLS],
              'host_design_edits':False,'selection':'last on-disk submission','official_acceptance_separate':True,
              'scoring_version':'b1-group-convergence-v2-20261115','case_seal_sha256':digest(ROOT/'seal.json'),
              'comparison_baseline_run':str(ROOT/'runs/20261115T043532Z/gpt-6.1-sol'),
              'adapter_hashes':{p.name:digest(p) for p in ADAPTER_ROOT.glob('*.py') if p.name!='session.py'},
              'scoring_spec_sha256':digest(ADAPTER_ROOT/'scoring_spec.md'),
              'provider_reasoning_equivalence':'Same requested medium and external limits; internal reasoning equivalence not established',
              'started_at':datetime.now(timezone.utc).isoformat()}
    save(run/'protocol.json',protocol)
    implementation=run/'implementation';implementation.mkdir()
    for p in ADAPTER_ROOT.glob('*.py'):
        if p.name!='session.py':shutil.copy2(p,implementation/p.name)
    shutil.copy2(ADAPTER_ROOT/'scoring_spec.md',implementation/'scoring_spec.md')
    save(ADAPTER_ROOT/'latest_run.json',{'path':str(run),'phase':'running'})
    one(key,run,image)
    from scoring_v2 import assess
    folder=run/model;data=(folder/'result.json').read_bytes()
    import hashlib
    revised=assess(json.loads(data),hashlib.sha256(data).hexdigest(),model)
    save(folder/'score_v2.json',revised)
    save(ADAPTER_ROOT/'latest_run.json',{'path':str(run),'phase':'completed','score_v2':revised['score']})
    print('SCORE_V2 '+json.dumps({'score':revised['score'],'task_success':revised['task_success']}),flush=True)

if __name__=='__main__':main()
