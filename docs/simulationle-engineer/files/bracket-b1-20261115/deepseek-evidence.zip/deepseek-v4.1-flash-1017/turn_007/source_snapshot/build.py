"""B1 lightweight interface bracket - parametric CAD source.

Design: two planar side walls (delta/truss gussets) run from the fixed base
pad row up to a module carrier plate at the module interface plane.  The walls
carry the vertical/ bending loads as deep in-plane members; the carrier plate
ties the four module pads and the two walls into one box section.  Every
tool-access channel, bore and keep-out volume from the instance contract is
subtracted after the positive solids are fused, so the bracket clears the
driver paths, the module insertion sweep and the optical/cable corridors.

Run with FreeCADCmd:
    B1_INSTANCE=... B1_PUBLIC=... B1_OUTPUT=... freecadcmd build.py
"""
import json
import math
import os
import sys
from pathlib import Path

import Part
import FreeCAD as App

HERE = Path(__file__).resolve().parent
PUBLIC = Path(os.environ.get('B1_PUBLIC', '/opt/b1/public'))
sys.path.insert(0, str(PUBLIC))
from cad_common import interface_solids, exclusion_volumes, export_document, box, cylinder, V  # noqa: E402


def load_inputs():
    spec_path = os.environ.get('B1_INSTANCE')
    if not spec_path:
        raise SystemExit('B1_INSTANCE must point at the instance JSON')
    spec = json.loads(Path(spec_path).read_text(encoding='utf-8'))
    params = json.loads((HERE / 'parameters.json').read_text(encoding='utf-8'))
    return spec, params


def rounded_polygon(pts, radius, segments=8):
    """Closed polygon in the XZ plane with circular corner fillets."""
    out = []
    n = len(pts)
    for i in range(n):
        p0, p1, p2 = pts[i - 1], pts[i], pts[(i + 1) % n]
        v1 = (p0[0] - p1[0], p0[1] - p1[1])
        v2 = (p2[0] - p1[0], p2[1] - p1[1])
        l1, l2 = math.hypot(*v1), math.hypot(*v2)
        u1 = (v1[0] / l1, v1[1] / l1)
        u2 = (v2[0] / l2, v2[1] / l2)
        ang = math.acos(max(-1.0, min(1.0, u1[0] * u2[0] + u1[1] * u2[1])))
        if ang > math.pi - 1e-6 or ang < 1e-6:
            out.append(p1)
            continue
        t = radius / math.tan(ang / 2.0)
        t = min(t, 0.45 * l1, 0.45 * l2)
        r = t * math.tan(ang / 2.0)
        a = (p1[0] + u1[0] * t, p1[1] + u1[1] * t)
        b = (p1[0] + u2[0] * t, p1[1] + u2[1] * t)
        bis = (u1[0] + u2[0], u1[1] + u2[1])
        lb = math.hypot(*bis)
        bis = (bis[0] / lb, bis[1] / lb)
        d = r / math.sin(ang / 2.0)
        c = (p1[0] + bis[0] * d, p1[1] + bis[1] * d)
        a0 = math.atan2(a[1] - c[1], a[0] - c[0])
        a1 = math.atan2(b[1] - c[1], b[0] - c[0])
        da = a1 - a0
        while da > math.pi:
            da -= 2 * math.pi
        while da < -math.pi:
            da += 2 * math.pi
        out.append(a)
        for k in range(1, segments):
            q = a0 + da * k / segments
            out.append((c[0] + r * math.cos(q), c[1] + r * math.sin(q)))
        out.append(b)
    return out


def prism_xz(points, y0, y1):
    """Extrude a closed (x, z) polygon along Y from y0 to y1."""
    lo, hi = min(y0, y1), max(y0, y1)
    wire = [V(p[0], 0.0, p[1]) for p in points]
    wire.append(wire[0])
    face = Part.Face(Part.makePolygon(wire))
    solid = face.extrude(V(0.0, hi - lo, 0.0))
    return solid.translate(V(0.0, lo, 0.0))


def offset_polygon(pts, dist):
    """Inward offset of a convex polygon given in counter-clockwise XZ order."""
    n = len(pts)
    cx = sum(p[0] for p in pts) / n
    cz = sum(p[1] for p in pts) / n
    lines = []
    for i in range(n):
        p, q = pts[i], pts[(i + 1) % n]
        dx, dz = q[0] - p[0], q[1] - p[1]
        ln = math.hypot(dx, dz)
        nx, nz = -dz / ln, dx / ln
        # make normal point at the centroid
        if (cx - p[0]) * nx + (cz - p[1]) * nz < 0:
            nx, nz = -nx, -nz
        lines.append((p[0] + nx * dist, p[1] + nz * dist, dx, dz))
    out = []
    for i in range(n):
        x1, z1, dx1, dz1 = lines[i - 1]
        x2, z2, dx2, dz2 = lines[i]
        det = dx1 * (-dz2) - dz1 * (-dx2)
        if abs(det) < 1e-9:
            out.append((x2, z2))
            continue
        rx, rz = x2 - x1, z2 - z1
        t = (rx * (-dz2) - rz * (-dx2)) / det
        out.append((x1 + dx1 * t, z1 + dz1 * t))
    return out


def build(spec, params):
    p = params['design']
    base, module = spec['base'], spec['module']
    bxs = [c[0] for c in base['centers_xy_mm']]
    bys = [c[1] for c in base['centers_xy_mm']]
    mxs = [c[0] for c in module['centers_xy_mm']]
    mys = [c[1] for c in module['centers_xy_mm']]
    pz = module['plane_z_mm']
    mp = module['pad_height_mm']
    bp = base['pad_height_mm']

    y_in = min(min(mys), min(bys))            # inner wall face (module side)
    y_out = max(max(mys), max(bys))           # outer wall face
    plate_half = max(abs(y) for y in bys) + p['plate_y_margin']
    plate_x0 = min(mxs) - p['plate_x_overhang']
    plate_x1 = max(mxs) + p['plate_x_overhang']
    plate_z0 = pz - mp
    foot_x0 = min(bxs) - base['pad_radius_mm']
    foot_x1 = max(bxs) + base['pad_radius_mm']

    positives = list(interface_solids(spec))
    positives.append(box((plate_x0, -plate_half, plate_z0, plate_x1, plate_half, pz)))

    outer = [(foot_x0, 0.0), (foot_x1, 0.0), (plate_x1, plate_z0), (plate_x0, plate_z0)]
    walls = []
    for side in (1.0, -1.0):
        lo = y_in * side
        hi = y_out * side
        solid = prism_xz(rounded_polygon(outer, p['wall_outer_radius']), lo, hi)
        hole = p['wall_window']
        if hole and p['wall_window_frame'] > 0:
            inner = offset_polygon(outer, p['wall_window_frame'])
            solid = solid.cut(prism_xz(rounded_polygon(inner, hole), lo - 1.0, hi + 1.0))
        walls.append(solid)
    positives.extend(walls)

    shape = positives[0]
    for s in positives[1:]:
        shape = shape.fuse(s)

    negatives = []
    for name, region in exclusion_volumes(spec):
        if name == 'envelope':
            continue
        negatives.append(region)
    shape = shape.cut(negatives[0])
    for r in negatives[1:]:
        shape = shape.cut(r)
    shape = shape.removeSplitter()
    return shape, dict(y_in=y_in, y_out=y_out, plate=(plate_x0, plate_x1, plate_z0, pz),
                       plate_half=plate_half, foot=(foot_x0, foot_x1), pz=pz)


def main():
    spec, params = load_inputs()
    shape, info = build(spec, params)
    solids = shape.Solids
    if len(solids) != 1:
        raise SystemExit('built shape has %d solids' % len(solids))
    print('volume mm3', shape.Volume, 'mass g', shape.Volume * spec['material']['density_g_mm3'])
    print('faces', len(shape.Faces), 'valid', shape.isValid())
    print('info', json.dumps(info, default=str))
    out = os.environ['B1_OUTPUT']
    export_document(shape, spec, params, out, 'B1Bracket')


main()
