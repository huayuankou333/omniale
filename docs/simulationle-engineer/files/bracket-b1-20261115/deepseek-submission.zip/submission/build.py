"""B1 lightweight interface bracket - parametric CAD source (single valid solid).

Topology
--------
* Base frame: two longitudinal rails (one per base-pad row) that carry the four
  fixed base pads and act as the foundation beam of each side.
* Two side gusset walls, one per base row, that run from the base rails up to
  the module carrier plate.  The walls are placed inboard of the base screw
  driver cylinders so the mandatory tool channel stays completely free and the
  wall is never severed by it; the module driver cylinders only notch the top
  edge of the wall where the carrier plate bridges the load.
* Module carrier plate: a flat plate one module-pad height below the module
  mating plane.  It contains the four module pads, ties both walls together
  (torsion box) and spreads the pad loads into the walls.

Every bore, screw-driver channel, keep-out volume and the module insertion
sweep of the instance contract are subtracted from the fused positive solids,
so interface pads stay complete and all access space stays empty.

Run with FreeCADCmd:  B1_INSTANCE, B1_PUBLIC, B1_OUTPUT environment variables.
"""
import json
import math
import os
import sys
from pathlib import Path

import Part
import FreeCAD as App

HERE = Path(__file__).resolve().parent
PUBLIC = Path(os.environ.get('B1_PUBLIC', '/opt/b1/public'))
sys.path.insert(0, str(PUBLIC))
from cad_common import interface_solids, exclusion_volumes, export_document, box, cylinder, V  # noqa: E402


def load_inputs():
    spec_path = os.environ.get('B1_INSTANCE')
    if not spec_path:
        raise SystemExit('B1_INSTANCE must point at the instance JSON')
    spec = json.loads(Path(spec_path).read_text(encoding='utf-8'))
    params = json.loads((HERE / 'parameters.json').read_text(encoding='utf-8'))
    # per-instance parameter overrides
    merged = dict(params['design'])
    merged.update(params.get('instances', {}).get(spec['id'], {}))
    return spec, params, merged


def rounded_polygon(pts, radius, segments=8):
    """Closed polygon in the (x, z) plane with circular corner fillets."""
    out = []
    n = len(pts)
    for i in range(n):
        p0, p1, p2 = pts[i - 1], pts[i], pts[(i + 1) % n]
        v1 = (p0[0] - p1[0], p0[1] - p1[1])
        v2 = (p2[0] - p1[0], p2[1] - p1[1])
        l1, l2 = math.hypot(*v1), math.hypot(*v2)
        u1 = (v1[0] / l1, v1[1] / l1)
        u2 = (v2[0] / l2, v2[1] / l2)
        ang = math.acos(max(-1.0, min(1.0, u1[0] * u2[0] + u1[1] * u2[1])))
        if ang > math.pi - 1e-6 or ang < 1e-6:
            out.append(p1)
            continue
        t = radius / math.tan(ang / 2.0)
        t = min(t, 0.45 * l1, 0.45 * l2)
        r = t * math.tan(ang / 2.0)
        a = (p1[0] + u1[0] * t, p1[1] + u1[1] * t)
        b = (p1[0] + u2[0] * t, p1[1] + u2[1] * t)
        bis = (u1[0] + u2[0], u1[1] + u2[1])
        lb = math.hypot(*bis)
        bis = (bis[0] / lb, bis[1] / lb)
        d = r / math.sin(ang / 2.0)
        c = (p1[0] + bis[0] * d, p1[1] + bis[1] * d)
        a0 = math.atan2(a[1] - c[1], a[0] - c[0])
        a1 = math.atan2(b[1] - c[1], b[0] - c[0])
        da = a1 - a0
        while da > math.pi:
            da -= 2 * math.pi
        while da < -math.pi:
            da += 2 * math.pi
        out.append(a)
        for k in range(1, segments):
            q = a0 + da * k / segments
            out.append((c[0] + r * math.cos(q), c[1] + r * math.sin(q)))
        out.append(b)
    return out


def prism_xz(points, y0, y1):
    """Extrude a closed (x, z) polygon along Y from y0 to y1."""
    lo, hi = min(y0, y1), max(y0, y1)
    wire = [V(p[0], 0.0, p[1]) for p in points]
    wire.append(wire[0])
    face = Part.Face(Part.makePolygon(wire))
    return face.extrude(V(0.0, hi - lo, 0.0)).translate(V(0.0, lo, 0.0))


def build(spec, params, p):
    base, module = spec['base'], spec['module']
    bxs = [c[0] for c in base['centers_xy_mm']]
    bys = [abs(c[1]) for c in base['centers_xy_mm']]
    mxs = [c[0] for c in module['centers_xy_mm']]
    mys = [abs(c[1]) for c in module['centers_xy_mm']]
    pz = module['plane_z_mm']
    zt = pz - module['pad_height_mm']            # module carrier plate bottom
    plate_half = max(bys) + p['plate_y_margin']
    plate_x0 = min(mxs) - p['plate_x_overhang']
    plate_x1 = max(mxs) + p['plate_x_overhang']
    foot_x0 = min(bxs) - base['pad_radius_mm']
    bottom_x1 = p['wall_bottom_x1']
    y_in = p['wall_y_inner']
    y_out = y_in + p['wall_t']
    rail_out = p['base_rail_y_out']

    positives = list(interface_solids(spec))
    # module carrier plate
    positives.append(box((plate_x0, -plate_half, zt, plate_x1, plate_half, pz)))
    # base rails (foundation beams carrying the pads)
    for side in (1.0, -1.0):
        positives.append(box((foot_x0, min(side * y_in, side * rail_out), 0.0,
                              bottom_x1, max(side * y_in, side * rail_out), p['base_rail_z'])))
    # side gusset walls
    outer = [(foot_x0, 0.0), (bottom_x1, 0.0), (plate_x1, zt), (plate_x0, zt)]
    outer = rounded_polygon(outer, p['wall_outer_radius'])
    for side in (1.0, -1.0):
        wall = prism_xz(outer, side * y_in, side * y_out)
        if p.get('wall_window_frame', 0) > 0:
            inner = offset_polygon([(foot_x0, 0.0), (bottom_x1, 0.0), (plate_x1, zt), (plate_x0, zt)],
                                   p['wall_window_frame'])
            wall = wall.cut(prism_xz(rounded_polygon(inner, p['wall_window_radius']),
                                     side * y_in - 1.0, side * y_out + 1.0))
        positives.append(wall)

    shape = positives[0]
    for s in positives[1:]:
        shape = shape.fuse(s)
    negatives = [r for n, r in exclusion_volumes(spec) if n != 'envelope']
    shape = shape.cut(negatives[0])
    for r in negatives[1:]:
        shape = shape.cut(r)
    shape = shape.removeSplitter()
    return shape


def offset_polygon(pts, dist):
    n = len(pts)
    cx = sum(q[0] for q in pts) / n
    cz = sum(q[1] for q in pts) / n
    lines = []
    for i in range(n):
        a, b = pts[i], pts[(i + 1) % n]
        dx, dz = b[0] - a[0], b[1] - a[1]
        ln = math.hypot(dx, dz)
        nx, nz = -dz / ln, dx / ln
        if (cx - a[0]) * nx + (cz - a[1]) * nz < 0:
            nx, nz = -nx, -nz
        lines.append((a[0] + nx * dist, a[1] + nz * dist, dx, dz))
    out = []
    for i in range(n):
        x1, z1, dx1, dz1 = lines[i - 1]
        x2, z2, dx2, dz2 = lines[i]
        det = dx1 * (-dz2) - dz1 * (-dx2)
        if abs(det) < 1e-9:
            out.append((x2, z2))
            continue
        rx, rz = x2 - x1, z2 - z1
        t = (rx * (-dz2) - rz * (-dx2)) / det
        out.append((x1 + dx1 * t, z1 + dz1 * t))
    return out


def main():
    spec, params, p = load_inputs()
    shape = build(spec, params, p)
    if len(shape.Solids) != 1 or not shape.isValid():
        raise SystemExit('invalid shape: %d solids' % len(shape.Solids))
    print('volume_mm3 %.2f  mass_g %.3f  faces %d' % (
        shape.Volume, shape.Volume * spec['material']['density_g_mm3'], len(shape.Faces)))
    export_document(shape, spec, params, os.environ['B1_OUTPUT'], 'B1Bracket')


main()
