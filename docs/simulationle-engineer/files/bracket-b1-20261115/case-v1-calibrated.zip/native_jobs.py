"""Host-owned native worker queue; no credentials or private assets mounted."""
import json,os,shutil,subprocess,threading,time,uuid
from pathlib import Path
from config import ROOT,BASE_IMAGE,TOOLS_PATH,LIMITS,save,digest

def safe_copy(source,target,limit=200*1024*1024):
    source=Path(source).resolve();total=0
    for p in source.rglob('*'):
        if p.is_symlink():raise ValueError('Symlinks are not accepted in a native snapshot')
        if p.is_file():
            total+=p.stat().st_size
            if total>limit:raise ValueError('Snapshot exceeds 200 MiB; keep old results outside submitted design folders')
            q=target/p.relative_to(source);q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q)

class Jobs:
    def __init__(self,folder,workspace):
        self.folder=Path(folder);self.workspace=Path(workspace);self.active=None;self.closed=False
        self.folder.mkdir(parents=True,exist_ok=True)
        self.state={'analysis_calls':0,'solver_credits':0,'custom_solver_calls':0,'jobs':[]}
        self.thread=None;self.name=None

    def launch(self,kind,args):
        if self.closed:raise ValueError('Development frozen')
        if self.thread and self.thread.is_alive():raise ValueError('A native job is still running; inspect /app/development/job_NNN/status.json before starting another')
        cost=12 if kind=='analyze' else 1
        if self.state['solver_credits']+cost>LIMITS['max_solver_credits']:raise ValueError('Shared solver-credit budget exhausted')
        if kind=='analyze' and self.state['analysis_calls']>=LIMITS['max_analysis_calls']:raise ValueError('Analysis-call budget exhausted')
        # Rejected input snapshots remain as evidence and must not block a
        # later valid request or consume solver credits.
        number=len(list(self.folder.glob('job_*')))+1;folder=self.folder/f'job_{number:03d}';folder.mkdir()
        snapshot=folder/'input';snapshot.mkdir()
        if kind=='analyze':
            identity=args['instance']
            if identity not in ['B1-01-offset-open','B1-02-cross-optical']:raise ValueError('Unknown instance')
            source=self.workspace/'submission'/identity
            for name in ['bracket.step','design.FCStd']:
                p=source/name
                if p.is_symlink() or not p.is_file() or p.stat().st_size>20000000:raise ValueError('Missing or unsafe artifact '+name)
                shutil.copy2(p,snapshot/name)
        else:
            p=self.workspace/args['deck_path'].removeprefix('/app/')
            if not p.resolve().is_relative_to(self.workspace.resolve()) or p.is_symlink() or p.suffix!='.inp':raise ValueError('Use a regular .inp file under /app')
            safe_copy(p.parent,snapshot)
            # Native includes may reference only the snapshot, never workers'
            # bundled prior benchmark material or host paths.
            for f in snapshot.rglob('*'):
                if f.is_file():
                    import re
                    for match in re.finditer(r'(?im)^\s*\*include\s*,([^\r\n]+)',f.read_text(errors='replace')):
                        field=re.search(r'(?i)(?:^|,)\s*input\s*=\s*([^,]+)',match.group(1))
                        if not field:raise ValueError('Solver include must name an input within the snapshot')
                        include=field.group(1).strip().strip('"\x27')
                        if Path(include).is_absolute() or '..' in Path(include).parts:raise ValueError('Solver includes must stay within the snapshot')
            args=dict(args,deck_name=p.name)
        self.state['solver_credits']+=cost
        self.state['analysis_calls']+=int(kind=='analyze');self.state['custom_solver_calls']+=int(kind!='analyze')
        record={'number':number,'kind':kind,'args':args,'status':'running','reserved_credits':cost,
                'input_hashes':{p.relative_to(snapshot).as_posix():digest(p) for p in snapshot.rglob('*') if p.is_file()}}
        self.state['jobs'].append(record);save(self.folder/'state.json',self.state)
        target=self.workspace/'development'/folder.name;target.mkdir(parents=True,exist_ok=True)
        self.name='b1-native-'+uuid.uuid4().hex[:12];self.active=record
        self.thread=threading.Thread(target=self.worker,args=(record,folder,snapshot,target,self.name),daemon=True);self.thread.start()
        return {'job':number,'output_directory':'/app/development/'+folder.name,'asynchronous':True,'budget':self.budget()}

    def budget(self):return {k:self.state[k] for k in ['analysis_calls','custom_solver_calls','solver_credits']}

    def worker(self,record,folder,snapshot,target,name):
        started=time.monotonic();save(target/'status.json',{'status':'running','job':record['number']})
        result=folder/'output';result.mkdir();os.chmod(result,0o777)
        command=['docker','run','--rm','--name',name,'--network','none','--read-only','--cpus','2','--memory',f'{LIMITS["memory_gib"]}g',
                 '--pids-limit','512','--cap-drop','ALL','--security-opt','no-new-privileges','--user','1000:1000',
                 '--tmpfs','/tmp:rw,nosuid,size=1g','-v',f'{TOOLS_PATH}:/opt/tools:ro',
                 '-e','HOME=/tmp','-e','QT_QPA_PLATFORM=offscreen','-e','OMP_NUM_THREADS=2','-e','OPENBLAS_NUM_THREADS=1',
                 '-e','MPLCONFIGDIR=/tmp/matplotlib','-v',f'{ROOT/"public"}:/opt/b1/public:ro']
        if record['kind']=='analyze':
            args=record['args'];command+=['-v',f'{snapshot}:/candidate:ro','-v',f'{result}:/result','-w','/tmp',BASE_IMAGE,
             'python3','/opt/b1/public/analyze.py','--submission','/candidate','--instance',f'/opt/b1/public/instances/{args["instance"]}.json','--out','/result']
            if args['geometry_only']:command+=['--geometry-only']
            timeout=5100
        else:
            safe_copy(snapshot,result)
            command+=['-v',f'{result}:/work','-w','/work',BASE_IMAGE,'ccx','-i',Path(record['args']['deck_name']).stem]
            timeout=300
        save(folder/'command.json',{'command':command,'timeout':timeout})
        try:
            p=subprocess.run(command,capture_output=True,text=True,errors='replace',timeout=timeout)
            (folder/'stdout.log').write_text(p.stdout);(folder/'stderr.log').write_text(p.stderr)
            (result/'native_stdout.log').write_text(p.stdout);(result/'native_stderr.log').write_text(p.stderr)
            record.update(status='completed' if p.returncode==0 else 'process_failed',returncode=p.returncode)
        except Exception as exc:record.update(status='worker_error',error=str(exc))
        finally:
            subprocess.run(['docker','rm','-f',name],capture_output=True,timeout=20)
            # Copy data only, never follow a candidate-created symlink.
            total=0
            files=sorted(result.rglob('*'),key=lambda p:(0 if p.suffix in ['.json','.npz','.log'] else 1,len(p.parts),str(p)))
            for p in files:
                if p.is_file() and not p.is_symlink():
                    size=p.stat().st_size
                    if total+size>400*1024*1024:
                        record['artifact_warning']='400 MiB copy limit: JSON, compressed fields and logs prioritized; remaining raw files retained on host';continue
                    total+=size
                    q=target/p.relative_to(result)
                    if q.is_symlink() or not q.resolve().is_relative_to(self.workspace.resolve()):continue
                    q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q)
            record['wall_seconds']=time.monotonic()-started
            record['actual_solver_attempts']=len(list(result.rglob('job.inp'))) if record['kind']=='analyze' else 1
            record['actual_mesh_outputs']=len(list(result.rglob('mesh.json')))
            save(target/'status.json',record);save(folder/'record.json',record);save(self.folder/'state.json',self.state)

    def close(self):
        self.closed=True
        if self.thread and self.thread.is_alive():
            subprocess.run(['docker','rm','-f',self.name],capture_output=True,timeout=20)
            self.thread.join(timeout=25)
        save(self.folder/'state.json',self.state)
