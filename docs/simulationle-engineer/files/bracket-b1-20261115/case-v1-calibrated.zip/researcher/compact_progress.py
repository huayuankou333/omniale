import json,sys
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'public'))
import fem
for tag in sys.argv[1:]:
 for base in (ROOT/'calibration'/tag).glob('*'):
  if not base.is_dir():continue
  spec=json.loads((ROOT/'public/instances'/(base.name+'.json')).read_text())
  g=base/'measurement/geometry.json'
  if g.exists():
   d=json.loads(g.read_text());print(tag,base.name,d['status'],d['metrics'],'failed',[c['name'] for c in d['checks'] if not c['passed']],'errors',d['errors'])
  for b in sorted((base/'measurement').glob('mesh_*')):
   p=b/'mesh_arrays.npz'
   if not p.exists():continue
   m=np.load(p);ids,xyz,conn,volumes,areas=[m[n] for n in ['ids','xyz','conn','volumes','node_area']]
   fixed=fem.patches(xyz,areas,spec,'base');loaded=fem.patches(xyz,areas,spec,'module')
   for c in spec['loads']:
    f=b/c['id'];r=f/'ccx_invocation.json'
    if not r.exists():continue
    d=json.loads(r.read_text())
    if d['returncode']:print(b.name,c['id'],'solver returncode',d['returncode']);continue
    force,origin,wrench=fem.loading(xyz,loaded,areas,spec,c)
    u,rf,s=fem.parse_dat(f/'job.dat',ids,conn,fixed)
    v=fem.metrics(ids,xyz,conn,volumes,areas,fixed,loaded,u,rf,s,origin,wrench,spec)
    print(b.name,c['id'],{k:round(v[k],5) for k in ['interface_translation_mm','interface_rotation_deg','interface_warp_mm','bulk_peak_vm_mpa','interface_p99_vm_mpa']})
