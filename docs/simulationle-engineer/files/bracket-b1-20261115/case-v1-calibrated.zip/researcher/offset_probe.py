import json,os,time
from pathlib import Path
import Part
p=Path(os.environ['B1_STEP']);s=Part.Shape();s.read(str(p));result=[]
for intersection,join in [(False,0),(False,2),(True,0),(True,2)]:
    start=time.time()
    try:
        q=s.makeOffsetShape(-1.5,0.01,intersection,False,0,join)
        item={'intersection':intersection,'join':join,'null':q.isNull(),'solids':len(q.Solids),'volume':q.Volume,'valid':q.isValid()}
    except Exception as e:item={'intersection':intersection,'join':join,'error':str(e)}
    item['seconds']=time.time()-start;result.append(item);print(json.dumps(item),flush=True)
Path('/out/offset_probe.json').write_text(json.dumps(result,indent=2))
