"""Research reference: three-dimensional triangulation around both corridors."""
import json,os,sys
from pathlib import Path
import FreeCAD as App,Part
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'public'))
from cad_common import V,box,interface_solids,exclusion_volumes,export_document,beam_xz
spec=json.loads(Path(os.environ['B1_INSTANCE']).read_text())
z=spec['module']['plane_z_mm'];mx=sum(c[0] for c in spec['module']['centers_xy_mm'])/4
def beam3(a,b,w,d):
    a=V(*a);b=V(*b);axis=b-a;axis.normalize()
    n=axis.cross(V(0,0,1))
    if n.Length<.01:n=axis.cross(V(0,1,0))
    n.normalize();q=axis.cross(n);q.normalize()
    pts=[a+n*w/2+q*d/2,a-n*w/2+q*d/2,a-n*w/2-q*d/2,a+n*w/2-q*d/2]
    return Part.Face(Part.makePolygon(pts+[pts[0]])).extrude(b-a)
pieces=interface_solids(spec)
for y in [-24,24]:
    lo,hi=(y-14,y+8) if y<0 else (y-8,y+14)
    pieces.append(box([-64,lo,0,-16,hi,4]))
for sy in [-1,1]:
    for center in [-56,-20]:
        pts=[V(center-4,sy*28,3),V(center-4,sy*38,3),V(center-4,sy*38,14)]
        pieces.append(Part.Face(Part.makePolygon(pts+[pts[0]])).extrude(V(8,0,0)))
blocked=bool(spec['keepouts']);top_h=6
for x in [mx-14,mx+14]:pieces.append(box([x-6.5,-38,z-top_h,x+6.5,38,z]))
for y in [-35,35]:pieces.append(box([mx-22,y-3,z-top_h,mx+22,y+3,z]))
for y in [-36,36]:
    cx=-8 if blocked else -14
    A=(-60,3);B=(-20,3);C=(cx,z-3);F=(cx,34 if blocked else 20);D=(mx-18,z-3);E=(mx+20,z-3)
    for a,b in [(B,F),(A,F)]:pieces.append(beam_xz(a,b,y,4,8))
    pieces.append(beam_xz(F,C,y,4,6))
    pieces.append(beam_xz(C,E,y,4,8))
    pieces.append(beam_xz(F,D,y,4,10 if blocked else 8))
    pieces.append(beam_xz(F,E,y,4,9 if blocked else 8))
    pieces.append(beam_xz(A,C,y,4,20 if blocked else 12))
for sy in [-1,1]:
    cx=-8 if blocked else -14
    pieces.append(beam3((-20,sy*36,3),(cx,-sy*36,z-3),4,6))
    pieces.append(beam3((cx,sy*36,z-3),(mx+20,-sy*36,z-3),4,6))
shape=pieces[0]
for p in pieces[1:]:shape=shape.fuse(p)
shape=shape.common(box(spec['envelope_mm']))
for lo,hi in [(16,31),(-31,-16)]:shape=shape.cut(box([-47,lo,0,-33,hi,4]))
for name,region in exclusion_volumes(spec):
    if name!='envelope':shape=shape.cut(region)
shape=shape.removeSplitter()
export_document(shape,spec,{'candidate':'space_v9','blocked':blocked},os.environ['B1_OUTPUT'],'B1Space')
