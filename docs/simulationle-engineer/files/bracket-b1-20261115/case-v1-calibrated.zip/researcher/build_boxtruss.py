"""Research calibration: direct diagonal chords without an elbow hinge."""
import json,os,sys
from pathlib import Path
import FreeCAD as App,Part
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'public'))
from cad_common import V,box,interface_solids,exclusion_volumes,export_document,beam_xz
spec=json.loads(Path(os.environ['B1_INSTANCE']).read_text())
z=spec['module']['plane_z_mm'];mx=sum(c[0] for c in spec['module']['centers_xy_mm'])/4
mode=os.environ.get('B1_CANDIDATE','boxtruss')
pieces=interface_solids(spec)
light=mode=='light'
if light:
    for y in [-24,24]:pieces.append(box([-64,y-15,0,-16,y+15,6]))
    pieces.append(box([-44,-39,0,-36,39,4]))
    for x in [mx-14,mx+14]:pieces.append(box([x-6.5,-39,z-6,x+6.5,39,z]))
    for y in [-35,35]:pieces.append(box([mx-22,y-4,z-6,mx+22,y+4,z]))
else:
    for y in [-24,24]:pieces.append(box([-64,y-16,0,-16,y+16,6]))
    pieces.append(box([-64,-40,0,-16,40,4]))
    pieces.append(box([mx-23,-40,z-6,mx+23,40,z]))
for y in [-36,36]:
    pieces.extend([beam_xz((-60,3),(mx-18,z-3),y,4,8 if light else 10),
                   beam_xz((-20,3),(mx+20,z-3),y,4,8 if light else 10),
                   beam_xz((-60,3),(mx+20,z-3),y,4,7 if light else 9),
                   beam_xz((-20,3),(mx-18,z-3),y,4,6 if light else 8)])
# Horizontal diaphragms tie the two side trusses and resist lateral bending.
pieces.append(box([-49,-38,6,-45,38,20]))
pieces.append(box([mx-20,-38,z-18,mx-16,38,z-6]))
shape=pieces[0]
for p in pieces[1:]:shape=shape.fuse(p)
shape=shape.common(box(spec['envelope_mm']))
for name,region in exclusion_volumes(spec):
    if name!='envelope':shape=shape.cut(region)
shape=shape.removeSplitter()
export_document(shape,spec,{'candidate':'boxtruss','mode':mode},os.environ['B1_OUTPUT'],'B1BoxTruss')
