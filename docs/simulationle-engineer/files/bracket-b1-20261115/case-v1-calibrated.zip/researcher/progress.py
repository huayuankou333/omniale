import json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
for p in sorted((ROOT/'calibration').glob('*/*/measurement')):
    info={'tag':p.parent.parent.name,'instance':p.parent.name}
    if (p/'geometry.json').exists():
        g=json.loads((p/'geometry.json').read_text());info.update(mass=g['metrics'].get('mass_g'),geometry_errors=g['errors'],geometry_failed=[c['name'] for c in g['checks'] if not c['passed']])
    for f in sorted(p.glob('mesh_*/result.json')):
        j=json.loads(f.read_text());values=[v['metrics'] for v in j['loadcases'].values()]
        info[f.parent.name]={'status':j['status'],'cases':len(values),'errors':j['errors'],
          'worst':{key:max((v[key] for v in values),default=None) for key in ['interface_translation_mm','interface_rotation_deg','bulk_peak_vm_mpa','interface_p99_vm_mpa']}}
    if (p/'result.json').exists():
        j=json.loads((p/'result.json').read_text());info.update(status=j['status'],score=j['score'],errors=j['errors'],
          failed=[c for c in j['checks'] if not c['passed']],convergence_failed=[c for c in j.get('convergence',[]) if not c['passed']])
    print(json.dumps(info))
