"""Local slow-stream fixture only; never contacts a model provider."""
import json,sys,time,threading
from http.server import BaseHTTPRequestHandler,HTTPServer
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
import api_client
from config import save
class Handler(BaseHTTPRequestHandler):
 def log_message(self,*args):pass
 def do_POST(self):
  self.rfile.read(int(self.headers['Content-Length']));self.send_response(200);self.send_header('Content-Type','text/event-stream');self.end_headers();self.wfile.flush();time.sleep(2)
server=HTTPServer(('127.0.0.1',0),Handler);thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
api_client.BASE_URL=f'http://127.0.0.1:{server.server_port}'
out=ROOT/'validation/api_deadline_fixture';out.mkdir(exist_ok=False)
started=time.monotonic();api_client.DEADLINE=started+.6
try:api_client.call('local-fixture-no-secret','local-fixture',[],'',[],out,20)
except api_client.DeadlineReached:elapsed=time.monotonic()-started
else:raise AssertionError('Silent stream did not stop at the development deadline')
assert elapsed<1.5,elapsed
save(ROOT/'validation/deadline_checks.json',{'ready':True,'elapsed_seconds':elapsed,'deadline_seconds':.6,'fixture_only':True,'provider_requests':0,'model_calls':0})
server.server_close();print(json.dumps({'ready':True,'elapsed_seconds':elapsed,'provider_requests':0}))
