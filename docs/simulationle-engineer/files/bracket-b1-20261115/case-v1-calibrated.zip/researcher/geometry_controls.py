import json,os,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from calibrate import ROOT,run
tag=sys.argv[1];identity='B1-02-cross-optical'
source=ROOT/'calibration'/tag/identity
summary={}
for mode,expected in [('baseline',None),('overweight','mass'),('blocked','optical'),('thin','connected_3mm_backbone'),('fcstd_mismatch','fcstd_matches_step')]:
 out=ROOT/'validation/geometry_controls'/mode;out.mkdir(parents=True,exist_ok=False);os.chmod(out,0o777)
 env={'B1_INSTANCE':f'/case/public/instances/{identity}.json','B1_SOURCE_STEP':f'/case/calibration/{tag}/{identity}/bracket.step','B1_OUTPUT':'/out','B1_CONTROL':mode}
 build=run(['/home/user/.local/bin/freecadcmd','/case/researcher/build_control.py'],[(ROOT,'/case',False),(out,'/out',True)],env,out/'build.json',300)
 measurement=out/'measurement';measurement.mkdir();os.chmod(measurement,0o777)
 r=run(['python3','/case/public/analyze.py','--submission','/design','--instance',f'/case/public/instances/{identity}.json','--out','/result','--geometry-only'],
       [(ROOT,'/case',False),(out,'/design',False),(measurement,'/result',True)],{},out/'measurement_invocation.json',400)
 d=json.loads((measurement/'geometry.json').read_text());checks={c['name']:c['passed'] for c in d['checks']}
 assert not d['errors'],d['errors']
 if expected:assert checks[expected] is False,(mode,checks)
 else:assert all(checks.values()),checks
 assert checks['valid_single_solid'],(mode,checks)
 summary[mode]={'target':expected,'checks':checks,'metrics':d['metrics'],'expected_detection':True}
(ROOT/'validation/negative_controls.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'ready':True,'controls':list(summary)}))
