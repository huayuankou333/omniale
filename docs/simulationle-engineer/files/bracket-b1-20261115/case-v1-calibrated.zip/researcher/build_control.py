import json,os,sys
from pathlib import Path
import FreeCAD as App,Part
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'public'))
from cad_common import box,beam_xz,export_document
spec=json.loads(Path(os.environ['B1_INSTANCE']).read_text());mode=os.environ['B1_CONTROL']
s=Part.Shape();s.read(os.environ['B1_SOURCE_STEP'])
if mode in ['overweight','fcstd_mismatch']:s=s.fuse(box([-46,-12,0,-34,12,35]))
elif mode=='blocked':s=s.fuse(box([0,12,38,4,37,43]))
elif mode=='thin':
    z=spec['module']['plane_z_mm'];slab=box([-70,-42,40,82,42,44])
    neck=beam_xz((-60,3),(-8,z-3),36,1,1)
    s=s.cut(slab.cut(neck))
s=s.removeSplitter()
export_document(s,spec,{'control':mode},os.environ['B1_OUTPUT'],'Control')
if mode=='fcstd_mismatch':Path(os.environ['B1_OUTPUT'],'bracket.step').write_bytes(Path(os.environ['B1_SOURCE_STEP']).read_bytes())
