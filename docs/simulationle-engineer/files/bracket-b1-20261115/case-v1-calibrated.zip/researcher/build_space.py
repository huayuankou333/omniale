"""Research reference: three-dimensional triangulation around both corridors."""
import json,os,sys
from pathlib import Path
import FreeCAD as App,Part
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'public'))
from cad_common import V,box,interface_solids,exclusion_volumes,export_document,beam_xz
spec=json.loads(Path(os.environ['B1_INSTANCE']).read_text())
z=spec['module']['plane_z_mm'];mx=sum(c[0] for c in spec['module']['centers_xy_mm'])/4
def beam3(a,b,w,d):
    a=V(*a);b=V(*b);axis=b-a;axis.normalize()
    n=axis.cross(V(0,0,1))
    if n.Length<.01:n=axis.cross(V(0,1,0))
    n.normalize();q=axis.cross(n);q.normalize()
    pts=[a+n*w/2+q*d/2,a-n*w/2+q*d/2,a-n*w/2-q*d/2,a+n*w/2-q*d/2]
    return Part.Face(Part.makePolygon(pts+[pts[0]])).extrude(b-a)
pieces=interface_solids(spec)
for y in [-24,24]:pieces.append(box([-64,y-15,0,-16,y+15,6]))
pieces.append(box([-44,-39,0,-36,39,4]))
for x in [mx-14,mx+14]:pieces.append(box([x-6.5,-39,z-6,x+6.5,39,z]))
for y in [-35,35]:pieces.append(box([mx-22,y-4,z-6,mx+22,y+4,z]))
for y in [-36,36]:
    A=(-60,3);B=(-20,3);C=(-14,60);F=(-14,38);D=(mx-18,z-3);E=(mx+20,z-3)
    for a,b in [(A,C),(B,F),(A,F),(F,C),(C,E),(F,E)]:pieces.append(beam_xz(a,b,y,4,8))
    pieces.append(beam_xz(C,D,y,4,8))
for sy in [-1,1]:
    pieces.append(beam3((-20,sy*36,3),(-14,-sy*36,60),6,4))
    pieces.append(beam3((-14,sy*36,60),(mx+20,-sy*36,z-3),6,4))
shape=pieces[0]
for p in pieces[1:]:shape=shape.fuse(p)
shape=shape.common(box(spec['envelope_mm']))
for name,region in exclusion_volumes(spec):
    if name!='envelope':shape=shape.cut(region)
shape=shape.removeSplitter()
export_document(shape,spec,{'candidate':'space','web_width':4,'web_depth':8},os.environ['B1_OUTPUT'],'B1Space')
