"""Small reviewable evidence bundle; full native fields remain on the server."""
import hashlib,json,os,re,sys,zipfile
from datetime import datetime,timezone
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from config import save,digest,LIMITS
latest=json.loads((ROOT/'latest_run.json').read_text());run=Path(latest['path']);model=run/'gpt-6.1-sol'
result=json.loads((model/'result.json').read_text());development=json.loads((model/'development_summary.json').read_text())
seal=json.loads((ROOT/'seal.json').read_text());bad=[n for n,h in seal['files'].items() if digest(ROOT/n)!=h]
assert not bad,bad
out=ROOT/'exports';out.mkdir(exist_ok=True)
turns=sorted(model.glob('turn_*'));inferences=[];tools=[]
for turn in turns:
 p=turn/'inference.json'
 if p.exists():inferences.append(json.loads(p.read_text()))
 for p in sorted(turn.glob('tool_*.json')):
  if p.stem.endswith('_full'):continue
  d=json.loads(p.read_text());tools.append({'turn':turn.name,'file':p.name,'name':d['name'],'arguments':d.get('arguments'),
    'budget':d.get('result',{}).get('budget'),'error':d.get('result',{}).get('error')})
native_path=model/'native_jobs/state.json';native=json.loads(native_path.read_text()) if native_path.exists() else {'jobs':[]}
api_attempts=[]
for turn in turns:
 for p in sorted(turn.glob('response_attempt_*.json')):
  r=json.loads(p.read_text());api_attempts.append({'turn':turn.name,'attempt':p.stem,'model':r.get('model'),'status':r.get('status'),'usage':r.get('usage')})
reported_input=sum((a['usage'] or {}).get('input_tokens',0) for a in api_attempts)
reported_output=sum((a['usage'] or {}).get('output_tokens',0) for a in api_attempts)
assert len(inferences)==development['responses'];assert len(tools)==development['tool_calls']
assert all(i['requested_model']=='gpt-6.1-sol' and i['reported_model']=='gpt-6.1-sol' for i in inferences)
assert native.get('solver_credits',0)<=LIMITS['max_solver_credits'] and native.get('analysis_calls',0)<=LIMITS['max_analysis_calls']
frozen=json.loads((model/'frozen_manifest.json').read_text());assert all(digest(model/'frozen'/n)==h for n,h in frozen['files'].items())
final_checks={}
for identity,value in result.get('instances',{}).items():
 final_checks[identity]={'status':value['status'],'score':value.get('score'),'groups':value.get('groups'),
  'mass_g':value.get('geometry',{}).get('metrics',{}).get('mass_g'),
  'failed_checks':[c for c in value.get('checks',[]) if not c['passed']],
  'errors':value.get('errors',[]),'worst':{k:max((c['metrics'][k] for m in value.get('meshes',[]) for c in m.get('loadcases',{}).values()),default=None)
   for k in ['interface_translation_mm','interface_rotation_deg','interface_warp_mm','bulk_peak_vm_mpa','interface_p99_vm_mpa']}}
audit={'requested_models':['gpt-6.1-sol'],'reported_models':sorted(set(i['reported_model'] for i in inferences)),
 'one_trial_claim':json.loads((ROOT/'trial_claim.json').read_text()),'logical_runs':1,'responses':len(inferences),'tools':len(tools),
 'development':development,'native_budget':{k:native.get(k,0) for k in ['analysis_calls','custom_solver_calls','solver_credits']},
 'api_attempts_with_terminal_response':api_attempts,'all_terminal_response_input_tokens':reported_input,'all_terminal_response_output_tokens':reported_output,
 'output_budget_compliant_including_reported_retries':reported_output<=LIMITS['max_output_tokens'],
 'request_turns':sum((t/'request.json').is_file() for t in turns),
 'turns_without_reported_usage':[t.name for t in turns if (t/'request.json').exists() and not (t/'inference.json').exists()],
 'transport_error_records':sum(len(list(t.glob('transport_*.json'))) for t in turns),
 'hosted_solver_attempts':sum(j.get('actual_solver_attempts',0) for j in native['jobs']),
 'hosted_mesh_outputs':sum(j.get('actual_mesh_outputs',0) for j in native['jobs']),
 'native_jobs_with_incomplete_accounting':[j['number'] for j in native['jobs'] if 'actual_solver_attempts' not in j],
 'official_mesh_outputs':len(list((model/'final_evaluation').rglob('mesh.json'))),
 'official_prepared_solver_decks':len(list((model/'final_evaluation').rglob('job.inp'))),
 'case_files_unchanged':True,'frozen_files_unchanged':True,'selection':'last on-disk submission; no host repair or historical best',
 'source_only_rebuild':result.get('source_only_rebuild'),'instances':final_checks,
 'calibration_separate':json.loads((ROOT/'validation/pretrial_compute_inventory.json').read_text()),
 'financial_cost_and_balance':'not verified; provider-reported token usage only',
 'raw_native_fields':'retained on server; compressed deliverable carries summaries, logs, source snapshots and frozen submission',
 'raw_API_records':'retained on server; deliverable carries model identity, usage and tool records'}
save(out/'B1_trace_audit.json',audit);save(out/'B1_Sol_result.json',result)
for source,name in [(ROOT/'seal.json','B1_seal.json'),(ROOT/'validation/calibration.json','B1_calibration.json'),
 (ROOT/'runtime/protocol.json','B1_protocol.json'),(ROOT/'validation/physical_contract_integrity.json','B1_physical_contract_integrity.json'),
 (ROOT/'TASK.md','B1_v1_TASK.md'),(model/'frozen_manifest.json','B1_Sol_manifest.json')]:
 (out/name).write_bytes(source.read_bytes())
def zip_files(target,files):
 seen=set()
 with zipfile.ZipFile(target,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for file,name in files:
   if name in seen:continue
   seen.add(name);z.write(file,name)
case_files=[(ROOT/n,n) for n in seal['files']]+[(ROOT/'seal.json','seal.json')]
zip_files(out/'B1_case_v1_calibrated.zip',case_files)
evidence=[]
for p in [run/'protocol.json',model/'development_summary.json',model/'usage.json',model/'frozen_manifest.json',model/'integrity_after_development.json',model/'result.json',model/'container.json']:
 if p.is_file():evidence.append((p,p.relative_to(run).as_posix()))
for p in (model/'frozen').rglob('*'):
 if p.is_file():evidence.append((p,p.relative_to(run).as_posix()))
for turn in turns:
 for p in turn.rglob('*'):
  if p.is_file() and (p.name=='inference.json' or p.name.startswith('tool_') or 'source_snapshot' in p.parts):evidence.append((p,p.relative_to(run).as_posix()))
for p in (model/'final_evaluation').rglob('*'):
 if p.is_file() and (p.suffix in ['.json','.log'] or p.name in ['build.py','parameters.json','engineering_report.json']):evidence.append((p,p.relative_to(run).as_posix()))
for p in (model/'native_jobs').rglob('*.json'):
 if p.name in ['state.json','record.json','command.json','result.json','geometry.json','mesh.json','ccx_invocation.json','invocation.json'] and p.stat().st_size<2000000:evidence.append((p,p.relative_to(run).as_posix()))
evidence.append((out/'B1_trace_audit.json','B1_trace_audit.json'))
zip_files(out/'B1_Sol_evidence.zip',evidence)
calibration=[]
for base in [ROOT/'calibration',ROOT/'validation']:
 for p in base.rglob('*.json'):
  if p.stat().st_size<2000000 and p.name in ['result.json','geometry.json','mesh.json','ccx_invocation.json','build_invocation.json','instance_at_start.json','rebuild_invocation.json','record.json','state.json']:calibration.append((p,p.relative_to(ROOT).as_posix()))
zip_files(out/'B1_calibration_evidence.zip',calibration)
secret_pattern=re.compile(rb'(?:sk-[A-Za-z0-9_-]{24,}|-----BEGIN (?:RSA |OPENSSH )?PRIVATE KEY-----)')
for file in out.iterdir():
 if file.suffix=='.zip':
  with zipfile.ZipFile(file) as z:
   for name in z.namelist():
    assert not name.endswith(('session.py','remote_session.py')),'Private transport script in package'
    assert not secret_pattern.search(z.read(name)),'Secret-shaped content in '+name
 else:assert not secret_pattern.search(file.read_bytes()),'Secret-shaped content in '+file.name
save(out/'B1_delivery_verification.json',{'case_files_unchanged':True,'private_transport_excluded':True,'secret_pattern_scan_passed':True,
 'files':{p.name:{'sha256':digest(p),'bytes':p.stat().st_size} for p in out.iterdir() if p.is_file() and p.name!='B1_delivery_verification.json'},
 'server_run_path':str(run),'exported_at':datetime.now(timezone.utc).isoformat()})
print(json.dumps({'exports':str(out),'score':result.get('score'),'full_pass':result.get('full_pass'),'files':[p.name for p in out.iterdir()]}))
