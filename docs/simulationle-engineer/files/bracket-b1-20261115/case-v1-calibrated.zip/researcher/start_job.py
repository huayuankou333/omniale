"""Start a local researcher operation with durable logs; does not hold SSH."""
import json,subprocess,sys
from pathlib import Path
root=Path(__file__).resolve().parents[1]
log=root/sys.argv[1];log.parent.mkdir(parents=True,exist_ok=True)
with log.open('ab') as stream:
    p=subprocess.Popen(sys.argv[2:],cwd=root,stdin=subprocess.DEVNULL,stdout=stream,stderr=subprocess.STDOUT,
                       start_new_session=True,close_fds=True)
print(json.dumps({'pid':p.pid,'log':str(log)}))
