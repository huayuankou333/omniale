"""Pretrial integrity gate. Never edits the physical acceptance thresholds."""
import argparse,json,os,subprocess,sys
from datetime import datetime,timezone
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from config import BASE_IMAGE,TOOLS_PATH,LIMITS,digest,save
p=argparse.ArgumentParser();p.add_argument('--inventory-only',action='store_true');a=p.parse_args()
tool_manifest=ROOT/'runtime/external_tools_manifest.json'
if not tool_manifest.exists():
 files={};links={}
 for f in sorted(TOOLS_PATH.rglob('*')):
  if '__pycache__' in f.parts:continue
  n=f.relative_to(TOOLS_PATH).as_posix()
  if f.is_symlink():links[n]=os.readlink(f)
  elif f.is_file():files[n]=digest(f)
 save(tool_manifest,{'root':str(TOOLS_PATH),'files':files,'symlinks':links,'excluded':'Python cache only'})
 print(json.dumps({'external_tools_files':len(files),'external_tools_symlinks':len(links)}),flush=True)
if a.inventory_only:raise SystemExit(0)
assert not (ROOT/'trial_claim.json').exists(),'A model trial has already been claimed'
reference_path=ROOT/'validation/reference_full_rebuild_v4/result.json'
ref=json.loads(reference_path.read_text());assert ref['status']=='valid' and ref['score']==100 and ref['full_pass']
assert ref['frozen_files_unchanged']
assert ref['source_only_rebuild']
runtime=json.loads((ROOT/'validation/runtime_checks.json').read_text());assert runtime['ready'] and runtime['freecad_build_with_solver_and_archive_masks']
gateway=json.loads((ROOT/'validation/gateway_checks.json').read_text());assert gateway['ready']
assert json.loads((ROOT/'validation/mesh_repeatability.json').read_text())['ready']
assert json.loads((ROOT/'validation/source_isolation.json').read_text())['ready']
assert json.loads((ROOT/'validation/deadline_checks.json').read_text())['ready']
negative=json.loads((ROOT/'validation/negative_controls.json').read_text());assert len(negative)==5 and all(v['expected_detection'] for v in negative.values())
physical={}
for file in (ROOT/'public/instances').glob('*.json'):
 old=ROOT.parent/'draft_20261115/public/instances'/file.name
 first=json.loads(old.read_text());now=json.loads(file.read_text())
 keys=['limits','material','envelope_mm','base','module','keepouts','loads','stress_regions','loading','scoring']
 equal={k:first[k]==now[k] for k in keys};assert all(equal.values()),equal
 physical[file.stem]={'original_sha256':digest(old),'final_sha256':digest(file),'preserved_sections':equal}
save(ROOT/'validation/physical_contract_integrity.json',physical)
time=datetime.now(timezone.utc).isoformat()
save(ROOT/'runtime/base_image_inventory.json',{'base_image_id':BASE_IMAGE,'agent_image':json.loads((ROOT/'runtime/images.json').read_text())['agent_image'],
 'verified_at':time,'external_tools_manifest_sha256':digest(tool_manifest),'tools':{'FreeCAD':'1.1.0','Gmsh':'4.12.1','CalculiX':'2.21'},
 'correction':'Original draft had an extra hexadecimal character in its copied image ID; actual local image was verified and pinned before calibration.'})
save(ROOT/'validation/calibration.json',{'ready':True,'revision':'v1-20261115','time':time,'model_calls_at_freeze':0,
 'reference_score':100,'reference_full_pass':True,'reference_result_sha256':digest(reference_path),
 'reference_submission':{p.relative_to(ROOT/'researcher/reference_submission').as_posix():digest(p) for p in (ROOT/'researcher/reference_submission').rglob('*') if p.is_file()},
 'instances':{k:{'mass_g':v['geometry']['metrics']['mass_g'],'worst':{m:max(c['metrics'][m] for mesh in v['meshes'] for c in mesh['loadcases'].values()) for m in ['interface_translation_mm','interface_rotation_deg','interface_warp_mm','bulk_peak_vm_mpa','interface_p99_vm_mpa']},'all_checks_passed':all(c['passed'] for c in v['checks'])} for k,v in ref['instances'].items()},
 'negative_controls':list(negative),'native_runtime_checks':True,'gateway_checks':True,'physical_thresholds_preserved':True,
 'numerical_changes':{'meshes_mm':[2.5,2.0],'mesh_threads':1,'random_seed':1,'memory_gib':8,'backbone':'0.75mm sampled erosion proxy, radius1.5mm, tessellation0.12mm','stress_convergence':'delta <= max(8% fine stress,5MPa)'},
 'limitations':['One complete feasible construction with obstacle-dependent sections; not a proof of a unique or broad feasible design space.','Mechanical difficulty is unverified until the single Sol trial.']})
save(ROOT/'validation/STATUS.json',{'case_revision':'v1-20261115','calibrated':True,'independent_reference_rebuild_passed':True,'reference_score':100,'reference_full_pass':True,'Sol_calls_at_freeze':0,'Sol_result':None,'trial_authorization':'开始测试B1（只测试sol）','limits':LIMITS})
contract=json.loads((ROOT/'contract.json').read_text());contract.update(acceptance_status='FROZEN_CALIBRATED',reference_feasibility='INDEPENDENT_FULL_PASS_BOTH_INSTANCES',difficulty_evidence='AWAITING_SINGLE_SOL_TRIAL');save(ROOT/'contract.json',contract)
task=(ROOT/'TASK.md').read_text();task=task.replace('**当前状态：测试前校准版。正式测试须先建立两个实例均通过的参考设计，完成独立重建检查，并记录试验前冻结哈希。**','**当前状态：已完成双实例可行参考校准与独立重建验收，作为本次单次 Sol 测试的冻结题面。**');(ROOT/'TASK.md').write_text(task)
(ROOT/'researcher/CALIBRATION_PLAN.md').write_text('''# B1 本次校准状态

原草案及每个失败候选均保留。已完成：固定镜像与外部工具、标准求解算例、模型隔离检查、异步额度网关、有效/超重/障碍/细连接/FCStd不一致的几何对照，以及双实例参考设计的隔离重建与独立两网格六工况复算。

物理阈值、接口、材料、禁入区与载荷均保持原草案数值。OCC 内缩失败改用公开的固定采样代理；收敛应力绝对容差为5MPa；网格2.5/2mm，内存8GiB。旧候选的旧合同测量不覆盖、不重写，新合同由独立参考验收重新运行。

已得到一种完整可行构造，包含针对两实例的不同截面选择。没有声称已证明第二种独立完整可行拓扑、唯一性或广泛可行域。Sol 仅运行一次，难度结论等待实际结果；不会用测量/执行故障制造低分。
''',encoding='utf-8')
save(ROOT/'validation/pretrial_compute_inventory.json',{'scope':'calibration and validation only; no model generation',
 'calibration_build_records':len(list((ROOT/'calibration').rglob('build_invocation.json'))),
 'calibration_mesh_outputs':len(list((ROOT/'calibration').rglob('mesh.json'))),
 'calibration_prepared_solver_decks':len(list((ROOT/'calibration').rglob('job.inp'))),
 'independent_reference_solver_decks':len(list(reference_path.parent.rglob('job.inp'))),
 'validation_mesh_outputs':len(list((ROOT/'validation').rglob('mesh.json'))),
 'note':'Prepared decks count solver attempts, including failed/terminated attempts; distinguish from successful solves and reserved credits. Native custom cube probes are reported in their own state records.'})
selected=[]
for p in ROOT.rglob('*'):
 if not p.is_file() or p.is_symlink():continue
 n=p.relative_to(ROOT).as_posix()
 if '__pycache__' in p.parts or n.startswith(('calibration/','runs/')) or n in ['seal.json','MANIFEST.json','trial_claim.json','latest_run.json']:continue
 if n.startswith('validation/') and n not in ['validation/calibration.json','validation/STATUS.json','validation/runtime_checks.json','validation/gateway_checks.json','validation/negative_controls.json','validation/mesh_repeatability.json','validation/source_isolation.json','validation/deadline_checks.json','validation/physical_contract_integrity.json','validation/pretrial_compute_inventory.json','validation/reference_full_rebuild_v4/result.json']:continue
 if p.suffix=='.log':continue
 selected.append(p)
files={p.relative_to(ROOT).as_posix():digest(p) for p in sorted(selected)}
save(ROOT/'MANIFEST.json',{'revision':'v1-20261115','files':files});files['MANIFEST.json']=digest(ROOT/'MANIFEST.json')
save(ROOT/'seal.json',{'revision':'v1-20261115','time':time,'files':files,'external_tools_manifest':'runtime/external_tools_manifest.json','physical_thresholds_preserved':True,'Sol_calls_at_freeze':0})
print(json.dumps({'sealed':True,'files':len(files),'reference_score':100,'Sol_calls':0}),flush=True)
