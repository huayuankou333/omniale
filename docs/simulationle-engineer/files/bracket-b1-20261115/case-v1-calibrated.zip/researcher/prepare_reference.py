"""Package one calibrated construction for the isolated source rebuild gate."""
import argparse,json,shutil
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser();p.add_argument('--script',required=True);p.add_argument('--tags',nargs=2,required=True);a=p.parse_args()
out=ROOT/'researcher/reference_submission';out.mkdir(exist_ok=False)
source=(ROOT/'researcher'/a.script).read_text()
source=source.replace("sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'public'))","sys.path.insert(0,os.environ['B1_PUBLIC'])")
source=source.replace("spec=json.loads(Path(os.environ['B1_INSTANCE']).read_text())", "params=json.loads(Path(__file__).with_name('parameters.json').read_text())\nspec=json.loads(Path(os.environ['B1_INSTANCE']).read_text())")
(out/'build.py').write_text(source)
(out/'parameters.json').write_text(json.dumps({'construction':a.script,'revision':'calibrated_v1'})+'\n')
(out/'engineering_report.json').write_text(json.dumps({'design_summary':'Triangulated rear support, side cantilever chords, plan bracing, ribbed mounting crossmembers; separate obstacle-aware section choices.','instances':{'B1-01-offset-open':{'load_path':'lower return chord in open space'},'B1-02-cross-optical':{'load_path':'raised return chord around optical and cable clearances'}}},indent=2)+'\n')
for identity,tag in zip(['B1-01-offset-open','B1-02-cross-optical'],a.tags):
 d=out/identity;d.mkdir()
 for f in ['bracket.step','design.FCStd']:shutil.copy2(ROOT/'calibration'/tag/identity/f,d/f)
print(out)
