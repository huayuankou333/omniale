"""Finalize calibrated numerics before any model call; original draft is separate."""
import argparse,json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from config import LIMITS,BASE_IMAGE,save
p=argparse.ArgumentParser();p.add_argument('--stress-absolute-mpa',type=float,default=0);a=p.parse_args()
for path in (ROOT/'public/instances').glob('*.json'):
 d=json.loads(path.read_text());d.update(revision='v1-20261115',status='calibrated_pretrial_contract')
 d['meshing']['sizes_mm']=[2.5,2.0]
 d['meshing']['threads']=1;d['meshing']['random_seed']=1
 if a.stress_absolute_mpa:
  for k in ['bulk_peak_vm_mpa','interface_p99_vm_mpa']:d['meshing']['convergence_floors'][k]=a.stress_absolute_mpa/d['meshing']['convergence_relative']
  d['meshing']['stress_absolute_convergence_mpa']=a.stress_absolute_mpa
 save(path,d)
protocol={'status':'PRETRIAL_FINAL','models':['gpt-6.1-sol'],'runs_per_model':1,'limits':LIMITS,
 'candidate_count_limit':None,'reset_limit':None,'analysis_reserved_solver_credits':12,'geometry_only_reserved_solver_credits':12,
 'custom_deck_reserved_solver_credits':1,'unused_credits_refunded':False,'selection':'last submission on disk',
 'official_acceptance_outside_development_budget':True,'network':'none','api_secret_in_agent':False,
 'reference_or_verifier_mount':False,'pricing_and_balance':'unverified; report usage only'}
save(ROOT/'runtime/protocol.json',protocol)
d=json.loads((ROOT/'contract.json').read_text());d.update(revision='v1-20261115',acceptance_status='AWAITING_INDEPENDENT_REFERENCE_REBUILD',
 reference_feasibility='native_calibration_in_progress',difficulty_evidence='awaiting_one_Sol_trial',
 threshold_policy='Physical limits preserved from draft; numerical measurement and runtime calibrated before Sol')
d.pop('no_test_instruction',None);save(ROOT/'contract.json',d)
(ROOT/'README.md').write_text('''# B1 受空间和接口约束的轻量支架

本目录是 B1 的原生校准和单次 Sol 测试版本。原始未执行草案单独保留在 draft_20261115 和原交付压缩包中。任务复用传感器外壳结构 B 的 CAD → Gmsh → CalculiX 工作流，新增支架载荷路径、偏心力矩、光路/线束障碍和模块平移/转角/翘曲要求；不继承旧题成绩。

公开文件是 TASK.md、public/、starter/、runtime/AGENT_PROTOCOL.md。researcher/、validation/、verifier/ 和任何凭据均不提供给模型。

runtime/protocol.json 和 config.py 规定正式预算。run_sol.py 只允许一次 gpt-6.1-sol 试验；必须先通过 validation/calibration.json 和 seal.json。托管异步求解网关单独记账，禁止直接绕过求解预算。模型停止后冻结最后一版提交，独立运行 build.py、比较 STEP/FCStd，再从交付 STEP 重新网格与计算。

实际参考可行性见 validation/calibration.json；几何负对照见 validation/negative_controls.json；运行环境检查见 validation/runtime_checks.json。原生校准全量记录位于 calibration/，模型记录位于 runs/。尚未取得的结果不会由草案状态推定。
''',encoding='utf-8')
(ROOT/'runtime/README.md').write_text('''# B1 固定运行环境

实际基础镜像以 config.py 的不可变 ID 为准，模型镜像以 images.json 为准。agent.Dockerfile 删除旧参考、规格、验收器和系统 ccx。外部 FreeCAD 工具只读挂载，额外屏蔽其附带 ccx 和可重新解包该二进制的 AppImage 归档；具体挂载由 config.agent_tool_mounts 统一生成。

FreeCAD 1.1.0、Gmsh 4.12.1、CalculiX 2.21。每容器 2 CPU、8 GiB，开发和托管工作器均无网络。API 密钥仅在宿主调用器内存中使用。模型不获得 Docker socket、宿主私有数据或参考设计。

预算和额度规则见 protocol.json、AGENT_PROTOCOL.md。2.5/2 mm 二次网格，六个独立工况，各次求解最多 300 秒；单网格工作器 2400 秒，整体验证工作器约 5100 秒。墙钟到期会停止模型容器及活动开发作业。最后独立验收位于开发预算之外。

Dockerfile 是通用公开工具配方；正式模型环境只使用 agent.Dockerfile 及已固定镜像。原草案的 protocol_draft.json 仅为历史建议，不是本次运行合同。
''',encoding='utf-8')
print(json.dumps({'physical_limits_changed':False,'mesh_sizes_mm':[2.5,2.0],'memory_gib':LIMITS['memory_gib'],'stress_absolute_mpa':a.stress_absolute_mpa}))
