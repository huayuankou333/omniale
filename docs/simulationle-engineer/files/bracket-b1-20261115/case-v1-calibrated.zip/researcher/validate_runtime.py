"""Infrastructure checks without model generation or reference disclosure."""
import json,os,sys,time,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from config import BASE_IMAGE,TOOLS_PATH,save,agent_tool_mounts
from native_jobs import Jobs
out=ROOT/'validation'/('runtime_probe_'+time.strftime('%Y%m%dT%H%M%S'));out.mkdir(parents=True,exist_ok=False)
workspace=out/'workspace';deck=workspace/'probe';deck.mkdir(parents=True)
text='*HEADING\nNative job probe\n*NODE\n1,0,0,0\n2,1,0,0\n3,1,1,0\n4,0,1,0\n5,0,0,1\n6,1,0,1\n7,1,1,1\n8,0,1,1\n*ELEMENT,TYPE=C3D8,ELSET=ALL\n1,1,2,3,4,5,6,7,8\n*NSET,NSET=ALLN\n1,2,3,4,5,6,7,8\n*MATERIAL,NAME=M\n*ELASTIC\n1000,0\n*SOLID SECTION,ELSET=ALL,MATERIAL=M\n*BOUNDARY\n1,1,3\n2,1,3\n3,1,3\n4,1,3\n5,1,2\n6,1,2\n7,1,2\n8,1,2\n*STEP\n*STATIC\n*CLOAD\n5,3,.25\n6,3,.25\n7,3,.25\n8,3,.25\n*NODE PRINT,NSET=ALLN\nU\n*END STEP\n'
(deck/'probe.inp').write_text(text)
jobs=Jobs(out/'native',workspace)
r=jobs.launch('solver',{'deck_path':'/app/probe/probe.inp'})
while jobs.thread.is_alive():time.sleep(.2)
target=workspace/'development/job_001';record=json.loads((target/'status.json').read_text())
values=[];mode=False
for line in (target/'probe.dat').read_text().splitlines():
 if line.lower().strip().startswith('displacements'):mode=True;continue
 if mode:
  try:n=[float(x) for x in line.split()]
  except ValueError:continue
  if len(n)==4 and n[0]>=5:values.append(n[3])
assert len(values)==4 and max(abs(v-.001) for v in values)<1e-8,values
assert (target/'native_stdout.log').exists() and record['returncode']==0
assert jobs.budget()=={'analysis_calls':0,'custom_solver_calls':1,'solver_credits':1}
(deck/'probe.inp').write_text('*INCLUDE,INPUT=/opt/reference/secret.inp\n')
try:jobs.launch('solver',{'deck_path':'/app/probe/probe.inp'})
except ValueError:include_rejected=True
else:raise AssertionError('Absolute include accepted')
assert jobs.budget()['solver_credits']==1
(deck/'probe.inp').write_text(text)
second=jobs.launch('solver',{'deck_path':'/app/probe/probe.inp'})
while jobs.thread.is_alive():time.sleep(.2)
assert jobs.state['jobs'][-1]['returncode']==0 and jobs.budget()['solver_credits']==2
image=subprocess.check_output(['docker','image','inspect','simulationle-b1-agent:v1','--format','{{.Id}}'],text=True).strip()
command=['docker','run','--rm','--network','none','--read-only','--user','1000:1000']+agent_tool_mounts()+[image,'sh','-c',
 "test ! -e /opt/reference && test ! -e /opt/verifier && test ! -e /opt/spec && test ! -e /opt/reference_driver.py && ! command -v ccx && ! find /opt/tools -type f -name 'ccx*' -executable | grep ."]
r=subprocess.run(command,capture_output=True,text=True,timeout=30)
assert r.returncode==0,r.stdout+r.stderr
jobs.close()
save(ROOT/'runtime/images.json',{'agent_image':image,'base_image':BASE_IMAGE})
save(ROOT/'validation/runtime_checks.json',{'ready':True,'model_generation_calls':0,'custom_cube_displacement_mm':values,
 'native_budget':jobs.budget(),'unsafe_include_rejected_without_charge':include_rejected,
 'native_stdout_exposed':True,'reference_assets_absent':True,'unmetered_ccx_absent':True,'agent_image':image})
print(json.dumps({'ready':True,'agent_image':image,'model_generation_calls':0}))
