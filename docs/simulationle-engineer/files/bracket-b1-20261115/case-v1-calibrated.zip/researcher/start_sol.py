"""Durable one-trial launch; pass the provider credential only through a pipe."""
import json,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
key=sys.stdin.readline().strip()
if not key:raise SystemExit('Missing credential on standard input')
with (ROOT/'sol_trial.log').open('xb') as log:
 process=subprocess.Popen([sys.executable,'-u',str(ROOT/'run_sol.py'),'run'],cwd=ROOT,stdin=subprocess.PIPE,
                          stdout=log,stderr=subprocess.STDOUT,start_new_session=True,close_fds=True)
 process.stdin.write((key+'\n').encode());process.stdin.close()
print(json.dumps({'pid':process.pid,'log':str(ROOT/'sol_trial.log'),'requested_model':'gpt-6.1-sol','trial_limit':1}))
