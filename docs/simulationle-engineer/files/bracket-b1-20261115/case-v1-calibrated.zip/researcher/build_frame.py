"""Calibration candidate: triangulated side plates and transverse webs."""
import json,os,sys
from pathlib import Path
import FreeCAD as App,Part
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'public'))
from cad_common import V,box,interface_solids,exclusion_volumes,export_document,beam_xz

spec=json.loads(Path(os.environ['B1_INSTANCE']).read_text())
z=spec['module']['plane_z_mm'];mx=sum(c[0] for c in spec['module']['centers_xy_mm'])/4
mode=os.environ.get('B1_CANDIDATE','frame')
w=float(os.environ.get('B1_WEB','4'));rail=float(os.environ.get('B1_RAIL','10'))
def polygon(points,y,thickness):
    p=[V(x,y-thickness/2,h) for x,h in points]
    return Part.Face(Part.makePolygon(p+[p[0]])).extrude(V(0,thickness,0))

pieces=interface_solids(spec)
for y in [-24,24]:pieces.append(box([-64,y-8,0,-16,y+8,6]))
pieces.append(box([-44,-32,0,-36,32,6]))
top=box([mx-22,-34,z-6,mx+22,34,z]).cut(box([mx-5,-10,z-7,mx+5,10,z+1]))
pieces.append(top)
for y in [-31,31]:
    # Two long triangularly braced paths; the lower contour rises before cable.
    outline=[(-64,0),(-16,0),(-6,40),(mx+22,z-6),(mx+22,z),(mx-22,z),(-24,42)]
    side=polygon(outline,y,w)
    # Remove interior material while retaining broad diagonal straps.
    if mode!='solid':
        holes=[[(-53,10),(-26,10),(-15,36),(-27,31)],
               [(-20,45),(-6,48),(mx+6,z-10),(mx-19,z-10)]]
        for hole in holes:side=side.cut(polygon(hole,y,w+2))
    pieces.append(side)
# Transverse web well behind the optical aperture, and base gussets that give
# lateral forces a membrane load path instead of side-plate bending alone.
pieces.append(box([-17.5,-33,6,-14.0,33,45]))
for y in [-31,31]:pieces.append(beam_xz((-40,3),(-15.5,44),y,6,rail))
shape=pieces[0]
for piece in pieces[1:]:shape=shape.fuse(piece)
shape=shape.common(box(spec['envelope_mm']))
for name,region in exclusion_volumes(spec):
    if name!='envelope':shape=shape.cut(region)
shape=shape.removeSplitter()
export_document(shape,spec,{'candidate':'frame','web_mm':w,'rail_mm':rail,'mode':mode},os.environ['B1_OUTPUT'],'B1Frame')
