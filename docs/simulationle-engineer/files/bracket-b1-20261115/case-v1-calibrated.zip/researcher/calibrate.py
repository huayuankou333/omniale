"""Native construction and calibration driver. All calls retained."""
import argparse,json,os,subprocess,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
IMAGE='sha256:0a013e99c92abc76ffc41d90cb22a0af8c76ed6cbd29e7df413d94127eba8c07'
TOOLS=Path('/data3/adminweihunj/SimulationLE/case/D2/mechanical_sensor_enclosure/runtime-rootfs/opt/tools')
MEMORY='4g'

def run(container_command,mounts,env,out,timeout):
    out=Path(out);out.parent.mkdir(parents=True,exist_ok=True)
    command=['docker','run','--rm','--network','none','--cpus','2','--memory',MEMORY,
             '--pids-limit','512','--cap-drop','ALL','--security-opt','no-new-privileges',
             '--read-only','--user','1000:1000','--tmpfs','/tmp:rw,nosuid,size=1g',
             '-e','HOME=/tmp','-e','QT_QPA_PLATFORM=offscreen','-w','/tmp']
    command+=['-v',f'{TOOLS}:/opt/tools:ro','-e','OPENBLAS_NUM_THREADS=1','-e','MPLCONFIGDIR=/tmp/matplotlib']
    for source,target,writable in mounts:command+=['-v',f'{source}:{target}'+('' if writable else ':ro')]
    for k,v in env.items():command+=['-e',k+'='+str(v)]
    command+=[IMAGE]+container_command
    started=time.time()
    try:
        p=subprocess.run(command,capture_output=True,text=True,errors='replace',timeout=timeout)
        result=dict(returncode=p.returncode,stdout=p.stdout,stderr=p.stderr,wall_seconds=time.time()-started)
    except subprocess.TimeoutExpired as exc:
        result=dict(returncode=None,error='timeout',wall_seconds=time.time()-started)
    result['command']=command
    out.write_text(json.dumps(result,indent=2)+'\n')
    return result

def main():
    p=argparse.ArgumentParser();p.add_argument('--mode',default='detour_truss');p.add_argument('--tag',required=True)
    p.add_argument('--instance',default='B1-01-offset-open');p.add_argument('--geometry-only',action='store_true')
    p.add_argument('--script',default='build_candidate.py');p.add_argument('--meshes');p.add_argument('--memory',default='4g');a=p.parse_args()
    global MEMORY
    MEMORY=a.memory
    out=ROOT/'calibration'/a.tag/a.instance;out.mkdir(parents=True,exist_ok=True);os.chmod(out,0o777)
    import shutil
    shutil.copy2(ROOT/'researcher'/a.script,out/'construction_source.py')
    frozen_spec=json.loads((ROOT/'public/instances'/(a.instance+'.json')).read_text())
    if a.meshes:frozen_spec['meshing']['sizes_mm']=[float(x) for x in a.meshes.split(',')]
    (out/'instance_at_start.json').write_text(json.dumps(frozen_spec,indent=2)+'\n')
    env={'B1_INSTANCE':'/out/instance_at_start.json','B1_OUTPUT':'/out','B1_CANDIDATE':a.mode}
    r=run(['/home/user/.local/bin/freecadcmd','/case/researcher/'+a.script],[(ROOT,'/case',False),(out,'/out',True)],env,out/'build_invocation.json',300)
    if r['returncode']!=0 or not (out/'bracket.step').exists():print(json.dumps({'build_failed':r}));return
    measure=out/'measurement';measure.mkdir(exist_ok=True);os.chmod(measure,0o777)
    command=['python3','/case/public/analyze.py','--submission','/design',
             '--instance','/design/instance_at_start.json','--out','/result']
    if a.geometry_only:command+=['--geometry-only']
    r=run(command,[(ROOT,'/case',False),(out,'/design',False),(measure,'/result',True)],{},out/'measurement_invocation.json',6000)
    if (measure/'result.json').exists():
        result=json.loads((measure/'result.json').read_text())
        print(json.dumps({'status':result['status'],'score':result['score'],
              'checks_failed':[c for c in result['checks'] if not c['passed']],
              'errors':result['errors'],'mass':result.get('geometry',{}).get('metrics'),
              'meshes':[{'meta':m.get('mesh'), 'cases':{k:v['metrics'] for k,v in m['loadcases'].items()},'errors':m['errors']} for m in result['meshes']]},indent=2))
    else:print(json.dumps({'measurement_failed':r}))

if __name__=='__main__':main()
