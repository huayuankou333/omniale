import json,os,shutil,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from config import BASE_IMAGE,save,digest
from verifier.verify import docker
out=ROOT/'validation/source_isolation';out.mkdir(exist_ok=False)
source=out/'source_only';source.mkdir()
for f in ['build.py','parameters.json','engineering_report.json']:shutil.copy2(ROOT/'researcher/reference_submission'/f,source/f)
results={}
for identity in ['B1-01-offset-open','B1-02-cross-optical']:
 d=out/identity;d.mkdir();os.chmod(d,0o777)
 env={'B1_INSTANCE':f'/opt/b1/public/instances/{identity}.json','B1_PUBLIC':'/opt/b1/public','B1_OUTPUT':'/out'}
 r=docker(BASE_IMAGE,[(source,'/submission',False),(ROOT/'public','/opt/b1/public',False),(d,'/out',True)],['/home/user/.local/bin/freecadcmd','/submission/build.py'],env,timeout=300)
 (d/'build.log').write_text(r.stdout+r.stderr);assert r.returncode==0 and (d/'bracket.step').is_file()
 measure=d/'measurement';measure.mkdir();os.chmod(measure,0o777)
 r=docker(BASE_IMAGE,[(ROOT/'public','/opt/b1/public',False),(ROOT/'researcher/reference_submission'/identity,'/candidate',False),(d,'/rebuilt',False),(measure,'/result',True)],
  ['python3','/opt/b1/public/analyze.py','--submission','/candidate','--instance',env['B1_INSTANCE'],'--out','/result','--rebuild-step','/rebuilt/bracket.step','--geometry-only'],timeout=400)
 g=json.loads((measure/'geometry.json').read_text());assert not g['errors'] and all(c['passed'] for c in g['checks']),g
 results[identity]={'source_only_rebuild_passed':True,'submitted_CAD_visible_to_source':False,'all_geometry_checks_passed':True}
save(ROOT/'validation/source_isolation.json',{'ready':True,'instances':results,'source_hashes':{p.name:digest(p) for p in source.iterdir()}})
print(json.dumps({'ready':True,'source_only_rebuilds':2,'model_calls':0}))
