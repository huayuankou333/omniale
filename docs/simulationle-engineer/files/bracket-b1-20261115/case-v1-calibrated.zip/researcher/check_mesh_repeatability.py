import hashlib,json,os,sys,time
from pathlib import Path
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parent))
from calibrate import ROOT,run
base=ROOT/'validation'/('mesh_repeatability_'+time.strftime('%Y%m%dT%H%M%S'));base.mkdir(exist_ok=False);results=[]
for k in [1,2]:
 out=base/str(k);out.mkdir();os.chmod(out,0o777)
 code="import sys,json;from pathlib import Path;sys.path.insert(0,'/case/public');from fem import mesh;s=json.loads(Path('/case/public/instances/B1-01-offset-open.json').read_text());mesh(Path('/design/bracket.step'),Path('/out'),2.5,s)"
 r=run(['python3','-c',code],[(ROOT,'/case',False),(ROOT/'researcher/reference_submission/B1-01-offset-open','/design',False),(out,'/out',True)],{},out/'invocation.json',400)
 assert r['returncode']==0,r
 m=np.load(out/'mesh_arrays.npz');hashes={n:hashlib.sha256(m[n].tobytes()).hexdigest() for n in m.files}
 results.append(hashes)
assert results[0]==results[1],results
(ROOT/'validation/mesh_repeatability.json').write_text(json.dumps({'ready':True,'threads':1,'random_seed':1,'reproducible':True,'array_hashes':results,'model_calls':0},indent=2)+'\n')
print(json.dumps({'ready':True,'identical_mesh_arrays':True,'model_calls':0}))
