import json,os,shutil,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from config import agent_tool_mounts,save
folder=ROOT/'validation/masked_cad_probe';folder.mkdir(exist_ok=False)
for f in ['build.py','parameters.json']:shutil.copy2(ROOT/'starter'/f,folder/f)
for p in [folder]+list(folder.rglob('*')):p.chmod(0o777 if p.is_dir() else 0o666)
image=json.loads((ROOT/'runtime/images.json').read_text())['agent_image']
command=['docker','run','--rm','--network','none','--read-only','--cpus','2','--memory','8g','--user','1000:1000','--tmpfs','/tmp:rw,size=1g']+agent_tool_mounts()+[
 '-v',f'{folder}:/app','-v',f'{ROOT/"public"}:/opt/b1/public:ro','-e','B1_PUBLIC=/opt/b1/public',
 '-e','B1_INSTANCE=/opt/b1/public/instances/B1-01-offset-open.json','-e','B1_OUTPUT=/app/generated',image,
 '/home/user/.local/bin/freecadcmd','/app/build.py']
r=subprocess.run(command,capture_output=True,text=True,timeout=180)
save(folder/'invocation.json',{'returncode':r.returncode,'stdout':r.stdout,'stderr':r.stderr,'command':command})
assert r.returncode==0 and (folder/'generated/bracket.step').is_file() and (folder/'generated/design.FCStd').is_file(),r.stderr
d=json.loads((ROOT/'validation/runtime_checks.json').read_text());d['freecad_build_with_solver_and_archive_masks']=True;save(ROOT/'validation/runtime_checks.json',d)
print(json.dumps({'masked_FreeCAD_build':True,'model_calls':0}))
