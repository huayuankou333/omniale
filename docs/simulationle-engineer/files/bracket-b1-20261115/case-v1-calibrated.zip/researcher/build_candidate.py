"""Unexecuted construction candidates, not validated references. Researcher only."""
import json
import os
import sys
from pathlib import Path
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent/'public'))
from cad_common import box,beam_xz,interface_solids,exclusion_volumes,export_document

spec=json.loads(Path(os.environ['B1_INSTANCE']).read_text(encoding='utf-8'))
mode=os.environ.get('B1_CANDIDATE','detour_truss')
width,depth={'detour_truss':(4.0,9.0),'straight_truss':(4.0,9.0),
             'overweight':(12.0,20.0),'thin':(2.0,3.0)}[mode]
z=spec['module']['plane_z_mm'];centers=spec['module']['centers_xy_mm']
xmid=sum(c[0] for c in centers)/4
pieces=interface_solids(spec)
pieces += [box([-64,-33,0,-16,33,6]),box([min(c[0] for c in centers)-8,-27,z-6,max(c[0] for c in centers)+8,27,z])]
for y in [-30,30]:
    end=(xmid,z-3)
    # Side-plane topology is an initial design hypothesis only.
    if mode=='straight_truss':
        routes=[[(-55,3),end],[(-25,3),end]]
    else:
        routes=[[(-55,3),(-10,45),end],[(-25,3),(-10,45)]]
    for route in routes:
        for a,b in zip(route,route[1:]):pieces.append(beam_xz(a,b,y,width,depth))
    pieces.append(box([xmid-8,min(y,0),z-6,xmid+8,max(y,0)+width/2,z]))
shape=pieces[0]
for piece in pieces[1:]:shape=shape.fuse(piece)
shape=shape.common(box(spec['envelope_mm']))
# Tool and module corridors are mandatory. Optical/cable obstacles deliberately
# remain uncut so the straight-route control can expose a genuine interference.
for name,region in exclusion_volumes(spec):
    if name.startswith(('base_','module_')):shape=shape.cut(region)
shape=shape.removeSplitter()
export_document(shape,spec,dict(mode=mode,width=width,depth=depth),os.environ['B1_OUTPUT'],'B1Candidate')

