import json,os,shutil,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from native_jobs import Jobs
from config import save
out=ROOT/'validation/gateway_calibration';out.mkdir(exist_ok=False)
w=out/'workspace';identity='B1-01-offset-open';d=w/'submission'/identity;d.mkdir(parents=True)
for name in ['bracket.step','design.FCStd']:shutil.copy2(ROOT/'researcher/reference_submission'/identity/name,d/name)
j=Jobs(out/'jobs',w);r=j.launch('analyze',{'instance':identity,'geometry_only':True})
while j.thread.is_alive():time.sleep(.2)
record=j.state['jobs'][0];target=w/'development/job_001'
result=json.loads((target/'result.json').read_text())
assert record['returncode']==0 and result['status']=='geometry_only',record
assert not result['errors'] and all(c['passed'] for c in result['checks']),result
assert j.budget()=={'analysis_calls':1,'custom_solver_calls':0,'solver_credits':12}
assert record['actual_solver_attempts']==0 and record['actual_mesh_outputs']==0
p=w/'probe';p.mkdir();(p/'deck.inp').write_text('*INCLUDE,INPUT=payload.txt\n');(p/'payload.txt').write_text('*INCLUDE,OTHER=ignored,INPUT=/opt/reference/hidden.inp\n')
try:j.launch('solver',{'deck_path':'/app/probe/deck.inp'})
except ValueError:nested_include_rejected=True
else:raise AssertionError('Nested unusual-extension absolute include accepted')
assert j.budget()['solver_credits']==12
j.close();save(ROOT/'validation/gateway_checks.json',{'ready':True,'model_calls':0,'geometry_only_status':result['status'],
 'all_geometry_checks_passed':True,'budget':j.budget(),'geometry_only_actual_solver_attempts':0,
 'nested_include_rejected':nested_include_rejected,'result_and_compressed_fields_priority':True})
print(json.dumps({'ready':True,'model_calls':0,'budget':j.budget()}))
