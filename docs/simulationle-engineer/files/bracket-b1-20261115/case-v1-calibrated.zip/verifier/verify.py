"""Isolated freeze, source reconstruction, and fresh independent measurement."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
import sys

CASE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(CASE))
from config import LIMITS
INSTANCE_IDS=['B1-01-offset-open','B1-02-cross-optical']

def docker(image,mounts,command,env=None,timeout=6000):
    args=['docker','run','--rm','--network','none','--read-only','--cap-drop','ALL',
          '--security-opt','no-new-privileges','--pids-limit','512','--cpus','2','--memory',f'{LIMITS["memory_gib"]}g',
          '--user','1000:1000','--tmpfs','/tmp:rw,nosuid,size=1g',
          '-e','HOME=/tmp','--workdir','/tmp']
    args+=['-v','/data3/adminweihunj/SimulationLE/case/D2/mechanical_sensor_enclosure/runtime-rootfs/opt/tools:/opt/tools:ro',
           '-e','QT_QPA_PLATFORM=offscreen','-e','OPENBLAS_NUM_THREADS=1']
    for source,destination,writable in mounts:
        args+=['--mount',f'type=bind,src={source},dst={destination}'+('' if writable else ',readonly')]
    for key,value in (env or {}).items():args+=['-e',key+'='+str(value)]
    return subprocess.run(args+[image]+command,capture_output=True,text=True,errors='replace',timeout=timeout)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--submission',required=True);ap.add_argument('--out',required=True)
    ap.add_argument('--image',required=True);ap.add_argument('--allow-unvalidated-draft',action='store_true')
    a=ap.parse_args()
    if not a.allow_unvalidated_draft:
        calibration=json.loads((CASE/'validation/calibration.json').read_text())
        if not calibration.get('ready'):raise SystemExit('Calibration has not established a feasible case')
    if not (a.image.startswith('sha256:') or '@sha256:' in a.image):raise SystemExit('Use an immutable runtime image ID/digest')
    source=Path(a.submission).resolve();out=Path(a.out).resolve()
    if out.exists():raise SystemExit('Output directory must be new; never overwrite evidence')
    out.mkdir(parents=True);frozen=out/'frozen';frozen.mkdir()
    allowed={'build.py','parameters.json','engineering_report.json'}
    allowed|={f'{i}/{n}' for i in INSTANCE_IDS for n in ['bracket.step','design.FCStd']}
    hashes={};submission_errors=[]
    for name in sorted(allowed):
        p=source/name
        if p.is_symlink() or source not in p.resolve().parents or not p.is_file():
            submission_errors.append('Missing/unsafe submission path: '+name);continue
        if p.stat().st_size>20000000:
            submission_errors.append('Submission file too large: '+name);continue
        target=frozen/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,target)
        hashes[name]=hashlib.sha256(target.read_bytes()).hexdigest()
    (out/'manifest.json').write_text(json.dumps(hashes,indent=2)+'\n')
    summary={'calibration_mode':a.allow_unvalidated_draft,'score':None,'full_pass':False,'status':'indeterminate','instances':{},'runtime_image':a.image,'source_only_rebuild':True}
    if submission_errors:
        summary.update(status='invalid_submission',errors=submission_errors)
        (out/'result.json').write_text(json.dumps(summary,indent=2)+'\n');return
    source_only=out/'source_only';source_only.mkdir()
    for name in ['build.py','parameters.json','engineering_report.json']:shutil.copy2(frozen/name,source_only/name)
    for identity in INSTANCE_IDS:
        result=out/identity;result.mkdir();rebuilt=result/'rebuilt';rebuilt.mkdir()
        if os.name=='posix':os.chmod(result,0o777);os.chmod(rebuilt,0o777)
        env={'B1_PUBLIC':'/opt/b1/public','B1_INSTANCE':f'/opt/b1/public/instances/{identity}.json',
             'B1_OUTPUT':'/rebuild','QT_QPA_PLATFORM':'offscreen'}
        # Candidate code runs only in its own container. It cannot see the
        # final measurement worker, the host filesystem, or credentials.
        r=docker(a.image,[(source_only,'/submission',False),(CASE/'public','/opt/b1/public',False),(rebuilt,'/rebuild',True)],
                 ['/home/user/.local/bin/freecadcmd','/submission/build.py'],env,timeout=300)
        (result/'rebuild.log').write_text(r.stdout+'\n'+r.stderr)
        if r.returncode or not (rebuilt/'bracket.step').is_file():
            summary['instances'][identity]={'status':'rebuild_failed','score':None};continue
        if (rebuilt/'bracket.step').is_symlink() or (rebuilt/'bracket.step').stat().st_size>20000000:
            summary['instances'][identity]={'status':'invalid_rebuild_artifact','score':None};continue
        # Separate fresh container; only immutable evaluator code is executed.
        diag=result/'measurement';diag.mkdir()
        if os.name=='posix':os.chmod(diag,0o777)
        r=docker(a.image,[(CASE/'public','/opt/b1/public',False),(frozen/identity,'/candidate',False),
                          (rebuilt,'/rebuilt',False),(diag,'/result',True)],
                 ['python3','/opt/b1/public/analyze.py','--submission','/candidate',
                  '--instance',f'/opt/b1/public/instances/{identity}.json','--out','/result',
                  '--rebuild-step','/rebuilt/bracket.step'])
        (result/'measurement.log').write_text(r.stdout+'\n'+r.stderr)
        if r.returncode==0 and (diag/'result.json').exists():summary['instances'][identity]=json.loads((diag/'result.json').read_text(encoding='utf-8'))
        else:summary['instances'][identity]={'status':'measurement_worker_failed','score':None}
    if len(summary['instances'])==2 and all(r.get('status')=='diagnostic_valid' for r in summary['instances'].values()):
        groups={k:all(r['groups'][k] for r in summary['instances'].values()) for k in
                ['geometry_interfaces','space_access','mass_backbone','alignment','strength']}
        summary.update(status='valid',groups=groups,score=20*sum(groups.values()),full_pass=all(groups.values()))
    summary['frozen_files_unchanged']=all(hashlib.sha256((frozen/n).read_bytes()).hexdigest()==h for n,h in hashes.items())
    if not summary['frozen_files_unchanged']:summary.update(status='integrity_error',score=None,full_pass=False)
    (out/'result.json').write_text(json.dumps(summary,indent=2,allow_nan=False)+'\n')

if __name__=='__main__':main()
