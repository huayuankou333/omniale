# B1 受空间和接口约束的轻量支架

本目录是 B1 的原生校准和单次 Sol 测试版本。原始未执行草案单独保留在 draft_20261115 和原交付压缩包中。任务复用传感器外壳结构 B 的 CAD → Gmsh → CalculiX 工作流，新增支架载荷路径、偏心力矩、光路/线束障碍和模块平移/转角/翘曲要求；不继承旧题成绩。

公开文件是 TASK.md、public/、starter/、runtime/AGENT_PROTOCOL.md。researcher/、validation/、verifier/ 和任何凭据均不提供给模型。

runtime/protocol.json 和 config.py 规定正式预算。run_sol.py 只允许一次 gpt-6.1-sol 试验；必须先通过 validation/calibration.json 和 seal.json。托管异步求解网关单独记账，禁止直接绕过求解预算。模型停止后冻结最后一版提交，独立运行 build.py、比较 STEP/FCStd，再从交付 STEP 重新网格与计算。

实际参考可行性见 validation/calibration.json；几何负对照见 validation/negative_controls.json；运行环境检查见 validation/runtime_checks.json。原生校准全量记录位于 calibration/，模型记录位于 runs/。尚未取得的结果不会由草案状态推定。
