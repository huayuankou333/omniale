"""FreeCAD geometry helpers for the B1 contract. Authored, not executed."""
import json
from pathlib import Path
import FreeCAD as App
import Part

V=App.Vector
def box(bounds):
    x,y,z,X,Y,Z=bounds
    return Part.makeBox(X-x,Y-y,Z-z,V(x,y,z))

def cylinder(x,y,z,r,h):
    return Part.makeCylinder(r,h,V(x,y,z))

def pad(spec,group,xy):
    g=spec[group];x,y=xy
    z=g['plane_z_mm'] if group=='base' else g['plane_z_mm']-g['pad_height_mm']
    return cylinder(x,y,z,g['pad_radius_mm'],g['pad_height_mm']).cut(
        cylinder(x,y,z,g['bore_radius_mm'],g['pad_height_mm']))

def interface_solids(spec):
    return [pad(spec,g,xy) for g in ['base','module'] for xy in spec[g]['centers_xy_mm']]

def exclusion_volumes(spec):
    regions=[('envelope',box(spec['envelope_mm']))]
    regions += [(r['id'],box(r['box_mm'])) for r in spec['keepouts']]
    footprint=list(spec['module']['footprint_mm'])
    # Sweep starts at the mating plane; sharing that plane is allowed.
    footprint[5]=spec['envelope_mm'][5]+60
    regions.append(('module_insertion',box(footprint)))
    for i,(x,y) in enumerate(spec['base']['centers_xy_mm']):
        g=spec['base']
        regions += [('base_bore_'+str(i),cylinder(x,y,-1,g['bore_radius_mm'],g['pad_height_mm']+2)),
                    ('base_driver_'+str(i),cylinder(x,y,g['driver_from_z_mm'],g['driver_radius_mm'],g['driver_to_z_mm']-g['driver_from_z_mm']))]
    for i,(x,y) in enumerate(spec['module']['centers_xy_mm']):
        g=spec['module'];z=g['plane_z_mm'];h=g['pad_height_mm']
        regions += [('module_bore_'+str(i),cylinder(x,y,z-h,g['bore_radius_mm'],h+1)),
                    ('module_driver_'+str(i),cylinder(x,y,g['driver_below_z_mm'],g['driver_radius_mm'],z-h-g['driver_below_z_mm']))]
    return regions

def beam_xz(a,b,y,width,depth):
    """Rectangular beam in an XZ side plane, with freely chosen end points."""
    import math
    dx,dz=b[0]-a[0],b[1]-a[1];length=math.hypot(dx,dz)
    if length<=0:raise ValueError('Beam endpoints must differ')
    nx,nz=-dz/length*depth/2,dx/length*depth/2
    points=[V(a[0]+nx,y-width/2,a[1]+nz),V(b[0]+nx,y-width/2,b[1]+nz),
            V(b[0]-nx,y-width/2,b[1]-nz),V(a[0]-nx,y-width/2,a[1]-nz)]
    face=Part.Face(Part.makePolygon(points+[points[0]]))
    return face.extrude(V(0,width,0))

def export_document(shape,spec,params,out,name='B1Bracket'):
    out=Path(out);out.mkdir(parents=True,exist_ok=True)
    doc=App.newDocument(name)
    feature=doc.addObject('PartDesign::Feature','Bracket')
    feature.addProperty('App::PropertyString','InstanceJSON','Rebuild').InstanceJSON=json.dumps(spec,sort_keys=True)
    feature.addProperty('App::PropertyString','ParametersJSON','Rebuild').ParametersJSON=json.dumps(params,sort_keys=True)
    feature.Shape=shape
    doc.recompute()
    Part.export([feature],str(out/'bracket.step'))
    doc.saveAs(str(out/'design.FCStd'))
    (out/'design_parameters.json').write_text(json.dumps(params,indent=2)+'\n')
    App.closeDocument(doc.Name)

