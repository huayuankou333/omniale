"""Public diagnostics and official immutable measurements share this module.

Not run during draft construction. This program does not execute build.py.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

HERE=Path(__file__).resolve().parent
def save(path,obj):Path(path).write_text(json.dumps(obj,indent=2,allow_nan=False)+'\n')

def invoke(command,folder,timeout,env=None):
    try:
        p=subprocess.run(command,cwd=folder,env=env,capture_output=True,text=True,errors='replace',timeout=timeout)
        return {'returncode':p.returncode,'stdout':p.stdout,'stderr':p.stderr}
    except subprocess.TimeoutExpired as exc:
        return {'returncode':None,'error':'timeout','timeout_seconds':timeout}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--submission',required=True);ap.add_argument('--instance',required=True)
    ap.add_argument('--out',required=True);ap.add_argument('--rebuild-step');ap.add_argument('--geometry-only',action='store_true')
    a=ap.parse_args();work=Path(a.submission).resolve();out=Path(a.out).resolve();out.mkdir(parents=True,exist_ok=True)
    instance=Path(a.instance).resolve();spec=json.loads(instance.read_text(encoding='utf-8'));step=work/'bracket.step'
    result={'revision':spec['revision'],'instance':spec['id'],'status':'indeterminate','score':None,'full_pass':False,
            'checks':[],'errors':[],'meshes':[],'contract_sha256':hashlib.sha256(instance.read_bytes()).hexdigest()}
    env=dict(os.environ,B1_INSTANCE=str(instance),B1_STEP=str(step),B1_GEOMETRY_OUT=str(out/'geometry.json'),
             B1_FCSTD=str(work/'design.FCStd'),QT_QPA_PLATFORM='offscreen')
    if a.rebuild_step:env['B1_COMPARE_STEP']=str(Path(a.rebuild_step).resolve())
    r=invoke([os.environ.get('B1_FREECAD','/home/user/.local/bin/freecadcmd'),str(HERE/'geometry.py')],out,300,env)
    save(out/'geometry_invocation.json',r)
    if r.get('returncode')!=0 or not (out/'geometry.json').exists():
        result['errors'].append('Geometry worker failed or did not produce result')
        save(out/'result.json',result);return
    geometry=json.loads((out/'geometry.json').read_text(encoding='utf-8'));result['geometry']=geometry
    result['checks']+=geometry['checks'];result['errors']+=geometry['errors']
    if a.geometry_only:
        result['status']='geometry_only';save(out/'result.json',result);return
    if not any(c['name']=='valid_single_solid' and c['passed'] for c in result['checks']):
        result['status']='invalid_submission';save(out/'result.json',result);return
    for size in spec['meshing']['sizes_mm']:
        folder=out/('mesh_'+str(size));folder.mkdir(exist_ok=True)
        r=invoke([sys.executable,str(HERE/'fem.py'),'--step',str(step),'--instance',str(instance),
                  '--out',str(folder),'--mesh-mm',str(size)],folder,2400)
        save(folder/'invocation.json',r)
        if r.get('returncode')!=0 or not (folder/'result.json').exists():
            result['errors'].append('FEA worker failed at mesh '+str(size));continue
        m=json.loads((folder/'result.json').read_text(encoding='utf-8'));result['meshes'].append(m)
        result['errors']+=m['errors']
        if 'mesh' not in m:continue
        volume=geometry['metrics']['volume_mm3']
        volume_error=abs(m['mesh']['volume_mm3']-volume)/volume
        if volume_error>spec['meshing']['volume_relative_tolerance']:result['errors'].append('Mesh volume mismatch')
        for name,case in m['loadcases'].items():
            metrics=case['metrics']
            if not metrics['force_moment_balance_valid']:result['errors'].append(name+': reactions do not balance applied wrench')
            for key in ['interface_translation_mm','interface_rotation_deg','interface_warp_mm','global_displacement_mm',
                        'bulk_peak_vm_mpa','interface_p99_vm_mpa']:
                result['checks'].append({'name':f'{name}@{size}:{key}',
                    'group':'strength' if 'vm_' in key else 'alignment','passed':metrics[key]<=spec['limits'][key],
                    'actual':metrics[key],'limit':spec['limits'][key]})
    if len(result['meshes'])==2 and all(m['status']=='measured' for m in result['meshes']):
        result['convergence']=[]
        for case in spec['loads']:
            for key,floor in spec['meshing']['convergence_floors'].items():
                x,y=[m['loadcases'][case['id']]['metrics'][key] for m in result['meshes']]
                relative=abs(x-y)/max(abs(y),floor)
                ok=relative<=spec['meshing']['convergence_relative']
                result['convergence'].append({'case':case['id'],'metric':key,'relative':relative,'passed':ok})
                if not ok:result['errors'].append(case['id']+': insufficient mesh convergence for '+key)
    else:result['errors'].append('Missing complete two-mesh result')
    result['groups']={g:bool([c for c in result['checks'] if c['group']==g]) and
                      all(c['passed'] for c in result['checks'] if c['group']==g) for g in spec['scoring']['groups']}
    if not result['errors']:
        result['status']='diagnostic_valid'
        result['score']=sum(result['groups'].values())*20
        result['full_pass']=all(result['groups'].values())
    save(out/'result.json',result)

if __name__=='__main__':main()
