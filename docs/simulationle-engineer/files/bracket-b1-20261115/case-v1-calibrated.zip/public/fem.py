"""B1 native worker: STEP -> quadratic tetrahedra -> six CCX solves.

This draft has not been executed. Numerical validity is reported separately
from design pass/fail. No submitted mesh, deck or result is trusted.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import traceback
import numpy as np

def save(path,data):
    Path(path).write_text(json.dumps(data,indent=2,allow_nan=False)+'\n')

def skew(v):
    x,y,z=v
    return np.array([[0,-z,y],[z,0,-x],[-y,x,0]],dtype=float)

def mesh(step,out,size,spec):
    import gmsh
    gmsh.initialize()
    try:
        options={'General.NumThreads':1,'General.Terminal':1,
                 'Mesh.MaxNumThreads1D':1,'Mesh.MaxNumThreads2D':1,'Mesh.MaxNumThreads3D':1,
                 'Mesh.RandomSeed':1,
                 'Mesh.MeshSizeMin':size*0.4,'Mesh.MeshSizeMax':size,
                 'Mesh.MeshSizeFromCurvature':20,'Mesh.MeshSizeExtendFromBoundary':1,
                 'Mesh.Algorithm3D':1,'Mesh.Optimize':1,'Mesh.ElementOrder':2,
                 'Mesh.SecondOrderLinear':1}
        for k,v in options.items():gmsh.option.setNumber(k,v)
        gmsh.model.add('B1')
        gmsh.model.occ.importShapes(str(step))
        gmsh.model.occ.synchronize()
        if len(gmsh.model.getEntities(3))!=1:raise ValueError('Exactly one volume required')
        gmsh.model.mesh.generate(3)
        gmsh.write(str(out/'mesh.msh'))
        ids,flat,_=gmsh.model.mesh.getNodes()
        order=np.argsort(ids);ids=np.asarray(ids,dtype=np.int64)[order]
        xyz=np.asarray(flat).reshape(-1,3)[order]
        types,element_tags,nodes=gmsh.model.mesh.getElements(3)
        if list(types)!=[11]:raise ValueError('Expected Gmsh type 11 quadratic tetrahedra')
        raw=np.asarray(nodes[0],dtype=np.int64).reshape(-1,10)
        if len(ids)>spec['meshing']['max_nodes'] or len(raw)>spec['meshing']['max_elements']:
            raise RuntimeError('Public mesh resource bound exceeded')
        rows=np.searchsorted(ids,raw);corners=xyz[rows[:,:4]];mids=xyz[rows[:,4:]]
        edges=[(0,1),(1,2),(2,0),(0,3),(1,3),(2,3)]
        perm=np.stack([np.argmin(np.linalg.norm(mids-(corners[:,a]+corners[:,b])[:,None,:]/2,axis=2),axis=1) for a,b in edges],axis=1)
        if np.any(np.sort(perm,axis=1)!=np.arange(6)):raise RuntimeError('Ambiguous C3D10 edge mapping')
        conn=np.concatenate([raw[:,:4],np.take_along_axis(raw[:,4:],perm,axis=1)],axis=1)
        volumes=np.linalg.det(np.stack([corners[:,1]-corners[:,0],corners[:,2]-corners[:,0],corners[:,3]-corners[:,0]],axis=2))/6
        if np.any(volumes<=1e-12):raise RuntimeError('Degenerate or inverted tetrahedron')
        st,_,sn=gmsh.model.mesh.getElements(2)
        if list(st)!=[9]:raise RuntimeError('Expected quadratic triangular boundary faces')
        tris=np.asarray(sn[0],dtype=np.int64).reshape(-1,6)
        tr=np.searchsorted(ids,tris);c=xyz[tr[:,:3]]
        area=np.linalg.norm(np.cross(c[:,1]-c[:,0],c[:,2]-c[:,0]),axis=1)/2
        on_plane=np.zeros(len(tris),dtype=bool)
        for group in ['base','module']:
            on_plane|=np.all(np.abs(xyz[tr,2]-spec[group]['plane_z_mm'])<=0.005,axis=1)
        area=area*on_plane
        node_area=np.zeros(len(ids))
        for j,w in enumerate(spec['loading']['triangle6_lumping']):np.add.at(node_area,tr[:,j],area*w)
        np.savez_compressed(out/'mesh_arrays.npz',ids=ids,xyz=xyz,conn=conn,volumes=volumes,node_area=node_area)
        meta={'nodes':len(ids),'elements':len(conn),'volume_mm3':float(volumes.sum()),
              'gmsh_version':gmsh.__version__,'element_type':'C3D10','size_mm':size,
              'step_sha256':hashlib.sha256(step.read_bytes()).hexdigest(),
              'mesh_threads':1,'random_seed':1}
        save(out/'mesh.json',meta)
        return ids,xyz,conn,volumes,node_area,meta
    finally:gmsh.finalize()

def patches(xyz,node_area,spec,group):
    g=spec[group];mask=np.zeros(len(xyz),dtype=bool)
    for x,y in g['centers_xy_mm']:
        r=np.linalg.norm(xyz[:,:2]-[x,y],axis=1)
        m=(np.abs(xyz[:,2]-g['plane_z_mm'])<=0.005)&(r>=g['bore_radius_mm']-0.005)&(r<=g['pad_radius_mm']+0.005)&(node_area>0)
        if int(m.sum())<spec['loading']['minimum_nodes_per_pad']:raise RuntimeError('Insufficient surface nodes on '+group+' pad')
        mask|=m
    return mask

def loading(xyz,loaded,areas,spec,case):
    g=spec['module'];origin=np.array([*np.mean(g['centers_xy_mm'],axis=0),g['plane_z_mm']])
    p=xyz[loaded];r=p-origin
    # A maps nodal forces to net force and net moment. Positive area lumping
    # gives a smooth, mesh-area-weighted least-norm traction distribution.
    A=np.concatenate([np.vstack([np.eye(3),skew(ri)]) for ri in r],axis=1)
    force=np.asarray(case['force_n'],dtype=float)
    moment=np.asarray(case['free_moment_nmm'],dtype=float)+np.cross(np.array(g['load_point_mm'])-origin,force)
    desired=np.r_[force,moment]
    W=np.repeat(areas[loaded]/areas[loaded].sum(),3)
    gram=(A*W)@A.T
    if np.linalg.matrix_rank(gram)!=6:raise RuntimeError('Loaded patch wrench map has deficient rank')
    nodal=(W*(A.T@np.linalg.solve(gram,desired))).reshape(-1,3)
    if not np.allclose(A@nodal.ravel(),desired,rtol=1e-8,atol=1e-7):raise RuntimeError('Nodal wrench construction failed')
    return nodal,origin,desired

def write_deck(path,ids,xyz,conn,fixed,loaded,forces,spec):
    with path.open('w') as f:
        f.write('*HEADING\nB1 draft trusted static model, N mm MPa\n*NODE,NSET=ALLN\n')
        for i,p in zip(ids,xyz):f.write(str(i)+','+','.join(f'{x:.12g}' for x in p)+'\n')
        f.write('*ELEMENT,TYPE=C3D10,ELSET=EALL\n')
        for i,c in enumerate(conn,1):f.write(str(i)+','+','.join(map(str,c))+'\n')
        f.write('*NSET,NSET=FIX\n')
        fixids=ids[fixed]
        for k in range(0,len(fixids),16):f.write(','.join(map(str,fixids[k:k+16]))+'\n')
        mat=spec['material']
        f.write(f'*MATERIAL,NAME=FIXED_ALUMINUM\n*ELASTIC\n{mat["young_modulus_mpa"]},{mat["poisson_ratio"]}\n')
        f.write('*SOLID SECTION,ELSET=EALL,MATERIAL=FIXED_ALUMINUM\n*BOUNDARY\nFIX,1,3\n*STEP\n*STATIC\n*CLOAD\n')
        for i,force in zip(ids[loaded],forces):
            for axis,value in enumerate(force,1):f.write(f'{i},{axis},{value:.14g}\n')
        f.write('*NODE PRINT,NSET=ALLN\nU\n*NODE PRINT,NSET=FIX\nRF\n*EL PRINT,ELSET=EALL\nS\n*NODE FILE\nU\n*EL FILE\nS\n*END STEP\n')

def parse_dat(path,ids,conn,fixed):
    sections={'u':[],'s':[],'rf':[]};mode=None
    for line in path.read_text(errors='replace').splitlines():
        low=line.lower().strip()
        if low.startswith('displacements '):mode='u';continue
        if low.startswith('stresses '):mode='s';continue
        if low.startswith('forces '):mode='rf';continue
        if low.startswith('total force'):mode=None;continue
        try:n=[float(x.replace('D','E')) for x in line.split()]
        except ValueError:continue
        if mode in ['u','rf'] and len(n)==4:sections[mode].append(n)
        if mode=='s' and len(n)==8:sections['s'].append(n)
    arrays={k:np.asarray(v,dtype=float) for k,v in sections.items()}
    if any(v.size==0 or not np.all(np.isfinite(v)) for v in arrays.values()):raise RuntimeError('Missing/nonfinite solver tables')
    u=arrays['u'];rf=arrays['rf'];s=arrays['s']
    u=u[np.argsort(u[:,0])];rf=rf[np.argsort(rf[:,0])]
    if not np.array_equal(u[:,0],ids):raise RuntimeError('Displacement node coverage mismatch')
    if not np.array_equal(rf[:,0],ids[fixed]):raise RuntimeError('Reaction node coverage mismatch')
    pairs={(int(row[0]),int(row[1])) for row in s}
    if len(s)!=4*len(conn) or pairs!={(e,k) for e in range(1,len(conn)+1) for k in range(1,5)}:
        raise RuntimeError('C3D10 integration point coverage mismatch')
    return u[:,1:],rf[:,1:],s

def percentile(values,weights,q):
    order=np.argsort(values);k=np.searchsorted(np.cumsum(weights[order]),q*weights.sum())
    return float(values[order[min(k,len(order)-1)]])

def metrics(ids,xyz,conn,volumes,areas,fixed,loaded,u,rf,s,origin,wrench,spec):
    points=xyz[loaded]-origin
    B=np.concatenate([np.hstack([np.eye(3),-skew(r)]) for r in points],axis=0)
    weights=np.repeat(areas[loaded]/areas[loaded].sum(),3)
    motion=np.linalg.lstsq(B*np.sqrt(weights[:,None]),u[loaded].ravel()*np.sqrt(weights),rcond=None)[0]
    residual=u[loaded]-(B@motion).reshape(-1,3)
    sx,sy,sz,txy,txz,tyz=s[:,2:].T
    vm=np.sqrt(0.5*((sx-sy)**2+(sy-sz)**2+(sz-sx)**2)+3*(txy**2+txz**2+tyz**2))
    centroid=xyz[np.searchsorted(ids,conn[:,:4])].mean(axis=1)
    interface=np.zeros(len(conn),dtype=bool)
    for group in ['base','module']:
        g=spec[group];z=g['plane_z_mm']+(g['pad_height_mm']/2 if group=='base' else -g['pad_height_mm']/2)
        radius=spec['stress_regions'][group+'_exclusion_radius_mm']
        for x,y in g['centers_xy_mm']:interface|=np.linalg.norm(centroid-[x,y,z],axis=1)<=radius
    fraction=float(volumes[~interface].sum()/volumes.sum())
    if fraction<spec['geometry']['minimum_bulk_volume_fraction']:raise RuntimeError('Bulk region contains too little structural volume')
    interface_ip=interface[s[:,0].astype(int)-1]
    if not interface_ip.any() or interface_ip.all():raise RuntimeError('Missing stress region')
    stress_weights=volumes[s[:,0].astype(int)-1]/4
    force_error=np.linalg.norm(rf.sum(axis=0)+wrench[:3])
    moment_error=np.linalg.norm(np.cross(xyz[fixed]-origin,rf).sum(axis=0)+wrench[3:])
    loading_spec=spec['loading']
    force_rel=float(force_error/max(np.linalg.norm(wrench[:3]),loading_spec['force_balance_floor_n']))
    moment_rel=float(moment_error/max(np.linalg.norm(wrench[3:]),loading_spec['moment_balance_floor_nmm']))
    return {'interface_translation_mm':float(np.linalg.norm(motion[:3])),
            'interface_rotation_deg':float(np.linalg.norm(motion[3:])*180/np.pi),
            'interface_warp_mm':float(np.linalg.norm(residual,axis=1).max()),
            'bulk_peak_vm_mpa':float(vm[~interface_ip].max()),
            'interface_p99_vm_mpa':percentile(vm[interface_ip],stress_weights[interface_ip],0.99),
            'global_peak_vm_mpa':float(vm.max()),'global_displacement_mm':float(np.linalg.norm(u,axis=1).max()),
            'bulk_volume_fraction':fraction,'force_balance_relative':force_rel,'moment_balance_relative':moment_rel,
            'translation_vector_mm':motion[:3].tolist(),'rotation_vector_rad':motion[3:].tolist(),
            'force_moment_balance_valid':force_rel<=loading_spec['force_balance_relative'] and moment_rel<=loading_spec['moment_balance_relative']}

def main():
    p=argparse.ArgumentParser();p.add_argument('--step',required=True);p.add_argument('--instance',required=True)
    p.add_argument('--out',required=True);p.add_argument('--mesh-mm',required=True,type=float);a=p.parse_args()
    out=Path(a.out).resolve();out.mkdir(parents=True,exist_ok=True)
    spec=json.loads(Path(a.instance).read_text(encoding='utf-8'));result={'status':'measurement_error','loadcases':{},'errors':[]}
    try:
        ids,xyz,conn,volumes,areas,meta=mesh(Path(a.step).resolve(),out,a.mesh_mm,spec)
        result['mesh']=meta
        fixed=patches(xyz,areas,spec,'base');loaded=patches(xyz,areas,spec,'module')
        if np.any(fixed&loaded):raise RuntimeError('Fixture and loaded nodes overlap')
        for case in spec['loads']:
            folder=out/case['id'];folder.mkdir(exist_ok=True)
            try:
                forces,origin,wrench=loading(xyz,loaded,areas,spec,case)
                write_deck(folder/'job.inp',ids,xyz,conn,fixed,loaded,forces,spec)
                env=dict(os.environ,OMP_NUM_THREADS='2',CCX_NPROC_RESULTS='2',CCX_NPROC_EQUATION_SOLVER='2')
                run=subprocess.run(['ccx','-i','job'],cwd=folder,env=env,capture_output=True,text=True,errors='replace',timeout=300)
                (folder/'stdout.log').write_text(run.stdout);(folder/'stderr.log').write_text(run.stderr)
                save(folder/'ccx_invocation.json',{'returncode':run.returncode,'force_n':case['force_n'],'free_moment_nmm':case['free_moment_nmm']})
                if run.returncode!=0:raise RuntimeError('CalculiX nonzero exit')
                u,rf,s=parse_dat(folder/'job.dat',ids,conn,fixed)
                m=metrics(ids,xyz,conn,volumes,areas,fixed,loaded,u,rf,s,origin,wrench,spec)
                np.savez_compressed(folder/'fields.npz',u=u,rf=rf,stress=s)
                result['loadcases'][case['id']]={'metrics':m,'wrench_about_interface':wrench.tolist()}
            except Exception as exc:
                result['errors'].append({'case':case['id'],'detail':str(exc),'traceback':traceback.format_exc()})
        result['status']='measured' if not result['errors'] else 'measurement_error'
    except Exception as exc:result['errors'].append({'detail':str(exc),'traceback':traceback.format_exc()})
    save(out/'result.json',result)

if __name__=='__main__':main()
