"""Disclosed sampled 3mm backbone proxy. No fragile BRep offset operation.

Ray fill a tessellated watertight CAD surface on a fixed 0.75mm lattice, erode
by a radius1.5mm ball stencil, and require one 6-connected component to reach
the eroded interior of every mandatory interface pad. This is a sampled proxy,
not a continuous manufacturing/thickness certificate.
"""
import argparse,json
from pathlib import Path
import numpy as np
from scipy import ndimage

def main():
    p=argparse.ArgumentParser();p.add_argument('--mesh',required=True);p.add_argument('--instance',required=True);p.add_argument('--out',required=True);a=p.parse_args()
    spec=json.loads(Path(a.instance).read_text());mesh=json.loads(Path(a.mesh).read_text())
    pitch=spec['geometry']['backbone_voxel_pitch_mm'];bounds=spec['envelope_mm']
    axes=[np.arange(bounds[k]-pitch*2,bounds[k+3]+pitch*2,pitch)+pitch/2 for k in range(3)]
    nx,ny,nz=map(len,axes);hits={};vertices=np.array(mesh['vertices'])
    for face in mesh['triangles']:
        t=vertices[face];xy=t[:,:2]
        determinant=(xy[1,1]-xy[2,1])*(xy[0,0]-xy[2,0])+(xy[2,0]-xy[1,0])*(xy[0,1]-xy[2,1])
        if abs(determinant)<1e-12:continue
        lo=np.searchsorted(axes[0],xy[:,0].min()-1e-9);hi=np.searchsorted(axes[0],xy[:,0].max()+1e-9,side='right')
        bot=np.searchsorted(axes[1],xy[:,1].min()-1e-9);top=np.searchsorted(axes[1],xy[:,1].max()+1e-9,side='right')
        if lo==hi or bot==top:continue
        ix,iy=np.meshgrid(np.arange(lo,hi),np.arange(bot,top),indexing='ij');x=axes[0][ix];y=axes[1][iy]
        b0=((xy[1,1]-xy[2,1])*(x-xy[2,0])+(xy[2,0]-xy[1,0])*(y-xy[2,1]))/determinant
        b1=((xy[2,1]-xy[0,1])*(x-xy[2,0])+(xy[0,0]-xy[2,0])*(y-xy[2,1]))/determinant
        b2=1-b0-b1;inside=(b0>=-1e-9)&(b1>=-1e-9)&(b2>=-1e-9)
        zs=b0*t[0,2]+b1*t[1,2]+b2*t[2,2]
        for i,j,z in zip(ix[inside].flat,iy[inside].flat,zs[inside].flat):hits.setdefault((int(i),int(j)),[]).append(float(z))
    solid=np.zeros((nx,ny,nz),dtype=bool);odd=0
    for (i,j),z in hits.items():
        z=np.unique(np.round(z,6))
        if len(z)%2:odd+=1;continue
        for low,high in z.reshape(-1,2):solid[i,j]|=(axes[2]>=low)&(axes[2]<=high)
    if odd:raise RuntimeError('Watertight ray parity failed at '+str(odd)+' lattice columns')
    radius=spec['geometry']['minimum_backbone_diameter_mm']/2
    reach=int(np.ceil(radius/pitch));v=np.arange(-reach,reach+1)*pitch
    xx,yy,zz=np.meshgrid(v,v,v,indexing='ij');stencil=xx**2+yy**2+zz**2<=radius**2+1e-10
    eroded=ndimage.binary_erosion(solid,structure=stencil,border_value=0)
    labels,count=ndimage.label(eroded,structure=ndimage.generate_binary_structure(3,1))
    common=None;pad_components={}
    for group in ['base','module']:
        g=spec[group];z=g['plane_z_mm'] if group=='base' else g['plane_z_mm']-g['pad_height_mm']
        iz=(axes[2]>=z+radius-1e-8)&(axes[2]<=z+g['pad_height_mm']-radius+1e-8)
        for k,(x,y) in enumerate(g['centers_xy_mm']):
            rr=(axes[0][:,None]-x)**2+(axes[1][None,:]-y)**2
            core=(rr>=(g['bore_radius_mm']+radius)**2)&(rr<=(g['pad_radius_mm']-radius)**2)
            values=set(int(i) for i in np.unique(labels[core][:,iz]) if i)
            pad_components[group+str(k)]=sorted(values);common=values if common is None else common&values
    result={'passed':bool(common),'method':'fixed-grid ray fill + spherical stencil + 6-connectivity',
            'pitch_mm':pitch,'erosion_radius_mm':radius,'solid_voxels':int(solid.sum()),'eroded_components':count,
            'pad_components':pad_components,'connecting_components':sorted(common or [])}
    Path(a.out).write_text(json.dumps(result,indent=2)+'\n')

if __name__=='__main__':main()
