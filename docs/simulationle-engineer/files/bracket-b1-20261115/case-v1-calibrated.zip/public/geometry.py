"""Immutable BRep measurements. Execute in FreeCAD, never import candidate code."""
import json
import os
import traceback
import tempfile
import zipfile
import sys
import subprocess
from pathlib import Path
import FreeCAD as App
import Part
sys.path.insert(0,str(Path(__file__).resolve().parent))
from cad_common import V,box,cylinder,pad,exclusion_volumes

spec=json.loads(Path(os.environ['B1_INSTANCE']).read_text(encoding='utf-8'))
step=Path(os.environ['B1_STEP'])
out=Path(os.environ['B1_GEOMETRY_OUT'])
checks=[];errors=[];metrics={};g=spec['geometry']
def add(name,group,ok,actual=None):
    checks.append(dict(name=name,group=group,passed=bool(ok),actual=actual))
try:
    if step.stat().st_size>g['max_step_bytes']:raise ValueError('STEP exceeds public size limit')
    shape=Part.Shape();shape.read(str(step))
    valid=shape.isValid() and len(shape.Solids)==1 and not shape.isNull()
    add('valid_single_solid','geometry_interfaces',valid,{'solids':len(shape.Solids),'faces':len(shape.Faces)})
    add('face_resource_limit','geometry_interfaces',len(shape.Faces)<=g['max_faces'],len(shape.Faces))
    if valid:
        metrics.update(volume_mm3=shape.Volume,mass_g=shape.Volume*spec['material']['density_g_mm3'])
        add('mass','mass_backbone',metrics['mass_g']<=spec['limits']['mass_g'],metrics['mass_g'])
        excess=shape.cut(box(spec['envelope_mm'])).Volume
        add('envelope','space_access',excess<=g['boolean_volume_tolerance_mm3'],excess)
        for group in ['base','module']:
            for i,xy in enumerate(spec[group]['centers_xy_mm']):
                missing=pad(spec,group,xy).cut(shape).Volume
                add(group+'_pad_'+str(i),'geometry_interfaces',missing<=g['interface_match_volume_mm3'],missing)
        for name,region in exclusion_volumes(spec):
            if name=='envelope':continue
            overlap=shape.common(region).Volume
            add(name,'space_access' if not '_bore_' in name else 'geometry_interfaces',
                overlap<=g['boolean_volume_tolerance_mm3'],overlap)
        # Compare a freshly rebuilt STEP, and the archived BRep in FCStd,
        # without opening the untrusted FreeCAD document or restoring proxies.
        compare_step=os.environ.get('B1_COMPARE_STEP')
        if compare_step:
            other=Part.Shape();other.read(compare_step)
            diff=shape.cut(other).Volume+other.cut(shape).Volume
            add('source_rebuild_matches_step','geometry_interfaces',
                other.isValid() and len(other.Solids)==1 and diff<=g['interface_match_volume_mm3'],diff)
        fcstd=os.environ.get('B1_FCSTD')
        if fcstd:
            with zipfile.ZipFile(fcstd) as archive:
                members=[n for n in archive.namelist() if n.lower().endswith('.brp')]
                if not members or len(members)>8:raise ValueError('FCStd BRep entry count outside public bound')
                with tempfile.TemporaryDirectory() as temp:
                    nonempty=[]
                    for index,member in enumerate(members):
                        if archive.getinfo(member).file_size>g['max_step_bytes']:raise ValueError('FCStd BRep exceeds declared resource bound')
                        shape_path=Path(temp)/('shape_'+str(index)+'.brp');shape_path.write_bytes(archive.read(member))
                        part=Part.Shape();part.read(str(shape_path))
                        if not part.isNull() and part.Volume>g['boolean_volume_tolerance_mm3']:nonempty.append(part)
                    if len(nonempty)!=1:raise ValueError('FCStd must contain exactly one nonempty BRep; empty SuppressedShape entries are permitted')
                    other=nonempty[0]
                    diff=shape.cut(other).Volume+other.cut(shape).Volume
                    add('fcstd_matches_step','geometry_interfaces',
                        other.isValid() and len(other.Solids)==1 and diff<=g['interface_match_volume_mm3'],diff)
        try:
            vertices,triangles=shape.tessellate(g['backbone_surface_tolerance_mm'])
            mesh_path=out.parent/'backbone_surface.json'
            mesh_path.write_text(json.dumps({'vertices':[[p.x,p.y,p.z] for p in vertices],'triangles':triangles}))
            result_path=out.parent/'backbone.json'
            native_env=dict(os.environ)
            for name in ['PYTHONHOME','PYTHONPATH','LD_LIBRARY_PATH']:native_env.pop(name,None)
            process=subprocess.run(['/usr/bin/python3',str(Path(__file__).with_name('backbone.py')),
                '--mesh',str(mesh_path),'--instance',os.environ['B1_INSTANCE'],'--out',str(result_path)],
                capture_output=True,text=True,timeout=180,env=native_env)
            if process.returncode or not result_path.exists():raise RuntimeError(process.stderr[-2000:])
            backbone=json.loads(result_path.read_text())
            add('connected_3mm_backbone','mass_backbone',backbone['passed'],backbone)
        except Exception as exc:
            errors.append({'stage':'sampled_backbone','kind':'measurement_error','detail':str(exc)})
except Exception as exc:
    errors.append({'stage':'brep','kind':'invalid_or_unreadable_submission','detail':str(exc),'traceback':traceback.format_exc()})
result=dict(status='measurement_error' if errors else 'measured',checks=checks,metrics=metrics,errors=errors)
out.parent.mkdir(parents=True,exist_ok=True)
out.write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')

