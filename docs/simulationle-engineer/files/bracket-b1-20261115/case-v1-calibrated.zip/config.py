from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parent
BASE_URL='https://api-temporary.nju-link.com/v1'
BASE_IMAGE='sha256:0a013e99c92abc76ffc41d90cb22a0af8c76ed6cbd29e7df413d94127eba8c07'
TOOLS_PATH=Path('/data3/adminweihunj/SimulationLE/case/D2/mechanical_sensor_enclosure/runtime-rootfs/opt/tools')
AGENT_TOOL_MASKS=['/opt/tools/freecad/squashfs-root/usr/bin/ccx',
                  '/opt/tools/freecad/FreeCAD_1.1.0-Linux-x86_64-py311.AppImage']
def agent_tool_mounts():
    return ['-v',f'{TOOLS_PATH}:/opt/tools:ro']+[s for p in AGENT_TOOL_MASKS for s in ['-v',f'/dev/null:{p}:ro']]
MODELS=['gpt-6.1-sol']
LIMITS=dict(max_responses=48,max_tool_calls=120,max_output_tokens=131072,max_output_per_response=32768,
            reasoning_effort='medium',max_wall_seconds=7200,terminal_timeout=180,
            max_analysis_calls=160,max_solver_credits=1920,cpu=2,memory_gib=8)
def save(path,data):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_suffix(path.suffix+'.tmp');tmp.write_text(json.dumps(data,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8');tmp.replace(path)
def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
