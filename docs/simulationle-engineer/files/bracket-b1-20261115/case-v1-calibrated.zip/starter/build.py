"""Starter: exports the eight immutable interface pads, NOT a feasible bracket.

Run through FreeCADCmd with B1_INSTANCE and B1_OUTPUT environment variables.
Add your load-bearing geometry; keep rebuilding both instances from this entry.
The script and parameter file are the parametric CAD source. FCStd is a snapshot.
"""
import json
import os
import sys
from pathlib import Path
import Part

HERE=Path(__file__).resolve().parent
PUBLIC=Path(os.environ.get('B1_PUBLIC',str(HERE.parent/'public')))
sys.path.insert(0,str(PUBLIC))
from cad_common import interface_solids,export_document

spec=json.loads(Path(os.environ['B1_INSTANCE']).read_text(encoding='utf-8'))
params=json.loads((HERE/'parameters.json').read_text(encoding='utf-8'))
shape=Part.makeCompound(interface_solids(spec))
# Replace this disconnected compound with one valid, connected bracket.
export_document(shape,spec,params,os.environ['B1_OUTPUT'],'B1Starter')

