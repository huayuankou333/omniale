ARG BASE_IMAGE
FROM ${BASE_IMAGE}
USER root
# Old benchmark assets are not part of the B1 model's environment.
RUN rm -rf /opt/reference /opt/verifier /opt/spec /opt/reference_driver.py && rm -f /usr/bin/ccx
RUN mkdir -p /app /opt/b1 /tmp && chmod 1777 /tmp
ENV HOME=/tmp USER=user QT_QPA_PLATFORM=offscreen LANG=C.UTF-8 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=2 MPLCONFIGDIR=/tmp/matplotlib
WORKDIR /app
USER 1000:1000
CMD ["sleep","infinity"]
