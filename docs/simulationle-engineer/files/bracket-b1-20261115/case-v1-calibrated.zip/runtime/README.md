# B1 固定运行环境

实际基础镜像以 config.py 的不可变 ID 为准，模型镜像以 images.json 为准。agent.Dockerfile 删除旧参考、规格、验收器和系统 ccx。外部 FreeCAD 工具只读挂载，额外屏蔽其附带 ccx 和可重新解包该二进制的 AppImage 归档；具体挂载由 config.agent_tool_mounts 统一生成。

FreeCAD 1.1.0、Gmsh 4.12.1、CalculiX 2.21。每容器 2 CPU、8 GiB，开发和托管工作器均无网络。API 密钥仅在宿主调用器内存中使用。模型不获得 Docker socket、宿主私有数据或参考设计。

预算和额度规则见 protocol.json、AGENT_PROTOCOL.md。2.5/2 mm 二次网格，六个独立工况，各次求解最多 300 秒；单网格工作器 2400 秒，整体验证工作器约 5100 秒。墙钟到期会停止模型容器及活动开发作业。最后独立验收位于开发预算之外。

Dockerfile 是通用公开工具配方；正式模型环境只使用 agent.Dockerfile 及已固定镜像。原草案的 protocol_draft.json 仅为历史建议，不是本次运行合同。
