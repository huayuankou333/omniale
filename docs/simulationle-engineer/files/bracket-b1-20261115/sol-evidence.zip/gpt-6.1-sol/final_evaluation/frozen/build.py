"""Parametric twin triangulated side-frame bracket, dimensions in mm."""
import json, os, sys
from pathlib import Path
import FreeCAD as App
import Part
HERE=Path(__file__).resolve().parent
sys.path.insert(0,os.environ.get('B1_PUBLIC','/opt/b1/public'))
from cad_common import interface_solids, exclusion_volumes, export_document, box, beam_xz
spec=json.loads(Path(os.environ['B1_INSTANCE']).read_text())
params=json.loads((HERE/'parameters.json').read_text())
p=params[spec['id']]
z=spec['module']['plane_z_mm']; top=z-p['top_thickness']/2
shapes=interface_solids(spec)
# Deep triangular side frames. Rear posts, upper chords, and long diagonal struts.
for sign in [-1,1]:
    y=sign*p['side_y']; w=p['side_width']
    shapes.append(box([-63,y-w/2,0,-17,y+w/2,6]))
    shapes.append(beam_xz((-62,3),(-62,top),y,w,p['post_depth']))
    shapes.append(beam_xz((-62,top),(74,top),y,w,p['top_thickness']))
    if spec['keepouts'] and sign==1:
        shapes.append(beam_xz((-24,3),(-1,41),y,w,p['diagonal_depth']))
        shapes.append(beam_xz((-1,41),(70,top),y,w,p.get('cable_diagonal_depth',p['diagonal_depth'])))
        shapes.append(beam_xz((-1,41),(-1,top),y,w,6))
    else:
        shapes.append(beam_xz((-24,3),(70,top),y,w,p['diagonal_depth']))
    if True:
        start=(-1,41) if spec['keepouts'] and sign==1 else (-24,3)
        shapes.append(beam_xz(start,(35,top),y,w,p['inner_diagonal_depth']))
    # In-plane short brace closes the rear pedestal.
    shapes.append(beam_xz((-24,3),(-62,top),y,w,p['post_depth']))
# Base transverse ties and module platform tie the frames against torsion.
# No ground-level cross-tie: each foot is fixed only on its annulus.
if spec['keepouts']:
    for xc in sorted(set(x for x,y in spec['module']['centers_xy_mm'])):
        shapes.append(box([xc-6.5,-p['side_y']-p['side_width']/2,z-p['top_thickness'],xc+6.5,p['side_y']+p['side_width']/2,z]))
else:
    shapes.append(box([31,-p['side_y']-p['side_width']/2,z-p['top_thickness'],77,p['side_y']+p['side_width']/2,z]))
# Rear upper cross-member, clear of all driver columns.
shapes.append(box([-65,-p['side_y'],top-2.75,-59,p['side_y'],top+2.75]))
def rod(a,b,r):
    a=App.Vector(*a);b=App.Vector(*b);d=b-a
    return Part.makeCylinder(r,d.Length,a,d)
shapes.append(rod((-62,-p['side_y'],3),(-62,p['side_y'],top),p['brace_radius']))
shapes.append(rod((-45,-p['side_y'],top),(35,p['side_y'],top),p['brace_radius']))
if True:
    shapes.append(rod((-45,p['side_y'],top),(35,-p['side_y'],top),p['brace_radius']))
shape=shapes[0].multiFuse(shapes[1:]).removeSplitter()
# Blend the side-frame/foot shoulders before cutting access volumes.
edges=[]
for e in shape.Edges:
    v=e.Vertexes
    if len(v)==2:
        a,b=[v0.Point for v0 in v]
        if abs(a.x-b.x)<1e-6 and abs(a.z-b.z)<1e-6 and abs(a.y-b.y)>4 and -28<a.x<-10 and 5.9<a.z<12:
            edges.append(e)
try:
    if edges:
        shape=shape.makeFillet(2.5,edges)
        print('foot blends',len(edges),flush=True)
except Exception as e:
    print('large foot blend unavailable',str(e),flush=True)
    try:
        shape=shape.makeFillet(1.2,edges)
        print('small foot blends',len(edges),flush=True)
    except Exception as e:
        print('foot blend unavailable',str(e),flush=True)
for name,tool in exclusion_volumes(spec):
    if name=='envelope': shape=shape.common(tool)
    else: shape=shape.cut(tool)
if not spec['keepouts']:
    for lo,hi in [(31,48),(56,77)]:
        shape=shape.cut(box([lo,-10,z-7,hi,10,z+1]))

shape=shape.removeSplitter()
print('CAD',spec['id'],'volume',shape.Volume,'mass',shape.Volume*.0027,'solids',len(shape.Solids),'valid',shape.isValid(),flush=True)
export_document(shape,spec,params,os.environ['B1_OUTPUT'],'TriangulatedBracket')
