"""Parametric twin triangulated side-frame bracket, dimensions in mm."""
import json, os, sys
from pathlib import Path
import FreeCAD as App
import Part
HERE=Path(__file__).resolve().parent
sys.path.insert(0,os.environ.get('B1_PUBLIC','/opt/b1/public'))
from cad_common import interface_solids, exclusion_volumes, export_document, box, beam_xz
spec=json.loads(Path(os.environ['B1_INSTANCE']).read_text())
params=json.loads((HERE/'parameters.json').read_text())
p=params[spec['id']]
z=spec['module']['plane_z_mm']; top=z-p['top_thickness']/2
shapes=interface_solids(spec)
# Deep triangular side frames. Rear posts, upper chords, and long diagonal struts.
for sign in [-1,1]:
    y=sign*p['side_y']; w=p['side_width']
    shapes.append(box([-63,y-w/2,0,-17,y+w/2,6]))
    shapes.append(beam_xz((-45,3),(-45,top),y,w,p['post_depth']))
    shapes.append(beam_xz((-45,top),(74,top),y,w,p['top_thickness']))
    if spec['keepouts'] and sign==1:
        shapes.append(beam_xz((-24,3),(-1,41),y,w,p['diagonal_depth']))
        shapes.append(beam_xz((-1,41),(70,top),y,w,p['diagonal_depth']))
        shapes.append(beam_xz((-1,41),(-1,top),y,w,6))
    else:
        shapes.append(beam_xz((-24,3),(70,top),y,w,p['diagonal_depth']))
    # In-plane short brace closes the rear pedestal.
    shapes.append(beam_xz((-59,3),(-45,25),y,w,p['post_depth']))
# Base transverse ties and module platform tie the frames against torsion.
shapes.append(box([-49,-p['side_y'],0,-41,p['side_y'],6]))
shapes.append(box([31,-p['side_y']-p['side_width']/2,z-p['top_thickness'],77,p['side_y']+p['side_width']/2,z]))
# Rear upper cross-member, clear of all driver columns.
shapes.append(box([-49,-p['side_y'],top-3,-41,p['side_y'],top+3]))
shape=shapes[0].multiFuse(shapes[1:]).removeSplitter()
for name,tool in exclusion_volumes(spec):
    if name=='envelope': shape=shape.common(tool)
    else: shape=shape.cut(tool)
shape=shape.cut(box([45,-11,z-7,59,11,z+1])).removeSplitter()
print('CAD',spec['id'],'volume',shape.Volume,'mass',shape.Volume*.0027,'solids',len(shape.Solids),'valid',shape.isValid(),flush=True)
export_document(shape,spec,params,os.environ['B1_OUTPUT'],'TriangulatedBracket')
