# OC6：半潜式平台差频波浪载荷与减载改造

**SLE_E_D3_OC6_v1 · D3 改编实验基准 + 原创工程设计 · 参考解空缺**

入口：[TASK.md](TASK.md)。机器契约：[contract.json](contract.json)；评分：[rubric.json](rubric.json)。

以 OC6 Phase Ib 固定三柱模型的公开实验幅值为验证锚点，要求为 OC4 衍生的带系泊半潜平台设计可制造的外挂减载改造，完成真实三维自由液面求解、差频辨识、六自由度响应、动态系泊、局部结构与不确定性支持的决策。

本版已提供论文和官方报告、30 项公开实验幅值及总不确定度、固定版本的 OpenFAST 水动力数据和模型输入摘录。**没有下载到实验原始时序**：WDH 的数据清单接口返回 401。本版因此采用表格幅值验证，不要求或声称完成实验相位、逐柱时序和重复试验复算。详见 [DATA_AUDIT.md](DATA_AUDIT.md)。

public 为冻结只读输入。求解时复制所需素材到 SLE_E_D3 下独立可写目录。工具仅提供输入几何、谱定义、数据检查与交付结构检查，不含拟合系数、优化设计、参考波浪载荷或参考解。原版公开水动力系数是输入资产，并不是本题改造答案。

```bash
source /home/adminweihunj/SLE_E_D3/cases/OC6_D3_v1/public/environment/activate.sh
python /home/adminweihunj/SLE_E_D3/cases/OC6_D3_v1/public/tools/selfcheck.py
python /home/adminweihunj/SLE_E_D3/cases/OC6_D3_v1/public/tools/verify_assets.py
```

建题检查只说明输入、几何、算术和运行环境可用，不证明改造可行。`reference_solution/` 保持空目录；专家标注待补；本次没有启动 sol 测试。未来若评测，沿用 7200 秒上限，工程要求保持原样。
