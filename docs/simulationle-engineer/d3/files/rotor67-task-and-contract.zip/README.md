# NASA Rotor 67：多工况压气机叶型改造

这是SLE_E_D3原创工程委托。用NASA Rotor67公开实验和HiOCFD几何建立可信基准，再承担五转速叶型改造、间隙/粗糙度/制造偏差、进口畸变、动态失速、强度/振动及鲁棒释放决策。NASA原始对象是跨声速风扇转子；题名中的“压气机”指轴流压缩部件，不把它称为完整压气机级或整台发动机。

先读 TASK.md、DATA_AUDIT.md、EVALUATION_PROTOCOL.md 和 DELIVERY_FORMAT.md。机器约束见 contract.json 与 inputs/。评分见 rubric.json。

提供原始PDF、CAD、经核对的表格、边界分组与辅助工具；没有流体体网格、求解结果、预训练代理或可行改造答案。reference_solution/在public旁边，保持空目录。

准备环境：`source environment/activate.sh`。输入检查：`python tools/selfcheck.py /可写路径/selfcheck.json`。素材校验：`python tools/verify_assets.py`。交付检查：`python tools/validate_delivery.py /可写路径/submission`。这些工具不输出工程总分，也不认证物理正确性。

![源流道几何检查，仅几何预览，无CFD结果](figures/source_geometry_preview.png)

固定矩阵为60个名义、576个误差角点和24个畸变工况；另外要求10个均匀地图、12个畸变稳定性及396个气弹模态—相位campaign。连续不利搜索单独登记。以上数量是题目要求，不表示已经执行。
