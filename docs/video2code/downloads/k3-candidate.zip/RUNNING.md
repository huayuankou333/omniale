Candidate source unchanged. Requires Node.js22.19.0. Extract complete ZIP; run npm run dev -- --host 0.0.0.0 --port 3000 and open http://localhost:3000 . Three.js0.180.0 and license bundled.
