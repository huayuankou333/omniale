Candidate files are unchanged. Requires Node.js 22.19.0. Extract the whole ZIP, then run: npm run dev -- --host 0.0.0.0 --port 3000
Open http://localhost:3000 . Three.js 0.180.0 and its license are bundled locally.
