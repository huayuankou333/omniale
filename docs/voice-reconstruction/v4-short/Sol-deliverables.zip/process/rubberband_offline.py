import ctypes as C,numpy as np,soundfile as sf
lib=C.CDLL('librubberband.so.2');ptr=C.c_void_p;size=C.c_size_t;u=C.c_uint;d=C.c_double;i=C.c_int;fp=C.POINTER(C.c_float);fpp=C.POINTER(fp)
def setup(name,restype,args):
 f=getattr(lib,name);f.restype=restype;f.argtypes=args;return f
new=setup('rubberband_new',ptr,[u,u,i,d,d]);delete=setup('rubberband_delete',None,[ptr]);study=setup('rubberband_study',None,[ptr,fpp,size,i]);process=setup('rubberband_process',None,[ptr,fpp,size,i]);available=setup('rubberband_available',i,[ptr]);retrieve=setup('rubberband_retrieve',size,[ptr,fpp,size]);setdur=setup('rubberband_set_expected_input_duration',None,[ptr,size]);setblock=setup('rubberband_set_max_process_size',None,[ptr,size]);engine=setup('rubberband_get_engine_version',i,[ptr])
def shift(x,sr,semitones):
 # R3 finer engine, offline, formants preserved. No tempo modification.
 options=0x20000000|0x01000000|0x02000000|0x00010000
 st=new(sr,1,options,1.,2**(semitones/12));assert st
 print('RubberBand engine',engine(st),flush=True)
 x=np.ascontiguousarray(x,dtype=np.float32);n=len(x);setdur(st,n);setblock(st,8192)
 def cp(a):return (fp*1)(a.ctypes.data_as(fp))
 for b in range(0,n,8192):
  part=np.ascontiguousarray(x[b:b+8192]);study(st,cp(part),len(part),int(b+8192>=n))
 ys=[]
 for b in range(0,n,8192):
  part=np.ascontiguousarray(x[b:b+8192]);process(st,cp(part),len(part),int(b+8192>=n))
  while (a:=available(st))>0:
   z=np.empty(a,np.float32);got=retrieve(st,cp(z),a);ys.append(z[:got].copy())
 delete(st);out=np.concatenate(ys);print('Rubberband sizes',n,len(out),flush=True)
 return out[:n] if len(out)>=n else np.pad(out,(0,n-len(out)))
if __name__=='__main__':
 import sys
 x,sr=sf.read(sys.argv[1]);y=shift(x,sr,float(sys.argv[3]));sf.write(sys.argv[2],y,sr,subtype='FLOAT')
