# 转换溯源（不是编辑工程的运行依赖）

两个编辑工程只需要各自引用的 WAV 与 `media/F63.mp4`。本目录用于说明 `Voice.wav` 如何生成，不能把这里的同系列编码条件或任何相似度当成独立身份评分。

- `source_embedding.pt`：本次导唱五个 6 秒窗的神经参考条件均值。
- `target_embedding.pt`：题包全部三段、共 72 秒目标参考，九个 8 秒窗的条件均值。
- `recipe.json`：实际参数、输入／通用 checkpoint 哈希、固定电平与纠偏设置。
- `environment.json`：制作环境版本。
- `rebuild_voice.py` 与 `rubberband_offline.py`：可选的**这一段导唱专用**离线重建，不下载资源。需要题包原始 guide、现有 `/opt/models` 下通用 OpenVoice V2 源码及权重、Python 包和 `librubberband.so.2`（3.3.0，R3）。不要为了编辑或重渲染 Mix 而运行它们。

在提供的离线环境中，例如：

```bash
OPENBLAS_NUM_THREADS=2 OMP_NUM_THREADS=3 python process/rebuild_voice.py \
  --guide /workspace/task/guide.wav --output /tmp/Voice-rebuilt.wav
```

输出文件必须不存在，不默认覆盖交付文件。源／目标条件由实际题包参考自行提取，无外部预适配状态。没有改变歌词、另造朗读、切贴目标歌词或使用原歌者片段补洞。神经换声后的 −0.81 半音保共振峰纠偏用来恢复旋律，不是身份变换的替代。

本环境实际重建已通过：输出与 `Voice.wav` 逐样本、逐字节相同，记录位于 `evidence/voice_rebuild_report.json`。其他环境可能受数值库版本影响。Rubber Band 库的版权说明附于 `licenses/RubberBand-COPYRIGHT`；库本身未随包复制。
