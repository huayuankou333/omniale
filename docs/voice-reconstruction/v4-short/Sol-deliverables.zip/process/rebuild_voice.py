"""Optional, one-clip provenance rebuild. Not used by either editing project.
Needs the original task guide and the generic offline OpenVoice V2 installation.
Does not download models, synthesize other songs, or overwrite the final by default.
"""
from pathlib import Path
import argparse, hashlib, json, sys
import numpy as np
import soundfile as sf
import librosa
import torch
from rubberband_offline import shift

p = argparse.ArgumentParser()
p.add_argument('--guide', required=True, type=Path)
p.add_argument('--output', required=True, type=Path)
p.add_argument('--models', default='/opt/models', type=Path)
a = p.parse_args()
here = Path(__file__).resolve().parent
recipe = json.loads((here / 'recipe.json').read_text())
assert hashlib.sha256(a.guide.read_bytes()).hexdigest() == recipe['guide_sha256'], 'Use the supplied 30s guide only.'
assert a.output.resolve() != a.guide.resolve()
assert not a.output.exists(), 'Choose a new output filename.'
ckpt = a.models / 'weights/converter/checkpoint.pth'
assert hashlib.sha256(ckpt.read_bytes()).hexdigest() == recipe['checkpoint_sha256']
sys.path.insert(0, str(a.models / 'source'))
from openvoice.models import SynthesizerTrn
from openvoice.mel_processing import spectrogram_torch
config = json.loads((a.models / 'weights/converter/config.json').read_text())
d = config['data']; sr = d['sampling_rate']
torch.set_num_threads(3)
model = SynthesizerTrn(0, d['filter_length'] // 2 + 1, n_speakers=0, **config['model']).eval()
model.load_state_dict(torch.load(ckpt, map_location='cpu', weights_only=False)['model'], strict=False)
source = torch.load(here / 'source_embedding.pt', weights_only=True, map_location='cpu')
target = torch.load(here / 'target_embedding.pt', weights_only=True, map_location='cpu')
x, insr = sf.read(a.guide, always_2d=True)
x = x.mean(axis=1)
x = librosa.resample(x, orig_sr=insr, target_sr=sr).astype(np.float32)
pad = recipe['context_padding_each_side_samples']
with torch.inference_mode():
    torch.manual_seed(recipe['seed'])
    spec = spectrogram_torch(torch.from_numpy(np.pad(x, (pad, pad), mode='reflect'))[None, :],
                             d['filter_length'], sr, d['hop_length'], d['win_length'], center=False)
    y = model.voice_conversion(spec, torch.LongTensor([spec.shape[-1]]),
                               sid_src=source, sid_tgt=target, tau=.3)[0][0, 0].cpu().numpy()
y = y[pad:pad + len(x)]
y = librosa.resample(y, orig_sr=sr, target_sr=24000)
y = shift(y, 24000, recipe['pitch_correction_semitones'])
y = y[:720000].astype(np.float64)
y *= (10 ** (-2 / 20)) / np.max(np.abs(y))
a.output.parent.mkdir(parents=True, exist_ok=True)
sf.write(a.output, y, 24000, subtype='PCM_24')
print(a.output, sf.info(a.output))
