# ADR checkpoint - D3 scene v3 (142 s, 24 fps, 48 kHz)

## Delivered (final)
- mix.wav 48 kHz / 24-bit / 142.000 s ; role_A..H.wav ; reaper/session.rpp + reaper/media copies
- shotcut/project.mlt ; final.mp4 1280x534 / 24 fps / 3408 frames / AAC 48 kHz
- edit_plan.json (34 items) ; cue_sheet.json (34 cues) ; checkpoints.md

## Final cue list (role / at / candidate / offset / dur)
A Celia: U03 18.10 C146 .445 1.30 | U12 57.10 C153 .155 3.10 | U21 87.95 C079 .88 .80 | U23 96.90 C092 .45 1.90 | U25 100.45 C104 .45 1.90 | U27 104.05 C058 .45 2.20
B Thom: U04 24.15 C016 .24 1.65 | U05 25.95 C149 .25 1.05 | U06 28.30 C018 .555 1.75 | U07 30.10 C053 .57 1.65 | U08 33.30 C069 .40 2.95 | U13 67.95 C013 1.10 1.80 | U14 70.00 C099 .20 .85 | U15 70.95 C123 .45 1.90 | U20 86.35 C073 .25 1.05 | U24 99.10 C027 .25 1.00 | U26 102.70 C183 .25 1.00 | U28 106.60 C113 .10 1.05 | U29 107.45 C141 .25 1.05 | U31 113.10 C049 .40 1.45
C Console man: U19 84.55 C075 .25 1.05 | U22 90.20 C088 .45 1.90
D Captain: U01 3.17 C041 .55 2.78 (And at 3.17, Action! at ~5.05) | U10 52.35 C097 .15 1.18 | U11 55.25 C125 .25 1.10 | U17 77.15 C165 .45 1.85 | U30 111.45 C081 .25 1.05 | U32 120.35 C184 .25 1.05 | U33 136.30 C076 .40 1.45 | U34 138.75 C129 .02 0.70
E Assistant: U16 75.00 C040 .25 1.10 | U18 82.05 C057 .25 1.10
F Guard: U09 49.35 C039 .20 2.15
G System: U02 7.50 C025 .285 1.55

## Picture evidence used
- 0-5.9 s captain at desk: one finger up 4.0 s, points at camera 5.0 s.
- 8.0 s HUD MEMORY OVERWRITE 004.61 % ; processed voice, no human lips.
- 18.0-19.0 robot head opens with glowing emitter; Celia lips pursed 19.5, shut 20.0.
- Thom lips shut 20.6-25.5, open 26.0-27.0, open 28.5-29.9, cutaway 30-32.9 (Celia silent), projection 33.0-34.9, back on Thom 35.0-37.0.
- 49-51 guard with headset; 52-56.6 captain + mic, mouth shut 53.5-55.0, open 55.5-56.0; 57-58.9 Celia speaking, 59-60 two-shot.
- 68.0-68.9 and 70.0-72.4 Thom speaking; 75-77 assistant with radio; 77 captain mouth open; 82-83 assistant radio; 84-85.9 console man shouting; 90-93 sustained scream.
- 97.0-98.8 / 100.5-102.4 Celia speaking with the robot hand on Thom's face; 102.5-108.5 his mouth fully covered -> offscreen replies.
- 111-114 and 119.8-121 captain speaking; 135.4-138.3 empty set; 138.5-141 captain on walkie-talkie; 141.5 guard on the rooftop.

## Auditory clustering (Qwen3.8-omni)
- C001/C097/C125 bright projected male; C041/C076/C081/C006 low smooth male; C165/C075 brighter male; C040/C057 female; C016+C049 same young strained male; C025 processed system.
- C091 turned out to be an older man's No (not a whoa) -> U21 rebuilt from C079's second burst at 0.88 s.

## Mix verification (rendered mix auditions)
- 3-6 s And / Action! complete; 8-9 s Memory overwrite in progress complete.
- 24-38 s Sorry / Look Celia / We have to follow our passions / You have your robotics / and I just want to be awesome in space, no overlaps.
- 49-60 s Okay they're coming... / Speed it up Thom / Vivacissimo / full robot-hand question, all complete.
- 68-79 s Listen Celia I was young / and a dick / But that's no reason... / Why does he do this / We already tried that one.
- 96-110 s You broke my heart / I know / You forgot me on earth / I know / I should just crush you / I'm sorry.
- 108-122 s I'm sorry / Good ad-lib / Not my fault / This time.
- 136-139 s Quiet on set / We're out of time.

## Known uncertainties
- U04 voice-over (no lips) ; U09 guard turned away ; U20/U21/U22 inside inserts with no face.
- U30/U31/U33 offscreen over other characters' shots ; U17 vs U19 share a timbre cluster.
- U02 could be the console man rather than the system.
