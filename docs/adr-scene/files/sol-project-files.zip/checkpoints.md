# D3 actual execution checkpoints

## Initial four-cue draft
Read input_manifest.json, dialogue-script.json, role-cards.json and complete candidate-index.csv. Saved seven-role renderable edit_plan with U01–U04 and checkpoint early. Heard genuine sources; system announcement not forced onto console face. No original full soundtrack, internet, synthetic dialogue or cloned voice used.

## Four-cue batches to complete34
Added U05–U08, U09–U12, U13–U16, U17–U20, U21–U24, U25–U28 and U29–U34 as actual candidate items. Compared alternate utterance families rather than assuming200 independent takes. C086 processed robot versus C146 natural; C153 versus C181 question; C078/C171 versus separated reenactment family; separate C027/C183 I know; distinct C073/C091/C088 cries. Full142s picture surveyed and selected timing/physical-source details inspected. 480 frame observations used, many repeated checks. Voice observer is advisory and occasionally inconsistent; coarse word times never treated as exact sync truth.

## Playable first export (~40 active minutes)
Native REAPER7.85 executed34 items; mix, A–H stems, portable reaper/session.rpp and real used media produced. Native Shotcut exported shotcut/project.mlt and final.mp4 before70% budget. Nothing replaced by a report.

## Trims and source corrections
Opening captain item moved from preliminary1.6s to opening region. C041 .45s source head trim; C086 .35s head trim and tail retained to1.9s; C016 both Sorry complete through2s; C149 full Look Celia with low-level gain correction; C018 .45s pre-roll trim without moving audible onset. U02 switched from C025 to matching context C151 offset.57 duration2.16 after isolated audition for full announcement tail. No pitch/time processing; all rate1. Short fades retained. U27 observer misidentifies female-you vowel as male No in isolated tail; retained full phrase to avoid deleting required word, uncertainty recorded.

## Actual output listening and gain pass
Listened actual mix windows0–15,25–40,40–55,54–69,69–84,83.5–98.5,93–108,110–125,127–142. Observer sometimes mistakes crop endpoints for edit truncation and local versus global time; interpretations corrected accordingly. All34 cues present; three separate cries audible, no word-level collision noted. Objective tail peak before gain correction -0.774dBFS, so reported source-radio distortion not proven digital clipping. Reduced excessive shouted levels: U10/U11 -1.5dB; Abort -3; Cut -2; Quiet on set -3; final radio -4. Re-rendered both native applications.

## Final context correction (~83 active minutes)
U30 Good ad-lib moved from119.8 to110.75, matching first captain reaction cut at111s immediately after apology rather than leaving nine-second incorrect pause. Updated cue_sheet and plan, then re-rendered REAPER34 items and Shotcut again. Final MP4 bytes47,813,178. No further edits after this render.

## Delivery checks
Final MP4 probe:1280x534,24/1fps,3408frames, video142.000s;48kHz stereo AAC, container142.016s AAC tail. Mix probe:48kHz stereo24-bitPCM,6,816,000samples,142.000s. A–G stems same renderer/duration; G independently probed. Final file listing confirms final.mp4, mix.wav, role_A..G.wav, native projects, usedCxxx media, edit_plan.json,cue_sheet.json. No two-frame-all-anchor compliance claim: uncertain offsets/occlusion/voice attribution remain explicitly noted.

## Tool limitations (not auditory comprehension failures)
No external auditory service outage. Text reader refuses .rpp/.mlt ("Read text only; use media tools"). Attempt to author requested root timeline.mlt alias rejected by bounded-text writer ("Write bounded text only"). Actual native MLT is shotcut/project.mlt and native RPP is reaper/session.rpp; README states paths honestly. Root aliases not falsely claimed. Native app execution/rendering itself succeeded every pass.
