# IKEA BESTÅ local demonstration

Run with the provided local static server (for example `node server.mjs` from the project directory), then open the displayed localhost URL. No install or external services are required. Direct product URLs, search, comparison and shopping bag routes are supported by the configured static server. Data and images are read from `/assets/catalog.json` and `/assets/`.

Shopping bag, location, sort, filter and comparison selections persist in localStorage. The displayed offers and availability are a recorded snapshot; checkout and account registration are intentionally not connected to a service.