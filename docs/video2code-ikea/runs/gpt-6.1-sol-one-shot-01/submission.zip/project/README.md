# IKEA BESTÅ shopping journey

A dependency-free, locally routed frontend recreated from the supplied recording and local product catalog.

## Start

Use the already configured static server for this project (the supplied `server.mjs` / package start command). No installation or build step is necessary. Open its local URL at `/` or `/us/en/`.

The server must expose the read-only `/assets/` folder and serve `index.html` for frontend deep links. All scripts, styles, images and catalog requests use absolute local paths. No external services are requested.

## Main routes

- `/us/en/` — home and layered product navigation
- `/us/en/search/?q=besta` — search, color and price filters, comparison selection
- `/us/en/compare/` — comparison, dimensions, remove/add a third frame
- Product routes from `/assets/catalog.json`, including the oak and walnut BESTÅ combinations and STUBBARP 20293568
- `/us/en/shoppingcart/` — shopping bag and order summary

## Interactions and state

The catalog is fetched from `/assets/catalog.json`; the image manifest is also read locally. White filtering, clearing, price sorting, five-product comparison selection, gallery and measurement views, detail tabs, component links, quantity controls, ZIP validation (`95054`), East Palo Alto store selection, reviews with lowest-rating sorting, assembly selection, item removal/Undo and invalid discount-code feedback are implemented.

Anonymous shopping bags use **regular prices**. IKEA Family prices and savings are separate prompts. Quantities multiply included component counts and assembly fees. The minimum assembly service fee is $52.00. Shipping is displayed as a fixed informational snapshot and is not added before checkout.

Shopping bag, assembly selections, location, comparison selection, filtering and product-tab preferences persist in localStorage. Browser history navigation restores route and saved scroll position. Component links open in the same tab so browser Back returns to the combination context.

Real account authentication, ordering/payment and 3D planning are intentionally not connected; their controls show explanatory local panels. To reset the demonstration, clear the `ikea-besta-state` localStorage key in the browser. Reference desktop viewport: 1440 × 900.
