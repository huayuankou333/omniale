# IKEA BESTÅ — local shopping journey

## Run

This frontend uses only native HTML, CSS and JavaScript. No installation or build step is required.

Place `index.html`, `style.css`, and `app.js` in the supplied static server's frontend root, alongside its existing read-only `assets/` directory. Start the provided server using its configured start command (or `node server.mjs` from the supplied project root). Open the local server URL in a browser.

The server should serve `index.html` for frontend routes (SPA fallback), including `/us/en/p/...`, `/us/en/search/`, `/us/en/compare-products/`, and `/us/en/shoppingbag/`. All scripts, styles, catalog requests and images use absolute local paths. No external requests, packages, real account, order or payment services are used.

## Included flows

- Homepage, layered Products / Storage navigation, live search suggestions and search results.
- White filtering, clearing, price sorting, comparison selection and comparison tables, including 60245844, 00245842 and 70245848.
- Oak and walnut BESTÅ combinations, standalone STUBBARP, color switching, image thumbnails, media gallery, enlarged images, dimensions, product information, packaging and linked components.
- ZIP form validation, store search and East Palo Alto selection, fixed delivery and stock information.
- Add-to-bag confirmation, persisted anonymous cart, quantity updates, original-price subtotals, separate Family savings, component multiplication, optional assembly with the minimum service fee, deletion and Undo, and invalid discount feedback.
- Review overlay, lowest-rated sorting, review feedback and a local review form.
- Local routes, browser history, and persistent cart, location, selected comparisons and product UI state.

## State and snapshot

State is stored under `besta-shop-v1` in localStorage. Clear that key (or site storage) to start again. Prices and catalog imagery are loaded from the supplied `/assets/catalog.json`. The two combinations and standalone leg packs retain separate SKU identities. Delivery charges are informational until checkout, matching the recorded shopping-bag summary. Family discounts are shown separately and never applied to anonymous-cart totals.

The homepage promotional video is represented by the provided photo. Unrecorded color choices are reference-only; real account access, payments and the 3D planner are intentionally replaced with local explanatory dialogs. The recorded ZIP `95054` and store `East Palo Alto, CA` can be entered in any order.
