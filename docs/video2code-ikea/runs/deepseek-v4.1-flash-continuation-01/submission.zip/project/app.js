/* ============================================================
   IKEA BESTÅ replica — routing, state, rendering, interactions
   ============================================================ */
(function () {
  'use strict';

  var app = document.getElementById('app');
  var modals = document.getElementById('modals');
  var toastWrap = document.getElementById('toast');

  /* ---------- state ---------- */
  var LS = 'ikea-besta-demo-v1';
  var ST = { location: { zip: null, store: null }, bag: [], compare: [], cookieHidden: false };
  try {
    var raw = localStorage.getItem(LS);
    if (raw) {
      var o = JSON.parse(raw);
      if (o.location) ST.location = o.location;
      if (o.bag) ST.bag = o.bag;
      if (o.compare) ST.compare = o.compare;
      ST.cookieHidden = !!o.cookieHidden;
    }
  } catch (e) {}
  function persist() {
    try { localStorage.setItem(LS, JSON.stringify({ location: ST.location, bag: ST.bag, compare: ST.compare, cookieHidden: ST.cookieHidden })); } catch (e) {}
  }

  var UI = {
    route: { name: 'home' },
    meganav: null, meganavTab: 'new',
    overlay: null,
    filters: { color: null },
    sort: 'best_match',
    reviewSort: 'most_recent',
    reviewCountry: 'us',
    reviewSummary: true,
    mainImg: {}, qty: {}, pdTab: 'overview',
    searchVal: '', lastRemoved: null,
    discountOpen: false, discountCode: '', discountError: false,
    zipVal: '', zipErr: '',
    storeFilter: '', storeSel: null,
    mediaTab: 'all',
    accordions: { sort: false, color: false, size: false, type: false, category: false, material: false, doors: false, features: false, price: false, finish: false, rating: false },
    reviewForm: null,
    cartQty: {}
  };

  /* ---------- helpers ---------- */
  function P(id) { for (var i = 0; i < PRODUCTS.length; i++) if (PRODUCTS[i].id === id) return PRODUCTS[i]; return null; }
  function esc(s) { return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;'); }
  function money(n) { return '$' + Number(n).toFixed(2); }
  function big(n) { var s = Number(n).toFixed(2).split('.'); return '<span class="pr">$' + s[0] + '<sup>' + s[1] + '</sup></span>'; }
  function pct(p) { return Math.round((p.regular_price - p.member_price) / p.regular_price * 100); }
  function saveAmt(p) { return (p.regular_price - p.member_price).toFixed(2); }
  function stars(r, count) {
    var f = Math.round(r), s = '<span class="stars">';
    for (var i = 1; i <= 5; i++) s += '<span class="' + (i <= f ? '' : 'off') + '">★</span>';
    s += '</span>';
    if (count !== undefined && count !== null) s += '<span class="rc">(' + count + ')</span>';
    return s;
  }
  function money2(n) { return Number(n).toFixed(2); }

  /* ---------- icons ---------- */
  var I = {
    globe: '<svg viewBox="0 0 24 24" width="19" height="19" fill="none" stroke-width="1.6"><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c2.6 2.8 2.6 15.2 0 18M12 3c-2.6 2.8-2.6 15.2 0 18"/></svg>',
    bag: '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke-width="1.6"><path d="M4 7h16l-1.2 13.2a1.5 1.5 0 0 1-1.5 1.3H6.7a1.5 1.5 0 0 1-1.5-1.3z"/><path d="M8.5 7V5.5a3.5 3.5 0 0 1 7 0V7"/></svg>',
    cart: '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke-width="1.6"><path d="M3 5h2l2.2 10.2a2 2 0 0 0 2 1.6h7.6a2 2 0 0 0 2-1.55L20.5 8H6"/><circle cx="10" cy="20" r="1.3"/><circle cx="17" cy="20" r="1.3"/></svg>',
    cartW: '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="#fff" stroke-width="1.8"><path d="M3 5h2l2.2 10.2a2 2 0 0 0 2 1.6h7.6a2 2 0 0 0 2-1.55L20.5 8H6"/><circle cx="10" cy="20" r="1.3"/><circle cx="17" cy="20" r="1.3"/></svg>',
    heart: '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke-width="1.6"><path d="M12 20s-7-4.6-7-9.6A4 4 0 0 1 12 7.9a4 4 0 0 1 7 2.5c0 5-7 9.6-7 9.6z"/></svg>',
    search: '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke-width="1.8"><circle cx="11" cy="11" r="6.5"/><path d="M16 16l4.5 4.5"/></svg>',
    user: '<svg viewBox="0 0 24 24" width="21" height="21" fill="none" stroke-width="1.6"><circle cx="12" cy="8" r="3.6"/><path d="M4.5 20c1.2-3.6 4-5.4 7.5-5.4S18.3 16.4 19.5 20"/></svg>',
    store: '<svg viewBox="0 0 24 24" width="21" height="21" fill="none" stroke-width="1.6"><path d="M4 9h16v11H4z"/><path d="M3 9l1.6-5h14.8L21 9" /><path d="M9 20v-6h6v6"/></svg>',
    truck: '<svg viewBox="0 0 24 24" width="21" height="21" fill="none" stroke-width="1.6"><path d="M2 7h11v9H2z"/><path d="M13 10h4l3 3v3h-7z"/><circle cx="6" cy="18" r="1.6"/><circle cx="17" cy="18" r="1.6"/></svg>',
    truckW: '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="#fff" stroke-width="1.8"><path d="M2 7h11v9H2z"/><path d="M13 10h4l3 3v3h-7z"/><circle cx="6" cy="18" r="1.6"/><circle cx="17" cy="18" r="1.6"/></svg>',
    close: '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke-width="1.8"><path d="M5 5l14 14M19 5L5 19"/></svg>',
    chev: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke-width="1.8"><path d="M5 9l7 7 7-7"/></svg>',
    check: '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="#fff" stroke-width="2.6"><path d="M5 12.5l4.5 4.5L19 7"/></svg>',
    info: '<svg viewBox="0 0 24 24" width="17" height="17" fill="none" stroke-width="1.7"><circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 7.6v.2"/></svg>',
    pencil: '<svg viewBox="0 0 24 24" width="21" height="21" fill="none" stroke-width="1.6"><path d="M4 20l1-4 11-11 3 3-11 11z"/></svg>',
    external: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke-width="1.6"><path d="M14 4h6v6M20 4l-8 8"/><path d="M18 14v5H5V6h5"/></svg>',
    task: '<svg viewBox="0 0 24 24" width="21" height="21" fill="none" stroke-width="1.6"><path d="M3 20h18"/><path d="M9 20V9h9l-4.5 5.5z"/><path d="M9 9l-4 5"/></svg>',
    family: '<svg viewBox="0 0 24 24" width="22" height="22" fill="#111"><path d="M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18zm0 2.2a6.8 6.8 0 1 1 0 13.6 6.8 6.8 0 0 1 0-13.6z"/><circle cx="12" cy="12" r="3"/></svg>',
    layers: '<svg viewBox="0 0 24 24" width="21" height="21" fill="none" stroke-width="1.6"><path d="M12 3l8 4.5-8 4.5-8-4.5z"/><path d="M4 12l8 4.5 8-4.5"/><path d="M4 16.5L12 21l8-4.5"/></svg>',
    med: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke-width="1.7"><path d="M3 6h18v12H3z"/><path d="M8 12h8M12 8v8"/></svg>',
    rot: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke-width="1.7"><path d="M12 5a7 7 0 1 1-6.4 10"/><path d="M3.5 8.5L6 11l3-2"/></svg>',
    filter: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke-width="1.7"><path d="M4 7h16M7 12h10M10 17h4"/></svg>',
    sorti: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke-width="1.7"><path d="M7 4v16M7 20l-3-3M7 20l3-3M17 20V4M17 4l-3 3M17 4l3 3"/></svg>',
    plus: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke-width="2"><path d="M12 5v14M5 12h14"/></svg>',
    minus: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke-width="2"><path d="M5 12h14"/></svg>',
    trash: '<svg viewBox="0 0 24 24" width="21" height="21" fill="none" stroke-width="1.6"><path d="M4 6h16M9 6V4h6v2M6 6l1 14h10l1-14"/></svg>',
    pause: '<svg viewBox="0 0 24 24" width="18" height="18" fill="#111"><rect x="7" y="5" width="3.4" height="14"/><rect x="13.6" y="5" width="3.4" height="14"/></svg>',
    arrow: '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="#fff" stroke-width="2"><path d="M5 12h13M13 7l5 5-5 5"/></svg>',
    chevR: '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke-width="2"><path d="M9 5l7 7-7 7"/></svg>',
    pin: '<svg viewBox="0 0 24 24" width="17" height="17" fill="none" stroke-width="1.7"><path d="M12 21s6-5.2 6-10a6 6 0 1 0-12 0c0 4.8 6 10 6 10z"/><circle cx="12" cy="11" r="2.2"/></svg>',
    chat: '<svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="#111" stroke-width="1.7"><path d="M4 5h16v11H9l-5 4z"/></svg>',
    heartOut: '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke-width="1.7"><path d="M12 20s-7-4.6-7-9.6A4 4 0 0 1 12 7.9a4 4 0 0 1 7 2.5c0 5-7 9.6-7 9.6z"/></svg>'
  };

  /* ---------- routing ---------- */
  function parseHash() {
    var raw = location.hash.replace(/^#/, '') || '/';
    var qi = raw.indexOf('?');
    var path = qi >= 0 ? raw.slice(0, qi) : raw;
    var qs = qi >= 0 ? raw.slice(qi + 1) : '';
    var parts = path.split('/').filter(Boolean);
    var q = '';
    qs.split('&').forEach(function (kv) { var a = kv.split('='); if (a[0] === 'q') q = decodeURIComponent(a[1] || ''); });
    if (parts.length === 0) return { name: 'home' };
    if (parts[0] === 'search') return { name: 'search', q: q || 'besta' };
    if (parts[0] === 'compare') return { name: 'compare' };
    if (parts[0] === 'bag') return { name: 'bag' };
    if (parts[0] === 'p' && parts[1]) return { name: 'product', id: parts[1] };
    return { name: 'home' };
  }
  function go(href) { location.hash = href; }

  /* ============================================================ HEADER */
  function bagCount() { return ST.bag.reduce(function (s, l) { return s + l.qty; }, 0); }

  function renderTop() {
    var zipSet = ST.location.zip;
    return '<div class="topbar"><div class="in">' +
      '<div class="l">' + I.globe + '<span>US</span><span style="opacity:.5">|</span><span>English</span></div>' +
      '<div class="c"><a data-act="nav" data-href="#/search?q=besta">' + I.bag + '<span>Shop new arrivals</span></a></div>' +
      '<div class="r">' +
        '<button data-act="open-location">' + I.truckW + '<span>' + (zipSet ? esc(zipSet) : 'Enter ZIP code') + '</span></button>' +
        '<button data-act="open-store">' + I.store + '<span>' + (ST.location.store ? esc(ST.location.store) : 'Select store') + '</span></button>' +
      '</div></div></div>';
  }

  function renderHeader(route) {
    var qv = (route.name === 'search') ? esc(route.q) : '';
    var filled = qv ? ' filled' : '';
    return '<header class="hdr"><div class="in">' +
      '<a class="logo" data-act="nav" data-href="#/"><img src="/assets/media-000.svg" alt="IKEA"></a>' +
      '<nav class="hnav">' +
        '<button data-act="toggle-meganav" class="' + (UI.meganav ? 'on' : '') + '">Products</button>' +
        '<button data-act="nav" data-href="#/search?q=rooms">Rooms</button>' +
        '<button data-act="nav" data-href="#/search?q=deals">Deals</button>' +
        '<button data-act="nav" data-href="#/search?q=design">Design &amp; ideas</button>' +
        '<button data-act="nav" data-href="#/search?q=services">Services</button>' +
      '</nav>' +
      '<form class="search' + filled + '" id="searchForm" autocomplete="off">' +
        '<div class="box">' + I.search +
          '<input id="searchInput" placeholder="What are you looking for?" value="' + qv + '">' +
          '<button type="button" class="ibtn cx" data-act="clear-search" aria-label="Clear">' + I.close + '</button>' +
          '<button type="button" class="ibtn" data-act="do-search" aria-label="Search">' + I.search + '</button>' +
        '</div>' +
        '<div class="sug" id="sugBox"></div>' +
      '</form>' +
      '<div class="hright">' +
        '<button class="acc" data-act="login">' + I.user + '<span>Hej! Log in or sign up</span></button>' +
        '<button class="iconbtn" data-act="favourites" aria-label="Favourites">' + I.heart + '</button>' +
        '<button class="iconbtn" data-act="nav" data-href="#/bag" aria-label="Shopping bag">' + I.bag +
          (bagCount() ? '<span class="badge">' + bagCount() + '</span>' : '') + '</button>' +
      '</div></div></header>';
  }

  /* ---------- meganav ---------- */
  function renderMeganav() {
    var d = MEGANAV[UI.meganavTab] || MEGANAV.new;
    var order = ['new', 'winter', 'storage', 'sofas', 'beds', 'lighting', 'kitchen'];
    var tabs = '';
    for (var i = 0; i < order.length; i++) {
      var k = order[i], m = MEGANAV[k];
      tabs += '<button data-act="meganav-tab" data-tab="' + k + '" class="' + (k === UI.meganavTab ? 'on' : '') + '">' + esc(m.title) +
        (k === 'kitchen' ? ' <span style="display:inline-flex;vertical-align:middle">' + I.chevR + '</span>' : '') + '</button>';
    }
    var left = d.left.map(function (t) { return '<a data-act="nav" data-href="#/search?q=' + encodeURIComponent(t) + '">' + esc(t) + '</a>'; }).join('');
    var cols = d.cols.map(function (c) {
      return '<div class="col">' + (c.h ? '<h4>' + esc(c.h) + '</h4>' : '') +
        c.items.map(function (t) { return '<a data-act="nav" data-href="#/search?q=' + encodeURIComponent(t) + '">' + esc(t) + '</a>'; }).join('') + '</div>';
    });
    while (cols.length < 3) cols.push('<div class="col"></div>');
    return '<section class="meganav"><div class="wrap">' +
      '<div class="tabs">' + tabs + '</div>' +
      '<div class="body">' +
        '<div class="left">' + left + '</div>' +
        cols.join('') +
        '<div class="promo"><img src="' + d.promo.img + '" alt=""><div class="t" style="background:' + d.promo.bg + '">' + esc(d.promo.text) + '</div></div>' +
      '</div></div></section>';
  }

  /* ---------- pills ---------- */
  function renderPills() {
    var pills = [
      { t: 'Deals', ic: '/assets/media-353.jpg', tab: 'new' },
      { t: 'Winter holiday shop', ic: '/assets/media-084.jpg', tab: 'winter' },
      { t: 'Storage &amp; organization', ic: '/assets/media-329.jpeg', tab: 'storage' },
      { t: 'Sofas &amp; armchairs', ic: '/assets/media-035.jpg', tab: 'sofas' },
      { t: 'Beds &amp; mattresses', ic: '/assets/media-101.jpg', tab: 'beds' },
      { t: 'Lighting', ic: '/assets/media-036.jpg', tab: 'lighting' },
      { t: 'Kitchen, appliances &amp; supplies', ic: '/assets/media-031.jpg', tab: 'kitchen' }
    ];
    return '<div class="pills">' + pills.map(function (p) {
      return '<button class="pill' + (UI.meganav && UI.meganavTab === p.tab ? ' on' : '') + '" data-act="pill" data-tab="' + p.tab + '">' +
        '<span class="ic"><img src="' + p.ic + '" alt=""></span><span>' + p.t + '</span></button>';
    }).join('') + '</div>';
  }

  /* ============================================================ HOME */
  function renderHome() {
    return '<div class="wrap">' + renderPills() +
      '<section class="hero">' +
        '<div class="big"><img src="/assets/kitchen-video-still.jpg" alt="Kitchen">' +
          '<span class="tag">IKEA Family price</span>' +
          '<button class="pause" data-act="pause" aria-label="Pause">' + I.pause + '</button></div>' +
        '<div class="col">' +
          '<div class="card top"><img src="/assets/media-031.jpg" alt=""><span class="new">New</span>' +
            '<div class="cap"><span data-act="nav" data-href="#/search?q=kitchen accessories">New, must-try kitchen accessories</span><span>' + I.arrow + '</span></div></div>' +
          '<div class="row">' +
            '<div class="card"><img src="/assets/media-025.jpg" alt=""><div class="cap"><span>IKEA Projekt credit card</span></div></div>' +
            '<div class="card"><img src="/assets/media-026.jpg" alt=""><div class="cap"><span>Kitchen planning service</span></div></div>' +
          '</div>' +
        '</div>' +
      '</section>' +

      '<section style="padding-bottom:70px">' +
        '<h2 style="font-size:24px;margin-bottom:22px">Explore BESTÅ storage combinations</h2>' +
        '<div class="grid" style="grid-template-columns:repeat(4,1fr)">' +
          cardHTML(P('29209829'), false) + cardHTML(P('29612189'), false) +
          cardHTML(P('20293568'), false) + cardHTML(P('09590409'), false) +
        '</div>' +
      '</section>' +

      '<section style="padding-bottom:70px">' +
        '<h2 style="font-size:24px;margin-bottom:22px">Everyday essentials for you</h2>' +
        renderEssentials() +
      '</section>' +
      renderFooter() + '</div>';
  }

  function renderFooter() {
    var cols = [
      ['Join IKEA Family', ['IKEA Family', 'IKEA for Business', 'IKEA Visa Credit Card', 'IKEA Gift card']],
      ['Customer service', ['Contact us', 'Returns', 'Delivery', 'Track your order', 'Warranties']],
      ['Services', ['Assembly service', 'Kitchen planning', 'Personal shopping', 'Interior design', 'Financing']],
      ['About IKEA', ['About us', 'Careers', 'Sustainability', 'Newsroom', 'IKEA Food']]
    ];
    return '<footer class="foot"><div class="cols">' + cols.map(function (c) {
      return '<div><h4>' + c[0] + '</h4>' + c[1].map(function (t) { return '<a>' + t + '</a>'; }).join('') + '</div>';
    }).join('') + '</div><p style="margin-top:30px">© Inter IKEA Systems B.V. 1999 - 2026 — local replica for demonstration purposes.</p></footer>';
  }

  function renderCookie() {
    return '<div class="cookie"><div class="in">' +
      '<p>IKEA US and our digital partners use cookies on this site. Some are strictly necessary to run the site and others are used for measuring site usage, enabling personalization and for advertising, marketing, and social media. View our <a style="text-decoration:underline">Privacy Policy</a>, <a style="text-decoration:underline">California Notice at Collection</a>, and <a style="text-decoration:underline">Cookie Policy</a> for more information.</p>' +
      '<div class="acts"><button class="btn black" data-act="cookie-priv">Your privacy choices</button><button class="btn black" data-act="cookie-ok">Ok</button></div>' +
      '</div></div>';
  }

  /* ============================================================ CARDS */
  function cardHTML(p, showCompare) {
    if (!p) return '';
    var checked = ST.compare.indexOf(p.id) >= 0;
    var inBagQty = 0; ST.bag.forEach(function (l) { if (l.id === p.id) inBagQty = l.qty; });
    return '<article class="card">' +
      (showCompare === false ? '' : '<label class="cmpl"><input type="checkbox" data-cmp="' + p.id + '"' + (checked ? ' checked' : '') + '> Compare</label>') +
      '<div class="thumbwrap"><a data-act="nav" data-href="#/p/' + p.id + '"><img src="' + p.image + '" alt="' + esc(p.description) + '"></a>' +
        (p.badge ? '<span class="tag">' + esc(p.badge) + '</span>' : '') +
        '<button class="fav" data-act="fav" aria-label="Save">' + I.heart + '</button></div>' +
      '<div class="info">
        <button class="addb" data-act="add-to-bag" data-id="' + p.id + '" data-qty="1" aria-label="Add to bag">' + I.cartW + '</button>' +
        '<div class="fam">IKEA Family price</div>' +
        '<a data-act="nav" data-href="#/p/' + p.id + '"><div class="nm">' + esc(p.name) + '</div><div class="ds">' + esc(p.description) + '</div></a>' +
        '<div class="pr">' + big(p.member_price) + '</div>' +
        '<div class="sv">' + pct(p) + '% off, save $' + saveAmt(p) + '</div>' +
        '<div class="rg">Regular price ' + money(p.regular_price) + '</div>' +
        '<div class="dt">Price valid Oct 7, 2026 - Nov 11, 2026 or while supply lasts</div>' +
        '<div class="rt">' + stars(p.rating, p.review_count) + '</div>' +
        '<a class="mo" data-act="nav" data-href="#/p/' + p.id + '">More options</a>' +
      '</div></article>';
  }

  function renderEssentials() {
    return '<div class="essgrid">' + ESSENTIALS.map(function (e) {
      return '<div class="it"><img src="' + e.img + '" alt=""><div class="nm">' + esc(e.name) + '</div>' +
        '<div class="ds">' + esc(e.desc) + '</div>' +
        (e.was ? '<span class="badge2">$' + e.price.toFixed(2) + '</span><div class="was">$' + e.was.toFixed(2) + '</div>' : '<div class="pr">$' + e.price.toFixed(2) + '</div>') +
        '<div class="av"><div><span class="htg"><span class="dot g" style="background:var(--green)"></span></span>Available for delivery</div><div><span class="dot g" style="background:var(--green)"></span>Available for Click &amp; collect</div></div></div>';
    }).join('') + '</div>';
  }

  /* ============================================================ SEARCH */
  function searchIds() {
    if (UI.filters.color === 'white') {
      return ['60245844', '00245842', '89209829', '89622907', '09590409', '19047432', '59047388', '39429699', '59046906', '89425910', '60245919', '39284998', '40565775'];
    }
    return ['60245844', '00245842', '29209829', '09590409', '59622907', '60245919', '59047388', '39429699', '19047432', '40565775', '99623146', '69612205', '39284998', '89425910', '59046906'];
  }
  function sortedIds() {
    var ids = searchIds();
    var arr = ids.map(function (id) { return P(id); }).filter(Boolean);
    var s = UI.sort;
    if (s === 'price_asc') arr.sort(function (a, b) { return a.member_price - b.member_price; });
    else if (s === 'price_desc') arr.sort(function (a, b) { return b.member_price - a.member_price; });
    else if (s === 'rating') arr.sort(function (a, b) { return b.rating - a.rating; });
    else if (s === 'name') arr.sort(function (a, b) { return a.name.localeCompare(b.name); });
    else if (s === 'popular') arr.sort(function (a, b) { return b.review_count - a.review_count; });
    else if (s === 'newest') arr.reverse();
    return arr;
  }
  var SORTS = [['best_match', 'Best match'], ['price_asc', 'Price: low to high'], ['price_desc', 'Price: high to low'],
    ['newest', 'Newest'], ['rating', 'Customer rating'], ['name', 'Name'], ['popular', 'Most popular'],
    ['width', 'Width'], ['height', 'Height']];

  function renderSearch(route) {
    var items = sortedIds();
    var count = UI.filters.color === 'white' ? SEARCH_SNAPSHOT.white_results : SEARCH_SNAPSHOT.total_results;
    var smart = UI.filters.color === 'white' ? 3 : 5;

    function acc(key, label, panel) {
      return '<div class="acc' + (UI.accordions[key] ? ' open' : '') + '"><button data-act="acc" data-acc="' + key + '"><b>' + label + '</b>' + I.chev + '</button>' +
        '<div class="panel">' + (panel || '') + '</div></div>';
    }

    var sortPanel = SORTS.map(function (s) {
      return '<label class="radio' + (UI.sort === s[0] ? ' on' : '') + '" data-act="set-sort" data-sort="' + s[0] + '"><span class="dot"></span><span>' + s[1] + '</span></label>';
    }).join('');

    var colorPanel = '<div class="swatches">' + [
      ['Gray', 87, '#9c9c9c'], ['White', 87, '#ffffff'], ['Black', 66, '#111111'], ['Beige', 59, '#eae0c9'],
      ['Brown', 55, '#8b5a2b'], ['Green', 19, '#3f6f3f']
    ].map(function (c) {
      return '<button class="sw' + (UI.filters.color === c[0].toLowerCase() ? ' on' : '') + '" data-act="set-color" data-color="' + c[0].toLowerCase() + '">' +
        '<span class="c" style="background:' + c[2] + '"></span><span>' + c[0] + '</span><span>' + c[1] + '</span></button>';
    }).join('') + '</div>';

    var filterCols = [
      acc('sort', 'Sort', sortPanel),
      acc('size', 'Size', '<p style="font-size:13px;color:#484848">Width, height and depth filters.</p>'),
      acc('color', 'Color', colorPanel),
      acc('type', 'Type', '<p style="font-size:13px;color:#484848">Storage combinations, frames, benches…</p>'),
      acc('category', 'Category', '<p style="font-size:13px;color:#484848">Storage &amp; organization</p>'),
      '<div class="cnt"><span>Smart home</span><span style="display:flex;gap:10px;align-items:center">' + smart + '<input type="checkbox" style="width:20px;height:20px;accent-color:#111"></span></div>',
      acc('material', 'Material', '<p style="font-size:13px;color:#484848">Particleboard, wood, glass.</p>'),
      acc('doors', 'Doors', '<p style="font-size:13px;color:#484848">With doors, without doors.</p>'),
      acc('features', 'Features', '<p style="font-size:13px;color:#484848">Adjustable shelves, soft closing.</p>'),
      acc('price', 'Price', '<p style="font-size:13px;color:#484848">$0 - $1,000+</p>'),
      acc('finish', 'Finish', '<p style="font-size:13px;color:#484848">White, oak effect, walnut effect.</p>'),
      acc('rating', 'Customer rating', '<p style="font-size:13px;color:#484848">4 stars &amp; up</p>')
    ].join('');

    var chips = UI.filters.color === 'white' ? '<div class="chip">white <button data-act="clear-color" aria-label="Remove filter">' + I.close + '</button></div>' : '';

    return '<div class="wrap">' +
      '<div class="info-banner">Need help planning your BESTÅ system? Our storage experts can help at 1-888-888-4532, 8AM-11:59PM EST.</div>' +
      '<div class="search-head"><h1>' + count + ' items for "' + esc(route.q) + '"</h1>' +
        '<div class="design-box">' + I.pencil + '<div><div class="t">Design your own BESTÅ storage</div><a data-act="nav" data-href="#/p/29209829">Get started</a></div></div></div>' +
      '<div class="search-body">' +
        '<aside class="filters">' + filterCols + '</aside>' +
        '<div><div class="chips">' + chips + '</div><div class="grid">' + items.map(function (p) { return cardHTML(p, true); }).join('') + '</div></div>' +
      '</div></div>' + renderCompareBar();
  }

  function renderCompareBar() {
    if (!ST.compare.length) return '';
    var thumbs = '';
    for (var i = 0; i < 5; i++) {
      if (ST.compare[i]) { var p = P(ST.compare[i]); thumbs += '<img src="' + p.image + '">'; }
      else thumbs += '<span></span>';
    }
    return '<div class="cmpbar"><div class="wrap" style="display:flex;align-items:center;gap:20px">' +
      '<button class="close" data-act="compare-close">Close</button>' +
      '<span class="cnt2">' + ST.compare.length + '/5 selected</span>' +
      '<span class="thumbs">' + thumbs + '</span>' +
      '<button class="btn ' + (ST.compare.length >= 2 ? 'black' : 'gray') + '" data-act="go-compare">Compare products</button>' +
      '</div></div>';
  }

  /* ============================================================ COMPARE */
  function cmpDims(p) {
    for (var i = 0; i < COMPARABLES.length; i++) if (COMPARABLES[i].id === p.id) return COMPARABLES[i];
    return { width: (p.dims ? p.dims.width : ''), height: (p.dims ? p.dims.height : ''), depth: (p.dims ? p.dims.depth : '') };
  }
  function renderCompare() {
    var ids = ST.compare;
    if (!ids.length) {
      return '<div class="wrap fake"><h1 class="cmp-title">Product comparison</h1><p>No products selected. Add products from a search result to compare them.</p>' +
        '<p style="margin-top:18px"><a class="btn black" data-act="nav" data-href="#/search?q=besta">Back to search</a></p></div>';
    }
    var ps = ids.map(function (id) { return P(id); }).filter(Boolean);
    var cols = 'repeat(' + ps.length + ',1fr)';
    var head = '<div class="cmp-head" style="--cols:' + ps.length + '"><div></div>' + ps.map(function (p) {
      return '<div class="cmp-col"><button class="x" data-act="remove-compare" data-id="' + p.id + '">' + I.close + '</button>' +
        '<div class="im"><a data-act="nav" data-href="#/p/' + p.id + '"><img src="' + p.image + '"></a><button class="fav">' + I.heart + '</button></div>' +
        '<div class="fam">IKEA Family price</div><div class="nm">' + esc(p.name) + '</div>' +
        '<div class="ds">' + esc(p.description) + '</div>' +
        '<div class="pr">' + big(p.member_price) + '</div>' +
        '<div class="sv">' + pct(p) + '% off, save $' + saveAmt(p) + '</div>' +
        '<div class="rg">Regular price ' + money(p.regular_price) + '</div>' +
        '<div class="dt">Price valid Oct 7, 2026 - Nov 11, 2026 or while supply lasts</div>' +
        '<div class="rt" style="margin-top:10px">' + stars(p.rating, p.review_count) + '</div></div>';
    }).join('') + '</div>';

    function row(label, fn) {
      return '<div class="cmp-head" style="--cols:' + ps.length + '"><div class="cmp-row-h" style="background:#fff;font-weight:700;padding:22px 16px 6px">' + label + '</div>' +
        ps.map(function (p) { return '<div class="cmp-row-c" style="background:#fff;padding:22px 22px 6px">' + fn(p) + '</div>'; }).join('') + '</div>';
    }
    function kv(label, fn) {
      return '<div class="cmp-head" style="--cols:' + ps.length + '"><div class="cmp-row-h">' + label + '</div>' +
        ps.map(function (p) { return '<div class="cmp-row-c">' + fn(p) + '</div>'; }).join('') + '</div>';
    }
    return '<div class="wrap"><h1 class="cmp-title">Product comparison</h1>' +
      '<div>' + head +
      row('Key features', function () { return ''; }) +
      kv('Width', function (p) { return cmpDims(p).width; }) +
      kv('Height', function (p) { return cmpDims(p).height; }) +
      kv('Depth', function (p) { return cmpDims(p).depth; }) +
      kv('Regular price', function (p) { return money(p.regular_price); }) +
      kv('IKEA Family price', function (p) { return money(p.member_price); }) +
      kv('Customer rating', function (p) { return p.rating + ' / 5 (' + p.review_count + ' reviews)'; }) +
      '</div></div>' + renderFooter();
  }

  /* ============================================================ PRODUCT */
  function renderProduct(id) {
    var p = P(id);
    if (!p) return '<div class="wrap fake"><h1>Product not found</h1><p style="margin-top:16px"><a class="btn black" data-act="nav" data-href="#/search?q=besta">Back to search</a></p></div>';
    var gal = p.gallery || [p.image];
    var cur = UI.mainImg[id] || gal[0];
    if (gal.indexOf(cur) < 0) cur = gal[0];
    var qty = UI.qty[id] || 1;

    var crumbs = (p.crumb || CRUMB_GEN).map(function (c, i) {
      var last = i === (p.crumb || CRUMB_GEN).length - 1;
      return '<a data-act="nav" data-href="#/search?q=besta">' + esc(c) + '</a>' + (last ? '' : '<span class="sep">›</span>');
    }).join('');

    var thumbs = '<div class="thumbs">' + gal.map(function (g) {
      return '<button class="' + (g === cur ? 'on' : '') + '" data-act="thumb" data-id="' + id + '" data-img="' + g + '"><img src="' + g + '"></button>';
    }).join('') + '</div>';

    var variants = null;
    if (p.combo) variants = VARIANTS_COMBO;
    else if (id === '20293568' || id === '60293566') variants = VARIANTS_LEG;
    var swHtml = '';
    if (variants) {
      swHtml = '<div class="pd-sec"><h3>Choose color</h3><div class="sub">' + esc(p.color) + '</div><div class="swrow">' +
        variants.map(function (v) {
          var on = (v.id === id) || (!v.id && v.img === p.image);
          return '<button class="' + (on ? 'on' : '') + '" data-act="swatch" data-id="' + id + '" data-vid="' + (v.id || '') + '" data-img="' + v.img + '" data-color="' + esc(v.color) + '"><img src="' + v.img + '"></button>';
        }).join('') +
        (p.combo ? '<button class="more">+12</button>' : '') + '</div></div>';
    }

    var addLabel = qty > 1 ? ('Add ' + qty + ' items to cart') : 'Add to bag';
    var per = p.pack_size ? ('/' + p.pack_size + ' pack') : '';

    var svc = p.assembly_per_unit ? '<div class="svcbox">' + I.task + '<div><div style="font-weight:700">Available services</div>Have your ' + esc(p.name) + ' professionally assembled for ' + money(p.assembly_per_unit) + '. <a style="text-decoration:underline" data-act="nav" data-href="#/bag">Learn more</a></div></div>' : '';

    return '<div class="wrap">' +
      '<div class="crumbs">' + crumbs + '</div>' +
      '<div class="pd">' + thumbs +
        '<div class="main"><img id="mainImg" src="' + cur + '" alt="' + esc(p.description) + '">' +
          '<div class="ovbtns">' +
            '<button data-act="open-media" data-id="' + id + '">' + I.med + 'All media</button>' +
            '<button data-act="open-3d">' + I.rot + 'View in 3D</button>' +
          '</div></div>' +
        '<div class="pd-info">' +
          '<div class="fam">IKEA Family price</div>' +
          '<div style="display:flex;justify-content:space-between;align-items:flex-start"><div><h1>' + esc(p.name) + '</h1>' +
            '<div class="desc">' + esc(p.description) + '</div></div>' +
            '<button class="iconbtn" data-act="fav">' + I.heart + '</button></div>' +
          '<div class="pr">' + big(p.member_price) + (per ? '<span style="font-size:15px;font-weight:400">' + per + '</span>' : '') + '</div>' +
          '<div class="sv">' + pct(p) + '% off, save $' + saveAmt(p) + '</div>' +
          '<div class="rg">Regular price: ' + money(p.regular_price) + per + '</div>' +
          '<div class="rg">Price valid Oct 7, 2026 - Nov 11, 2026 or while supply lasts</div>' +
          '<div class="rt">' + stars(p.rating, p.review_count) + '</div>' +
          (p.combo ? '<div class="note">' + I.info + '<span>Knobs and handles are sold separately.</span></div>' : '') +
          (id === '20293568' ? '<div class="note">' + I.info + '<span>BESTÅ supporting leg sold separately.</span></div>' : '') +
          swHtml +
          '<div class="pd-sec"><h3>Design it yourself</h3><div class="sub">Customise BESTÅ in our planning tool</div></div>' +
          '<div class="pd-sec"><h3>How to get it</h3>' + howToGetIt(p) + '</div>' +
          '<div class="qtyrow"><div class="stepper"><button data-act="pdp-minus" data-id="' + id + '"' + (qty <= 1 ? ' disabled' : '') + '>' + I.minus + '</button>' +
            '<span class="v">' + qty + '</span><button data-act="pdp-plus" data-id="' + id + '">' + I.plus + '</button></div>' +
            '<button class="btn blue" style="flex:1" data-act="add-to-bag" data-id="' + id + '" data-qty="' + qty + '">' + addLabel + '</button></div>' +
          svc +
          '<div class="points"><span class="p1">' + I.family + '</span><div><b>Collect ' + Math.round(p.member_price) + ' points with IKEA Family</b><div><a style="text-decoration:underline">Join for free or log in</a> | <a style="text-decoration:underline">Explore what you can get</a></div></div></div>' +
          '<div class="returns">' + I.heart + '<div><b>It\u2019s OK to change your mind</b><div style="font-size:13px;color:#484848">Return within 365 days for a full refund*. <a style="text-decoration:underline">Learn more</a></div></div></div>' +
        '</div>' +
      '</div>' +
      renderPdTabs(p) +
      renderReviewSummary(p) +
      renderAccessories(p) +
      renderFooter() + '</div>';
  }

  function howToGetIt(p) {
    if (!ST.location.zip) {
      return '<div class="htg"><div class="r"><span class="dot"></span><a data-act="open-location" style="text-decoration:underline">Check delivery and in-stock availability</a></div></div>';
    }
    var st = ST.location.store || LOC.store;
    return '<div class="htg">' +
      '<div class="r">' + I.store + '<div><span class="dot g"></span><b style="display:inline"> In stock in IKEA ' + esc(st) + '</b><div class="s">Opens at 10:00 AM<br><a style="text-decoration:underline">Find in store</a></div></div></div>' +
      '<div class="r">' + I.store + '<div><span class="dot g"></span><b style="display:inline"> Click and collect at IKEA ' + esc(st) + '</b><div class="s">From $2.00 or <a style="text-decoration:underline">Free with IKEA Family</a></div></div></div>' +
      '<div class="r">' + I.truck + '<div><span class="dot g"></span><b style="display:inline"> Home delivery to ' + esc(ST.location.zip) + '</b></div></div>' +
      '</div>';
  }

  function renderPdTabs(p) {
    var tabs = [['overview', 'Overview'], ['details', 'Product details'], ['measurements', 'Measurements'], ['included', "What's included"]];
    var bar = tabs.map(function (t) { return '<button class="' + (UI.pdTab === t[0] ? 'on' : '') + '" data-act="pd-tab" data-tab="' + t[0] + '">' + t[1] + '</button>'; }).join('');
    var body = '';
    if (UI.pdTab === 'overview') {
      body = '<h3 style="font-size:20px;margin-bottom:14px">' + esc(p.name) + ' ' + esc(p.description) + '</h3>' +
        '<p style="max-width:760px">BESTÅ storage system is a flexible, modular solution that lets you build exactly the storage you need. The frame is easy to assemble and the doors and drawers keep dust away and clutter out of sight. Combine frames, doors, legs and interior organisers — knobs and handles are sold separately so you can finish the look your way.</p>' +
        '<div style="margin-top:22px;max-width:760px">' +
        '<div class="infoline">' + I.info + '<span>Design and build your own BESTÅ in the IKEA planning tool.</span></div>' +
        '<div class="infoline">' + I.info + '<span>Wall-anchoring kit included — always secure furniture to the wall.</span></div></div>';
    } else if (UI.pdTab === 'details') {
      var rows = (p.details || [['Width', (p.dims ? p.dims.width : '')], ['Depth', (p.dims ? p.dims.depth : '')], ['Height', (p.dims ? p.dims.height : '')], ['Max load/shelf', (p.dims ? p.dims.load : '')]]);
      body = '<div class="mtable" style="max-width:900px">' + rows.map(function (r, i) {
        return '<div class="row"' + (i ? ' style="border-top:1px solid var(--line)"' : '') + '><span>' + esc(r[0]) + '</span><b>' + esc(r[1]) + '</b></div>';
      }).join('') + '</div>';
    } else if (UI.pdTab === 'measurements') {
      var d = p.dims || { width: '47 1/4 "', depth: '16 1/2 "', height: '29 1/8 "', load: '44 lb' };
      body = '<div class="meas"><div class="ill"><img src="/assets/media-317.jpg" alt="Measurement drawing"></div>' +
        '<div class="mtable"><div class="h"><span>Measurements</span>' + I.chev + '</div>' +
        '<div class="grid2"><div class="cell"><span class="k">Width</span><span class="v">' + esc(d.width) + '</span></div>' +
        '<div class="cell"><span class="k">Depth</span><span class="v">' + esc(d.depth || '16 1/2 "') + '</span></div>' +
        '<div class="cell"><span class="k">Height</span><span class="v">' + esc(d.height) + '</span></div>' +
        '<div class="cell"><span class="k">Max load/shelf</span><span class="v">' + esc(d.load || '44 lb') + '</span></div></div>' +
        '<div class="h" style="border-top:1px solid var(--line);border-bottom:0"><span>Packaging</span>' + I.chev + '</div></div></div>';
    } else {
      var comps = p.components;
      if (!comps) {
        body = '<p>This product is sold as a single unit and does not contain separate components.</p>';
      } else {
        body = '<p style="margin-bottom:24px">This product is made up of more than one component. You can find the details of these components below.</p>' +
          '<div class="inc"><div class="list">' + comps.map(function (c) {
            return '<div class="compc" ' + (c.link ? 'data-act="nav" data-href="#/p/' + c.link + '" style="cursor:pointer"' : '') + '>' +
              '<div class="im"><img src="' + c.img + '"></div>' +
              '<div><div class="q">' + c.qty + ' x ' + esc(c.type) + '</div><div class="nm">' + esc(c.name) + '</div>' +
              (c.desc ? '<div class="ds">' + esc(c.desc) + '</div>' : '') + '<div class="art">' + esc(c.art) + '</div></div></div>';
          }).join('') + '</div>' +
          '<div class="hero2"><img src="' + p.image + '"></div></div>';
      }
    }
    return '<div class="pdtabs"><div class="wrap" style="padding:0"><div class="bar">' + bar + '</div><div class="panel">' + body + '</div></div></div>';
  }

  function renderReviewSummary(p) {
    return '<div class="revsec"><div class="wrap"><div class="revcard">' +
      '<div class="l">Customer reviews</div>' +
      '<div class="r"><div><div class="bignum">' + p.rating.toFixed(1) + '</div>' + stars(p.rating) +
        '<div style="color:#484848;font-size:13px">Average rating</div></div>' +
        '<div><div class="rev">' + p.review_count + '</div><div style="color:#484848;font-size:13px">Reviews</div></div>' +
        '<div style="flex:1;text-align:center"><button class="btn ghost" style="padding:14px 40px" data-act="open-reviews" data-id="' + p.id + '">Show all reviews</button></div>' +
      '</div></div></div></div>';
  }

  function renderAccessories(p) {
    return '<div class="access wrap"><div class="hd"><h2>Accessories for ' + esc(p.name) + '</h2>' +
      '<button class="btn black" data-act="nav" data-href="#/search?q=accessories">Show all accessories</button></div>' +
      '<div class="accgrid">' + ACCESSORIES.map(function (a) { return '<div class="it"><img src="' + a + '"></div>'; }).join('') + '</div></div>';
  }

  /* ============================================================ BAG */
  function bagTotals() {
    var prods = 0, savings = 0, asmb = 0;
    ST.bag.forEach(function (l) {
      var p = P(l.id); if (!p) return;
      prods += p.regular_price * l.qty;
      savings += (p.regular_price - p.member_price) * l.qty;
      if (l.assembly && p.assembly_per_unit) asmb += p.assembly_per_unit * l.qty;
    });
    return { prods: prods, savings: savings, asmb: asmb, total: prods + asmb };
  }

  function renderBag() {
    var t = bagTotals();
    var zip = ST.location.zip;
    var delivery = zip ?
      '<div class="dcards">' +
        '<div class="dcard"><div class="hd">' + I.truck + '<span>Delivery to ' + esc(zip) + '</span></div>' +
          '<div><span class="dot g" style="background:var(--green);display:inline-block;width:9px;height:9px;border-radius:50%"></span> Starting at $' + LOC.delivery_from.toFixed(2) + '</div>' +
          '<div class="g">or <span class="l">$' + LOC.family_delivery_from.toFixed(2) + ' with IKEA Family</span></div>' +
          '<div class="g">Arrives Oct 27</div></div>' +
        '<div class="dcard"><div class="hd">' + I.store + '<span>Pick up at IKEA ' + esc(ST.location.store || LOC.store) + '</span></div>' +
          '<div><span style="background:var(--green);display:inline-block;width:9px;height:9px;border-radius:50%"></span> $2.00 or <span class="l">Free with IKEA Family</span></div>' +
          '<div class="g">Get it tomorrow</div></div>' +
        '<div class="dcard"><div class="hd">' + I.layers + '<span>Collect at CRST/N…</span></div>' +
          '<div><span style="background:var(--green);display:inline-block;width:9px;height:9px;border-radius:50%"></span> $' + LOC.collect_near.toFixed(2) + '</div></div>' +
      '</div>' :
      '<div class="dcards" style="grid-template-columns:1fr"><div class="dcard"><div class="hd">' + I.truck + '<span>Enter your ZIP code to see delivery options</span></div>' +
        '<a class="l" data-act="open-location">Enter ZIP code</a></div></div>';

    var lines = ST.bag.length ? ST.bag.map(function (l, idx) { return bagLine(l, idx); }).join('') :
      '<div style="padding:50px 0"><p>Your shopping bag is empty.</p><p style="margin-top:16px"><a class="btn black" data-act="nav" data-href="#/search?q=besta">Start shopping</a></p></div>';

    var payIcons = PAY_ICONS.map(function (i) { return '<img src="' + i + '">'; }).join('');

    return '<div class="wrap"><div class="bagwrap">' +
      '<div><h1>Shopping bag</h1>' + delivery +
        '<div class="pickup">' + I.cart + '<div>Pick up yourself at ' + esc(ST.location.store || LOC.store) + '</div></div>' +
        lines + '</div>' +
      '<aside class="os"><div class="hd">Order summary</div><div class="bd">' +
        '<div class="row"><span>Products</span><span>' + money(t.prods) + '</span></div>' +
        (t.asmb ? '<div class="row"><span>Assembly service</span><span>' + money(t.asmb) + '</span></div>' : '') +
        '<div class="row" style="color:#767676"><span>Shipping costs are calculated at checkout</span></div>' +
        '<div class="tot"><span>Total excluding tax</span><span class="big">' + big(t.total) + '</span></div>' +
        '<div class="afterpay"><span class="am">$</span><div><b>Afterpay</b><div>4 interest-free payments of $' + Math.ceil(t.total / 4) + ' + tax. <a style="text-decoration:underline">Learn more</a></div></div></div>' +
        '<div style="margin-top:18px"><b>IKEA Visa Credit Card</b><div style="font-size:13px">Earn 5% in rewards at IKEA using the IKEA Visa Credit Card*. <a style="text-decoration:underline">Learn more</a></div></div>' +
        '<div class="fam"><img src="/assets/media-352.svg" style="width:40px" alt=""><div><b>Save $' + t.savings.toFixed(2) + ' with IKEA Family</b><div><a style="text-decoration:underline">Join for free or log in</a></div></div></div>' +
        '<div class="fam" style="background:#fff;gap:12px"><span style="width:24px;height:24px;border-radius:50%;background:var(--yellow);display:inline-flex;align-items:center;justify-content:center">' + I.family + '</span><div><b>Collect ' + Math.round(t.total) + ' points with IKEA Family</b><div><a style="text-decoration:underline">Explore what you can get</a></div></div></div>' +
        '<div class="disc' + (UI.discountOpen ? ' open' : '') + '"><div class="hd" data-act="toggle-discount"><span>+ &nbsp;Apply discount code</span>' + I.chev + '</div>' +
          '<div class="body"><div class="f"><input id="discInput" class="' + (UI.discountError ? 'err' : '') + '" placeholder="" value="' + esc(UI.discountCode) + '">' +
            '<button class="btn black" data-act="apply-discount">Apply</button></div>' +
            (UI.discountError ? '<div class="msg">' + I.info + 'Please enter a valid discount code.</div>' : '') +
            '<div class="hint">Enter the code without any space between letters. Gift cards can be exchanged later in the process.</div></div></div>' +
        '<button class="btn blue full" style="margin-top:24px;justify-content:space-between;padding:20px 24px" data-act="checkout">Continue to checkout <span style="width:34px;height:34px;border-radius:50%;background:#fff;display:flex;align-items:center;justify-content:center">' + I.chevR + '</span></button>' +
        '<div class="payrow">' + payIcons + '</div>' +
      '</div></aside>' +
    '</div>' +
    '<div class="essentials"><h2>Everyday essentials for you</h2>' + renderEssentials() + '</div>' +
    '</div>' + renderFooter();
  }

  function bagLine(l, idx) {
    var p = P(l.id); if (!p) return '';
    var lineTotal = p.regular_price * l.qty;
    var saved = (p.regular_price - p.member_price) * l.qty;
    var per = p.pack_size ? ('/' + p.pack_size + ' pack') : '';
    var comps = p.components ?
      '<a class="lnk" data-act="open-parts" data-id="' + p.id + '">Show included parts</a>' + '<br>' : '';
    var asmb = p.assembly_per_unit ?
      '<div class="asmb">' + I.task + '<div><a style="text-decoration:underline" data-act="noop">Assembly by Taskrabbit for ' + esc(p.name) + (l.qty > 1 ? ' (' + l.qty + ')' : '') + '</a>' +
      (p.id === '20293568' ? '<div class="mn">*Minimum fee for assembly service is $52.00. <a style="text-decoration:underline">Learn more</a></div>' : '') + '</div>' +
      '<span class="sp"></span><b>$' + (p.assembly_per_unit * l.qty).toFixed(2) + '</b>' +
      '<input type="checkbox" data-asmb="' + p.id + '"' + (l.assembly ? ' checked' : '') + '></div>' : '';

    return '<div class="line">' +
      '<div><div class="im"><img src="' + p.image + '"></div><div class="art">' + p.id.slice(0, 3) + '.' + p.id.slice(3, 6) + '.' + p.id.slice(6) + '</div></div>' +
      '<div><h3>' + esc(p.name) + '</h3><div class="ds">' + esc(p.description) + '</div>' +
        '<a class="sv" data-act="noop">' + pct(p) + '% off, save $' + saved.toFixed(2) + ' with IKEA Family</a>' +
        '<div class="unit">' + money(p.regular_price) + per + '/piece</div>' +
        comps +
        '<div class="avail"><div><span style="background:var(--green);display:inline-block;width:9px;height:9px;border-radius:50%"></span>Available for delivery</div>' +
        '<div><span style="background:var(--green);display:inline-block;width:9px;height:9px;border-radius:50%"></span>Available for Click &amp; collect</div>' +
        '<div><span style="background:var(--green);display:inline-block;width:9px;height:9px;border-radius:50%"></span>Available for Collect near you</div></div>' +
        '<div class="acts"><a style="text-decoration:underline" data-act="save-later" data-idx="' + idx + '">Save for later</a><span class="sp"></span>' +
          '<button data-act="remove-line" data-idx="' + idx + '" aria-label="Remove">' + I.trash + '</button>' +
          '<div class="stepper" style="height:46px"><button data-act="bag-minus" data-idx="' + idx + '"' + (l.qty <= 1 ? ' disabled' : '') + '>' + I.minus + '</button>' +
          '<span class="v">' + l.qty + '</span><button data-act="bag-plus" data-idx="' + idx + '">' + I.plus + '</button></div></div>' +
        asmb +
      '</div>' +
      '<div class="tot">' + money(lineTotal) + '</div></div>';
  }

  /* ============================================================ OVERLAYS */
  function renderOverlays() {
    var o = UI.overlay;
    if (!o) return '';
    if (o.type === 'location') return locationDrawer();
    if(o.type === 'store') return storeDrawer();
    if (o.type === 'media') return mediaModal(o);
    if (o.type === 'parts') return partsModal(o);
    if (o.type === 'added') return addedPanel(o);
    if (o.type === 'reviews') return reviewsModal(o);
    return '';
  }

  function closeIcon() { return '<button class="iconbtn" data-act="close-overlay" aria-label="Close">' + I.close + '</button>'; }
  function ovWrap(inner, center) {
    return '<div class="ov' + (center ? ' center' : '') + '" data-act="ov-bg">' + inner + '</div>';
  }
  var checkGreen = '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="#0a8a00" stroke-width="2.6"><path d="M5 12.5l4.5 4.5L19 7"/></svg>';

  /* ---------- ZIP / location drawer ---------- */
  function locationDrawer() {
    var cls = 'zipin' + (UI.zipOk ? ' ok' : (UI.zipErr ? ' err' : ''));
    var help = UI.zipErr
      ? '<div class="ziperr">' + I.info + ' ' + esc(UI.zipErr) + '</div>'
      : (UI.zipOk ? '<div class="ziphelp ok">' + checkGreen + ' e.g. 19428</div>' : '<div class="ziphelp">e.g. 19428</div>');
    return ovWrap('<aside class="drawer">' +
      '<div class="dh"><div></div>' + closeIcon() + '</div>' +
      '<div class="db">' +
        '<h2>Use your location</h2>' +
        '<p style="font-size:14px;margin-bottom:24px">Get updated information about product delivery and stock availability for your area.</p>' +
        '<div class="ziplbl"><span class="req">*</span> Enter a Zip code</div>' +
        '<input id="zipInput" class="' + cls + '" value="' + esc(UI.zipVal) + '" maxlength="5" autocomplete="off" inputmode="numeric">' +
        help +
        '<p style="font-size:14px;margin-top:32px;color:#333">We use cookies to provide this service. Read more about how we use cookies in ' +
        '<a style="text-decoration:underline">our policy</a> <span style="display:inline-block;width:13px;height:13px;border:1px solid #767676;vertical-align:-2px"></span>. ' +
        'Please note that your location won\u2019t be shared.</p>' +
      '</div>' +
      '<div class="df"><button class="btn black full" data-act="save-zip">Save</button></div>' +
      '</aside>');
  }

  /* ---------- store drawer ---------- */
  function storeDrawer() {
    var f = UI.storeFilter || '';
    var list = STORES.filter(function (s) {
      return !f || (s[0] + ' ' + s[1]).toLowerCase().indexOf(f.toLowerCase()) >= 0;
    });
    return ovWrap('<aside class="drawer wide">' +
      '<div class="dh"><div></div>' + closeIcon() + '</div>' +
      '<div class="db">' +
        '<h2>Select store</h2>' +
        '<p style="font-size:14px;margin-bottom:20px">Find your preferred store to learn about its opening hours, stock availability, and relevant offers.</p>' +
        '<div style="display:flex;align-items:center;gap:10px;background:#f5f5f5;border-radius:100px;height:48px;padding:0 16px">' + I.search +
          '<input id="storeSearch" placeholder="Search by location" value="' + esc(f) + '" style="border:0;outline:0;background:transparent;flex:1;font-size:15px">' +
        '</div>' +
        '<div class="storelist">' + list.map(function (s) {
          var on = ST.location.store === s[0];
          return '<button class="' + (on ? 'on' : '') + '" data-act="select-store" data-store="' + esc(s[0]) + '">' +
            '<div class="n">' + esc(s[0]) + '</div><div class="a">' + esc(s[1]) + '</div></button>';
        }).join('') + '</div>' +
      '</div></aside>');
  }

  /* ---------- media modal ---------- */
  function mediaModal(o) {
    var p = P(o.id);
    if (!p) return '';
    var gal = p.gallery || [p.image];
    var tabs = [['all', 'All media'], ['video', 'Video'], ['measurement', 'Measurement']];
    var body;
    if (UI.mediaTab === 'measurement') {
      body = '<div style="padding:0 30px"><img src="/assets/media-317.jpg" style="width:100%;background:#f5f5f5"></div>';
    } else if (UI.mediaTab === 'video') {
      var v = gal[1] || gal[0];
      body = '<div style="padding:0 30px"><div style="position:relative;background:#f5f5f5">' +
        '<img src="' + v + '" style="width:100%">' +
        '<span style="position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);width:58px;height:58px;border-radius:50%;background:rgba(0,0,0,.62);color:#fff;display:flex;align-items:center;justify-content:center;font-size:18px">\u25B6</span>' +
        '</div></div>';
    } else {
      body = '<div class="mgrid">' + gal.map(function (g) { return '<img src="' + g + '">'; }).join('') + '</div>';
    }
    return ovWrap('<div class="modal media">' +
      '<div class="mh">' + closeIcon() + '</div>' +
      '<div class="mb">' +
        '<div class="mtags">' + tabs.map(function (t) {
          return '<button class="' + (UI.mediaTab === t[0] ? 'on' : '') + '" data-act="media-tab" data-tab="' + t[0] + '">' + t[1] + '</button>';
        }).join('') + '</div>' + body +
      '</div></div>', true);
  }

  /* ---------- "What's included" parts modal ---------- */
  function partsModal(o) {
    var p = P(o.id);
    if (!p || !p.components) return '';
    var mult = o.qty || 1;
    var rows = p.components.map(function (c) {
      return '<div style="border-bottom:1px solid var(--line2);padding:18px 0">' +
        '<div style="font-weight:700;font-size:14px">' + esc(c.name) + '</div>' +
        '<div style="font-size:14px">' + esc(c.type) + (c.desc ? ', ' + esc(c.desc) : '') + '</div>' +
        '<div style="font-size:14px;color:#484848;margin-top:2px">Quantity: ' + (c.qty * mult) + '</div></div>';
    }).join('');
    return ovWrap('<aside class="drawer wide">' +
      '<div class="dh"><div></div>' + closeIcon() + '</div>' +
      '<div class="db">' +
        '<h2>' + esc(p.name) + '</h2>' +
        '<p style="font-size:15px;margin:8px 0 12px">This product is made up of ' + p.components.length + ' parts.</p>' +
        rows +
      '</div></aside>');
  }

  /* ---------- added-to-bag drawer ---------- */
  function addedPanel(o) {
    var p = P(o.id);
    if (!p) return '';
    var qty = o.qty || 1;
    var per = p.pack_size ? (', ' + p.pack_size + ' pack/pack') : '';
    var likes = (o.likes || []).map(function (id) { return P(id); }).filter(Boolean);
    var likeRows = likes.map(function (l) {
      var off = l.regular_price > l.member_price;
      return '<div class="like">' +
        '<img src="' + l.image + '">' +
        '<div>' + (off ? '<div class="fam">IKEA Family price</div>' : '') +
          '<div class="nm">' + esc(l.name) + '</div>' +
          '<div style="font-size:13px">' + esc(l.description) + (l.pack_size ? ', ' + l.pack_size + ' pack/pack' : '') + '</div>' +
          '<div class="pr">' + big(l.member_price) + '</div>' +
          (off ? '<div class="sv" style="color:var(--blue);font-weight:700;font-size:13px">' + pct(l) + '% off, save $' + saveAmt(l) + '</div>' +
            '<div style="font-size:12px;color:#484848">Regular price ' + money(l.regular_price) + '</div>' +
            '<div style="font-size:12px;color:#484848">Price valid Oct 7, 2026 - Nov 11, 2026 or while supply lasts</div>' : '') +
        '</div>' +
        '<div style="display:flex;flex-direction:column;gap:10px;align-items:center">' +
          '<button class="iconbtn" style="background:var(--blue);color:#fff;width:38px;height:38px" data-act="add-to-bag" data-id="' + l.id + '" data-qty="1" aria-label="Add to bag">' + I.cartW + '</button>' +
          '<button class="iconbtn" data-act="fav" aria-label="Save">' + I.heartOut + '</button>' +
        '</div></div>';
    }).join('');
    return ovWrap('<aside class="drawer wide added">' +
      '<div class="dh"><div></div>' + closeIcon() + '</div>' +
      '<div class="db">' +
        '<div class="item">' +
          '<img src="' + p.image + '">' +
          '<div><span class="ok" style="display:inline-flex;width:26px;height:26px;border-radius:50%;background:var(--green);color:#fff;align-items:center;justify-content:center;vertical-align:top">' + I.check + '</span>' +
            '<div style="display:inline-block;margin-left:12px;vertical-align:top">' +
              '<div style="font-weight:700">' + esc(p.name) + '</div>' +
              '<div style="font-size:14px">' + esc(p.description) + per + '</div></div></div>' +
          '<div style="font-weight:700">' + money(p.regular_price * qty) + '</div>' +
        '</div>' +
        '<p class="msg">' + qty + ' ' + esc(p.name) + ' were added to your shopping bag.</p>' +
        (likeRows ? '<div class="yl">You might also like</div>' + likeRows : '') +
        '<div class="ship">' + I.truck + '<span>Spend $15.00 more to enable delivery and other pick-up options. <a style="text-decoration:underline">Learn more</a></span></div>' +
      '</div>' +
      '<div class="df" style="display:flex;gap:12px">' +
        '<button class="btn ghost" style="flex:1" data-act="close-overlay">Continue shopping</button>' +
        '<button class="btn blue" style="flex:1" data-act="nav" data-href="#/bag">Go to shopping bag</button>' +
      '</div></aside>');
  }/* ---------- reviews modal ---------- */
  var REVIEW_SORTS = [['most_recent', 'Most recent'], ['oldest', 'Oldest'], ['highest', 'Highest rated'],
    ['lowest', 'Lowest rated'], ['most_helpful', 'Most helpful']];

  function reviewList() {
    var arr = REVIEWS.filter(function (r) { return !UI.reviewFilter || r.r === UI.reviewFilter; });
    var s = UI.reviewSort;
    if (s === 'oldest') arr.sort(function (a, b) { return new Date(a.d.replace(/\//g, '/')) - new Date(b.d.replace(/\//g, '/')); });
    else if (s === 'highest') arr.sort(function (a, b) { return b.r - a.r; });
    else if (s === 'lowest') arr.sort(function (a, b) { return a.r - b.r; });
    else if (s === 'most_helpful') arr.sort(function (a, b) { return b.h - a.h; });
    else arr.sort(function (a, b) { return new Date(b.d) - new Date(a.d); });
    return arr;
  }
  function starRow(r, size) {
    var s = '<span class="stars" style="font-size:' + (size || 14) + 'px">';
    for (var i = 1; i <= 5; i++) s += '<span class="' + (i <= Math.round(r) ? '' : 'off') + '">\u2605</span>';
    return s + '</span>';
  }

  function reviewsModal(o) {
    var p = P(o.id) || P('29612189');
    var hist = REVIEW_DIST.map(function (d) {
      var w = Math.round(d[1] / 54 * 100);
      if (w < 3) w = 3;
      return '<div class="rbar"><span>' + d[0] + ' \u2605</span><span class="track"><span class="fill" style="width:' + w + '%"></span></span><span>' + d[1] + '</span></div>';
    }).join('');
    var subs = REVIEW_SUB.map(function (s) {
      var dots = '';
      for (var i = 1; i <= 5; i++) dots += '<i class="' + (i <= Math.round(s[1]) ? '' : 'off') + '"></i>';
      return '<div class="subrow"><span>' + esc(s[0]) + '</span><span style="display:flex;gap:14px;align-items:center">' +
        '<span class="dots">' + dots + '</span><b>' + s[1].toFixed(1) + '</b></span></div>';
    }).join('');

    var filterMenu = UI.reviewFilterOpen ? '<div class="sortmenu" style="left:0;top:58px">' +
      '<label class="' + (!UI.reviewFilter ? 'on' : '') + '" data-act="review-filter-set" data-star="0"><span class="dot"></span><span>All ratings</span></label>' +
      [5, 4, 3, 2, 1].map(function (n) {
        return '<label class="' + (UI.reviewFilter === n ? 'on' : '') + '" data-act="review-filter-set" data-star="' + n + '"><span class="dot"></span><span>' + n + ' star' + (n > 1 ? 's' : '') + '</span></label>';
      }).join('') + '</div>' : '';
    var sortMenu = UI.reviewSortOpen ? '<div class="sortmenu">' +
      REVIEW_SORTS.map(function (s) {
        return '<label class="' + (UI.reviewSort === s[0] ? 'on' : '') + '" data-act="review-sort-set" data-sort="' + s[0] + '"><span class="dot"></span><span>' + s[1] + '</span></label>';
      }).join('') + '</div>' : '';

    var topics = '<div class="topics"><span class="t">Show all</span>' + REVIEW_TOPICS.map(function (t) {
      return '<span class="t alt">' + esc(t) + '</span>';
    }).join('') + '</div>';

    var summary = UI.reviewSummary ?
      '<div class="summary"><h4>Reviews summary ' + I.layers +
      '<span style="flex:1"></span><a style="font-size:13px;font-weight:400;text-decoration:underline" data-act="toggle-summary">Hide summary</a></h4>' +
      '<p>' + esc(REVIEW_SUMMARY) + '</p>' +
      '<p style="font-size:12px;color:#767676;margin-top:10px">AI-generated summary of actual customer reviews.</p>' +
      '<div class="sf"><span>Helpful?</span><a>\uD83D\uDC4D</a><a>\uD83D\uDC4E</a></div></div>' : '';

    var list = reviewList().map(function (r) {
      return '<div class="review"><div class="hd">' + starRow(r.r) +
        '<span style="font-size:13px;color:#484848">' + esc(r.d) + '</span></div>' +
        '<h4>' + esc(r.t) + '</h4><p>' + esc(r.b) + '</p>' +
        '<div class="ft"><span class="who">' + esc(r.a) + '</span><span style="flex:1"></span>' +
        '<a style="text-decoration:underline;font-weight:700" data-act="report">Report</a>' +
        '<button class="rep" data-act="helpful">Helpful? (' + r.h + ')</button></div>' +
        (r.resp ? '<div class="resp"><b>Response from IKEA:</b> ' + esc(r.rd) +
          '<div style="margin-top:6px">' + esc(r.resp) + '</div></div>' : '') +
        '</div>';
    }).join('');

    var formPanel = '';
    if (UI.reviewForm === 'open' || UI.reviewForm === 'done') {
      formPanel = '<div class="summary" style="background:#fff;border:1px solid var(--line2)">' +
        '<h4>Write a review</h4>' +
        (UI.reviewForm === 'done' ? '<p style="color:var(--green);font-weight:700;margin-bottom:10px">Thank you! Your review has been submitted.</p>' : '') +
        '<div style="display:flex;gap:16px;margin-bottom:10px"><span style="font-size:13px;font-weight:700">Your rating</span>' +
        '<span style="display:flex;gap:6px">' + [1, 2, 3, 4, 5].map(function (n) {
          return '<button data-act="form-star" data-star="' + n + '" class="' + (UI.reviewFormStar >= n ? '' : 'off') + '" style="color:' + (UI.reviewFormStar >= n ? '#111' : '#ccc') + ';font-size:20px">\u2605</button>';
        }).join('') + '</span></div>' +
        '<div style="display:flex;flex-direction:column;gap:10px;max-width:640px">' +
        '<input id="rvTitle" placeholder="Title of your review" value="' + esc(UI.reviewFormTitle || '') + '" style="height:44px;border:1px solid var(--line);border-radius:4px;padding:0 12px;font-size:14px;outline:0">' +
        '<textarea id="rvBody" rows="4" placeholder="Tell us what you think" style="border:1px solid var(--line);border-radius:4px;padding:10px 12px;font-size:14px;outline:0;font-family:inherit">' + esc(UI.reviewFormBody || '') + '</textarea>' +
        '<input id="rvName" placeholder="Your name" value="' + esc(UI.reviewFormName || '') + '" style="height:44px;border:1px solid var(--line);border-radius:4px;padding:0 12px;font-size:14px;outline:0">' +
        '<div style="display:flex;gap:12px"><button class="btn blue" data-act="submit-review">Submit review</button>' +
        '<button class="btn ghost" data-act="close-review-form">Cancel</button></div></div></div>';
    }

    return ovWrap('<div class="modal" style="max-width:1160px;width:calc(100% - 60px);height:88vh;position:relative">' +
      '<div class="mh" style="position:absolute;right:6px;top:6px;z-index:4">' + closeIcon() + '</div>' +
      '<div class="mb" style="padding:0;flex:1;overflow:hidden;display:flex">' +
        '<div class="reviewswrap" style="flex:1;height:100%">' +
          '<div class="rl" style="overflow:auto;height:100%">' +
            '<div class="avg">' + p.rating.toFixed(1) + '</div>' +
            '<span class="stars" style="text-align:center;font-size:22px;display:block">' +
              [1, 2, 3, 4, 5].map(function (i) { return '<span class="' + (i <= Math.round(p.rating) ? '' : 'off') + '">\u2605</span>'; }).join('') + '</span>' +
            '<div class="based">Based on ' + p.review_count + ' reviews</div>' +
            hist + subs +
            '<button class="btn ghost full" style="margin-top:24px" data-act="write-review">Write a review</button>' +
          '</div>' +
          '<div class="rr">' +
            '<h2>Customer reviews</h2>' +
            '<div class="rrf">' +
              '<button class="b' + (UI.reviewFilterOpen ? ' on' : '') + '" data-act="review-filter">' + I.filter + ' Filter</button>' +
              '<button class="b' + (UI.reviewSortOpen ? ' on' : '') + '" data-act="review-sort">' + I.sorti + ' Sort by</button>' +
              filterMenu + sortMenu +
            '</div>' +
            '<div class="tabs2">' +
              '<button class="' + (UI.reviewCountry === 'us' ? 'on' : '') + '" data-act="review-country" data-c="us">United States</button>' +
              '<button class="' + (UI.reviewCountry === 'other' ? 'on' : '') + '" data-act="review-country" data-c="other">Other countries</button>' +
            '</div>' +
            formPanel + summary + topics +
            (UI.reviewCountry === 'other'
              ? '<p style="padding:30px 0">Reviews from other countries are not available in this recording.</p>'
              : list) +
          '</div>' +
        '</div>' +
      '</div></div>', true);
  }

  /* ---------- toast ---------- */
  function toast(msg, undoLabel, undoFn) {
    var el = document.createElement('div');
    el.className = 'toast';
    el.innerHTML = '<span class="txt">' + msg + '</span>' +
      (undoLabel ? '<button class="undo">' + undoLabel + '</button>' : '') +
      '<button class="x" aria-label="Close">' + I.close + '</button>';
    toastWrap.appendChild(el);
    var timer = setTimeout(function () { if (el.parentNode) el.parentNode.removeChild(el); }, 7000);
    if (undoLabel && undoFn) {
      el.querySelector('.undo').addEventListener('click', function () {
        clearTimeout(timer);
        undoFn();
        if (el.parentNode) el.parentNode.removeChild(el);
      });
    }
    el.querySelector('.x').addEventListener('click', function () {
      clearTimeout(timer);
      if (el.parentNode) el.parentNode.removeChild(el);
    });
  }

  /* ============================================================ RENDER */
  function render() {
    var route = UI.route;
    var html = renderTop() + renderHeader(route);
    if (UI.meganav && route.name === 'home') html += renderMeganav();
    if (route.name === 'home') html += renderHome();
    else if (route.name === 'search') html += renderSearch(route);
    else if (route.name === 'compare') html += renderCompare();
    else if (route.name === 'bag') html += renderBag();
    else if (route.name === 'product') html += renderProduct(route.id);
    if (!ST.cookieHidden) html += renderCookie();
    app.innerHTML = html;
    app.className = UI.meganav ? 'mnav-open' : '';
    modals.innerHTML = renderOverlays();
    updateSug();
  }

  function updateSug() {
    var inp = document.getElementById('searchInput');
    var box = document.getElementById('sugBox');
    if (!inp || !box) return;
    var norm = (inp.value || '').trim().toLowerCase();
    if (!norm || !UI.searchOpen) { box.classList.remove('on'); return; }
    var matches = SUGGESTIONS.filter(function (s) {
      return s.toLowerCase().indexOf(norm) >= 0 && s.toLowerCase() !== norm;
    }).slice(0, 7);
    var rows = '<a data-act="do-search-now"><span>' + I.search + '</span><span>' + esc(inp.value) + '</span></a>';
    rows += matches.map(function (s) {
      return '<a data-act="sug" data-q="' + esc(s) + '"><span>' + I.search + '</span><span>' + esc(s) + '</span></a>';
    }).join('');
    box.innerHTML = rows;
    box.classList.add('on');
  }/* ============================================================ ACTIONS */
  function navigate(href) {
    UI.overlay = null;
    UI.searchOpen = false;
    if (location.hash === href) { UI.route = parseHash(); render(); window.scrollTo(0, 0); }
    else location.hash = href;
  }

  function findLine(id) {
    for (var i = 0; i < ST.bag.length; i++) if (ST.bag[i].id === id) return ST.bag[i];
    return null;
  }

  function addToBag(id, qty) {
    qty = qty || 1;
    var l = findLine(id);
    if (l) l.qty += qty; else ST.bag.push({ id: id, qty: qty, assembly: false });
    persist();
    var likes;
    if (id === '20293568' || id === '60293566') likes = ['80261258', '00291848'];
    else if (id === '29612189' || id === '29209829' || id === '89209829') likes = ['09590409', '20293568'];
    else likes = ['00295554', '80261258'];
    UI.overlay = { type: 'added', id: id, qty: qty, likes: likes };
    render();
  }

  function removeLine(idx, save) {
    var l = ST.bag[idx];
    if (!l) return;
    var nm = P(l.id) ? P(l.id).name : 'Item';
    ST.bag.splice(idx, 1);
    persist();
    render();
    toast(nm + (save ? ' was saved for later.' : ' was removed from your shopping bag.'), 'Undo', function () {
      ST.bag.splice(idx, 0, l);
      persist();
      render();
    });
  }

  function changeQty(idx, delta) {
    var l = ST.bag[idx];
    if (!l) return;
    var n = l.qty + delta;
    if (n < 1) return;
    l.qty = n;
    persist();
    render();
  }

  function applyDiscount() {
    var code = (UI.discountCode || '').trim();
    if (!code) { UI.discountError = true; render(); refocus('discInput'); return; }
    UI.discountError = true;
    render();
    refocus('discInput');
  }

  function refocus(id) {
    var el = document.getElementById(id);
    if (el) { el.focus(); if (el.setSelectionRange && el.value) el.setSelectionRange(el.value.length, el.value.length); }
  }

  function saveZip() {
    var v = (UI.zipVal || '').trim();
    if (/^[0-9]{5}$/.test(v)) {
      ST.location.zip = v;
      ST.location.store = (v === LOC.valid_postcode) ? LOC.store : (ST.location.store || LOC.store);
      persist();
      UI.zipOk = true; UI.zipErr = '';
      UI.overlay = null;
      render();
      toast('Delivery and stock availability updated for ' + v + '.');
    } else {
      UI.zipErr = 'Please enter a valid Zip code.';
      UI.zipOk = false;
      render();
      refocus('zipInput');
    }
  }

  /* ============================================================ CLICK */
  document.addEventListener('click', function (e) {
    var el = e.target.closest ? e.target.closest('[data-act]') : null;
    if (!el) {
      if (!(e.target.closest && e.target.closest('.search'))) {
        UI.searchOpen = false;
        var sb = document.getElementById('sugBox');
        if (sb) sb.classList.remove('on');
      }
      return;
    }
    if (el.classList.contains('ov')) { if (e.target === el) closeOverlay(); return; }
    var act = el.getAttribute('data-act');
    var id = el.getAttribute('data-id');

    if (act === 'nav') { navigate(el.getAttribute('data-href')); return; }
    if (act === 'noop' || act === 'helpful' || act === 'report' || act === 'login' || act === 'favourites') return;
    if (act === 'close-overlay') { closeOverlay(); return; }

    if (act === 'toggle-meganav') { UI.meganav = !UI.meganav; UI.meganavTab = 'new'; render(); return; }
    if (act === 'pill') {
      var tab = el.getAttribute('data-tab');
      UI.meganav = true; UI.meganavTab = tab; render();
      window.scrollTo({ top: 0, behavior: 'smooth' });
      return;
    }
    if (act === 'meganav-tab') { UI.meganavTab = el.getAttribute('data-tab'); render(); return; }

    if (act === 'do-search' || act === 'do-search-now') {
      var inp = document.getElementById('searchInput');
      var q = inp && inp.value.trim() ? inp.value.trim() : 'besta';
      UI.searchOpen = false;
      navigate('#/search?q=' + encodeURIComponent(q));
      return;
    }
    if (act === 'sug') { UI.searchOpen = false; navigate('#/search?q=' + encodeURIComponent(el.getAttribute('data-q'))); return; }
    if (act === 'clear-search') {
      var i2 = document.getElementById('searchInput');
      if (i2) { i2.value = ''; i2.focus(); }
      UI.searchVal = ''; UI.searchOpen = false; updateSug();
      var f = el.closest('.search'); if (f) f.classList.remove('filled');
      return;
    }

    if (act === 'acc') {
      var k = el.getAttribute('data-acc');
      UI.accordions[k] = !UI.accordions[k];
      render();
      return;
    }
    if (act === 'set-sort') { UI.sort = el.getAttribute('data-sort'); UI.accordions.sort = false; render(); return; }
    if (act === 'set-color') {
      var c = el.getAttribute('data-color');
      UI.filters.color = (UI.filters.color === c) ? null : c;
      render();
      return;
    }
    if (act === 'clear-color') { UI.filters.color = null; render(); return; }

    if (act === 'compare-close') { ST.compare = []; persist(); render(); return; }
    if (act === 'go-compare') {
      if (ST.compare.length >= 2) navigate('#/compare');
      else toast('Select at least 2 products to compare.');
      return;
    }
    if (act === 'remove-compare') {
      var ci = ST.compare.indexOf(id);
      if (ci >= 0) ST.compare.splice(ci, 1);
      persist(); render();
      return;
    }

    if (act === 'thumb') { UI.mainImg[id] = el.getAttribute('data-img'); render(); return; }
    if (act === 'swatch') {
      var vid = el.getAttribute('data-vid');
      if (vid) { navigate('#/p/' + vid); return; }
      UI.mainImg[id] = el.getAttribute('data-img');
      render();
      return;
    }
    if (act === 'pd-tab') { UI.pdTab = el.getAttribute('data-tab'); render(); return; }
    if (act === 'pdp-plus') { UI.qty[id] = (UI.qty[id] || 1) + 1; render(); return; }
    if (act === 'pdp-minus') { UI.qty[id] = Math.max(1, (UI.qty[id] || 1) - 1); render(); return; }
    if (act === 'add-to-bag') { addToBag(id, parseInt(el.getAttribute('data-qty') || '1', 10) || 1); return; }
    if (act === 'fav') { toast('Saved to your favourites.'); return; }

    if (act === 'open-media') { UI.overlay = { type: 'media', id: id }; UI.mediaTab = 'all'; render(); return; }
    if (act === 'media-tab') { UI.mediaTab = el.getAttribute('data-tab'); render(); return; }
    if (act === 'open-3d') { toast('The 3D planner is not part of this local replica.'); return; }
    if (act === 'open-parts') {
      var ln = findLine(id);
      UI.overlay = { type: 'parts', id: id, qty: ln ? ln.qty : 1 };
      render();
      return;
    }

    if (act === 'save-later') { removeLine(parseInt(el.getAttribute('data-idx'), 10), true); return; }
    if (act === 'remove-line') { removeLine(parseInt(el.getAttribute('data-idx'), 10), false); return; }
    if (act === 'bag-plus') { changeQty(parseInt(el.getAttribute('data-idx'), 10), 1); return; }
    if (act === 'bag-minus') { changeQty(parseInt(el.getAttribute('data-idx'), 10), -1); return; }

    if (act === 'toggle-discount') {
      UI.discountOpen = !UI.discountOpen;
      render();
      if (UI.discountOpen) refocus('discInput');
      return;
    }
    if (act === 'apply-discount') { applyDiscount(); return; }
    if (act === 'checkout') { toast('Checkout is not part of this local replica.'); return; }

    if (act === 'open-location') {
      UI.overlay = { type: 'location' };
      UI.zipVal = ST.location.zip || '';
      UI.zipOk = /^[0-9]{5}$/.test(UI.zipVal);
      UI.zipErr = '';
      render();
      refocus('zipInput');
      return;
    }
    if (act === 'save-zip') { saveZip(); return; }
    if (act === 'open-store') { UI.overlay = { type: 'store' }; UI.storeFilter = ''; render(); return; }
    if (act === 'select-store') {
      var s = el.getAttribute('data-store');
      ST.location.store = s;
      ST.location.zip = ST.location.zip || LOC.valid_postcode;
      persist();
      UI.overlay = null;
      render();
      return;
    }

    if (act === 'open-reviews') { UI.overlay = { type: 'reviews', id: id }; render(); return; }
    if (act === 'review-filter') { UI.reviewFilterOpen = !UI.reviewFilterOpen; UI.reviewSortOpen = false; render(); return; }
    if (act === 'review-sort') { UI.reviewSortOpen = !UI.reviewSortOpen; UI.reviewFilterOpen = false; render(); return; }
    if (act === 'review-filter-set') {
      var st = parseInt(el.getAttribute('data-star'), 10);
      UI.reviewFilter = st ? st : null;
      UI.reviewFilterOpen = false;
      render();
      return;
    }
    if (act === 'review-sort-set') {
      UI.reviewSort = el.getAttribute('data-sort');
      UI.reviewSortOpen = false;
      render();
      return;
    }
    if (act === 'review-country') { UI.reviewCountry = el.getAttribute('data-c'); render(); return; }
    if (act === 'toggle-summary') { UI.reviewSummary = !UI.reviewSummary; render(); return; }
    if (act === 'write-review') { UI.reviewForm = 'open'; uiReviewCapture(); render(); return; }
    if (act === 'form-star') { uiReviewCapture(); UI.reviewFormStar = parseInt(el.getAttribute('data-star'), 10); render(); return; }
    if (act === 'close-review-form') { UI.reviewForm = null; render(); return; }
    if (act === 'submit-review') {
      uiReviewCapture();
      if (!UI.reviewFormStar || !(UI.reviewFormTitle || '').trim() || !(UI.reviewFormBody || '').trim()) {
        toast('Please add a rating, a title and your review text.');
        render();
        return;
      }
      UI.reviewForm = 'done';
      UI.reviewFormStar = 0; UI.reviewFormTitle = ''; UI.reviewFormBody = ''; UI.reviewFormName = '';
      render();
      toast('Thank you! Your review has been submitted.');
      return;
    }

    if (act === 'cookie-ok') { ST.cookieHidden = true; persist(); render(); return; }
    if (act === 'cookie-priv') { ST.cookieHidden = true; persist(); render(); toast('Your privacy choices were saved.'); return; }
  });

  function uiReviewCapture() {
    var t = document.getElementById('rvTitle');
    var b = document.getElementById('rvBody');
    var n = document.getElementById('rvName');
    if (t) UI.reviewFormTitle = t.value;
    if (b) UI.reviewFormBody = b.value;
    if (n) UI.reviewFormName = n.value;
  }/* ============================================================ INPUT */
  document.addEventListener('input', function (e) {
    var t = e.target;
    if (!t || !t.id) return;

    if (t.id === 'searchInput') {
      UI.searchVal = t.value;
      UI.searchOpen = true;
      var f = t.closest('.search');
      if (f) { if (t.value) f.classList.add('filled'); else f.classList.remove('filled'); }
      updateSug();
      return;
    }

    if (t.id === 'zipInput') {
      UI.zipVal = t.value;
      var ok = /^[0-9]{5}$/.test(t.value.trim());
      UI.zipOk = ok;
      if (ok) { UI.zipErr = ''; t.classList.add('ok'); t.classList.remove('err'); }
      else { t.classList.remove('ok'); t.classList.remove('err'); }
      var help = t.parentNode.querySelector('.ziphelp') || t.parentNode.querySelector('.ziperr');
      if (help) {
        if (ok) {
          help.className = 'ziphelp ok';
          help.innerHTML = '<span style="display:inline-flex;vertical-align:-3px">' + checkGreen + '</span> e.g. 19428';
        } else if (help.className.indexOf('ziperr') === 0) {
          help.className = 'ziphelp';
          help.innerHTML = 'e.g. 19428';
        }
      }
      var saveBtn = document.querySelector('[data-act="save-zip"]');
      if (saveBtn) saveBtn.className = 'btn full ' + (ok ? 'black' : 'gray');
      return;
    }

    if (t.id === 'storeSearch') {
      UI.storeFilter = t.value;
      render();
      var si = document.getElementById('storeSearch');
      if (si) { si.focus(); if (si.setSelectionRange) si.setSelectionRange(si.value.length, si.value.length); }
      return;
    }

    if (t.id === 'discInput') {
      UI.discountCode = t.value;
      if (t.classList.contains('err')) { t.classList.remove('err'); UI.discountError = false; }
      return;
    }
  });

  document.addEventListener('focusin', function (e) {
    var t = e.target;
    if (t && t.id === 'searchInput') { UI.searchOpen = true; updateSug(); }
  });

  document.addEventListener('change', function (e) {
    var t = e.target;
    if (!t || !t.getAttribute) return;

    var cid = t.getAttribute('data-cmp');
    if (cid) {
      var i = ST.compare.indexOf(cid);
      if (t.checked) {
        if (i < 0) {
          if (ST.compare.length >= 5) { t.checked = false; toast('You can compare up to 5 products.'); return; }
          ST.compare.push(cid);
        }
      } else if (i >= 0) {
        ST.compare.splice(i, 1);
      }
      persist();
      render();
      return;
    }

    var aid = t.getAttribute('data-asmb');
    if (aid) {
      var l = findLine(aid);
      if (l) { l.assembly = !!t.checked; persist(); render(); }
      return;
    }
  });

  document.addEventListener('submit', function (e) {
    if (e.target && e.target.id === 'searchForm') {
      e.preventDefault();
      var inp = document.getElementById('searchInput');
      var q = inp && inp.value.trim() ? inp.value.trim() : 'besta';
      UI.searchOpen = false;
      navigate('#/search?q=' + encodeURIComponent(q));
    }
  });

  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape' || e.keyCode === 27) {
      if (UI.overlay) { UI.overlay = null; render(); return; }
      if (UI.meganav) { UI.meganav = false; render(); return; }
      return;
    }
    if (e.key === 'Enter' || e.keyCode === 13) {
      var t = e.target;
      if (!t) return;
      if (t.id === 'zipInput') { e.preventDefault(); saveZip(); return; }
      if (t.id === 'discInput') { e.preventDefault(); applyDiscount(); return; }
      if (t.id === 'storeSearch') { e.preventDefault(); render(); return; }
    }
  });

  /* ============================================================ BOOT */
  window.addEventListener('hashchange', function () {
    UI.route = parseHash();
    UI.overlay = null;
    UI.searchOpen = false;
    UI.storeFilter = '';
    UI.reviewSortOpen = false;
    UI.reviewFilterOpen = false;
    UI.zipErr = '';
    render();
    window.scrollTo(0, 0);
  });

  UI.route = parseHash();
  render();

})();