# IKEA BESTÅ shopping journey — local replica

A single-page, dependency-free replica of the IKEA BESTÅ shopping flow shown in the
reference recording (homepage layered navigation, search + suggestions, filters and
sorting, product comparison, combination product detail, media/measurement/part
overlays, standalone component detail, colour variants, ZIP + store selection,
shopping bag, reviews).

## Run

Any static file server that serves the project root (the folder containing
`index.html`), e.g.:

```
npx serve .        # or:  python3 -m http.server 8080
```

Then open `http://localhost:8080/`.
All asset references use absolute paths (`/assets/...`, `/app.js`, `/styles.css`), so
deep links such as `http://localhost:8080/#/p/29612189` work on a refresh.

`package.json`, `server.mjs` and `assets/` are read-only inputs and are not modified.

## Files

| file | purpose |
|---|---|
| `index.html` | app shell |
| `styles.css` | all styling (IKEA-like visual system, drawers, modals, grids) |
| `data.js` | local catalog slice, comparables, meganav, reviews, stores, essentials |
| `app.js` | routing, state, rendering, interactions, persistence |

## Routes

* `#/` homepage + layered navigation (Products / category pills)
* `#/search?q=besta` result list, colour filter, sorting, compare selection
* `#/compare` product comparison table
* `#/p/29209829` combination detail (also `29612189`, `20293568`, `70245848`, …)
* `#/bag` shopping bag

## Implemented behaviours

* Layered navigation tabs (New & trending, Storage & organization, …) pushing the hero down.
* Search suggestions while typing; Enter or the magnifier opens the results route.
* 165 → 87 item counts with the white colour filter; dismissible filter chip; sort
  accordion incl. *Price: low to high*; Smart home count changes 5 → 3 with the filter.
* Compare: checkboxes, sticky compare bar (n/5 selected, thumbnails), comparison page
  with removable columns and a Key features table for 60245844 / 00245842 / 70245848.
* Combination detail: gallery + thumbnails, All media modal (All media / Video /
  Measurement), Overview / Product details / Measurements / What's included tabs,
  component list with article numbers and a link to the standalone STUBBARP SKU.
* Colour swatches switch between the oak combination (29209829) and the walnut
  combination (29612189); undemoed swatches act as visual placeholders.
* ZIP drawer: invalid codes cannot be saved; `95054` validates and reveals the
  East Palo Alto, CA store, store stock, Click & collect and home delivery blocks.
* Store drawer with the recorded store list.
* Bag: regular (non-Family) pricing, separate Family savings hint, quantity changes
  update line totals, totals, component quantities (qty × included parts) and the
  assembly fee; delete + Undo; invalid discount codes are rejected without changing
  amounts; combination legs and standalone legs are independent SKUs.
* Reviews modal: rating histogram, sub-ratings, topics, sorting by most recent /
  oldest / highest / lowest / most helpful, and a write-a-review form with feedback.
* Bag, location, comparison and cookie state survive a refresh via `localStorage`.
