/* Local recorded data slice for the IKEA BESTÅ demonstration.
   Values are a fixed snapshot from the recording; no live IKEA data is used. */
var LOC = {
  valid_postcode: '95054',
  store: 'East Palo Alto, CA',
  store_addr: '1700 E Bayshore Rd, East Palo Alto',
  in_stock: true,
  delivery_from: 39,
  family_delivery_from: 29,
  click_collect: 2,
  family_click_collect: 0,
  collect_near: 14
};

var SEARCH_SNAPSHOT = { total_results: 165, content_results: 68, white_results: 87 };

var COMPARABLES = [
  { id: '60245844', width: '47 1/4 "', height: '15 "',      depth: '15 3/4 "', regular_price: 65, member_price: 55 },
  { id: '00245842', width: '23 5/8 "', height: '75 5/8 "',  depth: '15 3/4 "', regular_price: 90, member_price: 76 },
  { id: '70245848', width: '23 5/8 "', height: '15 "',      depth: '15 3/4 "', regular_price: 45, member_price: 38 }
];

/* Component lists of the two recorded storage combinations.
   ``art`` is the article number printed on the packaging label. */
var COMPONENTS_OAK = [
  { qty: 1, type: 'Frame',                        name: 'BESTÅ',    desc: '47 1/4x15 3/4x25 1/4 "', art: '902.473.75', img: '/assets/media-136.jpg' },
  { qty: 4, type: 'Shelf',                        name: 'BESTÅ',    desc: '22x14 1/8 "',            art: '002.955.49', img: '/assets/media-197.jpg' },
  { qty: 2, type: 'Leg',                          name: 'STUBBARP', desc: '',                       art: '202.935.68', img: '/assets/media-188.jpg', link: '20293568' },
  { qty: 1, type: 'Support leg',                  name: 'BESTÅ',    desc: '3 7/8 "',               art: '502.936.04', img: '/assets/media-340.jpg' },
  { qty: 2, type: 'Soft closing/push-open hinge', name: 'BESTÅ',    desc: '',                       art: '802.612.58', img: '/assets/media-190.jpg' },
  { qty: 2, type: 'Door',                         name: 'LAPPVIKEN',desc: '23 5/8x25 1/4 "',        art: '702.612.30', img: '/assets/media-373.jpg' }
];

var COMPONENTS_WALNUT = [
  { qty: 1, type: 'Frame',                        name: 'BESTÅ',    desc: '47 1/4x15 3/4x25 1/4 "', art: '902.473.75', img: '/assets/media-138.jpg' },
  { qty: 4, type: 'Shelf',                        name: 'BESTÅ',    desc: '22x14 1/8 "',            art: '002.955.49', img: '/assets/media-199.jpg' },
  { qty: 2, type: 'Leg',                          name: 'STUBBARP', desc: '',                       art: '202.935.68', img: '/assets/media-185.jpg', link: '20293568' },
  { qty: 1, type: 'Support leg',                  name: 'BESTÅ',    desc: '3 7/8 "',               art: '502.936.04', img: '/assets/media-340.jpg' },
  { qty: 2, type: 'Soft closing/push-open hinge', name: 'BESTÅ',    desc: '',                       art: '802.612.58', img: '/assets/media-190.jpg' },
  { qty: 2, type: 'Door',                         name: 'LAPPVIKEN',desc: '23 5/8x25 1/4 "',        art: '702.612.30', img: '/assets/media-373.jpg' }
];

var CRUMB_COMBO = ['Products', 'Storage & organization', 'Storage solution systems', 'BESTÅ storage system', 'BESTÅ sideboards', 'BESTÅ Storage combination with doors'];
var CRUMB_LEG   = ['Products', 'Storage & organization', 'Storage solution systems', 'BESTÅ storage system', 'BESTÅ all parts & accessories', 'BESTÅ legs', 'STUBBARP Leg'];
var CRUMB_GEN   = ['Products', 'Storage & organization', 'Storage solution systems', 'BESTÅ storage system'];

var PRODUCTS = [
  { id: '60245844', name: 'BESTÅ', description: 'Frame, white, 47 1/4x15 3/4x15 "', color: 'white',
    member_price: 55, regular_price: 65, image: '/assets/media-136.jpg', rating: 4.2, review_count: 1550,
    gallery: ['/assets/media-136.jpg', '/assets/media-137.jpg', '/assets/media-178.jpg', '/assets/media-272.jpg'],
    crumb: CRUMB_GEN, dims: { width: '47 1/4 "', depth: '15 3/4 "', height: '15 "', load: '44 lb' } },

  { id: '00245842', name: 'BESTÅ', description: 'Frame, white, 23 5/8x15 3/4x75 5/8 "', color: 'white',
    member_price: 76, regular_price: 90, image: '/assets/media-140.jpg', rating: 4.1, review_count: 4773,
    gallery: ['/assets/media-140.jpg', '/assets/media-141.jpg', '/assets/media-144.jpg', '/assets/media-193.jpg'],
    crumb: CRUMB_GEN, dims: { width: '23 5/8 "', depth: '15 3/4 "', height: '75 5/8 "', load: '44 lb' } },

  { id: '70245848', name: 'BESTÅ', description: 'Frame, white, 23 5/8x15 3/4x15 "', color: 'white',
    member_price: 38, regular_price: 45, image: '/assets/media-142.jpg', rating: 4.0, review_count: 4773,
    gallery: ['/assets/media-142.jpg', '/assets/media-143.jpg', '/assets/media-178.jpg'],
    crumb: CRUMB_GEN, dims: { width: '23 5/8 "', depth: '15 3/4 "', height: '15 "', load: '44 lb' } },

  { id: '29209829', name: 'BESTÅ',
    description: 'Storage combination with doors, white stained oak effect/Lappviken/Stubbarp white stained oak effect, 47 1/4x16 1/2x29 1/8 "',
    color: 'white stained oak effect/Lappviken/Stubbarp white stained oak effect',
    member_price: 197, regular_price: 240, image: '/assets/media-039.jpg', rating: 3.7, review_count: 123,
    assembly_per_unit: 58.5, components: COMPONENTS_OAK, crumb: CRUMB_COMBO, combo: true,
    gallery: ['/assets/media-039.jpg', '/assets/media-312.jpg', '/assets/media-040.jpg', '/assets/media-313.jpg',
              '/assets/media-314.jpg', '/assets/media-315.jpg', '/assets/media-316.jpg', '/assets/media-317.jpg'],
    dims: { width: '47 1/4 "', depth: '16 1/2 "', height: '29 1/8 "', load: '44 lb' },
    details: [['Width', '47 1/4 "'], ['Depth', '16 1/2 "'], ['Height', '29 1/8 "'], ['Max load/shelf', '44 lb'], ['Material', 'Particleboard, Paper foil, Plastic edging']] },

  { id: '29612189', name: 'BESTÅ',
    description: 'Storage combination with doors, black-brown Lappviken/Stubbarp/brown walnut effect, 47 1/4x16 1/2x29 1/8 "',
    color: 'black-brown Lappviken/Stubbarp/brown walnut effect',
    member_price: 197, regular_price: 240, image: '/assets/media-042.jpg', rating: 3.7, review_count: 123,
    assembly_per_unit: 58.5, components: COMPONENTS_WALNUT, crumb: CRUMB_COMBO, combo: true,
    gallery: ['/assets/media-042.jpg', '/assets/media-348.jpg', '/assets/media-349.jpg', '/assets/media-350.jpg', '/assets/media-039.jpg'],
    dims: { width: '47 1/4 "', depth: '16 1/2 "', height: '29 1/8 "', load: '44 lb' },
    details: [['Width', '47 1/4 "'], ['Depth', '16 1/2 "'], ['Height', '29 1/8 "'], ['Max load/shelf', '44 lb'], ['Material', 'Particleboard, Paper foil, Plastic edging']] },

  { id: '89209829', name: 'BESTÅ',
    description: 'Storage combination with doors, white/Lappviken/Stubbarp white, 47 1/4x16 1/2x29 1/8 "',
    color: 'white/Lappviken/Stubbarp white', badge: 'Best seller',
    member_price: 197, regular_price: 240, image: '/assets/media-041.jpg', rating: 3.7, review_count: 123,
    assembly_per_unit: 58.5, components: COMPONENTS_OAK, crumb: CRUMB_COMBO, combo: true,
    gallery: ['/assets/media-041.jpg', '/assets/media-067.jpg', '/assets/media-039.jpg'],
    dims: { width: '47 1/4 "', depth: '16 1/2 "', height: '29 1/8 "', load: '44 lb' } },

  { id: '89622907', name: 'BESTÅ',
    description: 'TV bench with doors, white Lappviken/brown walnut effect, 70 7/8x16 1/2x15 "',
    color: 'white Lappviken/brown walnut effect',
    member_price: 184, regular_price: 225, image: '/assets/media-061.jpg', rating: 3.8, review_count: 390,
    crumb: CRUMB_GEN, gallery: ['/assets/media-061.jpg', '/assets/media-055.jpg', '/assets/media-175.jpg'] },

  { id: '09590409', name: 'BESTÅ', description: 'Shelving unit, with 5 shelves/white, 23 5/8x15 3/4x76 "',
    color: 'with 5 shelves/white', badge: 'Best seller',
    member_price: 136, regular_price: 165, image: '/assets/media-145.jpg', rating: 3.4, review_count: 61,
    crumb: CRUMB_GEN, gallery: ['/assets/media-145.jpg', '/assets/media-146.jpg', '/assets/media-147.jpg'] },

  { id: '59622907', name: 'BESTÅ', description: 'TV bench with doors, black-brown Björköviken/oak veneer, 70 7/8x16 1/2x15 "',
    color: 'black-brown Björköviken/oak veneer',
    member_price: 325, regular_price: 390, image: '/assets/media-055.jpg', rating: 3.8, review_count: 390,
    crumb: CRUMB_GEN, gallery: ['/assets/media-055.jpg', '/assets/media-056.jpg', '/assets/media-175.jpg'] },

  { id: '00597863', name: 'BESTÅ', description: 'Top panel, brown/walnut, 47 1/4x16 1/2 "', color: 'brown/walnut',
    member_price: 20, regular_price: 25, image: '/assets/media-150.jpg', rating: 4.3, review_count: 40,
    crumb: CRUMB_GEN, gallery: ['/assets/media-150.jpg', '/assets/media-151.jpg', '/assets/media-154.jpg'] },

  { id: '60245919', name: 'BESTÅ', description: 'Frame, white, 23 5/8x7 7/8x25 1/4 "', color: 'white',
    member_price: 38, regular_price: 45, image: '/assets/media-155.jpg', rating: 4.3, review_count: 607,
    crumb: CRUMB_GEN, gallery: ['/assets/media-155.jpg', '/assets/media-156.jpg', '/assets/media-157.jpg'] },

  { id: '59047388', name: 'BESTÅ', description: 'Shelf unit with doors, 47 1/4x16 1/2x25 1/4 "', color: 'white',
    member_price: 145, regular_price: 175, image: '/assets/media-160.jpg', rating: 4.4, review_count: 483,
    crumb: CRUMB_GEN, gallery: ['/assets/media-160.jpg', '/assets/media-163.jpg', '/assets/media-161.jpg'] },

  { id: '39429699', name: 'BESTÅ', description: 'Shelf unit with doors, white Lappviken/white, 23 5/8x16 1/2x76 "',
    color: 'white Lappviken/white',
    member_price: 223, regular_price: 270, image: '/assets/media-166.jpg', rating: 2.8, review_count: 145,
    crumb: CRUMB_GEN, gallery: ['/assets/media-166.jpg', '/assets/media-167.jpg'] },

  { id: '19047432', name: 'BESTÅ',
    description: 'Shelf unit with doors, white stained oak effect/Lappviken white stained oak effect, 47 1/4x16 1/2x15 "',
    color: 'white stained oak effect/Lappviken white stained oak effect',
    member_price: 103, regular_price: 125, image: '/assets/media-170.jpg', rating: 4.3, review_count: 321,
    crumb: CRUMB_GEN, gallery: ['/assets/media-170.jpg', '/assets/media-171.jpg', '/assets/media-163.jpg'] },

  { id: '40565775', name: 'BESTÅ', description: 'TV unit, 70 7/8x15 3/4x15 "', color: 'black-brown',
    member_price: 76, regular_price: 90, image: '/assets/media-175.jpg', rating: 4.3, review_count: 2313,
    crumb: CRUMB_GEN, gallery: ['/assets/media-175.jpg', '/assets/media-177.jpg', '/assets/media-179.jpg'] },

  { id: '99623146', name: 'BESTÅ',
    description: 'Storage combination with doors, white/Björköviken oak veneer, 47 1/4x16 1/2x76 "',
    color: 'white/Björköviken oak veneer',
    member_price: 722, regular_price: 870, image: '/assets/media-062.jpg', rating: 3.7, review_count: 354,
    crumb: CRUMB_GEN, gallery: ['/assets/media-062.jpg', '/assets/media-063.jpg', '/assets/media-064.jpg'] },

  { id: '69612205', name: 'BESTÅ',
    description: 'Storage combination with drawers, black-brown Lappviken/Stubbarp/brown walnut effect, 70 7/8x16 1/2x29 1/8 "',
    color: 'black-brown Lappviken/Stubbarp/brown walnut effect',
    member_price: 300, regular_price: 365, image: '/assets/media-180.jpg', rating: 3.1, review_count: 127,
    crumb: CRUMB_GEN, gallery: ['/assets/media-180.jpg', '/assets/media-181.jpg', '/assets/media-046.jpg'] },

  { id: '60293566', name: 'STUBBARP', description: 'Leg, black-brown', color: 'black-brown',
    member_price: 8, regular_price: 10, image: '/assets/media-185.jpg', rating: 4.5, review_count: 867,
    pack_size: 2, assembly_per_unit: 2.6, crumb: CRUMB_LEG, gallery: ['/assets/media-185.jpg', '/assets/media-186.jpg'] },

  { id: '80261258', name: 'BESTÅ', description: 'Soft closing/push-open hinge', color: '',
    member_price: 12, regular_price: 15, image: '/assets/media-190.jpg', rating: 3.9, review_count: 1557,
    pack_size: 2, crumb: CRUMB_GEN, gallery: ['/assets/media-190.jpg', '/assets/media-191.jpg'] },

  { id: '39284998', name: 'BESTÅ', description: 'Cabinet, white, 23 5/8x15 3/4x79 1/2 "', color: 'white',
    member_price: 152, regular_price: 185, image: '/assets/media-192.jpg', rating: 3.8, review_count: 106,
    crumb: CRUMB_GEN, gallery: ['/assets/media-192.jpg', '/assets/media-193.jpg'] },

  { id: '00295554', name: 'BESTÅ', description: 'white flat shelf, rectangular, simple design, paper foil & particleboard.',
    color: 'rectangular', member_price: 12, regular_price: 15, image: '/assets/media-197.jpg', rating: 4.4, review_count: 1746,
    crumb: CRUMB_GEN, gallery: ['/assets/media-197.jpg', '/assets/media-198.jpg'] },

  { id: '89425910', name: 'BESTÅ', description: 'Wall-mounted cabinet combination, white/Lappviken white, 70 7/8x16 1/2x25 1/4 "',
    color: 'white/Lappviken white', member_price: 273, regular_price: 330, image: '/assets/media-203.jpg',
    rating: 3.3, review_count: 61, crumb: CRUMB_GEN, gallery: ['/assets/media-203.jpg', '/assets/media-204.jpg'] },

  { id: '59046906', name: 'BESTÅ', description: 'Shelf unit with door, white/Lappviken white, 23 5/8x16 1/2x25 1/4 "',
    color: 'white/Lappviken white', member_price: 83, regular_price: 100, image: '/assets/media-209.jpg',
    rating: 4.3, review_count: 271, crumb: CRUMB_GEN, gallery: ['/assets/media-209.jpg', '/assets/media-210.jpg'] },

  { id: '80351517', name: 'BESTÅ', description: 'Drawer frame, 23 5/8x9 7/8x15 3/4 "', color: 'white',
    member_price: 20, regular_price: 25, image: '/assets/media-214.jpg', rating: 3.9, review_count: 293,
    crumb: CRUMB_GEN, gallery: ['/assets/media-214.jpg', '/assets/media-215.jpg'] },

  { id: '70488318', name: 'BESTÅ', description: 'Suspension rail, 23 5/8 "', color: 'silver-color',
    member_price: 8, regular_price: 10, image: '/assets/media-219.jpg', rating: 4.0, review_count: 351,
    crumb: CRUMB_GEN, gallery: ['/assets/media-219.jpg'] },

  { id: '00291848', name: 'HANVIKEN', description: 'Door/drawer front, 23 1/2x15 "', color: 'white',
    member_price: 17, regular_price: 20, image: '/assets/media-220.jpg', rating: 4.5, review_count: 175,
    crumb: CRUMB_GEN, gallery: ['/assets/media-220.jpg', '/assets/media-221.jpg'] },

  { id: '20293568', name: 'STUBBARP', description: 'Leg, white stained oak effect', color: 'white stained oak effect',
    member_price: 8, regular_price: 10, image: '/assets/media-188.jpg', rating: 4.5, review_count: 867,
    pack_size: 2, assembly_per_unit: 2.6, crumb: CRUMB_LEG,
    gallery: ['/assets/media-188.jpg', '/assets/media-342.jpg', '/assets/media-343.jpg'] }
];

/* Colourways shown for the two recorded storage combinations.
   ``id`` links a swatch to the real SKU when one exists in the slice. */
var VARIANTS_COMBO = [
  { img: '/assets/media-042.jpg', color: 'Black-brown Lappviken/Stubbarp/brown walnut effect', id: '29612189' },
  { img: '/assets/media-043.jpg', color: 'Black-brown/Lappviken/Stubbarp black-brown' },
  { img: '/assets/media-044.jpg', color: 'Black-brown Björköviken/Stubbarp/brown stained oak veneer' },
  { img: '/assets/media-039.jpg', color: 'White stained oak effect/Lappviken/Stubbarp white stained oak effect', id: '29209829' },
  { img: '/assets/media-045.jpg', color: 'White/Hanviken/Stubbarp white' },
  { img: '/assets/media-318.jpg', color: 'White brown/Lappviken/Stubbarp brown walnut effect' },
  { img: '/assets/media-319.jpg', color: 'White/Lappviken/Stubbarp dark gray' },
  { img: '/assets/media-320.jpg', color: 'Black-brown/Hanviken/Stubbarp black-brown' },
  { img: '/assets/media-321.jpg', color: 'White stained oak effect/Hanviken/Stubbarp white stained oak effect' },
  { img: '/assets/media-322.jpg', color: 'Pipmakare white/Stubbarp white' },
  { img: '/assets/media-323.jpg', color: 'Förvaltare white/Stubbarp white' },
  { img: '/assets/media-324.jpg', color: 'Krukmakare beige/Stubbarp white' },
  { img: '/assets/media-325.jpg', color: 'Krukmakare dark gray-green/Stubbarp white' }
];

var VARIANTS_LEG = [
  { img: '/assets/media-185.jpg', color: 'Black', id: '60293566' },
  { img: '/assets/media-186.jpg', color: 'Black' },
  { img: '/assets/media-187.jpg', color: 'White' },
  { img: '/assets/media-188.jpg', color: 'White stained oak effect', id: '20293568' },
  { img: '/assets/media-189.jpg', color: 'Dark gray' }
];

var MEGANAV = {
  new: {
    title: 'New & trending',
    left: ['Explore all new', 'Limited collections', 'Home accessories shop', 'IKEA for Business'],
    cols: [
      { h: 'Trending', items: ['New products', 'Best sellers', 'Gift guide', 'IKEA Live Shopping'] },
      { h: 'Seasonal', items: ['Fall decor shop', 'Halloween decor', 'Thanksgiving essentials', 'Explore all shops'] },
      { h: 'Food', items: ['IKEA Swedish Restaurant & Bistro', 'IKEA Swedish Food Market', 'Food recipes'] }
    ],
    promo: { img: '/assets/media-031.jpg', text: 'Game on with YXSTABY, our new XBOX collab, available in store now', bg: '#e0651a' }
  },
  winter: {
    title: 'Winter holiday shop',
    left: ['Explore the winter holiday shop', 'New for the holidays', 'Best selling holiday decor', 'Gift ideas', 'IKEA for Business'],
    cols: [
      { h: 'Decorating', items: ['Christmas trees', 'Tree decorations', 'Wreaths & garlands', 'Advent calendars'] },
      { h: 'Table', items: ['Holiday tableware', 'Napkins & placemats', 'Serving dishes', 'Candles & holders'] },
      { h: 'Gifts', items: ['Gifts under $10', 'Gifts under $25', 'Stocking fillers', 'Gift cards'] }
    ],
    promo: { img: '/assets/media-084.jpg', text: 'Light up the season with STRÅLA lampshades', bg: '#c8102e' }
  },
  storage: {
    title: 'Storage & organization',
    left: ['Explore storage & organization', 'New storage & organization', 'Best selling storage & organization', 'Financing options', 'IKEA for Business'],
    cols: [
      { h: '', items: ['Dressers & storage drawers', 'Shelving furniture', 'Storage solution systems', 'Display & storage cabinets',
                       'Armoires & wardrobes', 'TV & media furniture', 'Living room & entryway tables', 'Rolling utility & storage carts',
                       'Garage storage solutions', 'Outdoor storage: shelves, cabinets & boxes', 'Room dividers'] },
      { h: '', items: ['Hallway furniture sets', 'Filing cabinets', 'Shoe cabinets', 'Kids storage & organization'] }
    ],
    promo: { img: '/assets/media-193.jpg', text: 'Shop our newest arrivals', bg: '#e0651a' }
  },
  sofas: {
    title: 'Sofas & armchairs',
    left: ['Explore sofas & armchairs', 'New sofas & armchairs', 'Best selling sofas', 'Sofas for small spaces', 'IKEA for Business'],
    cols: [
      { h: '', items: ['Sofas', 'Sofa beds', 'Armchairs', 'Footstools & pouffes', 'Chaise longues', 'Outdoor seating'] },
      { h: '', items: ['Sofa covers', 'Cushions', 'Throws', 'Coffee tables'] }
    ],
    promo: { img: '/assets/media-035.jpg', text: 'Comfort that fits — explore armchairs', bg: '#2c5f2d' }
  },
  beds: {
    title: 'Beds & mattresses',
    left: ['Explore beds & mattresses', 'New beds & mattresses', 'Best selling mattresses', 'Sleep quiz', 'IKEA for Business'],
    cols: [
      { h: '', items: ['Beds', 'Bed frames', 'Mattresses', 'Bed textiles', 'Pillows', 'Kids beds'] },
      { h: '', items: ['Bedside tables', 'Wardrobes', 'Dressers & storage drawers', 'Bed canopies'] }
    ],
    promo: { img: '/assets/media-101.jpg', text: 'Find your perfect mattress in minutes', bg: '#0058a3' }
  },
  lighting: {
    title: 'Lighting',
    left: ['Explore lighting', 'New lighting', 'Best selling lighting', 'Smart lighting', 'IKEA for Business'],
    cols: [
      { h: '', items: ['Ceiling lights', 'Floor lamps', 'Table lamps', 'Wall lamps', 'Pendant lamps', 'Work lamps'] },
      { h: '', items: ['LED bulbs', 'Lighting accessories', 'Candles & holders', 'Battery operated lighting'] }
    ],
    promo: { img: '/assets/media-036.jpg', text: 'Brighten every room with NYMÅNE', bg: '#4a4a4a' }
  },
  kitchen: {
    title: 'Kitchen, appliances & supplies',
    left: ['Explore kitchen', 'New kitchen', 'Best selling kitchen', 'Kitchen planning', 'IKEA for Business'],
    cols: [
      { h: '', items: ['Kitchen cabinets', 'Kitchen islands', 'Cookware', 'Bakeware', 'Tableware', 'Food storage'] },
      { h: '', items: ['Appliances', 'Kitchen faucets', 'Kitchen organizers', 'Waste sorting'] }
    ],
    promo: { img: '/assets/media-031.jpg', text: 'New, must-try kitchen accessories', bg: '#e0651a' }
  }
};

var REVIEWS = [
  { r: 2, t: 'Looks good, functions bad',
    b: 'The flimsy wood for the frame and plastic cam locks seriously degrade the quality of the overall product. The doors very easily misalign if the cabinet is nudged in any way. As soon as you go to open it, put something on top of it or take it off, the whole cabinet frame shifts, and the doors become misaligned. Not worth the price-this is weak sauce.',
    a: 'Dylan', d: '09/17/2026', h: 1,
    resp: "Oh no, we're sorry to hear this! You're welcome to visit our Returns Desk within 180 days of the purchase date.", rd: '09/20/2026' },
  { r: 1, t: 'So disappointed. Wobbly junk.',
    b: "Ordered the Besta TV stand and loved it! Very sturdy. However, we wanted something bigger. This is not the same sturdy quality. Very wobbly!!! Returning the first purchase was such an ordeal, I do not look forward to going through that again. I'd like to try brackets in each corner to see if it will help with the wobbling, but I'm undecided. I'll update if I do.",
    a: 'Anonymous reviewer', d: '11/14/2024', h: 63 },
  { r: 5, t: 'Great value and looks beautiful',
    b: 'Easy to assemble and looks much more expensive than it is. The white stained oak effect matches our other furniture perfectly.',
    a: 'Maria L.', d: '10/09/2024', h: 24 },
  { r: 4, t: 'Solid once anchored to the wall',
    b: 'Follow the instructions and anchor it to the wall — then it is rock solid. Great storage for the price.',
    a: 'Jonas P.', d: '09/28/2024', h: 12 },
  { r: 3, t: 'Decent, but the hardware is average',
    b: 'The cabinet itself is fine. The hinges feel a bit light and the cam locks are plastic. Acceptable for the price.',
    a: 'Alex', d: '08/15/2024', h: 8 },
  { r: 2, t: 'Arrived with a damaged corner',
    b: 'One of the doors had a chipped corner out of the box. Return was easy but inconvenient.',
    a: 'Priya', d: '07/02/2024', h: 5 },
  { r: 5, t: 'Perfect hallway sideboard',
    b: 'Exactly what I needed for my entryway. The legs make it easy to vacuum underneath.',
    a: 'Sam', d: '06/11/2024', h: 19 },
  { r: 4, t: 'Good, instructions could be clearer',
    b: 'Took about 90 minutes to build. The illustrations are small but manageable.',
    a: 'Chris', d: '05/03/2024', h: 3 }
];

var REVIEW_DIST = [ [5, 54], [4, 30], [3, 10], [2, 12], [1, 17] ];
var REVIEW_SUB = [ ['Appearance', 4.3], ['Ease of assembly/installation', 3.9], ['Product quality', 3.5], ['Value for money', 3.6], ['Works as expected', 3.7] ];
var REVIEW_TOPICS = ['Quality (11)', 'Assembly (11)', 'Components (10)', 'Stability (10)', 'Design (10)', 'Durability (6)', 'Price (5)'];
var REVIEW_SUMMARY = 'BESTÅ offers a stylish design that enhances many spaces. Customers often report issues with overall stability and quality. They mention wobbly structures and difficulty aligning or securing doors. Assembling the door components often proves difficult, impacting functionality. BESTÅ provides a modern, adaptable look for living spaces.';

var STORES = [
  ['Arcadia, CA', '400 South Baldwin Ave Suite D5, Arcadia'],
  ['Atlanta, GA', '441 16th Street, Atlanta'],
  ['Baltimore, MD', '8352 Honeygo Boulevard, Baltimore'],
  ['Bolingbrook, IL', '750 E Boughton, Bolingbrook'],
  ['Brooklyn, NY', '1 Beard Street, Brooklyn'],
  ['Burbank, CA', '600 South IKEA Way, Burbank'],
  ['Canton, MI', '41640 Ford Road, Canton'],
  ['Carson, CA', '20700 South Avalon Blvd, Carson'],
  ['East Palo Alto, CA', '1700 E Bayshore Rd, East Palo Alto']
];

var ESSENTIALS = [
  { name: 'LJUNGJORDFLY', desc: 'Sealing clip, set of 6, multicolor', price: 5.99, img: '/assets/media-353.jpg' },
  { name: 'FRAKTA', desc: 'Shopping bag, large, blue, 21 3/4x14 1/2x13 3/4"/19 gallon', price: 0.99, was: 1.99, img: '/assets/media-354.jpg' },
  { name: 'LILLNAGGEN', desc: 'Shower squeegee', price: 1.99, img: '/assets/media-355.jpg' },
  { name: 'RINNIG', desc: 'Cleaning gloves, bright yellow/off-white, M', price: 3.99, was: 4.99, img: '/assets/media-356.jpg' },
  { name: 'PEPPRIG', desc: 'Dust pan and brush, gray', price: 2.99, img: '/assets/media-357.jpg' },
  { name: 'BÄSTIS', desc: 'Lint roller, assorted colors', price: 1.49, img: '/assets/media-358.jpg' },
  { name: 'TRIXIG', desc: 'Screwdriver, assorted sizes', price: 4.99, img: '/assets/media-359.jpg' },
  { name: 'GÖRSNYGG', desc: 'Storage bag, white/transparent', price: 3.49, img: '/assets/media-360.jpg' },
  { name: 'TOMAT', desc: 'Plant pot, indoor/outdoor gray', price: 2.99, img: '/assets/media-361.jpg' },
  { name: 'RINNIG', desc: 'Cleaning brush, gray', price: 2.49, img: '/assets/media-364.jpg' }
];

var SUGGESTIONS = ['besta', 'besta frame', 'besta storage combination with doors', 'besta tv bench',
  'besta shelving unit', 'besta legs', 'besta doors', 'besta top panel', 'besta hinges',
  'besta drawer frame', 'besta sideboard'];

var ACCESSORIES = [
  '/assets/media-243.jpg', '/assets/media-326.jpg', '/assets/media-286.jpg',
  '/assets/media-327.jpg', '/assets/media-299.jpg'
];

var PAY_ICONS = ['/assets/media-121.svg', '/assets/media-122.svg', '/assets/media-123.svg', '/assets/media-124.svg',
  '/assets/media-125.svg', '/assets/media-126.svg', '/assets/media-127.svg', '/assets/media-128.svg',
  '/assets/media-133.svg', '/assets/media-130.svg', '/assets/media-132.svg', '/assets/media-129.svg'];
