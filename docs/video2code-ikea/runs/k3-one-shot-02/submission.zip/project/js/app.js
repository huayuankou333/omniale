'use strict';
/* =====================================================================
   IKEA BESTÅ shopping journey – recorded-slice reimplementation
   Hash-routed SPA, state persisted in localStorage.
   ===================================================================== */

/* ---------------- utils ---------------- */
const $  = s => document.querySelector(s);
const $$ = s => Array.from(document.querySelectorAll(s));
function money(n){ return '$' + (Math.round(n*100)/100).toFixed(2); }
function pct(reg, mem){ return Math.floor((reg-mem)/reg*100); }
function artNo(id){ const m = String(id).match(/(\d{3})(\d{3})(\d{2})$/); return m ? m[1]+'.'+m[2]+'.'+m[3] : id; }
let __starId = 0;
function starSVG(fill){
  const id = 'sg'+(++__starId);
  return '<svg viewBox="0 0 24 24" width="14" height="14"><defs><linearGradient id="'+id+'"><stop offset="'+(fill*100)+'%" stop-color="#111"/><stop offset="'+(fill*100)+'%" stop-color="#dfdfdf"/></linearGradient></defs><path fill="url(#'+id+')" d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01z"/></svg>';
}
function stars(r){
  const rr = Math.round(r*2)/2; let s='';
  for(let i=1;i<=5;i++){ let f = rr>=i?1:(rr>i-1?0.5:0); s+=starSVG(f); }
  return '<span class="stars">'+s+'</span>';
}
function esc(s){ return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;'); }

/* ---------------- icons ---------------- */
const I = {
  logo: '<svg viewBox="0 0 120 50" width="100" height="42" aria-label="IKEA"><rect x="1" y="2" width="118" height="46" rx="2" fill="#0058a3"/><ellipse cx="60" cy="25" rx="53" ry="20" fill="#ffdb00"/><text x="58" y="34" text-anchor="middle" font-family="Arial Black,Arial" font-size="23" font-weight="900" fill="#0058a3" letter-spacing="3">IKEA</text><text x="110" y="13" font-size="7" fill="#ffdb00">®</text></svg>',
  globe:'<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c3 3.5 3 14.5 0 18M12 3c-3 3.5-3 14.5 0 18"/></svg>',
  truck:'<svg viewBox="0 0 24 24"><path d="M2 6h12v10H2zM14 9h4l3 3v4h-7z"/><circle cx="6.5" cy="17.5" r="1.8"/><circle cx="17.5" cy="17.5" r="1.8"/></svg>',
  store:'<svg viewBox="0 0 24 24"><path d="M4 9l1.2-4h13.6L20 9M4 9h16M4 9v11h16V9M9.5 20v-6h5v6"/></svg>',
  bag:'<svg viewBox="0 0 24 24"><path d="M5.5 8h13l1 12.5h-15z"/><path d="M9 8a3 3 0 016 0"/></svg>',
  bagAdd:'<svg viewBox="0 0 24 24"><path d="M5.5 8h13l1 12.5h-15z"/><path d="M9 8a3 3 0 016 0"/><path d="M12 12v6M9 15h6"/></svg>',
  search:'<svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="7"/><path d="M16.5 16.5L21 21"/></svg>',
  user:'<svg viewBox="0 0 24 24"><circle cx="12" cy="8" r="4"/><path d="M4.5 20c1.5-4 4.5-5.5 7.5-5.5s6 1.5 7.5 5.5"/></svg>',
  heart:'<svg viewBox="0 0 24 24"><path d="M12 20.5S3.5 15.4 2.2 10.6C1.2 7 3.6 4 6.8 4c2.2 0 3.9 1.2 5.2 3 1.3-1.8 3-3 5.2-3 3.2 0 5.6 3 4.6 6.6C20.5 15.4 12 20.5 12 20.5z"/></svg>',
  chevD:'<svg viewBox="0 0 24 24"><path d="M5 9l7 7 7-7"/></svg>',
  check:'<svg viewBox="0 0 24 24"><path d="M4.5 12.5l5 5L19.5 7"/></svg>',
  trash:'<svg viewBox="0 0 24 24"><path d="M4 7h16M9.5 7V4.5h5V7M6.5 7l1 13.5h9l1-13.5M10 11v6M14 11v6"/></svg>',
  info:'<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M12 10.5V17M12 7v.5"/></svg>',
  play:'<svg viewBox="0 0 24 24"><path d="M8 5l11 7-11 7z"/></svg>',
  pencil:'<svg viewBox="0 0 24 24"><path d="M4 20l1-4L16.5 4.5a2.1 2.1 0 013 3L8 19l-4 1z"/></svg>',
  wrench:'<svg viewBox="0 0 24 24"><path d="M20.5 6.5a5 5 0 01-6.6 6.6L7 20a2.1 2.1 0 01-3-3l6.9-6.9a5 5 0 016.6-6.6L15 6l2.5 2.5L20 6z"/></svg>',
  ext:'<svg viewBox="0 0 24 24"><path d="M14 4h6v6M20 4L11 13M9 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-3"/></svg>',
  sort:'<svg viewBox="0 0 24 24"><path d="M8 5v14m0 0l-3.5-3.5M8 19l3.5-3.5M16 19V5m0 0l-3.5 3.5M16 5l3.5 3.5"/></svg>',
  filter:'<svg viewBox="0 0 24 24"><path d="M4 7h9M17 7h3M4 12h3M11 12h9M4 17h11M19 17h1"/><circle cx="15" cy="7" r="1.6"/><circle cx="9" cy="12" r="1.6"/><circle cx="17" cy="17" r="1.6"/></svg>',
  pause:'<svg viewBox="0 0 24 24"><rect x="6" y="4" width="4" height="16"/><rect x="14" y="4" width="4" height="16"/></svg>',
  arrow:'<svg viewBox="0 0 24 24"><path d="M4 12h15m-6-6l6 6-6 6"/></svg>',
  key:'<svg viewBox="0 0 24 24"><circle cx="8" cy="14" r="4.5"/><path d="M11 11l8-8M15 7l3 3M18 4l2.5 2.5"/></svg>',
  media:'<svg viewBox="0 0 24 24"><rect x="3.5" y="5" width="17" height="14" rx="2"/><circle cx="9" cy="10" r="1.6"/><path d="M4.5 17l5-4 3.5 3 3-2.5 4.5 3.5"/></svg>',
  cube:'<svg viewBox="0 0 24 24"><path d="M12 3l8 4.5v9L12 21l-8-4.5v-9zM12 12l8-4.5M12 12v9M12 12L4 7.5"/></svg>',
  tag:'<svg viewBox="0 0 24 24"><path d="M3.5 3.5H11l9.5 9.5-7.5 7.5L3.5 11z"/><circle cx="8" cy="8" r="1.6"/></svg>',
  err:'<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10" fill="#e00751"/><path d="M12 7v7M12 16.8v.4" stroke="#fff" stroke-width="2" fill="none"/></svg>'
};

/* ---------------- state ---------------- */
const LS_KEY = 'ikea-besta-demo-v1';
let S = { bag:[], compare:[], favs:[], zip:null, store:null, cookie:false };
try{ const raw = localStorage.getItem(LS_KEY); if(raw){ const o = JSON.parse(raw); S = Object.assign(S, o); } }catch(e){}
function save(){ try{ localStorage.setItem(LS_KEY, JSON.stringify(S)); }catch(e){} }

/* ephemeral UI state */
const ui = {
  megaOpen:false, megaTab:'New & trending', facets:new Set(),
  pdpImg:{}, pdpQty:{}, galTab:'all', galImgs:[], galCtx:null,
  rev:null, discOpen:false, discErr:false, lastRemoved:null,
  partsFor:null, drawerData:null, suggestOpen:false
};
let CUR = { path:'/us/en/', params:new URLSearchParams() };

/* ---------------- catalog ---------------- */
let CAT = null;
function findItem(id){ return CAT.catalog.find(i=>String(i.id)===String(id)); }
function findByRoute(path){ return CAT.catalog.find(i=>i.route===path); }
const DIMS = {};

/* pseudo / add-on products (recommendations, essentials, accessories) */
const PSEUDO = {};
function regPseudo(o){ PSEUDO[o.id]=o; return o; }
const RECO_LEG = [
  regPseudo({id:'rec-support', name:'BESTÅ', desc:'Support leg, gray, 3 7/8 "', img:'/assets/media-340.jpg', regular:15, member:12}),
  regPseudo({id:'rec-hinge', name:'BESTÅ', desc:'Soft closing/push-open hinge, 2 pack', img:'/assets/media-190.jpg', regular:15, member:12, suffix:'/2 pack'}),
  regPseudo({id:'rec-lapp-door', name:'LAPPVIKEN', desc:'Door, white stained oak effect, 23 1/2x25 1/8 "', img:'/assets/media-341.jpg', regular:20, member:16})
];
const RECO_COMBO = [
  regPseudo({id:'rec-billy', name:'BILLY', desc:'Bookcase, brown walnut effect, 31 1/2x11x79 1/2 "', img:'/assets/media-194.jpg', regular:89, member:89}),
  regPseudo({id:'rec-lapp-dd', name:'LAPPVIKEN', desc:'Door/drawer front, brown/walnut effect, 23 5/8x15 "', img:'/assets/media-341.jpg', regular:15, member:12}),
  regPseudo({id:'rec-lapp-df', name:'LAPPVIKEN', desc:'Drawer front, brown/walnut effect, 23 5/8x10 1/4 "', img:'/assets/media-150.jpg', regular:10, member:8})
];
const ESSENTIALS = [
  regPseudo({id:'ess-clip', name:'LJUNGJORDFLY', desc:'Sealing clip, set of 6, multicolor', img:'/assets/media-353.jpg', regular:5.99, member:5.99}),
  regPseudo({id:'ess-frakta', name:'FRAKTA', desc:'Shopping bag, large, blue, 21 ¾x14 ½x13 ¾ "/19 gallon', img:'/assets/media-354.jpg', regular:0.99, member:0.99, sale:true}),
  regPseudo({id:'ess-squeegee', name:'LILLNAGGEN', desc:'Shower squeegee', img:'/assets/media-355.jpg', regular:1.99, member:1.99}),
  regPseudo({id:'ess-gloves', name:'RINNIG', desc:'Cleaning gloves, bright yellow/off-white, M', img:'/assets/media-356.jpg', regular:3.99, member:3.99}),
  regPseudo({id:'ess-dustpan', name:'PEPPRIG', desc:'Dust pan and brush, gray', img:'/assets/media-357.jpg', regular:2.99, member:2.99})
];
const ACCESSORIES = [
  regPseudo({id:'acc-1', name:'KUGGIS', desc:'Box with lid, white, 7x10 1/4x6 "', img:'/assets/media-243.jpg', regular:9.99, member:9.99}),
  regPseudo({id:'acc-2', name:'KUGGIS', desc:'Box with lid, light wood/white, 7x10 1/4x6 "', img:'/assets/media-256.jpg', regular:12.99, member:12.99}),
  regPseudo({id:'acc-3', name:'KUGGIS', desc:'Box with lid, blue, 7x10 1/4x6 "', img:'/assets/media-257.jpg', regular:12.99, member:12.99}),
  regPseudo({id:'acc-4', name:'KUGGIS', desc:'Box with lid, gray, 10 1/4x13 3/4x7 3/4 "', img:'/assets/media-245.jpg', regular:14.99, member:14.99}),
  regPseudo({id:'acc-5', name:'KUGGIS', desc:'Box with lid, white, 10 1/4x13 3/4x7 3/4 "', img:'/assets/media-262.jpg', regular:14.99, member:14.99})
];

/* combination parts (What's included + bag parts drawer) */
const INCLUDED = {
  '29209829':[
    {qty:1,type:'Frame',name:'BESTÅ',dims:'47 1/4x15 3/4x25 1/4 "',art:'902.473.75',img:'/assets/media-139.jpg'},
    {qty:4,type:'Shelf',name:'BESTÅ',dims:'22x14 1/8 "',art:'002.955.49',img:'/assets/media-200.jpg'},
    {qty:2,type:'Leg',name:'STUBBARP',dims:'',art:'202.935.68',img:'/assets/media-188.jpg',link:'/us/en/p/stubbarp-leg-white-stained-oak-effect-20293568/'},
    {qty:1,type:'Support leg',name:'BESTÅ',dims:'3 7/8 "',art:'502.936.04',img:'/assets/media-340.jpg'},
    {qty:2,type:'Soft closing/push-open hinge',name:'BESTÅ',dims:'',art:'802.612.58',img:'/assets/media-190.jpg'},
    {qty:2,type:'Door',name:'LAPPVIKEN',dims:'23 5/8x25 1/4 "',art:'003.472.16',img:'/assets/media-341.jpg'}
  ],
  '29612189':[
    {qty:1,type:'Frame',name:'BESTÅ',dims:'black-brown, 47 1/4x15 3/4x25 1/4 "',art:'702.473.74',img:'/assets/media-138.jpg'},
    {qty:4,type:'Shelf',name:'BESTÅ',dims:'black-brown, 22x14 1/8 "',art:'602.955.52',img:'/assets/media-199.jpg'},
    {qty:2,type:'Leg',name:'STUBBARP',dims:'black-brown',art:'602.935.66',img:'/assets/media-185.jpg',link:'/us/en/p/stubbarp-leg-black-brown-60293566/'},
    {qty:1,type:'Support leg',name:'BESTÅ',dims:'gray, 3 7/8 "',art:'502.936.04',img:'/assets/media-340.jpg'},
    {qty:2,type:'Soft closing/push-open hinge',name:'BESTÅ',dims:'',art:'802.612.58',img:'/assets/media-190.jpg'},
    {qty:2,type:'Door',name:'LAPPVIKEN',dims:'brown/walnut effect, 23 5/8x25 1/4 "',art:'504.083.19',img:'/assets/media-150.jpg'}
  ]
};
const PARTS_DESC = {
  '29209829':[
    {name:'BESTÅ',desc:'Frame, white stained oak effect, 47 1/4x15 3/4x25 1/4 "',qty:1},
    {name:'BESTÅ',desc:'Shelf, white stained oak effect, 22x14 1/8 "',qty:4},
    {name:'STUBBARP',desc:'Leg, white stained oak effect',qty:2},
    {name:'BESTÅ',desc:'Support leg, gray, 3 7/8 "',qty:1},
    {name:'BESTÅ',desc:'Soft closing/push-open hinge',qty:2},
    {name:'LAPPVIKEN',desc:'Door, white stained oak effect, 23 5/8x25 1/4 "',qty:2}
  ],
  '29612189':[
    {name:'BESTÅ',desc:'Frame, black-brown, 47 1/4x15 3/4x25 1/4 "',qty:1},
    {name:'BESTÅ',desc:'Shelf, black-brown, 22x14 1/8 "',qty:4},
    {name:'STUBBARP',desc:'Leg, black-brown',qty:2},
    {name:'BESTÅ',desc:'Support leg, gray, 3 7/8 "',qty:1},
    {name:'BESTÅ',desc:'Soft closing/push-open hinge',qty:2},
    {name:'LAPPVIKEN',desc:'Door, brown/walnut effect, 23 5/8x25 1/4 "',qty:2}
  ]
};

/* color swatches on combo PDP */
const COMBO_SW = [
  {img:'/assets/media-042.jpg', route:'/us/en/p/besta-storage-combination-with-doors-black-brown-lappviken-stubbarp-brown-walnut-effect-s29612189/'},
  {img:'/assets/media-043.jpg'}, {img:'/assets/media-044.jpg'},
  {img:'/assets/media-039.jpg', route:'/us/en/p/besta-storage-combination-with-doors-white-stained-oak-effect-lappviken-stubbarp-white-stained-oak-effect-s29209829/'},
  {img:'/assets/media-041.jpg'}, {img:'/assets/media-045.jpg'}, {img:'/assets/media-318.jpg'},
  {img:'/assets/media-319.jpg'}, {img:'/assets/media-320.jpg'}, {img:'/assets/media-321.jpg'},
  {img:'/assets/media-322.jpg'}, {img:'/assets/media-323.jpg'}, {img:'/assets/media-324.jpg'}
];
const LEG_SW = [
  {img:'/assets/media-185.jpg', route:'/us/en/p/stubbarp-leg-black-brown-60293566/'},
  {img:'/assets/media-189.jpg'}, {img:'/assets/media-187.jpg'},
  {img:'/assets/media-188.jpg', route:'/us/en/p/stubbarp-leg-white-stained-oak-effect-20293568/'}
];
const STORES = [
  ['Arcadia, CA','400 South Baldwin Ave Suite D5, Arcadia'],
  ['Atlanta, GA','441 16th Street, Atlanta'],
  ['Baltimore, MD','8352 Honeygo Boulevard, Baltimore'],
  ['Bolingbrook, IL','750 E Boughton, Bolingbrook'],
  ['Brooklyn, NY','1 Beard Street, Brooklyn'],
  ['Burbank, CA','600 South IKEA Way, Burbank'],
  ['Canton, MI','41640 Ford Road, Canton'],
  ['Carson, CA','20700 South Avalon Blvd, Carson'],
  ['East Palo Alto, CA','1700 E Bayshore Hwy, East Palo Alto'],
  ['Emeryville, CA','4400 Shellmound Street, Emeryville']
];
const SORTS = [['best','Best match'],['price-asc','Price: low to high'],['price-desc','Price: high to low'],['newest','Newest'],['rating','Customer rating'],['name','Name'],['popular','Most popular'],['width','Width'],['height','Height']];
const COLORS = [['Gray','#9b9b9b',87],['White','#ffffff',87],['Black','#1b1b1b',66],['Beige','#f4efdc',59],['Brown','#7a4a22',55],['Green','#4c7a2e',19]];
const BEST_SELLER = new Set(['09590409']);

/* reviews */
const REVIEWS = [
  {r:2, d:'09/17/2026', t:'Looks good, functions bad', b:'The flimsy wood for the frame and plastic cam locks seriously degrade the quality of the overall product. The doors very easily misalign if the cabinet is nudged in any way. As soon as you go to open it, put something on top of it or take it off, the whole cabinet frame shifts, and the doors become misaligned. Not worth the price- this is weak sauce.', a:'Dylan', h:1, tags:['Quality','Stability','Components'], resp:'Oh no, we\'re sorry to hear this! You\'re welcome to visit our Returns Desk within 180 days of the purchase date with your receipt, and one of our co-workers will be happy to help you.', rd:'09/20/2026'},
  {r:1, d:'11/14/2024', t:'So disappointed. Wobbly junk.', b:'Ordered the Besta TV stand and loved it! Very sturdy. However, we wanted something bigger. This is not the same sturdy quality. Very wobbly!!! Returning the first purchase was such an ordeal, I do not look forward to going through that again. I\'d like to try brackets in each corner to see if it will help with the wobbling, but I\'m undecided. I\'ll update if I do.', a:'Anonymous reviewer', h:63, tags:['Stability','Quality']},
  {r:1, d:'10/09/2024', t:'Fell apart within a year', b:'The doors never stayed aligned and the frame started sagging in the middle. The cam locks loosen over time and the whole unit shifts. Expected better for the price. Would not recommend for daily use.', a:'Anonymous reviewer', h:12, tags:['Quality','Durability']},
  {r:5, d:'08/02/2026', t:'Beautiful and spacious', b:'Looks stunning in our hallway and holds far more than expected. Assembly took about an hour and the instructions were clear. The oak effect finish looks much more expensive than it is. Very happy with this purchase.', a:'Maria', h:8, tags:['Design','Assembly']},
  {r:4, d:'05/21/2026', t:'Great value for the price', b:'Solid storage for the money. One door needed adjusting but otherwise sturdy and clean looking. The push-open hinges work well once dialed in.', a:'James', h:5, tags:['Value for money','Assembly']},
  {r:3, d:'01/11/2025', t:'Decent but tricky assembly', b:'The end result looks good, but aligning the doors took patience. The push-open hinges are finicky and the instructions could be clearer for the hinge step.', a:'Anonymous reviewer', h:3, tags:['Assembly','Components']}
];
const REV_BARS = [[5,54],[4,30],[3,10],[2,12],[1,17]];
const REV_ASPECTS = [['Appearance',4.3],['Ease of assembly/installation',3.9],['Product quality',3.5],['Value for money',3.6],['Works as expected',3.7]];
const REV_TOPICS = ['Quality (11)','Assembly (11)','Components (10)','Stability (10)','Design (10)','Durability (9)','Value (8)'];

/* ---------------- bag helpers ---------------- */
function bagCount(){ return S.bag.reduce((a,i)=>a+i.qty,0); }
function bagTotals(){
  let products=0, saveFam=0, asmRaw=0;
  S.bag.forEach(i=>{ products += i.regular*i.qty; saveFam += (i.regular-i.member)*i.qty; if(i.asm && i.asmFee) asmRaw += i.asmFee*i.qty; });
  const asm = asmRaw>0 ? Math.max(asmRaw, 52) : 0;
  return { products, asm, total: products+asm, saveFam, points: Math.round(products) };
}
function snapshotOf(item){
  let desc = item.description || item.desc || '';
  if(item.pack_size) desc += ', '+item.pack_size+' pack/pack';
  if(item.desc && !item.description) desc = item.desc;
  return { id:item.id, route:item.route||null, name:item.name, desc, img:item.image||item.img,
    regular:item.regular_price!=null?item.regular_price:item.regular,
    member:item.member_price!=null?item.member_price:item.member,
    asmFee:item.assembly_per_unit||0, isCombo:!!item.components };
}
function addToBag(item, qty){
  const snap = snapshotOf(item);
  const ex = S.bag.find(i=>String(i.id)===String(snap.id));
  if(ex) ex.qty = Math.min(99, ex.qty+qty); else S.bag.push(Object.assign({qty, asm:false}, snap));
  save(); updateBadge();
}

/* ---------------- routing ---------------- */
function parseHash(){
  let h = location.hash.slice(1);
  if(!h) h = '/us/en/';
  const qi = h.indexOf('?');
  const p = qi>=0 ? h.slice(0,qi) : h;
  const qs = qi>=0 ? h.slice(qi+1) : '';
  return { path:p, params:new URLSearchParams(qs) };
}
function go(path){ if(location.hash === '#'+path){ renderApp(); } else location.hash = path; }
window.addEventListener('hashchange', ()=>{ closeOverlays(); renderApp(); });

function renderApp(){
  CUR = parseHash();
  document.getElementById('app').innerHTML =
    '<div id="headwrap">'+headerHTML()+'</div><main id="page">'+pageHTML(CUR.path, CUR.params)+'</main>'+footerHTML()+cookieHTML();
  window.scrollTo(0,0);
}
function renderHead(){ const w=$('#headwrap'); if(w) w.innerHTML = headerHTML(); }
function renderCurrentPage(){ CUR = parseHash(); const p=$('#page'); if(p) p.innerHTML = pageHTML(CUR.path, CUR.params); }
function updateBadge(){
  const b = $('#bag-badge'); const n = bagCount();
  if(b){ if(n>0){ b.textContent=n; b.classList.remove('hidden'); } else b.classList.add('hidden'); }
}
function pageHTML(path, params){
  if(path==='/' || path==='/us/en' || path==='/us/en/') return homeHTML();
  if(path.indexOf('/us/en/search')===0) return searchHTML(params);
  if(path.indexOf('/us/en/compare')===0) return compareHTML();
  if(path.indexOf('/us/en/bag')===0) return bagHTML();
  if(path.indexOf('/us/en/p/')===0) return pdpHTML(path);
  return '<div class="page-pad"><h1>Page not found</h1><p class="empty-note">This page is not part of the recorded slice. <a data-nav="/us/en/">Back to homepage</a></p></div>';
}

/* ---------------- header / mega ---------------- */
const MEGA = {
  'New & trending': {
    big:['Explore all new','Limited collections','Home accessories shop','IKEA for Business'],
    cols:[['Trending',['New products','Best sellers','Gift guide','IKEA Live Shopping']],
          ['Seasonal',['Fall decor shop','Halloween decor','Thanksgiving essentials','Explore all shops']],
          ['Food',['IKEA Swedish Restaurant & Bistro','IKEA Swedish Food Market','Food recipes']]],
    promo:{img:'/assets/media-027.jpg', text:'Game on with YXSTABY, our new XBOX collab, available in store now'}
  },
  'Winter holiday shop': {
    big:['Explore winter holiday','Holiday decor','Holiday lighting','Gift ideas'],
    cols:[['Decor',['Christmas trees','Ornaments','Holiday textiles']],['Table',['Dinnerware','Glassware','Serveware']],['More',['Gift wrap','Candles','Seasonal plants']]],
    promo:{img:'/assets/media-075.jpg', text:'Get cozy for the holidays'}
  },
  'Storage & organization': {
    big:['Explore storage & organization','New storage & organization','Best selling storage & organization','Financing options','IKEA for Business'],
    cols:[['',['Dressers & storage drawers','Shelving furniture','Storage solution systems','Display & storage cabinets','Armoires & wardrobes','TV & media furniture','Living room & entryway tables','Rolling utility & storage carts','Garage storage solutions','Outdoor storage: shelves, cabinets & boxes','Room dividers']],
          ['',['Hallway furniture sets','Filing cabinets','Shoe cabinets','Kids storage & organization']]],
    promo:{img:'/assets/media-087.jpg', text:'Shop our newest arrivals'}
  },
  'Sofas & armchairs': { big:['Explore sofas & armchairs','Fabric sofas','Leather sofas','Armchairs'], cols:[['',['Sofa beds','Sectionals','Loveseats']],['',['Chaise lounges','Ottomans','Sofa covers']]], promo:{img:'/assets/media-035.jpg', text:'Shop our newest arrivals'} },
  'Beds & mattresses': { big:['Explore beds & mattresses','Bed frames','Mattresses'], cols:[['',['Bedding','Duvets & pillows','Bedside tables']],['',['Wardrobes','Chests of drawers','Bedroom lighting']]], promo:{img:'/assets/media-101.jpg', text:'Shop our newest arrivals'} },
  'Lighting': { big:['Explore lighting','Table lamps','Floor lamps'], cols:[['',['Pendant lamps','Wall lamps','LED bulbs']],['',['Smart lighting','Decorative lighting','Children\'s lighting']]], promo:{img:'/assets/media-036.jpg', text:'Shop our newest arrivals'} },
  'Kitchen, appliances & supplies ›': { big:['Explore kitchen','Kitchen cabinets','Appliances'], cols:[['',['Cookware','Tableware','Food storage']],['',['Kitchen islands','Taps & sinks','Kitchen lighting']]], promo:{img:'/assets/media-031.jpg', text:'Shop our newest arrivals'} }
};
function megaHTML(){
  const tabs = Object.keys(MEGA);
  const t = MEGA[ui.megaTab] || MEGA[tabs[0]];
  let cols = '';
  t.cols.forEach(c=>{ cols += '<div class="mega-col">'+(c[0]?'<h5>'+esc(c[0])+'</h5>':'')+c[1].map(l=>'<a data-nav="/us/en/search/?q=besta">'+esc(l)+'</a>').join('')+'</div>'; });
  return '<div class="mega-tabs">'+tabs.map(k=>'<button class="mega-tab'+(k===ui.megaTab?' on':'')+'" data-action="mega-tab" data-tab="'+esc(k)+'">'+esc(k)+'</button>').join('')+'</div>'
    + '<div class="mega-body"><div class="mega-col big">'+t.big.map(l=>'<a data-nav="/us/en/search/?q=besta">'+esc(l)+'</a>').join('')+'</div>'+cols
    + '<div class="mega-promo" data-nav="/us/en/search/?q=besta"><img src="'+t.promo.img+'" alt=""><div class="mp-t">'+esc(t.promo.text)+'</div></div></div>';
}
function headerHTML(){
  const onSearch = CUR.path.indexOf('/us/en/search')===0;
  const q = onSearch ? (CUR.params.get('q')||'') : '';
  const n = bagCount();
  return ''
  + '<div class="topbar">'
  +   '<div class="tb-left">'+I.globe+'<span>US&nbsp; | &nbsp;English</span></div>'
  +   '<div class="tb-center">'+I.bag+'<span>Shop new arrivals</span></div>'
  +   '<div class="tb-right">'
  +     '<span class="tb-item" data-action="open-zip">'+I.truck+'<span>'+(S.zip?esc(S.zip):'Enter ZIP code')+'</span></span>'
  +     '<span class="tb-item" data-action="open-store">'+I.store+'<span>'+(S.store?esc(S.store):'Select store')+'</span></span>'
  +   '</div>'
  + '</div>'
  + '<header class="mainhead">'
  +   '<a class="logo" data-nav="/us/en/">'+I.logo+'</a>'
  +   '<nav class="mainnav">'
  +     '<button class="navlink'+(ui.megaOpen?' active':'')+'" data-action="products-toggle">Products</button>'
  +     '<button class="navlink">Rooms</button><button class="navlink">Deals</button>'
  +     '<button class="navlink">Design &amp; ideas</button><button class="navlink">Services</button>'
  +   '</nav>'
  +   '<div class="searchbox">'
  +     I.search.replace('<svg','<svg class="s-icon"')
  +     '<input id="header-search" placeholder="What are you looking for?" value="'+esc(q)+'" autocomplete="off" spellcheck="false">'
  +     '<button class="s-clear'+(q?'':' hidden')+'" data-action="search-clear" title="Clear">✕</button>'
  +     '<button class="s-go" data-action="search-submit" title="Search">'+I.search+'</button>'
  +     '<div id="suggest" class="suggest hidden"></div>'
  +   '</div>'
  +   '<div class="head-right">'
  +     '<a class="login">'+I.user+'<span>Hej! Log in or sign up</span></a>'
  +     '<button class="icon-btn" title="Favorites">'+I.heart+'</button>'
  +     '<button class="icon-btn" data-nav="/us/en/bag/" title="Shopping bag">'+I.bag+'<span id="bag-badge" class="badge'+(n?'':' hidden')+'">'+n+'</span></button>'
  +   '</div>'
  + '</header>'
  + '<div id="mega" class="mega'+(ui.megaOpen?' open':'')+'">'+megaHTML()+'</div>';
}
function cookieHTML(){
  if(S.cookie) return '';
  return '<div class="cookie" id="cookie"><p>IKEA US and our digital partners use cookies on this site. Some are strictly necessary to run the site and others are used for measuring site usage, enabling personalization and for advertising, marketing, and social media. View our <a>Privacy Policy</a>, <a>California Notice at Collection</a>, and <a>Cookie Policy</a> for more information.</p>'
  + '<div class="cookie-btns"><button class="btn-dark" data-action="cookie-pref">Your privacy choices</button><button class="btn-dark" data-action="cookie-ok">Ok</button></div></div>';
}
function footerHTML(){
  const pays = ['/assets/media-121.svg','/assets/media-122.svg','/assets/media-123.svg','/assets/media-124.svg','/assets/media-125.svg','/assets/media-126.svg','/assets/media-127.svg','/assets/media-128.svg','/assets/media-129.svg','/assets/media-130.svg','/assets/media-131.svg','/assets/media-132.svg','/assets/media-133.svg'];
  return '<footer class="footer"><div class="footer-cols">'
  + '<div><h5>IKEA Family</h5><a>Join IKEA Family</a><a>Member offers</a><a>Workshops &amp; events</a></div>'
  + '<div><h5>Customer services</h5><a>My orders</a><a>Return policy</a><a>Delivery information</a><a>Contact us</a></div>'
  + '<div><h5>About IKEA</h5><a>This is IKEA</a><a>Careers</a><a>Newsroom</a><a>Sustainability</a></div>'
  + '<div><h5>Shop &amp; learn</h5><a data-nav="/us/en/search/?q=besta">BESTÅ storage system</a><a>Planning tools</a><a>Services</a></div>'
  + '</div><div class="footer-bottom"><div class="pay-icons">'+pays.map(p=>'<img src="'+p+'" alt="">').join('')+'</div>'
  + '<p>© Inter IKEA Systems B.V. 1999-2026 &nbsp;|&nbsp; Privacy &nbsp;|&nbsp; Cookie &nbsp;|&nbsp; Terms &nbsp;|&nbsp; Recorded-slice demo</p></div></footer>';
}

/* ---------------- home ---------------- */
function homeHTML(){
  const pills = [
    ['Deals','/assets/media-353.jpg'],['Winter holiday shop','/assets/media-084.jpg'],
    ['Storage & organization','/assets/media-243.jpg'],['Sofas & armchairs','/assets/media-035.jpg'],
    ['Beds & mattresses','/assets/media-092.jpg'],['Lighting','/assets/media-036.jpg'],
    ['Kitchen, appliances & supplies','/assets/media-031.jpg']
  ];
  const series = [
    ['BESTÅ sideboards','/assets/media-329.jpeg'],['BESTÅ basic storage units','/assets/media-330.jpeg'],
    ['BESTÅ storage combinations','/assets/media-331.jpeg'],['BESTÅ TV benches','/assets/media-332.jpeg'],
    ['BESTÅ legs','/assets/media-344.jpeg'],['BESTÅ fittings & inside organizers','/assets/media-345.jpeg'],
    ['BESTÅ top panels','/assets/media-346.jpeg'],['BESTÅ doors & drawer fronts','/assets/media-347.jpeg']
  ];
  return ''
  + '<div class="pills">'+pills.map(p=>'<span class="pill" data-nav="/us/en/search/?q=besta"><img src="'+p[1]+'" alt="">'+esc(p[0])+'</span>').join('')+'</div>'
  + '<div class="hero">'
  +   '<div class="hero-big" data-nav="/us/en/search/?q=besta"><img src="/assets/kitchen-video-still.jpg" alt=""><span class="tag-fam">IKEA Family price</span><span class="pause-btn">'+I.pause+'</span></div>'
  +   '<div class="hero-r">'
  +     '<div class="hero-tile" data-nav="/us/en/search/?q=besta"><img src="/assets/media-114.jpg" alt=""><span class="tag-new">New</span><div class="hero-cap"><span>New, must-try kitchen accessories</span>'+I.arrow+'</div></div>'
  +     '<div class="hero-b">'
  +       '<div class="hero-tile"><img src="/assets/media-025.jpg" alt=""></div>'
  +       '<div class="hero-tile"><img src="/assets/media-026.jpg" alt=""></div>'
  +     '</div>'
  +   '</div>'
  + '</div>'
  + '<div class="home-sec"><h2>Explore the BESTÅ storage system</h2><div class="series-grid">'
  + series.map(s=>'<div class="series-tile" data-nav="/us/en/search/?q=besta"><img src="'+s[1]+'" alt=""><div class="st-t">'+esc(s[0])+'</div></div>').join('')
  + '</div></div>';
}

/* ---------------- listing ---------------- */
function isWhite(it){ return (String(it.color)+' '+it.description+' '+it.route).toLowerCase().indexOf('white')>=0; }
function searchItems(params){
  const q = (params.get('q')||'').toLowerCase();
  let items = CAT.catalog.filter(it=> !q || (it.name+' '+it.description+' '+it.route).toLowerCase().indexOf(q)>=0);
  if(params.get('color')==='white') items = items.filter(isWhite);
  const sort = params.get('sort')||'best';
  if(sort==='price-asc') items = items.slice().sort((a,b)=>a.member_price-b.member_price);
  else if(sort==='price-desc') items = items.slice().sort((a,b)=>b.member_price-a.member_price);
  else if(sort==='rating') items = items.slice().sort((a,b)=>(b.rating||0)-(a.rating||0));
  else if(sort==='name') items = items.slice().sort((a,b)=>(a.name+a.description).localeCompare(b.name+b.description));
  return items;
}
function searchURL(q, color, sort){
  let u = '/us/en/search/?q='+encodeURIComponent(q||'');
  if(color) u += '&color='+color;
  if(sort && sort!=='best') u += '&sort='+sort;
  return u;
}
function facetRow(key, label, body, extra){
  const open = ui.facets.has(key);
  return '<div class="facet'+(open?' open':'')+'"><button class="facet-head" data-action="facet" data-f="'+key+'"><span>'+label+'</span>'+(extra||'')+I.chevD+'</button>'
  + '<div class="facet-body">'+body+'</div></div>';
}
function placeholderFacet(key,label,rows){
  return facetRow(key,label,'<div class="facet-placeholder">'+rows.map(r=>'<div class="ph-row"><span>'+r[0]+'</span><span>'+r[1]+'</span></div>').join('')+'</div>');
}
function searchHTML(params){
  const q = params.get('q')||'';
  const color = params.get('color');
  const sort = params.get('sort')||'best';
  const items = searchItems(params);
  const isBesta = q.toLowerCase().indexOf('besta')>=0;
  const count = isBesta ? (color==='white' ? CAT.search_snapshot.white_results : CAT.search_snapshot.total_results) : items.length;
  /* facets */
  const sortBody = SORTS.map(s=>'<label class="sort-opt"><span>'+s[1]+'</span><input type="radio" name="sort" value="'+s[0]+'"'+(sort===s[0]?' checked':'')+'></label>').join('');
  const colorBody = '<div class="swatches">'+COLORS.map(c=>{
    const sel = color==='white' && c[0]==='White';
    const dis = c[0]!=='White';
    return '<div class="swatch'+(sel?' on':'')+(dis?' dis':'')+'" '+(dis?'':'data-action="color-pick" data-color="white"')+'><span class="swc" style="background:'+c[1]+'"></span><span>'+c[0]+'</span><span class="cnt">'+c[2]+'</span></div>';
  }).join('')+'</div>';
  const facets =
    facetRow('sort','Sort',sortBody)
    + placeholderFacet('size','Size',[['Width 23 5/8 "','38'],['Width 47 1/4 "','29'],['Width 70 7/8 "','21']])
    + facetRow('color','Color',colorBody)
    + placeholderFacet('type','Type',[['Storage combination','42'],['Frame','23'],['Shelving unit','15']])
    + placeholderFacet('category','Category',[['Sideboards','18'],['TV benches','22'],['Cabinets','31']])
    + '<div class="facet"><div class="facet-head" style="cursor:default"><span>Smart home</span><span class="fh-count">'+(color==='white'?3:5)+'</span><span class="fh-box"></span></div></div>'
    + placeholderFacet('material','Material',[['Particleboard','54'],['Solid wood','12'],['Glass','8']])
    + placeholderFacet('doors','Doors',[['With doors','39'],['Without doors','48']])
    + placeholderFacet('features','Features',[['Soft closing','21'],['Push-open','17'],['Adjustable shelves','33']])
    + placeholderFacet('price','Price',[['$0 - $50','24'],['$50 - $150','38'],['$150+','25']])
    + placeholderFacet('finish','Finish',[['Foil','31'],['Veneer','19'],['High-gloss','9']])
    + placeholderFacet('rating','Customer rating',[['4★ & up','44'],['3★ & up','61']]);
  /* compare bar */
  let cmpBar='';
  if(S.compare.length){
    cmpBar = '<div class="cmp-bar"><span class="cmp-close" data-action="cmp-close">Close</span>'
    + '<span class="cmp-right"><span>'+S.compare.length+'/5 selected</span><span class="cmp-thumbs">'
    + S.compare.map(id=>{ const it=findItem(id); return it?'<img src="'+it.image+'" alt="">':''; }).join('')
    + '</span><button class="btn-blackpill" data-action="cmp-go">Compare products</button></span></div>';
  }
  const chip = color==='white' ? '<div class="chips"><span class="chip" data-action="chip-clear">white <b>✕</b></span></div>' : '';
  const grid = items.map(it=>productCard(it,{compare:true})).join('');
  return ''
  + '<div class="help-banner">Need help planning your BESTÅ system? Our storage experts can help at 1-888-888-4532, 8AM-11:59PM EST.</div>'
  + '<div class="list-head"><h1>'+count+' items for "'+esc(q)+'"</h1>'
  + '<div class="design-card">'+I.pencil+'<span><b>Design your own BESTÅ storage</b><u>Get started</u></span></div></div>'
  + '<div class="list-body"><aside class="facets">'+facets+'</aside>'
  + '<div class="list-main">'+cmpBar+chip+'<div class="grid">'+grid+'</div></div></div>';
}
function productCard(it, opts){
  opts = opts||{};
  const fav = S.favs.indexOf(it.id)>=0;
  const inCmp = S.compare.indexOf(it.id)>=0;
  const p = pct(it.regular_price, it.member_price);
  return '<div class="card">'
  + (opts.compare?'<label class="cmp"><input type="checkbox" class="cmp-cb" data-id="'+it.id+'"'+(inCmp?' checked':'')+'><span>Compare</span></label>':'')
  + '<div class="card-img" data-nav="'+it.route+'">'
  + (BEST_SELLER.has(it.id)?'<span class="badge-best">Best seller</span>':'')
  + '<img src="'+it.image+'" alt="" loading="lazy">'
  + '<button class="heart'+(fav?' on':'')+'" data-action="fav" data-id="'+it.id+'">'+I.heart+'</button></div>'
  + '<div class="card-body">'
  + (it.member_price<it.regular_price?'<div class="fam-label">IKEA Family price</div>':'')
  + '<a class="card-name" data-nav="'+it.route+'">'+esc(it.name)+'</a>'
  + '<div class="card-desc">'+esc(it.description)+'</div>'
  + '<div class="price-row"><span class="price">'+money(it.member_price)+'</span>'
  + '<button class="cart-btn" data-action="add" data-id="'+it.id+'" title="Add to bag">'+I.bagAdd+'</button></div>'
  + (it.member_price<it.regular_price?'<div class="save-line">'+p+'% off, save '+money(it.regular_price-it.member_price)+'</div><div class="reg-line">Regular price '+money(it.regular_price)+'</div><div class="valid-line">Price valid Oct 7, 2026 - Nov 11, 2026 or while supply lasts</div>':'')
  + '<div class="rating-row">'+stars(it.rating||3.7)+'<span class="rc">('+(it.review_count||0)+')</span></div>'
  + '<div class="more-opt">More options</div>'
  + '</div></div>';
}

/* ---------------- compare page ---------------- */
function compareHTML(){
  const items = S.compare.map(findItem).filter(Boolean);
  if(!items.length){
    return '<div class="page-pad"><h1>Product comparison</h1><p class="empty-note">You haven\'t selected any products to compare yet. <a data-nav="/us/en/search/?q=besta">Browse BESTÅ products</a></p></div>';
  }
  const cards = items.map(it=>{
    const fav = S.favs.indexOf(it.id)>=0;
    const p = pct(it.regular_price, it.member_price);
    return '<div class="compare-card"><button class="rm-btn" data-action="compare-remove" data-id="'+it.id+'">✕</button>'
    + '<div class="card-img" data-nav="'+it.route+'"><img src="'+it.image+'" alt=""><button class="heart'+(fav?' on':'')+'" data-action="fav" data-id="'+it.id+'">'+I.heart+'</button></div>'
    + '<div class="card-body"><div class="fam-label">IKEA Family price</div>'
    + '<a class="card-name" data-nav="'+it.route+'">'+esc(it.name)+'</a><div class="card-desc">'+esc(it.description)+'</div>'
    + '<div class="price-row"><span class="price">'+money(it.member_price)+'</span><button class="cart-btn" data-action="add" data-id="'+it.id+'">'+I.bagAdd+'</button></div>'
    + '<div class="save-line">'+p+'% off, save '+money(it.regular_price-it.member_price)+'</div>'
    + '<div class="reg-line">Regular price '+money(it.regular_price)+'</div><div class="valid-line">Price valid Oct 7, 2026 - Nov 11, 2026 or while supply lasts</div>'
    + '<div class="rating-row">'+stars(it.rating||4)+'<span class="rc">('+(it.review_count||0)+')</span></div></div></div>';
  }).join('');
  const feats = [['Width','width'],['Height','height'],['Depth','depth']];
  const kf = feats.map(f=>'<div class="kf-row">'+items.map(it=>{
    const d = DIMS[it.id];
    return '<div class="kf-cell"><b>'+f[0]+'</b>'+(d?d[f[1]]+' "':'—')+'</div>';
  }).join('')+'</div>').join('');
  return '<div class="page-pad"><h1>Product comparison</h1><div class="compare-cards">'+cards+'</div>'
  + '<div class="kf-title">Key features</div>'+kf+'</div>';
}

/* ---------------- PDP ---------------- */
function crumbsHTML(list){
  return '<div class="crumbs">'+list.map((c,i)=>{
    const last = i===list.length-1;
    return (i?'<span class="sep">›</span>':'')+(last?'<span class="cur">'+esc(c)+'</span>':'<a data-nav="/us/en/search/?q=besta">'+esc(c)+'</a>');
  }).join('')+'</div>';
}
function galleryFor(item){
  let g = item.gallery ? item.gallery.slice() : [item.image];
  if(item.components && g.indexOf('/assets/media-317.jpg')<0) g.push('/assets/media-317.jpg');
  return g;
}
function galleryHTML(item){
  const g = galleryFor(item);
  const idx = Math.min(ui.pdpImg[item.id]||0, g.length-1);
  const thumbs = g.map((src,i)=>{
    const isVid = src.indexOf('media-312')>=0;
    return '<div class="thumb'+(i===idx?' on':'')+'" data-action="pdp-thumb" data-id="'+item.id+'" data-i="'+i+'"><img src="'+src+'" alt="">'+(isVid?'<span class="playb"><span>'+I.play+'</span></span>':'')+'</div>';
  }).join('');
  return '<div class="thumbs">'+thumbs+'</div>'
  + '<div class="main-img"><img src="'+g[idx]+'" alt="" data-action="open-media" data-id="'+item.id+'">'
  + '<div class="media-btns"><button class="pill-dark" data-action="open-media" data-id="'+item.id+'">'+I.media+'All media</button>'
  + '<button class="pill-dark" data-action="view-3d">'+I.cube+'View in 3D</button></div></div>';
}
function howtoHTML(){
  if(!S.zip){
    return '<div class="howto"><div class="sec-label">How to get it</div>'
    + '<div class="check-avail" data-action="open-zip"><span class="dot-ga"></span><u>Check delivery and in-stock availability</u></div></div>';
  }
  const store = S.store||'IKEA East Palo Alto, CA';
  return '<div class="howto"><div class="sec-label">How to get it</div>'
  + '<div class="avail-row">'+I.store+'<span><span class="dot-g"></span><b>In stock in <a data-action="open-store">IKEA '+esc(store)+'</a></b><div class="sub">Opens at 10:00 AM</div><a data-action="find-store">Find in store</a></span></div>'
  + '<div class="avail-row">'+I.store+'<span><span class="dot-g"></span><b>Click and collect at <a data-action="open-store">IKEA '+esc(store)+'</a></b><div class="sub">From $2.00 or <span style="color:#0076c1;font-weight:700">Free with IKEA Family</span></div></span></div>'
  + '<div class="avail-row">'+I.truck+'<span><span class="dot-g"></span><b>Home delivery to <a data-action="open-zip">'+esc(S.zip)+'</a></b></span></div></div>';
}
function priceBlockPDP(item, opts){
  opts = opts||{};
  const p = pct(item.regular_price, item.member_price);
  const fav = S.favs.indexOf(item.id)>=0;
  let price = '<span class="price blue" style="font-size:26px">'+money(item.member_price)+(opts.suffix?'<span class="pk">'+opts.suffix+'</span>':'')+'</span>';
  return '<div class="fam-label">IKEA Family price</div>'
  + '<div class="pdp-title">'+esc(item.name)+'</div>'
  + '<div class="pdp-desc">'+descWithDims(item.description)+'</div>'
  + '<div class="pdp-price">'+price+'</div>'
  + '<div class="pdp-save">'+p+'% off, save '+money(item.regular_price-item.member_price)+'</div>'
  + '<div class="pdp-reg">Regular price: '+money(item.regular_price)+(opts.suffix||'')+'</div>'
  + '<div class="pdp-valid">Price valid Oct 7, 2026 - Nov 11, 2026 or while supply lasts</div>'
  + '<div class="pdp-rating" data-action="open-reviews" data-id="'+item.id+'">'+stars(item.rating||3.7)+'<span class="rc">('+(item.review_count||123)+')</span></div>'
  + '<button class="heart pdp-fav'+(fav?' on':'')+'" data-action="fav" data-id="'+item.id+'">'+I.heart+'</button>';
}
function descWithDims(desc){
  const m = String(desc).match(/^(.*?)(,\s*[\d .\/x"]+\")\s*$/);
  if(m) return esc(m[1])+', <u>'+esc(m[2].slice(2))+'</u>';
  return esc(desc);
}
function stepperHTML(item){
  const q = ui.pdpQty[item.id]||1;
  return '<div class="qty-stepper"><button data-action="qty-dec" data-id="'+item.id+'"'+(q<=1?' class="dis"':'')+'>−</button><span class="qv" id="pdp-qv">'+q+'</span><button data-action="qty-inc" data-id="'+item.id+'">+</button></div>';
}
function addBtnHTML(item){
  const q = ui.pdpQty[item.id]||1;
  return '<button class="add-btn" data-action="pdp-add" data-id="'+item.id+'" id="pdp-add-btn">'+(q>1?'Add '+q+' items to cart':'Add to bag')+'</button>';
}
function pointsHTML(pts){
  return '<div class="points-box"><span class="pk-ic">'+I.key+'</span><span><b>Collect '+pts+' points with <span class="fam-link">IKEA Family</span></b><br><a>Join for free or log in</a> &nbsp;|&nbsp; <a>Explore what you can get</a></span></div>';
}
function mindHTML(){
  return '<div class="mind-box"><b>It\'s OK to change your mind '+I.heart+'</b><p>Return within 365 days for a full refund*. <a>Learn more</a></p></div>'
  + '<div class="mind-box" style="border-top:none;padding-top:0"><b>Low Price Guarantee '+I.check+'</b><p>Price drops? Get the difference back within 90 days with <span style="color:#0076c1;font-weight:700">IKEA Family</span></p></div>';
}
function payBoxHTML(total){
  return '<div class="pay-box"><h4>More ways to pay</h4>'
  + '<div class="pay-row"><b>$ Afterpay</b><span><p>4 interest-free payments of $'+Math.ceil(total/4)+' + tax</p></span></div>'
  + '<div class="pay-row"><b>IKEA Visa Credit Card</b><span><p>Earn 5% in rewards at IKEA using the IKEA Visa Credit Card*.</p></span></div></div>';
}
function swatchesHTML(list, currentImg){
  return '<div class="sw-grid">'+list.map(s=>{
    const on = s.img===currentImg;
    const inner = '<img src="'+s.img+'" alt="">';
    return s.route ? '<a class="sw'+(on?' on':'')+'" data-nav="'+s.route+'">'+inner+'</a>'
                   : '<span class="sw dis'+(on?' on':'')+'">'+inner+'</span>';
  }).join('')+'<span class="sw-more">+12</span></div>';
}
function revSectionHTML(item){
  return '<div class="pdp-sec" id="sec-reviews"><div class="rev-sec"><div class="rs-l">Customer reviews</div>'
  + '<div class="rs-r"><span><span class="rev-big">'+(item.rating||3.7)+'</span><br>'+stars(item.rating||3.7)+'<div class="rev-sub">Average rating</div></span>'
  + '<span><span class="rev-big">'+(item.review_count||123)+'</span><br><span class="rev-sub">Reviews</span></span>'
  + '<button class="btn-outline" data-action="open-reviews" data-id="'+item.id+'">Show all reviews</button></div></div></div>';
}
function accessoriesHTML(){
  return '<div class="pdp-sec"><div class="acc-head-row"><h3>Accessories for BESTÅ</h3><button class="btn-blackpill" data-nav="/us/en/search/?q=besta">Show all accessories</button></div>'
  + '<div class="acc-row">'+ACCESSORIES.map(a=>'<div class="acc-card"><img src="'+a.img+'" alt=""><div class="an">'+a.name+'</div><div class="ad">'+esc(a.desc)+'</div><div class="ap">'+money(a.regular)+'</div><button class="cart-btn" data-action="reco-add" data-id="'+a.id+'">'+I.bagAdd+'</button></div>').join('')+'</div></div>';
}
function measSectionHTML(){
  return '<div class="pdp-sec" id="sec-measurements"><div class="meas-wrap"><img src="/assets/media-317.jpg" alt="">'
  + '<div><div class="acc open"><button class="acc-head" data-action="acc-toggle">Measurements '+I.chevD+'</button><div class="acc-body"><table class="meas-table">'
  + '<tr><td class="k">Width</td><td class="v">47 1/4 "</td><td class="k">Depth</td><td class="v">16 1/2 "</td></tr>'
  + '<tr><td class="k">Height</td><td class="v">29 1/8 "</td><td class="k">Max load/shelf</td><td class="v">44 lb</td></tr>'
  + '</table></div></div>'
  + '<div class="acc"><button class="acc-head" data-action="acc-toggle">Packaging '+I.chevD+'</button><div class="acc-body"><p class="muted">This product comes as 6 packages.</p></div></div>'
  + '</div></div></div>';
}
function includedHTML(item){
  const parts = INCLUDED[item.id]||[];
  return '<div class="pdp-sec" id="sec-included"><p class="lead">This product is made up of more than one component. You can find the details of these components below.</p>'
  + '<div class="incl-wrap"><div class="incl-grid">'+parts.map(p=>{
    const inner = '<img src="'+p.img+'" alt=""><span><b>'+p.qty+' x '+esc(p.type)+'</b><span class="n2">'+esc(p.name)+'</span><br><span class="d">'+esc(p.dims)+'</span><br><span class="art-chip">'+p.art+'</span></span>';
    return p.link ? '<a class="incl-card link" data-nav="'+p.link+'">'+inner+'</a>' : '<div class="incl-card">'+inner+'</div>';
  }).join('')+'</div><div class="incl-side"><img src="'+item.image+'" alt=""></div></div></div>';
}
function tabsHTML(hasIncluded){
  const tabs = [['Overview','sec-overview'],['Product details','sec-details'],['Measurements','sec-measurements']];
  if(hasIncluded) tabs.push(['What\'s included','sec-included']);
  return '<div class="pdp-tabs">'+tabs.map((t,i)=>'<span class="pdp-tab'+(i===0?' on':'')+'" data-action="tab-scroll" data-t="'+t[1]+'">'+t[0]+'</span>').join('')+'</div>';
}
function pdpHTML(path){
  const item = findByRoute(path);
  if(!item) return '<div class="page-pad"><h1>Product not found</h1><p class="empty-note">This product is not part of the recorded catalog slice. <a data-nav="/us/en/search/?q=besta">Back to search</a></p></div>';
  document.title = item.name+' '+item.description.slice(0,40)+' - IKEA';
  const isCombo = !!item.components;
  const isLeg = item.id==='20293568';
  /* breadcrumbs */
  let crumbs;
  if(isLeg) crumbs = ['Products','Storage & organization','Storage solution systems','BESTÅ storage system','BESTÅ all parts & accessories','BESTÅ legs','STUBBARP Leg'];
  else if(item.name==='STUBBARP') crumbs = ['Products','Storage & organization','Storage solution systems','BESTÅ storage system','BESTÅ all parts & accessories','BESTÅ legs','STUBBARP Leg'];
  else if(isCombo) crumbs = ['Products','Storage & organization','Storage solution systems','BESTÅ storage system','BESTÅ sideboards','BESTÅ Storage combination with doors'];
  else crumbs = ['Products','Storage & organization','Storage solution systems','BESTÅ storage system','BESTÅ frames',item.name+' '+item.description.split(',')[0]];
  let info = '<div class="pdp-info info-wrap">'+priceBlockPDP(item,{suffix:isLeg?'/2 pack':''});
  if(isCombo){
    info += '<div class="note-row">'+I.info+'<span>Knobs and handles are sold separately.</span></div>';
    info += '<div class="sec-label">Choose color</div><div class="sec-sub">'+esc(item.color)+'</div>';
    info += swatchesHTML(COMBO_SW, item.image);
    info += '<div class="diy"><span><b>Design it yourself</b><span>Customise BESTÅ in our planning tool</span></span>'+I.ext+'</div>';
    info += howtoHTML();
    info += '<button class="add-btn" data-action="pdp-add" data-id="'+item.id+'">Add to bag</button>';
    info += '<div class="service-box">'+I.wrench+'<span>Have your BESTÅ professionally assembled for <b>'+money(item.assembly_per_unit)+'</b>. <a>Learn more</a></span></div>';
    info += pointsHTML(Math.round(item.member_price)) + mindHTML() + payBoxHTML(item.member_price);
  } else if(isLeg){
    info += '<div class="note-row">'+I.info+'<span>BESTÅ supporting leg sold separately.</span></div>';
    info += '<div class="sec-label">Choose color</div><div class="sec-sub">White stained oak effect</div>';
    info += '<div class="sw-grid">'+LEG_SW.map(s=> s.route ? '<a class="sw'+(s.img===item.image?' on':'')+'" data-nav="'+s.route+'"><img src="'+s.img+'" alt=""></a>' : '<span class="sw dis"><img src="'+s.img+'" alt=""></span>').join('')+'</div>';
    info += howtoHTML();
    info += '<div class="buy-row">'+stepperHTML(item)+addBtnHTML(item)+'</div>';
    info += pointsHTML(Math.round(item.member_price)) + mindHTML();
  } else {
    info += '<div class="note-row">'+I.info+'<span>Sold separately: knobs, handles and suspension rail.</span></div>';
    info += howtoHTML();
    info += '<div class="buy-row">'+stepperHTML(item)+addBtnHTML(item)+'</div>';
    info += pointsHTML(Math.round(item.member_price)) + mindHTML();
  }
  info += '</div>';
  let lower = '';
  if(isCombo){
    lower = tabsHTML(true)
    + '<div class="pdp-sec" id="sec-overview"><p class="lead">BESTÅ storage system lets you create exactly the solution you need – the frames, doors, drawers and interior organizers can be combined in almost endless ways, and you can change or add to your solution whenever you like.</p></div>'
    + '<div class="pdp-sec" id="sec-details"><div class="acc open"><button class="acc-head" data-action="acc-toggle">Product details '+I.chevD+'</button><div class="acc-body"><table class="meas-table"><tr><td class="k">Article number</td><td class="v">'+artNo(item.id)+'</td></tr><tr><td class="k">Color</td><td class="v">'+esc(item.color)+'</td></tr><tr><td class="k">Care instructions</td><td class="v">Wipe clean with a damp cloth</td></tr></table></div></div></div>'
    + measSectionHTML() + includedHTML(item) + revSectionHTML(item) + accessoriesHTML();
  } else {
    lower = revSectionHTML(item) + (item.name.indexOf('BESTÅ')>=0 ? accessoriesHTML() : '');
  }
  return crumbsHTML(crumbs) + '<div class="pdp">'+galleryHTML(item)+info+'</div>' + lower;
}

/* ---------------- shopping bag ---------------- */
function bagLineHTML(it){
  const line = it.regular*it.qty;
  const p = it.member<it.regular ? pct(it.regular,it.member) : 0;
  const favRoute = it.route || null;
  let asm = '';
  if(it.asmFee){
    const fee = it.asmFee*it.qty;
    const star = fee < 52 ? '*' : '';
    asm = '<div class="asm-row">'+I.wrench+'<span><a>Assembly by Taskrabbit</a> for '+esc(it.name)+(it.qty>1?' ('+it.qty+')':'')+'</span><span class="asm-p">'+money(fee)+star+'</span><input type="checkbox" class="asm-cb" data-id="'+it.id+'"'+(it.asm?' checked':'')+'></div>';
    if(fee < 52) asm += '<div class="asm-note">*Minimum fee for assembly service is $52.00. <a>Learn more</a></div>';
  }
  return '<div class="bag-line">'
  + '<div class="bl-img">'+(favRoute?'<img src="'+it.img+'" alt="" data-nav="'+favRoute+'">':'<img src="'+it.img+'" alt="">')+'<div class="art">'+artNo(it.id)+'</div></div>'
  + '<div class="bl-info">'
  +   (favRoute?'<a class="bl-name" data-nav="'+favRoute+'">'+esc(it.name)+'</a>':'<span class="bl-name">'+esc(it.name)+'</span>')
  +   '<div class="bl-desc">'+esc(it.desc)+'</div>'
  +   (it.member<it.regular?'<div class="bl-save">'+p+'% off, save '+money((it.regular-it.member)*it.qty)+' with IKEA Family</div>':'')
  +   (it.qty>1?'<div class="bl-piece">'+money(it.regular)+'/piece</div>':'')
  +   (it.isCombo?'<a class="bl-parts" data-action="show-parts" data-id="'+it.id+'">Show included parts</a>':'')
  +   '<div class="bl-avail"><div><span class="d"></span>Available for delivery</div><div><span class="d"></span>Available for Click &amp; collect</div><div><span class="d"></span>Available for Collect near you</div></div>'
  +   '<div class="bl-actions"><span class="sfl">Save for later</span><button class="trash" data-action="bag-remove" data-id="'+it.id+'" title="Remove">'+I.trash+'</button>'
  +   '<span class="qty-stepper"><button data-action="bag-dec" data-id="'+it.id+'"'+(it.qty<=1?' class="dis"':'')+'>−</button><span class="qv">'+it.qty+'</span><button data-action="bag-inc" data-id="'+it.id+'">+</button></span></div>'
  + '</div>'
  + '<div class="bl-price">'+money(line)+'</div></div>' + asm;
}
function bagHTML(){
  document.title = 'Shopping bag - IKEA';
  const t = bagTotals();
  const zip = S.zip, store = S.store||'East Palo Alto, CA';
  const lines = S.bag.map(bagLineHTML).join('');
  const left = S.bag.length ? lines : '<div class="bag-empty"><p>Your shopping bag is empty.</p><button class="btn-blackpill" data-nav="/us/en/search/?q=besta">Continue shopping</button></div>';
  const asmLine = t.asm>0 ? '<div class="sum-row"><span>Assembly service</span><span>'+money(t.asm)+'</span></div>' : '';
  const taskrabbit = t.asm>0 ? '<div class="taskrabbit">'+I.info+'<span><b>Assembly service by Taskrabbit</b>By purchasing assembly service by Taskrabbit you are directly interacting with Taskrabbit and direct IKEA to share your personal data with Taskrabbit for the purpose of providing you assembly service. In doing so, you agree that Taskrabbit will use your data to verify or create an account and provide its assembly services directly to you. Taskrabbit will process and use the personal data disclosed to it or that it collects in accordance with its Privacy Policy and Terms of Service. Follow the link for IKEA Assembly Terms and Taskrabbit\'s Privacy Policy &amp; Terms. <a>Learn more</a></span></div>' : '';
  const disc = '<div class="disc'+(ui.discOpen?' open':'')+'"><button class="disc-head" data-action="disc-toggle"><span class="dl">+<span>Apply discount code</span></span>'+I.chevD+'</button>'
  + '<div class="disc-body"><div class="disc-row"><input id="disc-input" class="'+(ui.discErr?'err':'')+'" placeholder="" autocomplete="off"><button class="btn-dark" data-action="disc-apply">Apply</button></div>'
  + (ui.discErr?'<div class="disc-err">'+I.err+'Please enter a valid discount code.</div>':'')
  + '<div class="disc-note">Enter the code without any space between letters. Gift cards can be exchanged later in the process.</div></div></div>';
  const pays = ['/assets/media-121.svg','/assets/media-122.svg','/assets/media-123.svg','/assets/media-124.svg','/assets/media-125.svg','/assets/media-126.svg','/assets/media-127.svg','/assets/media-128.svg','/assets/media-129.svg','/assets/media-130.svg','/assets/media-131.svg','/assets/media-132.svg','/assets/media-133.svg'];
  return '<div class="bag-wrap"><div class="bag-left"><h1>Shopping bag <span class="dots">•••</span></h1>'
  + '<div class="ful-cards">'
  + '<div class="ful-card"><div class="fc-t">'+I.truck+'Delivery to '+(zip?esc(zip):'your ZIP')+'</div><span class="dot-g"></span>Starting at $39.00<br>or <span class="fam-link">$29.00 with IKEA Family</span><div class="sub">Arrives Oct 27</div></div>'
  + '<div class="ful-card"><div class="fc-t">'+I.store+'Pick up at IKEA '+esc(store)+'</div><span class="dot-g"></span>$2.00 or <span class="fam-link">Free with IKEA Family</span><div class="sub">Get it tomorrow</div></div>'
  + '<div class="ful-card"><div class="fc-t">'+I.bag+'Collect at CRST/NorCal</div><span class="dot-g"></span>$14.00</div>'
  + '</div>'
  + '<div class="pickup-self">'+I.store.replace('viewBox','data-x viewBox')+'<a data-action="open-store">Pick up yourself at '+esc(store)+'</a></div>'
  + left + '</div>'
  + '<div class="summary"><h2>Order summary</h2>'
  + '<div class="sum-row"><span>Products</span><span>'+money(t.products)+'</span></div>'
  + '<div class="ship-note">Shipping costs are calculated at checkout</div>'
  + asmLine
  + '<div class="sum-row total"><span class="tt">Total excluding tax</span><span class="tv">'+money(t.total)+'</span></div>'
  + '<div class="pay-snippet"><b>$ Afterpay</b><p>4 interest-free payments of $'+Math.ceil(t.total/4)+' + tax <a>Learn more</a></p></div>'
  + '<div class="pay-snippet" style="border-top:none;padding-top:0"><b>IKEA Visa Credit Card</b><p>Earn 5% in rewards at IKEA using the IKEA Visa Credit Card*. <a>Learn more</a></p></div>'
  + taskrabbit
  + '<div class="fam-save"><img src="/assets/media-352.svg" alt="IKEA Family"><span><b>Save '+money(t.saveFam)+' with <span class="fam-link">IKEA Family</span></b><a>Join for free or log in</a></span></div>'
  + '<div class="pts-row"><span class="pk-ic">'+I.key+'</span><span><b>Collect '+t.points+' points with <span class="fam-link">IKEA Family</span></b><br><a>Explore what you can get</a></span></div>'
  + disc
  + '<button class="checkout-btn">Continue to checkout<span class="arr">'+I.arrow+'</span></button>'
  + '<div class="pay-icons">'+pays.map(p=>'<img src="'+p+'" alt="">').join('')+'</div>'
  + '<div class="fam-deliv">'+I.tag+'<span><b>IKEA Family members get discounted large item delivery -$10</b><br><a>Join for free or log in</a> &nbsp;|&nbsp; <a>Learn more</a></span></div>'
  + '<a class="ret-link">365-day worry-free return policy</a>'
  + '</div></div>'
  + '<div class="ess-wrap"><h2>Everyday essentials for you</h2><div class="ess-row">'
  + ESSENTIALS.map(e=>'<div class="ess-card"><img src="'+e.img+'" alt=""><div class="en">'+e.name+'</div><div class="ed">'+esc(e.desc)+'</div><span class="ep'+(e.sale?' yellow':'')+'">'+money(e.regular)+'</span><button class="cart-btn" data-action="reco-add" data-id="'+e.id+'">'+I.bagAdd+'</button><div class="ea"><div><span class="d"></span>Available for delivery</div><div><span class="d"></span>Available for Click &amp; collect</div></div></div>').join('')
  + '</div></div>';
}

/* ---------------- overlays ---------------- */
const overlayRoot = () => document.getElementById('overlay-root');
function closeOverlays(){ overlayRoot().innerHTML=''; }
function scrimHTML(){ return '<div class="scrim" data-action="close-overlays"></div>'; }

/* add-to-bag confirmation drawer */
function openAddDrawer(item, qtyAdded){
  const snap = snapshotOf(item);
  ui.drawerData = snap;
  const isCombo = !!item.components;
  const recos = isCombo ? RECO_COMBO : RECO_LEG;
  const t = bagTotals();
  const msg = qtyAdded>1 ? qtyAdded+' '+snap.name+' were added to your shopping bag.' : snap.name+' was added to your shopping bag.';
  const spend = t.products < 35 ? '<div class="spend">'+I.truck+'<span>Spend '+money(35-t.products)+' more to enable delivery and other pick-up options. <a>Learn more</a></span></div>' : '';
  overlayRoot().innerHTML = scrimHTML()
  + '<aside class="drawer"><button class="drawer-x" data-action="close-overlays">✕</button>'
  + '<div class="drawer-scroll"><div class="add-head"><span class="ah-img"><span class="check-green">'+I.check+'</span><img src="'+snap.img+'" alt=""></span>'
  + '<span class="ah-t"><span class="ah-row"><b>'+esc(snap.name)+'</b><span class="ah-p">'+money(snap.regular)+'</span></span><span class="ah-d">'+esc(snap.desc)+'</span></span></div>'
  + '<p class="add-msg">'+esc(msg)+'</p>'
  + '<div class="reco"><h3>You might also like</h3>'
  + recos.map(r=>{
      const fam = r.member<r.regular;
      return '<div class="reco-row"><img src="'+r.img+'" alt=""><span class="rr-b">'
      + (fam?'<div class="fam-label">IKEA Family price</div>':'')
      + '<span class="rn">'+esc(r.name)+'</span><div class="rd">'+esc(r.desc)+'</div>'
      + '<div class="rp">'+money(r.member)+(r.suffix?'<span class="pk">'+r.suffix+'</span>':'')+'</div>'
      + (fam?'<div class="rs">'+pct(r.regular,r.member)+'% off, save '+money(r.regular-r.member)+'</div><div class="rr">Regular price '+money(r.regular)+(r.suffix||'')+'</div><div class="rv">Price valid Oct 7, 2026 - Nov 11, 2026 or while supply lasts</div>':'')
      + '</span><span class="reco-acts"><button class="cart-btn" data-action="reco-add" data-id="'+r.id+'">'+I.bagAdd+'</button><button class="heart">'+I.heart+'</button></span></div>';
    }).join('')
  + '</div></div>'
  + '<div class="drawer-foot">'+spend+'<div class="drawer-btns"><button class="btn-outline" data-action="close-overlays">Continue shopping</button><button class="btn-blue" data-nav="/us/en/bag/">Go to shopping bag</button></div></div></aside>';
}

/* ZIP modal */
function openZip(){
  overlayRoot().innerHTML = scrimHTML()
  + '<aside class="drawer"><button class="drawer-x" data-action="close-overlays">✕</button>'
  + '<div class="drawer-scroll"><h2>Use your location</h2>'
  + '<p class="lead">Get updated information about product delivery and stock availability for your area.</p>'
  + '<label class="req"><span class="ast">*</span> Enter a Zip code</label>'
  + '<input id="zip-input" class="zip-input" autocomplete="off" maxlength="10" value="'+(S.zip||'')+'">'
  + '<div class="zip-hint" id="zip-hint">e.g. 19428</div>'
  + '<p class="zip-note">We use cookies to provide this service. Read more about how we use cookies in <a>our policy</a>. Please note that your location won\'t be shared.</p>'
  + '<button class="save-btn" data-action="zip-save">Save</button></div></aside>';
  setTimeout(()=>{ const i=$('#zip-input'); if(i) i.focus(); },50);
}
function saveZip(){
  const i = $('#zip-input'); const hint = $('#zip-hint');
  const v = (i.value||'').trim();
  if(!/^\d{5}$/.test(v)){
    i.classList.remove('ok'); i.classList.add('err');
    hint.className='zip-hint err'; hint.textContent='Enter a valid ZIP code.';
    return;
  }
  S.zip = v; save(); closeOverlays(); renderHead(); renderCurrentPage();
  if(!S.store) openStore();
}
/* store drawer */
function storeListHTML(f){
  const q = (f||'').toLowerCase();
  return STORES.filter(s=>!q || (s[0]+' '+s[1]).toLowerCase().indexOf(q)>=0)
    .map(s=>'<button class="store-row" data-action="store-pick" data-name="'+esc(s[0])+'"><b>'+esc(s[0])+'</b><span>'+esc(s[1])+'</span></button>').join('');
}
function openStore(){
  overlayRoot().innerHTML = scrimHTML()
  + '<aside class="drawer" style="width:460px"><button class="drawer-x" data-action="close-overlays">✕</button>'
  + '<div class="drawer-scroll"><h2>Select store</h2>'
  + '<p class="lead">Find your preferred store to learn about its opening hours, stock availability, and relevant offers.</p>'
  + '<div class="store-search">'+I.search+'<input id="store-search" placeholder="Search by location" autocomplete="off"></div>'
  + '<div id="store-list">'+storeListHTML('')+'</div></div></aside>';
}
/* gallery modal */
function openGallery(item, tab){
  ui.galImgs = galleryFor(item); ui.galTab = tab||'all'; ui.galCtx = item.id;
  renderGallery();
}
function renderGallery(){
  const g = ui.galImgs;
  let body='';
  if(ui.galTab==='all'){
    body = '<div class="gal-grid">'+g.map(src=>{
      const vid = src.indexOf('media-312')>=0;
      return vid ? '<div class="gal-vid"><img src="'+src+'" alt=""><span class="pv"><span>'+I.play+'</span></span></div>' : '<img src="'+src+'" alt="">';
    }).join('')+'</div>';
  } else if(ui.galTab==='video'){
    const v = g.find(s=>s.indexOf('media-312')>=0) || g[0];
    body = '<div class="gal-vid"><img src="'+v+'" alt=""><span class="pv"><span>'+I.play+'</span></span></div>';
  } else {
    body = '<div class="gal-meas"><img src="/assets/media-317.jpg" alt=""><div>'
    + '<div class="acc open"><button class="acc-head" data-action="acc-toggle">Measurements '+I.chevD+'</button><div class="acc-body"><table class="meas-table">'
    + '<tr><td class="k">Width</td><td class="v">47 1/4 "</td><td class="k">Depth</td><td class="v">16 1/2 "</td></tr>'
    + '<tr><td class="k">Height</td><td class="v">29 1/8 "</td><td class="k">Max load/shelf</td><td class="v">44 lb</td></tr>'
    + '</table></div></div>'
    + '<div class="acc"><button class="acc-head" data-action="acc-toggle">Packaging '+I.chevD+'</button><div class="acc-body"><p class="muted">This product comes as 6 packages.</p></div></div></div></div>';
  }
  overlayRoot().innerHTML = scrimHTML()
  + '<div class="gal"><button class="gal-x" data-action="close-overlays">✕</button>'
  + '<div class="gal-tabs"><span class="gal-tab'+(ui.galTab==='all'?' on':'')+'" data-action="media-tab" data-t="all">All media</span>'
  + '<span class="gal-tab'+(ui.galTab==='video'?' on':'')+'" data-action="media-tab" data-t="video">Video</span>'
  + '<span class="gal-tab'+(ui.galTab==='meas'?' on':'')+'" data-action="media-tab" data-t="meas">Measurement</span></div>'
  + '<div class="gal-body">'+body+'</div></div>';
}
/* included parts drawer */
function openParts(itemId){
  const line = S.bag.find(i=>String(i.id)===String(itemId));
  const parts = PARTS_DESC[itemId]||[];
  const qty = line?line.qty:1;
  overlayRoot().innerHTML = scrimHTML()
  + '<aside class="drawer"><button class="drawer-x" data-action="close-overlays">✕</button>'
  + '<div class="drawer-scroll"><h2>BESTÅ</h2><p class="lead">This product is made up of '+parts.length+' parts.</p>'
  + parts.map(p=>'<div class="part-row"><b>'+esc(p.name)+'</b><div class="pd">'+esc(p.desc)+'</div><div class="pq">Quantity: '+(p.qty*qty)+'</div></div>').join('')
  + '</div></aside>';
}
/* reviews modal */
function openReviews(item){
  ui.rev = { id:item.id, sort:'recent', topic:'all', stars:new Set(), hidden:false, sortOpen:false };
  renderReviews(item);
}
function reviewDate(r){ const p=r.d.split('/'); return (+p[2])*10000+(+p[0])*100+(+p[1]); }
function renderReviews(item){
  const st = ui.rev;
  const rating = item.rating||3.7, count = item.review_count||123;
  let list = REVIEWS.slice();
  if(st.topic!=='all') list = list.filter(r=>r.tags.indexOf(st.topic)>=0);
  if(st.stars.size) list = list.filter(r=>st.stars.has(r.r));
  if(st.sort==='recent') list.sort((a,b)=>reviewDate(b)-reviewDate(a));
  else if(st.sort==='oldest') list.sort((a,b)=>reviewDate(a)-reviewDate(b));
  else if(st.sort==='high') list.sort((a,b)=>b.r-a.r);
  else if(st.sort==='low') list.sort((a,b)=>a.r-b.r);
  else if(st.sort==='helpful') list.sort((a,b)=>b.h-a.h);
  const bars = REV_BARS.map(b=>{
    const c = Math.round(b[1]/123*count);
    return '<div class="bar-row"><span class="n">'+b[0]+'</span>'+starSVG(1)+'<span class="bar"><i style="width:'+(b[1]/54*100)+'%"></i></span><span class="c">'+c+'</span></div>';
  }).join('');
  const aspects = REV_ASPECTS.map(a=>{
    const filled = Math.round(a[1]); let dots='';
    for(let i=1;i<=5;i++) dots += '<i'+(i<=filled?'':' class="e"')+'></i>';
    return '<div class="aspect"><span class="a-n">'+a[0]+'</span><span><span class="dot5">'+dots+'</span>'+a[1].toFixed(1)+'</span></div>';
  }).join('');
  const sortPop = st.sortOpen ? '<div class="sort-pop">'+[['recent','Most recent'],['oldest','Oldest'],['high','Highest rated'],['low','Lowest rated'],['helpful','Most helpful']].map(o=>'<label><input type="radio" name="rev-sort" value="'+o[0]+'"'+(st.sort===o[0]?' checked':'')+'>'+o[1]+'</label>').join('')+'</div>' : '';
  const summary = st.hidden ? '' : '<p>BESTÅ offers a stylish design that enhances many spaces. Customers often report issues with overall stability and quality. They mention wobbly structures and difficulty aligning or securing doors. Assembling the door components often proves difficult, impacting functionality. BESTÅ provides a modern, adaptable look for living spaces.</p>';
  const items = list.map(r=>{
    return '<div class="rev-item"><div class="ri-h">'+stars(r.r)+'<span>'+r.d+'</span></div>'
    + '<h4>'+esc(r.t)+'</h4><p>'+esc(r.b)+'</p><span class="author-chip">'+esc(r.a)+'</span>'
    + '<div class="ri-f"><span class="rep">Report</span><button class="helpful">Helpful? ('+r.h+')</button></div>'
    + (r.resp?'<div class="ikea-resp"><b>Response from IKEA:</b> · '+r.rd+'<p>'+esc(r.resp)+'</p></div>':'')
    + '</div>';
  }).join('');
  overlayRoot().innerHTML = scrimHTML()
  + '<div class="rev"><button class="rev-x" data-action="close-overlays">✕</button>'
  + '<div class="rev-left"><div class="big">'+rating+'</div>'+stars(rating)+'<div class="based">Based on '+count+' reviews</div>'
  + bars + '<div style="margin-top:26px">'+aspects+'</div>'
  + '<button class="btn-outline" data-action="write-review">Write a review</button></div>'
  + '<div class="rev-right"><h2>Customer reviews</h2>'
  + '<div class="rev-tools"><button class="tool-btn" data-action="rev-filter">'+I.filter+'Filter</button>'
  + '<button class="tool-btn'+(st.sortOpen?' on':'')+'" data-action="rev-sort-btn">'+I.sort+'Sort by</button>'+sortPop+'</div>'
  + '<div class="rev-tabs"><span class="rev-tab on">United States</span><span class="rev-tab">Other countries</span></div>'
  + '<div class="rev-summary"><div class="rs-h"><b>Reviews summary <span class="ai">AI</span></b><a data-action="rev-summary">'+(st.hidden?'Show summary':'Hide summary')+'</a></div>'
  + summary
  + '<div class="rs-f"><span>AI-generated summary of actual customer reviews.</span><span class="help">Helpful? <svg viewBox="0 0 24 24"><path d="M7 11v9H4v-9h3zm1 0l4.5-7c1 0 1.8.8 1.5 1.8L13.5 9H20a2 2 0 012 2.3l-1.2 6A2 2 0 0118.8 19H8v-8z"/></svg><svg viewBox="0 0 24 24" style="transform:rotate(180deg)"><path d="M7 11v9H4v-9h3zm1 0l4.5-7c1 0 1.8.8 1.5 1.8L13.5 9H20a2 2 0 012 2.3l-1.2 6A2 2 0 0118.8 19H8v-8z"/></svg></span></div></div>'
  + '<div style="font-weight:700;font-size:14px;margin-bottom:10px">Topics <span class="ai" style="font-size:11px;border:1px solid #929292;border-radius:3px;padding:1px 4px">AI</span></div>'
  + '<div class="topics"><span class="topic-chip'+(st.topic==='all'?' on':'')+'" data-action="rev-topic" data-t="all">Show all</span>'
  + REV_TOPICS.map(t=>'<span class="topic-chip'+(st.topic===t?' on':'')+'" data-action="rev-topic" data-t="'+esc(t)+'">'+esc(t)+'</span>').join('')+'</div>'
  + (list.length?items:'<p class="muted" style="padding:30px 0">No reviews match the selected filters.</p>')
  + '</div></div>';
}

/* toast */
function showToast(msg, undo){
  const root = document.getElementById('toast-root');
  const el = document.createElement('div');
  el.className='toast';
  el.innerHTML = '<span>'+esc(msg)+'</span>'+(undo?'<a data-action="undo-remove">Undo</a>':'')+'<span class="tx" data-action="toast-close">✕</span>';
  root.appendChild(el);
  setTimeout(()=>{ if(el.parentNode) el.parentNode.removeChild(el); }, 8000);
}

/* ---------------- search suggestions ---------------- */
const SUGGS = ['besta','besta storage combination','besta tv unit','besta shelf unit','besta frame','besta cabinet','besta doors','besta legs'];
function renderSuggest(q){
  const box = $('#suggest'); if(!box) return;
  const ql = q.trim().toLowerCase();
  if(ql.length<2){ box.classList.add('hidden'); ui.suggestOpen=false; return; }
  const s = SUGGS.filter(x=>x.indexOf(ql)>=0);
  const prods = CAT.catalog.filter(it=>(it.name+' '+it.description).toLowerCase().indexOf(ql)>=0).slice(0,3);
  box.innerHTML =
    (s.length?'<div class="sg-head">Search suggestions</div>'+s.map(x=>'<div class="sg-item" data-action="sugg-pick" data-q="'+esc(x)+'">'+I.search+'<span>'+esc(x)+'</span></div>').join(''):'<div class="sg-item" data-action="sugg-pick" data-q="'+esc(q)+'">'+I.search+'<span>Search for "<b>'+esc(q)+'</b>"</span></div>')
    + (prods.length?'<div class="sg-head">Products</div>'+prods.map(p=>'<div class="sg-prod" data-nav="'+p.route+'"><img src="'+p.image+'" alt=""><span><b>'+esc(p.name)+'</b><br><span class="muted" style="font-size:12px">'+esc(p.description.slice(0,44))+'</span><br><span class="p">'+money(p.member_price)+'</span></span></div>').join(''):'');
  box.classList.remove('hidden'); ui.suggestOpen=true;
}
function submitSearch(){
  const i = $('#header-search'); if(!i) return;
  const q = i.value.trim(); if(!q) return;
  go('/us/en/search/?q='+encodeURIComponent(q));
}

/* ---------------- global event delegation ---------------- */
document.addEventListener('click', e=>{
  const nav = e.target.closest('[data-nav]');
  if(nav){ e.preventDefault(); ui.megaOpen=false; closeOverlays(); go(nav.getAttribute('data-nav')); return; }
  const a = e.target.closest('[data-action]');
  if(!a){
    if(ui.suggestOpen && !e.target.closest('.searchbox')){ const sg=$('#suggest'); if(sg) sg.classList.add('hidden'); ui.suggestOpen=false; }
    if(ui.megaOpen && !e.target.closest('#mega')){ ui.megaOpen=false; renderHead(); }
    return;
  }
  const act = a.getAttribute('data-action');
  const id = a.getAttribute('data-id');
  switch(act){
    case 'products-toggle': ui.megaOpen=!ui.megaOpen; renderHead(); break;
    case 'mega-tab': ui.megaTab=a.getAttribute('data-tab'); renderHead(); break;
    case 'cookie-ok': S.cookie=true; save(); const c=$('#cookie'); if(c) c.remove(); break;
    case 'cookie-pref': break;
    case 'search-submit': submitSearch(); break;
    case 'search-clear': { const i=$('#header-search'); if(i){ i.value=''; i.focus(); const sc=a; sc.classList.add('hidden'); const sg=$('#suggest'); if(sg) sg.classList.add('hidden'); } break; }
    case 'sugg-pick': go('/us/en/search/?q='+encodeURIComponent(a.getAttribute('data-q'))); break;
    case 'facet': { const f=a.getAttribute('data-f'); if(ui.facets.has(f)) ui.facets.delete(f); else ui.facets.add(f); renderCurrentPage(); break; }
    case 'color-pick': {
      const cur = CUR.params;
      if(cur.get('color')==='white') go(searchURL(cur.get('q'), null, cur.get('sort')));
      else go(searchURL(cur.get('q'), 'white', cur.get('sort')));
      break; }
    case 'chip-clear': go(searchURL(CUR.params.get('q'), null, CUR.params.get('sort'))); break;
    case 'cmp-close': S.compare=[]; save(); renderCurrentPage(); break;
    case 'cmp-go': go('/us/en/compare/'); break;
    case 'compare-remove': S.compare = S.compare.filter(x=>String(x)!==String(id)); save(); renderCurrentPage(); break;
    case 'add': { const it=findItem(id); if(it){ addToBag(it,1); openAddDrawer(it,1); } break; }
    case 'reco-add': { const r=PSEUDO[id]; if(r){ addToBag(r,1); showToast(r.name+' was added to your shopping bag.'); } break; }
    case 'fav': { const ix=S.favs.indexOf(id); if(ix>=0) S.favs.splice(ix,1); else S.favs.push(id); save(); a.classList.toggle('on'); break; }
    case 'pdp-thumb': ui.pdpImg[id]=+a.getAttribute('data-i'); renderCurrentPage(); break;
    case 'open-media': { const it=findItem(id); if(it) openGallery(it,'all'); break; }
    case 'view-3d': showToast('The 3D viewer is not part of this demo.'); break;
    case 'media-tab': ui.galTab=a.getAttribute('data-t'); renderGallery(); break;
    case 'qty-inc': case 'qty-dec': {
      const cur = ui.pdpQty[id]||1;
      let n = act==='qty-inc' ? Math.min(99,cur+1) : Math.max(1,cur-1);
      ui.pdpQty[id]=n;
      const qv=$('#pdp-qv'); if(qv) qv.textContent=n;
      const btn=$('#pdp-add-btn'); if(btn) btn.textContent = n>1 ? 'Add '+n+' items to cart' : 'Add to bag';
      const dec=a.parentElement.querySelector('[data-action="qty-dec"]'); if(dec) dec.classList.toggle('dis', n<=1);
      break; }
    case 'pdp-add': { const it=findItem(id); if(it){ const q=ui.pdpQty[id]||1; addToBag(it,q); ui.pdpQty[id]=1; openAddDrawer(it,q); } break; }
    case 'open-zip': closeOverlays(); openZip(); break;
    case 'zip-save': saveZip(); break;
    case 'open-store': closeOverlays(); openStore(); break;
    case 'store-pick': S.store=a.getAttribute('data-name'); save(); closeOverlays(); renderHead(); renderCurrentPage(); break;
    case 'find-store': break;
    case 'show-parts': openParts(id); break;
    case 'open-reviews': { const it=findItem(id); if(it) openReviews(it); break; }
    case 'rev-sort-btn': ui.rev.sortOpen=!ui.rev.sortOpen; renderReviews(findItem(ui.rev.id)); break;
    case 'rev-topic': ui.rev.topic=a.getAttribute('data-t'); renderReviews(findItem(ui.rev.id)); break;
    case 'rev-summary': ui.rev.hidden=!ui.rev.hidden; renderReviews(findItem(ui.rev.id)); break;
    case 'rev-filter': showToast('Review filters are limited in this recorded slice.'); break;
    case 'write-review': showToast('Writing reviews is not part of this demo.'); break;
    case 'tab-scroll': {
      $$('.pdp-tab').forEach(t=>t.classList.remove('on')); a.classList.add('on');
      const el=document.getElementById(a.getAttribute('data-t')); if(el) el.scrollIntoView({behavior:'smooth',block:'start'});
      break; }
    case 'acc-toggle': a.closest('.acc').classList.toggle('open'); break;
    case 'bag-inc': case 'bag-dec': {
      const it=S.bag.find(i=>String(i.id)===String(id)); if(!it) break;
      it.qty = act==='bag-inc' ? Math.min(99,it.qty+1) : Math.max(1,it.qty-1);
      save(); updateBadge(); renderCurrentPage(); break; }
    case 'bag-remove': {
      const ix=S.bag.findIndex(i=>String(i.id)===String(id)); if(ix<0) break;
      const rm=S.bag[ix]; ui.lastRemoved={item:rm, index:ix};
      S.bag.splice(ix,1); save(); updateBadge(); renderCurrentPage();
      showToast(rm.name+' was removed from your shopping bag.', true);
      break; }
    case 'undo-remove': {
      if(ui.lastRemoved){ const lr=ui.lastRemoved; S.bag.splice(Math.min(lr.index,S.bag.length),0,lr.item); ui.lastRemoved=null; save(); updateBadge(); renderCurrentPage(); }
      const t=e.target.closest('.toast'); if(t) t.remove();
      break; }
    case 'toast-close': { const t=a.closest('.toast'); if(t) t.remove(); break; }
    case 'disc-toggle': ui.discOpen=!ui.discOpen; ui.discErr=false; renderCurrentPage(); break;
    case 'disc-apply': ui.discOpen=true; ui.discErr=true; renderCurrentPage(); setTimeout(()=>{ const i=$('#disc-input'); if(i) i.focus(); },30); break;
    case 'close-overlays': closeOverlays(); break;
  }
});
document.addEventListener('change', e=>{
  const t = e.target;
  if(t.name==='sort' && CUR.path.indexOf('/us/en/search')===0){
    go(searchURL(CUR.params.get('q'), CUR.params.get('color'), t.value)); return;
  }
  if(t.classList.contains('cmp-cb')){
    const id=t.getAttribute('data-id');
    if(t.checked){
      if(S.compare.length>=5){ t.checked=false; showToast('You can compare up to 5 products.'); return; }
      if(S.compare.indexOf(id)<0) S.compare.push(id);
    } else S.compare=S.compare.filter(x=>String(x)!==String(id));
    save(); renderCurrentPage(); return;
  }
  if(t.classList.contains('asm-cb')){
    const it=S.bag.find(i=>String(i.id)===t.getAttribute('data-id'));
    if(it){ it.asm=t.checked; save(); renderCurrentPage(); }
    return;
  }
  if(t.name==='rev-sort' && ui.rev){
    ui.rev.sort=t.value; ui.rev.sortOpen=false; renderReviews(findItem(ui.rev.id)); return;
  }
});
document.addEventListener('input', e=>{
  const t=e.target;
  if(t.id==='header-search'){
    const clr=document.querySelector('.s-clear'); if(clr) clr.classList.toggle('hidden', !t.value);
    renderSuggest(t.value); return;
  }
  if(t.id==='zip-input'){
    const hint=$('#zip-hint'); const v=t.value.trim();
    if(/^\d{5}$/.test(v)){ t.classList.remove('err'); t.classList.add('ok'); hint.className='zip-hint ok'; hint.innerHTML=I.check+' e.g. 19428'; }
    else { t.classList.remove('ok'); if(hint.className.indexOf('err')<0){ hint.className='zip-hint'; hint.textContent='e.g. 19428'; } }
    return;
  }
  if(t.id==='store-search'){ const l=$('#store-list'); if(l) l.innerHTML=storeListHTML(t.value); return; }
  if(t.id==='disc-input'){ t.classList.remove('err'); const er=document.querySelector('.disc-err'); if(er) er.remove(); ui.discErr=false; return; }
});
document.addEventListener('keydown', e=>{
  if(e.key==='Escape'){ closeOverlays(); const sg=$('#suggest'); if(sg){sg.classList.add('hidden'); ui.suggestOpen=false;} if(ui.megaOpen){ui.megaOpen=false; renderHead();} return; }
  if(e.key==='Enter'){
    if(e.target.id==='header-search'){ submitSearch(); }
    if(e.target.id==='zip-input'){ saveZip(); }
  }
});

/* ---------------- boot ---------------- */
async function boot(){
  if(!location.hash && location.pathname.length>1){
    history.replaceState(null,'','/#'+location.pathname+location.search);
  }
  const res = await fetch('/assets/catalog.json');
  CAT = await res.json();
  /* extra recorded comparable frame not present in the slice list */
  const extra = { id:'70245848', route:'/us/en/p/besta-frame-white-70245848/', name:'BESTÅ',
    description:'Frame, white, 23 5/8x15 3/4x15 "', color:'white', member_price:38, regular_price:45,
    image:'/assets/media-142.jpg', rating:4.1, review_count:4773 };
  const ix = CAT.catalog.findIndex(i=>i.id==='60245919');
  CAT.catalog.splice(ix>=0?ix+1:CAT.catalog.length, 0, extra);
  /* enrich */
  CAT.catalog.forEach(it=>{
    if(it.rating==null) it.rating = it.id==='20293568'?4.5:3.7;
    if(it.review_count==null) it.review_count = it.id==='20293568'?867:123;
  });
  CAT.comparables.forEach(c=>{ DIMS[c.id]={width:c.width,height:c.height,depth:c.depth}; });
  renderApp();
}
boot();
