# IKEA BESTÅ Shopping Journey — Recorded-Slice Reimplementation

A self-contained vanilla HTML/CSS/JS single-page app that replicates the IKEA BESTÅ
shopping journey captured in `ikea-besta-demonstration.mp4`, driven by the recorded
catalog slice (`/assets/catalog.json`) and media manifest (`/assets/manifest.json`).

## Run

The project needs a static file server (the pre-configured `server.mjs` works as-is):

```bash
node server.mjs
# then open http://localhost:<port>/
```

Any static server rooted at this directory works too (e.g. `npx serve .`).
No build step, no external dependencies, no network calls outside `/assets/*`.

## Routes (hash-based, so refresh / deep links / browser back always work)

| Route | Page |
|---|---|
| `#/us/en/` | Homepage: top bar, mega nav (Products → category tabs), hero, BESTÅ series |
| `#/us/en/search/?q=besta` | Search results (165 items), white filter chip (87), price sort |
| `#/us/en/search/?q=besta&color=white&sort=price-asc` | Filtered + sorted state in URL |
| `#/us/en/compare/` | Product comparison (60245844 / 00245842 / 70245848, max 5) |
| `#/us/en/p/besta-storage-combination-...-s29209829/` | Oak combo PDP: gallery, media/measurement modal, tabs, What's included |
| `#/us/en/p/besta-storage-combination-...-s29612189/` | Black-brown/walnut variant |
| `#/us/en/p/stubbarp-leg-white-stained-oak-effect-20293568/` | STUBBARP component PDP with pack quantity stepper |
| `#/us/en/bag/` | Shopping bag |

Opening a pathname like `/us/en/p/...-s29209829/` directly is rewritten to the hash
route on load, so official-style URLs also work when the server has an SPA fallback.

## Implemented behavior

- Header search with live suggestions; search box keeps the query on the results page.
- Facet sidebar: working Sort radios (price low→high etc.), working White color swatch
  with result count 87 and removable `white ✕` chip; other facets are visual placeholders.
- Compare checkboxes → `N/5 selected` bar → comparison page with key-feature table
  (width/height/depth), add/remove items, browser back returns to the list.
- Combo PDP: thumbnails + main gallery, All media / Video / Measurement modal,
  Overview / Product details / Measurements / What's included tabs, component cards
  (STUBBARP card links to the standalone component page and back), color variant
  swatches switching 29209829 ↔ 29612189, availability block after location is set.
- STUBBARP PDP: `/2 pack` pricing, quantity stepper (`Add 2 items to cart`).
- Location: ZIP drawer rejects invalid input (`abc` → error), accepts `95054`
  (green check), then opens the store drawer; selecting East Palo Alto, CA updates
  the header and PDP/bag availability (fixed recorded snapshot: in stock,
  delivery from $39 / $29 Family, Click & Collect $2 / free Family, Oct 27).
- Add-to-bag confirmation drawer with "You might also like" recommendations and
  spend-more hint; header badge counts total quantity.
- Shopping bag (anonymous → regular prices): per-line totals, quantity steppers,
  Taskrabbit assembly rows that scale with quantity ($58.50 → $117.00; $2.60* with
  $52 minimum note) and add to the order total when checked, "Show included parts"
  drawer with component quantities multiplied by line quantity, remove + Undo toast,
  discount code accordion (any code, e.g. `OMNIALE-DEMO`, is rejected and never
  changes totals), Family savings/points summaries, payment icons, essentials row.
- Reviews: PDP summary card → full reviews modal with rating bars, aspect scores,
  topics, AI summary, and Sort by (Most recent / Oldest / Highest / **Lowest rated**
  / Most helpful) — lowest-rated sort surfaces the 1-star reviews first.
- All state (bag, assembly selections, compare set, favorites, ZIP, store, cookie
  consent) persists in `localStorage`, so refresh restores the exact bag.

## Notes

- Fonts use the system Arial stack; colors/spacing follow the recorded frames at 1440×900.
- Stores/variants not demonstrated in the video are visual placeholders, as permitted.
- No real accounts, orders, payments or 3D planner are included by design.
