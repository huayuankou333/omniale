import math
import numpy as np
from scipy.linalg import eigh


def solve(case, api):
    # Convert inputs to SI units.
    L = float(case['length_mm']) * 1.0e-3
    b = float(case['width_mm']) * 1.0e-3
    E = float(case['E_gpa']) * 1.0e9
    rho = float(case['density_kg_m3'])
    P = float(case['tip_force_n'])
    q = float(case['distributed_load_n_per_m'])
    dlim = float(case['tip_deflection_limit_mm']) * 1.0e-3
    slim = float(case['stress_limit_mpa']) * 1.0e6
    fmin = float(case['frequency_min_hz'])
    hmin = float(case['height_min_mm']) * 1.0e-3
    hmax = float(case['height_max_mm']) * 1.0e-3

    # Analytical lower bounds for a rectangular cantilever. The sizing
    # margin is intentionally small relative to the allowed mass tolerance.
    Mroot = P * L + q * L * L / 2.0
    compliance_numerator = P * L**3 / 3.0 + q * L**4 / 8.0
    h_deflection = (12.0 * compliance_numerator / (E * b * dlim)) ** (1.0 / 3.0)
    h_stress = math.sqrt(6.0 * Mroot / (b * slim))
    beta1 = 1.875104068711961
    omega_min = 2.0 * math.pi * fmin
    h_frequency = omega_min * L**2 / (beta1**2) * math.sqrt(12.0 * rho / E)
    h_required = max(hmin, h_deflection, h_stress, h_frequency)
    height = min(hmax, h_required * (1.0 + 2.0e-4))

    mesh_results = []
    for n_value in case['meshes']:
        n = int(n_value)
        le = L / n
        A = b * height
        I = b * height**3 / 12.0
        ndof = 2 * (n + 1)
        K = np.zeros((ndof, ndof), dtype=float)
        M = np.zeros((ndof, ndof), dtype=float)
        F = np.zeros(ndof, dtype=float)

        ke = (E * I / le**3) * np.array([
            [12.0, 6.0*le, -12.0, 6.0*le],
            [6.0*le, 4.0*le**2, -6.0*le, 2.0*le**2],
            [-12.0, -6.0*le, 12.0, -6.0*le],
            [6.0*le, 2.0*le**2, -6.0*le, 4.0*le**2]
        ])
        me = (rho * A * le / 420.0) * np.array([
            [156.0, 22.0*le, 54.0, -13.0*le],
            [22.0*le, 4.0*le**2, 13.0*le, -3.0*le**2],
            [54.0, 13.0*le, 156.0, -22.0*le],
            [-13.0*le, -3.0*le**2, -22.0*le, 4.0*le**2]
        ])
        # Positive displacement is upward; the distributed load acts downward.
        fe = np.array([-q*le/2.0, -q*le**2/12.0,
                       -q*le/2.0, q*le**2/12.0])
        for e in range(n):
            ids = np.array([2*e, 2*e+1, 2*e+2, 2*e+3])
            K[np.ix_(ids, ids)] += ke
            M[np.ix_(ids, ids)] += me
            F[ids] += fe

        F[2*n] -= P
        fixed = np.array([0, 1])
        free = np.arange(2, ndof)
        displacement = np.zeros(ndof, dtype=float)
        displacement[free] = np.linalg.solve(K[np.ix_(free, free)], F[free])
        reactions = K @ displacement - F

        eigenvalues = eigh(K[np.ix_(free, free)], M[np.ix_(free, free)],
                           eigvals_only=True, check_finite=False)
        positive = eigenvalues[eigenvalues > 0.0]
        frequency = math.sqrt(float(positive[0])) / (2.0 * math.pi)
        root_moment = abs(float(reactions[1]))
        root_stress = root_moment * (height / 2.0) / I

        mesh_results.append({
            'n_elements': n,
            'tip_m': float(displacement[2*n]),
            'root_shear_n': float(reactions[0]),
            'root_moment_nm': root_moment,
            'root_stress_pa': root_stress,
            'frequency_hz': frequency
        })

    return {'height_mm': height * 1.0e3, 'mesh_results': mesh_results}
