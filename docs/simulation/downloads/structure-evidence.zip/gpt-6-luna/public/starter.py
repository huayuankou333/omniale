def solve(case, api):
    h = 20.
    inertia = h * case['width_mm']**3 / 12.
    displacement = -case['tip_force_n']*case['length_mm']**3/(3.*case['E_gpa']*inertia)
    return {'height_mm': h, 'mesh_results': [
        {'n_elements': n, 'tip_m': displacement, 'root_shear_n': 0., 'root_moment_nm': 0.,
         'root_stress_pa': 0., 'frequency_hz': 0.} for n in case['meshes']]}
