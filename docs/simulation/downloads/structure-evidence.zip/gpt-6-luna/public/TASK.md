# Case 5: cantilever beam static/modal analysis and minimum-mass sizing

Submit a complete numerical module `solve(case, api)`. `api` has no methods.
This pilot uses linear Euler-Bernoulli beam elements and independent closed-form
checks, NOT a CalculiX/OpenSees binary. No material or geometric nonlinearity.

Public case inputs:

- length_mm, width_mm, E_gpa, density_kg_m3.
- Positive downward tip_force_n and distributed_load_n_per_m.
- tip_deflection_limit_mm, stress_limit_mpa, frequency_min_hz.
- Height design range [height_min_mm, height_max_mm].
- meshes: numbers of uniform beam elements [4,8,16].

The beam is horizontal, fixed at x=0 (vertical displacement and rotation zero),
free at x=L, rectangular width b and vertical height h. Self-weight is NOT an
additional static load; only the declared tip force and uniform load act.
Use area=b*h, second moment I=b*h^3/12; density contributes the distributed mass
for free vibration. Convert all supplied units consistently.

Find a minimum-mass continuous height satisfying displacement, root bending
stress and first bending-frequency limits. The submitted height must be no more
than 2% above the independent analytical optimum. There is no width design choice.

Build standard 2-DOF/node Euler-Bernoulli elements with the consistent 4x4 mass
matrix, apply consistent equivalent nodal loads for the uniform load, impose
only the root clamp, solve K*d=f, recover root reactions and solve the generalized
eigenproblem K*phi=omega^2*M*phi after removing fixed degrees of freedom.

Return this schema:

    {"height_mm": chosen_height,
     "mesh_results": [
         {"n_elements": n,
          "tip_m": signed vertical tip displacement (downward negative),
          "root_shear_n": upward support force (positive),
          "root_moment_nm": positive support moment magnitude,
          "root_stress_pa": positive maximum root bending stress,
          "frequency_hz": first positive bending frequency}, ... ]}

Submit all three requested meshes. Every reported quantity must match independent
host FEM within 1%; the host also checks its finest mesh against beam theory and
checks engineering constraints. Reporting invented performance is not accepted.
Numerical feasibility tolerance is 0.01%; choose a small sizing margin if needed.

NumPy, math and SciPy numerical routines are allowed, including scipy.linalg.eigh
and scipy.optimize. No file/network access, private engine access or introspection.

The starter has a units/inertia error and fake zero reactions/frequency. Repair
or replace it. Return JSON diagnosis, changes and code defining solve(case, api).
Three public development cases, at most three submissions, then freeze the code
before testing on new dimensions, materials and load combinations.
