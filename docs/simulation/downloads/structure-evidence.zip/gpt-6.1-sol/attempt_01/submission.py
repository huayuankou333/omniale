import math
import numpy as np
from scipy.linalg import solve as linear_solve, eigh


def solve(case, api):
    # SI units throughout the sizing and finite-element calculations.
    L = float(case['length_mm']) * 1.0e-3
    b = float(case['width_mm']) * 1.0e-3
    E = float(case['E_gpa']) * 1.0e9
    rho = float(case['density_kg_m3'])
    P = float(case['tip_force_n'])
    q = float(case['distributed_load_n_per_m'])
    displacement_limit = float(case['tip_deflection_limit_mm']) * 1.0e-3
    stress_limit = float(case['stress_limit_mpa']) * 1.0e6
    frequency_min = float(case['frequency_min_hz'])
    h_min = float(case['height_min_mm']) * 1.0e-3
    h_max = float(case['height_max_mm']) * 1.0e-3

    # For fixed width, mass increases linearly with height. Each constraint
    # therefore supplies a lower bound on the optimal continuous height.
    root_moment = P * L + q * L**2 / 2.0
    h_displacement = (
        12.0 * (P * L**3 / 3.0 + q * L**4 / 8.0)
        / (E * b * displacement_limit)
    ) ** (1.0 / 3.0)
    h_stress = math.sqrt(6.0 * abs(root_moment) / (b * stress_limit))
    beta1 = 1.875104068711961
    h_frequency = (
        frequency_min * 2.0 * math.pi * L**2 / beta1**2
        * math.sqrt(12.0 * rho / E)
    )
    h_required = max(h_min, h_displacement, h_stress, h_frequency)
    if h_required > h_max * (1.0 + 1.0e-12):
        raise ValueError('No feasible height within the supplied design range')
    h = min(h_max, h_required * 1.0001)

    A = b * h
    I = b * h**3 / 12.0
    results = []

    for requested_n in case['meshes']:
        n = int(requested_n)
        if n < 1:
            raise ValueError('Each mesh must contain at least one element')
        le = L / n
        le2 = le * le
        ndof = 2 * (n + 1)
        K = np.zeros((ndof, ndof), dtype=float)
        M = np.zeros((ndof, ndof), dtype=float)
        f = np.zeros(ndof, dtype=float)

        # DOFs are upward displacement and its spatial derivative.
        ke = E * I / le**3 * np.array([
            [12.0, 6.0*le, -12.0, 6.0*le],
            [6.0*le, 4.0*le2, -6.0*le, 2.0*le2],
            [-12.0, -6.0*le, 12.0, -6.0*le],
            [6.0*le, 2.0*le2, -6.0*le, 4.0*le2]
        ], dtype=float)
        me = rho * A * le / 420.0 * np.array([
            [156.0, 22.0*le, 54.0, -13.0*le],
            [22.0*le, 4.0*le2, 13.0*le, -3.0*le2],
            [54.0, 13.0*le, 156.0, -22.0*le],
            [-13.0*le, -3.0*le2, -22.0*le, 4.0*le2]
        ], dtype=float)
        fe = -q * np.array([
            le / 2.0, le2 / 12.0, le / 2.0, -le2 / 12.0
        ], dtype=float)

        for element in range(n):
            dofs = np.arange(2 * element, 2 * element + 4)
            K[np.ix_(dofs, dofs)] += ke
            M[np.ix_(dofs, dofs)] += me
            f[dofs] += fe
        f[2 * n] -= P

        # Remove only the root displacement and rotation.
        K_free = K[2:, 2:]
        M_free = M[2:, 2:]
        d = np.zeros(ndof, dtype=float)
        d[2:] = linear_solve(K_free, f[2:], assume_a='pos')
        reactions = K @ d - f

        # The clamped stiffness and mass are positive definite, so their
        # lowest generalized eigenvalue is the first bending eigenvalue.
        eigenvalue = float(eigh(
            K_free, M_free, eigvals_only=True, subset_by_index=[0, 0]
        )[0])
        if eigenvalue <= 0.0:
            raise ArithmeticError('Nonpositive clamped bending eigenvalue')
        frequency = math.sqrt(eigenvalue) / (2.0 * math.pi)
        support_moment = abs(float(reactions[1]))

        results.append({
            'n_elements': n,
            'tip_m': float(d[2 * n]),
            'root_shear_n': float(reactions[0]),
            'root_moment_nm': support_moment,
            'root_stress_pa': support_moment * h / (2.0 * I),
            'frequency_hz': frequency
        })

    return {'height_mm': float(h * 1.0e3), 'mesh_results': results}
