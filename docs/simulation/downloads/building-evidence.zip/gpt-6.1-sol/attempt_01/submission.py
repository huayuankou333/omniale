import numpy as np
from scipy.optimize import linprog


def solve(case, api):
    """Compute a minimum-cost heat-pump schedule for the supplied forecast."""
    n = int(case['n_steps'])
    dt = float(case['dt_hours'])
    A = np.asarray(case['Ad'], dtype=float).reshape(2, 2)
    b = np.asarray(case['Bheat'], dtype=float).reshape(2)
    d = np.asarray(case['disturbance'], dtype=float).reshape(n, 2)
    x0 = np.asarray(case['initial_state_c'], dtype=float).reshape(2)
    cop = np.asarray(case['cop'], dtype=float).reshape(n)
    price = np.asarray(case['price_per_kwh'], dtype=float).reshape(n)
    pmax = float(case['power_max_kw'])
    lower = float(case['comfort_min_c'])
    upper = float(case['comfort_max_c'])
    terminal = np.broadcast_to(
        np.asarray(case['terminal_min_c'], dtype=float), (2,)
    ).copy()

    if not lower - 0.02 <= x0[0] <= upper + 0.02:
        raise ValueError('Initial air temperature violates comfort bounds.')

    # Eliminate the thermal states exactly:
    # x[k+1] = free[k] + response[k] @ power.
    free = np.empty((n, 2), dtype=float)
    response = np.empty((n, 2, n), dtype=float)
    state = x0.copy()
    sensitivity = np.zeros((2, n), dtype=float)
    for k in range(n):
        state = A @ state + d[k]
        sensitivity = A @ sensitivity
        sensitivity[:, k] += b * cop[k]
        free[k] = state
        response[k] = sensitivity

    air_response = response[:, 0, :]
    inequalities = np.vstack((
        air_response,
        -air_response,
        -response[-1],
    ))
    objective = price * dt
    bounds = [(0.0, pmax)] * n
    options = {
        'primal_feasibility_tolerance': 1e-9,
        'dual_feasibility_tolerance': 1e-9,
    }

    # A tiny interior margin protects against numerical roundoff. Retry the
    # nominal constraints if that margin excludes a boundary-only solution.
    for margin in (1e-6, 0.0):
        rhs = np.concatenate((
            upper - margin - free[:, 0],
            free[:, 0] - lower - margin,
            free[-1] - terminal - margin,
        ))
        result = linprog(
            objective,
            A_ub=inequalities,
            b_ub=rhs,
            bounds=bounds,
            method='highs',
            options=options,
        )
        if not result.success:
            continue

        power = np.clip(result.x, 0.0, pmax)
        if not np.all(np.isfinite(power)):
            continue

        # Validate using the same step-by-step recurrence as the simulator.
        trajectory = np.empty((n + 1, 2), dtype=float)
        trajectory[0] = x0
        for k in range(n):
            trajectory[k + 1] = (
                A @ trajectory[k] + b * cop[k] * power[k] + d[k]
            )
        eps = 1e-5
        if (
            np.all(trajectory[1:, 0] >= lower - eps)
            and np.all(trajectory[1:, 0] <= upper + eps)
            and np.all(trajectory[-1] >= terminal - eps)
        ):
            return {'power_kw': power.tolist()}

    raise RuntimeError('Unable to obtain a feasible thermal planning schedule.')
