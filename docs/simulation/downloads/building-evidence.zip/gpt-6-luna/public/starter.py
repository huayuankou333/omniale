import numpy as np


def solve(case, api):
    outside = np.array(case['outside_c'])
    power = np.maximum(0., outside - 20.) * case['physical_parameters']['UA_kw_per_k'] * 1000.
    return {'power_kw': power.tolist()}
