# Case 2: heat-pump operating cost optimization

Implement `solve(case, api)` and return `{"power_kw": [electric powers]}`.
The module may import NumPy, math and SciPy numerical routines. No file/network
access or introspection. `api` has no methods for this case.

This pilot uses a local 2R2C air/slab thermal surrogate, NOT the BOPTEST FMU.
The simulator solves the exact zero-order-hold discretization of

    C_air*dTa/dt = UA*(Tout-Ta) + G*(Ts-Ta) + internal_gains
    C_slab*dTs/dt = G*(Ta-Ts) + COP*electric_power

Thermal capacities are kWh/K, conductances kW/K, time hours, powers kW.
State x = [air temperature, slab temperature] in degrees C.
The authoritative discrete dynamics are supplied in `case`:

    x[k+1] = Ad @ x[k] + Bheat * cop[k] * power_kw[k] + disturbance[k]

`Ad` is 2x2, `Bheat` length 2, `disturbance` n_steps x 2, and initial_state_c
length 2. Each power is held for dt_hours, and the complete outside/COP/price
forecast is known. There are 192 quarter-hour intervals (48 hours).

Hard conditions:

- One finite electrical power per interval, 0 <= power <= power_max_kw.
- The air temperature must remain in [comfort_min_c, comfort_max_c] for every
  recorded state, including the initial state. Numerical tolerance: 0.02 C.
- Both final temperatures must be >= terminal_min_c (tolerance 0.02 C).
  This prevents treating initial thermal storage as free energy.
- Minimize sum(price_per_kwh[k] * power[k] * dt_hours).
- Achieve at least min_cost_saving_fraction=5% lower cost than the supplied
  heuristic 22 C slab-target thermostat, whose execution appears in feedback.

All physical_parameters, state matrices and forecasts are public, vary by
scenario, and must remain unchanged. Recompute a valid schedule for each case.
Linear programming via scipy.optimize.linprog is allowed. You are responsible
for constructing the planning problem, comfort constraints and terminal terms.
Only a schedule is accepted; self-reported scores are ignored.

The initial module contains incorrect heating sign/units and ignores storage.
Repair or replace it. Return JSON containing diagnosis (brief), changes (list),
and code (complete Python module with solve(case, api)). Do not include private
reasoning. You get three public development scenarios and at most three code
submissions. The final source will be frozen and evaluated on new scenarios.
