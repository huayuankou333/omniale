import numpy as np
from scipy.optimize import linprog


def solve(case, api):
    Ad = np.asarray(case['Ad'], dtype=float)
    Bheat = np.asarray(case['Bheat'], dtype=float).reshape(2)
    disturbance = np.asarray(case['disturbance'], dtype=float)
    cop = np.asarray(case['cop'], dtype=float).reshape(-1)
    price = np.asarray(case['price_per_kwh'], dtype=float).reshape(-1)
    x0 = np.asarray(case['initial_state_c'], dtype=float).reshape(2)
    n = len(cop)
    dt = float(case['dt_hours'])

    # x[k] = offset[k] + sensitivity[k] @ power
    offset = x0.copy()
    sensitivity = np.zeros((2, n), dtype=float)
    rows = []
    rhs = []
    margin = 0.002
    lo = float(case['comfort_min_c']) + margin
    hi = float(case['comfort_max_c']) - margin

    # The initial state is recorded too; reject infeasible input if possible,
    # although the supplied scenarios start inside the comfort band.
    if x0[0] < lo - 1e-9 or x0[0] > hi + 1e-9:
        return {'power_kw': [0.0] * n}

    for k in range(n):
        sensitivity = Ad @ sensitivity
        sensitivity[:, k] += Bheat * cop[k]
        offset = Ad @ offset + disturbance[k]

        # Enforce comfort on the air state at every post-interval recording.
        rows.append(sensitivity[0].copy())
        rhs.append(hi - offset[0])
        rows.append(-sensitivity[0].copy())
        rhs.append(offset[0] - lo)

    terminal = np.asarray(case['terminal_min_c'], dtype=float).reshape(2)
    for j in range(2):
        rows.append(-sensitivity[j].copy())
        rhs.append(offset[j] - terminal[j] - margin)

    result = linprog(
        c=price * dt,
        A_ub=np.asarray(rows),
        b_ub=np.asarray(rhs),
        bounds=[(0.0, float(case['power_max_kw']))] * n,
        method='highs'
    )
    if not result.success or result.x is None:
        # Return a bounded finite result if a malformed or infeasible case is
        # encountered; valid supplied cases are handled by the LP above.
        power = np.zeros(n, dtype=float)
    else:
        power = np.clip(result.x, 0.0, float(case['power_max_kw']))
    return {'power_kw': power.tolist()}
