import numpy as np


def translate_local(transform, offset):
    result = np.array(transform, dtype=float, copy=True)
    result[:3, 3] += result[:3, :3] @ np.asarray(offset, dtype=float)
    return result


def head_target(api, half_length, head_x):
    # The hole pose is already expressed in WORLD coordinates.
    # An aligned peg's leading end is half_length along its local +x.
    return translate_local(api.hole, [head_x - half_length, 0.0, 0.0])


def solve(api):
    if api.done:
        return

    half_length = float(api.half_size[0])
    initial_peg = np.array(api.peg, dtype=float, copy=True)
    direction = initial_peg[:3, 0].copy()
    direction[2] = 0.0
    norm = float(np.linalg.norm(direction))
    if norm < 1.0e-8:
        direction = np.array([1.0, 0.0, 0.0])
    else:
        direction /= norm

    approaching = np.array([0.0, 0.0, -1.0])
    closing = np.cross(approaching, direction)
    grasp = np.eye(4)
    grasp[:3, :3] = np.column_stack((direction, closing, approaching))
    grasp[:3, 3] = (
        initial_peg[:3, 3]
        - direction * max(0.05, half_length / 2.0 + 0.01)
    )

    reach = grasp.copy()
    reach[2, 3] += 0.12
    api.move_tcp(reach, 32, 1.0, "approach")
    if api.done:
        return
    api.move_tcp(grasp, 20, 1.0, "descend")
    if api.done:
        return
    api.hold(18, -1.0, "grasp")
    if api.done:
        return

    lift = np.array(api.tcp, dtype=float, copy=True)
    lift[2, 3] += 0.17
    api.move_tcp(lift, 30, -1.0, "lift")
    if api.done:
        return

    # Rotate and transfer above the approach corridor while keeping the
    # leading end behind the aperture. Track the peg, not a stale TCP offset.
    transfer = head_target(api, half_length, -0.070)
    transfer[2, 3] = max(
        float(api.peg[2, 3]),
        float(transfer[2, 3]) + 0.10,
    )
    api.move_peg(transfer, 60, "transfer")
    if api.done:
        return

    # Finish transverse and angular alignment before advancing toward contact.
    preinsert = head_target(api, half_length, -0.070)
    api.move_peg(preinsert, 80, "preinsert")
    if api.done:
        return

    near_entry = head_target(api, half_length, -0.025)
    api.move_peg(near_entry, 65, "entry_align")
    if api.done:
        return

    insertion = head_target(api, half_length, 0.020)
    api.move_peg(insertion, 180, "insert")
    if api.done:
        return

    # Continue measured peg tracking rather than holding a possibly biased
    # joint command. Total requested motion is bounded at 585 control steps.
    api.log("Continuing measured insertion correction")
    insertion = head_target(api, half_length, 0.020)
    api.move_peg(insertion, 100, "insert_correct")
