# Side insertion controller repair

Repair `starter_controller.py` so that the physical robot completes the task.
Submit a self-contained Python module defining `solve(api)`. You may edit the
control sequence and create numeric helper functions. The host provides inverse
kinematics, joint PD control and real PhysX contact simulation.

All matrix poses below are 4x4 homogeneous transforms in the WORLD frame:

- `api.peg`: current measured peg pose; peg longitudinal axis is local +x.
- `api.hole`: current measured aperture pose; insertion direction is local +x.
- `api.tcp`: current measured gripper tool-center pose.
- `api.half_size`: the peg's three half-dimensions in meters.
- `api.done`: whether success, time limit or controller abort has ended the episode.

Methods:

- `api.move_tcp(target_world_pose, steps, gripper, stage)`: linearly interpolate
  the TCP to the requested world pose over the given number of control steps.
  Rotations are interpolated. IK and joint PD are provided. `gripper=1.0` opens
  the gripper; `gripper=-1.0` closes it. `stage` is a short diagnostic string.
- `api.move_peg(target_world_pose, steps, stage)`: while holding the peg, track
  the requested peg pose using the measured peg-to-gripper transform, bounded
  position/orientation integral compensation, IK, joint PD and physical contacts.
  This shared primitive is already implemented; do not reimplement its internals.
- `api.hold(steps, gripper, stage)`: hold the last joint command.
- `api.log(message)`: write a short diagnostic message.

Control frequency is 20 Hz. Budget is at most 600 control steps. Object sizes and
initial poses vary. Keep the actual contact geometry and physics intact. Do not
write files, access the environment/engine, set object/robot state, read other
project files, or change evaluator behavior. Only the API above is accessible.

The original environment success criterion is used: peg head coordinates in the
hole frame satisfy x >= -0.015 m, and y,z lie within the aperture half-width.
The original episode ends on first success. The 600-step budget is an explicitly
extended budget relative to the upstream task; this is not a 100-step leaderboard.

You can use NumPy, math and scipy.spatial.transform.Rotation/Slerp. Imports from
other modules and introspection/private attributes are not permitted. Only the
source code and public development feedback in your input are available. The
reference solution and final evaluation seeds are not provided.

Your response must be JSON with fields:
`diagnosis` (short engineering explanation), `changes` (list of changes), and
`code` (the complete Python source, including the `solve(api)` entry point).
