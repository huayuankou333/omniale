import numpy as np


def translate_local(transform, offset):
    result = transform.copy()
    result[:3, 3] += transform[:3, :3] @ np.asarray(offset)
    return result


def solve(api):
    half_length = float(api.half_size[0])
    initial_peg = api.peg.copy()
    direction = initial_peg[:3, 0].copy()
    direction[2] = 0.0
    direction /= np.linalg.norm(direction)
    approaching = np.array([0.0, 0.0, -1.0])
    closing = np.cross(approaching, direction)
    grasp = np.eye(4)
    grasp[:3, :3] = np.column_stack([direction, closing, approaching])
    grasp[:3, 3] = initial_peg[:3, 3] - direction * max(0.05, half_length / 2 + 0.01)
    reach = grasp.copy()
    reach[2, 3] += 0.12
    api.move_tcp(reach, 32, 1.0, "approach")
    api.move_tcp(grasp, 20, 1.0, "descend")
    api.hold(15, -1.0, "grasp")
    lift = api.tcp.copy()
    lift[2, 3] += 0.17
    api.move_tcp(lift, 25, -1.0, "lift")

    peg_to_tcp = np.linalg.inv(api.peg) @ api.tcp
    target_hole = api.hole.copy()
    reference = np.array([0.0, 0.25, 0.10])
    target_hole[:3, 3] = reference + target_hole[:3, :3] @ (target_hole[:3, 3] - reference)

    pre_insert = translate_local(target_hole, [-2 * half_length - 0.025, 0.0, 0.0]) @ peg_to_tcp
    transfer = pre_insert.copy()
    transfer[2, 3] = max(0.23, pre_insert[2, 3] + 0.10)
    api.move_tcp(transfer, 40, -1.0, "transfer")
    api.move_tcp(pre_insert, 25, -1.0, "preinsert")
    insert_peg = translate_local(target_hole, [-half_length + 0.025, 0.0, 0.0])
    api.move_peg(insert_peg, 180, "insert")
    api.hold(15, -1.0, "settle")
