import numpy as np


def translate_local(transform, offset):
    result = np.array(transform, dtype=float, copy=True)
    result[:3, 3] += result[:3, :3] @ np.asarray(offset, dtype=float)
    return result


def head_target(api, half_length, head_x):
    return translate_local(api.hole, [head_x - half_length, 0.0, 0.0])


def measured_head(api, half_length):
    peg = np.array(api.peg, dtype=float, copy=True)
    hole = np.array(api.hole, dtype=float, copy=True)
    head_world = peg[:3, 3] + half_length * peg[:3, 0]
    return hole[:3, :3].T @ (head_world - hole[:3, 3])


def solve(api):
    if api.done:
        return

    half_length = float(api.half_size[0])
    initial_peg = np.array(api.peg, dtype=float, copy=True)
    direction = initial_peg[:3, 0].copy()
    direction[2] = 0.0
    norm = float(np.linalg.norm(direction))
    if norm < 1.0e-8:
        direction = np.array([1.0, 0.0, 0.0])
    else:
        direction /= norm

    approaching = np.array([0.0, 0.0, -1.0])
    closing = np.cross(approaching, direction)
    grasp = np.eye(4)
    grasp[:3, :3] = np.column_stack((direction, closing, approaching))
    grasp[:3, 3] = initial_peg[:3, 3] - direction * max(
        0.05, half_length / 2.0 + 0.01
    )

    reach = grasp.copy()
    reach[2, 3] += 0.12
    api.move_tcp(reach, 32, 1.0, "approach")
    if api.done:
        return
    api.move_tcp(grasp, 20, 1.0, "descend")
    if api.done:
        return
    api.hold(18, -1.0, "grasp")
    if api.done:
        return
    lift = np.array(api.tcp, dtype=float, copy=True)
    lift[2, 3] += 0.17
    api.move_tcp(lift, 30, -1.0, "lift")
    if api.done:
        return

    # Align well behind the observed contact region. In particular, do not
    # descend to the hole centerline with the head only 7 cm behind its origin.
    clearance = max(0.20, 2.0 * half_length + 0.04)
    transfer = head_target(api, half_length, -clearance)
    transfer[2, 3] = max(
        float(api.peg[2, 3]), float(transfer[2, 3]) + 0.10
    )
    api.move_peg(transfer, 60, "transfer_clear")
    if api.done:
        return

    aligned = head_target(api, half_length, -clearance)
    api.move_peg(aligned, 75, "align_clear")
    if api.done:
        return

    # Approach the entrance axially, after height and rotation have settled.
    entrance = head_target(api, half_length, -0.135)
    api.move_peg(entrance, 50, "approach_entry")
    if api.done:
        return

    insertion = head_target(api, half_length, 0.020)
    api.move_peg(insertion, 180, "insert")
    if api.done:
        return

    # 465 steps have been requested. Use the remaining 135 for recovery,
    # rather than indefinitely pressing against the same contact constraint.
    head = measured_head(api, half_length)
    api.log("Measured head in hole frame: %.4f %.4f %.4f" % tuple(head))
    if float(head[0]) < -0.05:
        api.log("Withdrawing to clear contact before realignment")
        withdrawal = head_target(api, half_length, -max(0.17, clearance * 0.8))
        api.move_peg(withdrawal, 60, "withdraw_align")
        if api.done:
            return
        insertion = head_target(api, half_length, 0.020)
        api.move_peg(insertion, 75, "reinsert")
    else:
        insertion = head_target(api, half_length, 0.020)
        api.move_peg(insertion, 135, "finish_insert")
