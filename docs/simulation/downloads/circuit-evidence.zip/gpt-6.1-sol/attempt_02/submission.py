import math


def solve(case, api):
    if isinstance(case, dict):
        vdd = float(case['supply_v'])
        load = float(case['load_pf'])
        temp = float(case['temperature_c'])
        mobility = float(case['mobility_scale'])
        req = case['requirements']
    else:
        vdd = float(case.supply_v)
        load = float(case.load_pf)
        temp = float(case.temperature_c)
        mobility = float(case.mobility_scale)
        req = case.requirements

    if isinstance(req, dict):
        limits = {
            'gain_db': float(req['gain_db_min']),
            'unity_mhz': float(req['unity_mhz_min']),
            'phase_margin_deg': float(req['phase_margin_deg_min']),
            'power_mw': float(req['power_mw_max']),
            'settled_error_mv': float(req['settled_error_mv_max']),
            'overshoot_percent': float(req['overshoot_percent_max'])
        }
    else:
        limits = {
            'gain_db': float(req.gain_db_min),
            'unity_mhz': float(req.unity_mhz_min),
            'phase_margin_deg': float(req.phase_margin_deg_min),
            'power_mw': float(req.power_mw_max),
            'settled_error_mv': float(req.settled_error_mv_max),
            'overshoot_percent': float(req.overshoot_percent_max)
        }

    bounds = {
        'w_in_um': (2.0, 300.0),
        'w_load_um': (2.0, 300.0),
        'w_stage_um': (2.0, 1500.0),
        'w_sink_um': (2.0, 500.0),
        'ibias_ua': (2.0, 100.0),
        'cc_pf': (0.2, 30.0),
        'rz_ohm': (0.0, 20000.0)
    }

    def clip(p):
        return {k: float(max(lo, min(hi, p[k])))
                for k, (lo, hi) in bounds.items()}

    effective_mobility = max(
        0.15, mobility * (300.15 / (273.15 + temp)) ** 1.5)
    kn = 200e-6 * effective_mobility
    kp = 90e-6 * effective_mobility
    bias = 20.0
    ratio_limit = 2.0 * (
        0.80 * limits['power_mw'] * 1000.0 / (vdd * bias) - 2.0)
    ratio = max(6.0, min(15.0 * max(1.0, load / 6.0), ratio_limit))
    win = 80.0
    wload = 12.0
    gm1 = math.sqrt(kn * win * bias * 1e-6)
    target_mhz = max(8.0, 1.5 * limits['unity_mhz'])
    cc = gm1 / (2.0 * math.pi * target_mhz * 1e6) * 1e12
    tail_v = 0.9 - 0.45 - math.sqrt(bias * 1e-6 / (kn * win))
    diode_drop = 0.45 + math.sqrt(bias * 1e-6 / (kp * wload))
    sink = (5.0 * ratio * (1.0 + 0.04 * tail_v)
            / (1.0 + 0.04 * diode_drop))
    p = clip({
        'w_in_um': win,
        'w_load_um': wload,
        'w_stage_um': ratio * wload,
        'w_sink_um': sink,
        'ibias_ua': bias,
        'cc_pf': cc,
        'rz_ohm': 0.0
    })

    def stage_gm(q):
        current = q['ibias_ua'] * 1e-6 * q['w_sink_um'] / 10.0
        return math.sqrt(max(
            1e-16, 2.0 * kp * q['w_stage_um'] * current))

    p['rz_ohm'] = min(20000.0, 1.0 / stage_gm(p))

    def metrics(result):
        out = {}
        wanted = set(limits) | {'open_loop_output_v'}

        def visit(x, depth):
            if depth > 6:
                return
            if isinstance(x, dict):
                for key, value in x.items():
                    if key in wanted:
                        try:
                            number = float(value)
                            if math.isfinite(number):
                                out[key] = number
                        except (TypeError, ValueError):
                            pass
                    elif isinstance(value, (dict, list, tuple)):
                        visit(value, depth + 1)
            elif isinstance(x, (list, tuple)):
                for value in x:
                    visit(value, depth + 1)

        visit(result, 0)
        return out

    def violations(m):
        bad = {}
        for key, limit in limits.items():
            if key not in m:
                continue
            if key in ('gain_db', 'unity_mhz', 'phase_margin_deg'):
                bad[key] = max(0.0, (limit - m[key]) / max(1.0, limit))
            else:
                bad[key] = max(0.0, (m[key] - limit) / max(0.1, limit))
        if 'open_loop_output_v' in m:
            voltage = m['open_loop_output_v']
            bad['bias'] = max(
                0.0, 0.15 - voltage, voltage - (vdd - 0.15)) / 0.15
        return bad

    best = dict(p)
    best_score = float('inf')
    for iteration in range(12):
        p = clip(p)
        try:
            result = api.simulate(dict(p))
        except Exception:
            return best
        m = metrics(result)
        if not m:
            return best
        bad = violations(m)
        score = sum(bad.values()) + 2.0 * max(bad.values(), default=0.0)
        if score < best_score:
            best_score = score
            best = dict(p)
        if score == 0.0:
            return dict(p)

        q = dict(p)
        # Correct DC branch-current imbalance before AC adjustments.
        if bad.get('bias', 0.0) > 0.0:
            voltage = m['open_loop_output_v']
            correction = math.exp(0.077 * (voltage - 0.5 * vdd))
            q['w_sink_um'] *= correction
            p = q
            continue

        if bad.get('power_mw', 0.0) > 0.0:
            factor = max(0.35, min(
                0.9, 0.88 * limits['power_mw'] / m['power_mw']))
            q['ibias_ua'] *= factor
            # Preserve transconductance as branch currents decrease.
            q['w_in_um'] /= factor
            q['w_load_um'] /= factor
            q['w_stage_um'] /= factor
            q['rz_ohm'] = 1.0 / stage_gm(q)
        else:
            if bad.get('gain_db', 0.0) > 0.0:
                q['w_in_um'] *= 1.6
                q['w_load_um'] *= 1.6
                q['w_stage_um'] *= 1.6
                q['cc_pf'] *= math.sqrt(1.6)
                q['rz_ohm'] = 1.0 / stage_gm(q)

            unstable = (bad.get('phase_margin_deg', 0.0) > 0.0 or
                        bad.get('overshoot_percent', 0.0) > 0.0)
            if unstable:
                power = m.get('power_mw', limits['power_mw'])
                increase = min(1.4, max(
                    1.0, 0.90 * limits['power_mw'] / max(power, 1e-6)))
                q['w_stage_um'] *= increase
                q['w_sink_um'] *= increase
                q['cc_pf'] *= 1.15
                # Move the output pole upward and introduce phase lead.
                q['rz_ohm'] = (
                    1.0 + 0.7 * load / q['cc_pf']) / stage_gm(q)
            elif bad.get('unity_mhz', 0.0) > 0.0:
                measured = max(0.01, m['unity_mhz'])
                factor = measured / (1.3 * limits['unity_mhz'])
                q['cc_pf'] *= max(0.35, min(0.9, factor))
                q['rz_ohm'] = 1.0 / stage_gm(q)
            elif bad.get('settled_error_mv', 0.0) > 0.0:
                q['w_in_um'] *= 1.3
                q['cc_pf'] *= 0.9
                q['rz_ohm'] = (
                    1.0 + 0.3 * load / q['cc_pf']) / stage_gm(q)
        p = q

    return best
