def solve(case, api):
    import math

    names = ('w_in_um', 'w_load_um', 'w_stage_um', 'w_sink_um',
             'ibias_ua', 'cc_pf', 'rz_ohm')
    bounds = ((2., 300.), (2., 300.), (2., 1500.), (2., 500.),
              (2., 100.), (.2, 30.), (0., 20000.))

    def clamp(p):
        return {k: min(bounds[i][1], max(bounds[i][0], float(p[k])))
                for i, k in enumerate(names)}

    def values(obj):
        """Find reported metrics even if the host nests them in a result object."""
        found = {}
        def walk(x):
            if isinstance(x, dict):
                for k, v in x.items():
                    if k in ('gain_db', 'unity_mhz', 'phase_margin_deg',
                             'power_mw', 'open_loop_output_v',
                             'settled_error_mv', 'overshoot_percent'):
                        try:
                            found[k] = float(v)
                        except (TypeError, ValueError):
                            pass
                    if isinstance(v, (dict, list, tuple)):
                        walk(v)
            elif isinstance(x, (list, tuple)):
                for v in x:
                    walk(v)
        walk(obj)
        return found

    req = getattr(case, 'requirements', {}) or {}
    def requirement(key, default):
        try:
            return float(req.get(key, default))
        except Exception:
            return default

    gmin = requirement('gain_db_min', 60.)
    umin = requirement('unity_mhz_min', 5.)
    pmin = requirement('phase_margin_deg_min', 55.)
    pmax = requirement('power_mw_max', .65)
    emin = requirement('settled_error_mv_max', 1.)
    omax = requirement('overshoot_percent_max', 25.)
    vdd = float(getattr(case, 'supply_v', 1.8))

    def score(m):
        # Lower is better. Penalties are continuous, so imperfect first
        # candidates still guide the limited search toward useful regions.
        def get(k, fallback):
            return m.get(k, fallback)
        g = get('gain_db', -100.)
        u = get('unity_mhz', 0.)
        ph = get('phase_margin_deg', -100.)
        pw = get('power_mw', 100.)
        out = get('open_loop_output_v', -10.)
        err = get('settled_error_mv', 100.)
        ov = get('overshoot_percent', 100.)
        return (max(0., gmin-g)/10. + max(0., umin-u)/umin * 2.
                + max(0., pmin-ph)/20. + max(0., pw-pmax)/pmax * 2.
                + max(0., .15-out, out-(vdd-.15)) * 3.
                + max(0., err-emin)/emin + max(0., ov-omax)/omax
                # Prefer a useful output operating point away from either rail.
                + abs(out-vdd*.5)/max(vdd, .1)*.08)

    # Initial points cover plausible current levels and second-stage current
    # ratios. Later points perturb the strongest observed candidate.
    starts = [
        (60, 25, 100, 10, 20, 1.5, 5000),
        (60, 25, 100, 20, 20, 1.0, 5000),
        (60, 25, 200, 20, 20, 1.5, 5000),
        (60, 25, 50, 8, 20, 1.0, 8000),
        (80, 35, 150, 20, 35, 1.0, 3000),
        (40, 20, 100, 10, 35, .7, 5000),
        (100, 35, 200, 30, 35, 1.5, 3000),
        (80, 25, 100, 10, 12, .8, 8000),
        (60, 30, 250, 25, 50, 2.0, 2000),
        (120, 40, 300, 30, 50, 1.0, 3000),
        (80, 25, 150, 15, 25, .5, 10000),
        (50, 25, 150, 15, 25, 3.0, 5000),
    ]
    best = clamp(dict(zip(names, starts[0])))
    best_score = float('inf')
    used = 0
    for i in range(12):
        if i < len(starts):
            p = clamp(dict(zip(names, starts[i])))
        else:
            p = best
        try:
            result = api.simulate(p)
            used += 1
            s = score(values(result))
            if s < best_score:
                best_score, best = s, p
        except Exception:
            used += 1
            if used >= 12:
                break
    return best
