# Case 3: repair and size a fixed-topology two-stage Miller OTA

Submit a complete Python module defining `solve(case, api)`. Return a dictionary
with exactly these numerical transistor/compensation parameters:

    w_in_um, w_load_um, w_stage_um, w_sink_um,
    ibias_ua, cc_pf, rz_ohm

The host generates a protected netlist and runs real ngspice 47. This is an
educational CMOS LEVEL=1 task, NOT SKY130 or an Analog Design Bench reproduction.
All MOS channel lengths are 1 um. Topology and physical model are fixed:

    VSUP vdd 0 {case.supply_v}
    IREF vdd vb {ibias_ua}u
    M8 vb vb 0 0 NM W=10u L=1u
    M5 tail vb 0 0 NM W=10u L=1u
    M1 n1 inn tail 0 NM W={w_in_um}u L=1u
    M2 n2 inp tail 0 NM W={w_in_um}u L=1u
    M3 n1 n1 vdd vdd PM W={w_load_um}u L=1u
    M4 n2 n1 vdd vdd PM W={w_load_um}u L=1u
    M6 out n2 vdd vdd PM W={w_stage_um}u L=1u
    M7 out vb 0 0 NM W={w_sink_um}u L=1u
    RZERO n2 nc {rz_ohm}
    CCOMP nc out {cc_pf}p
    CLOAD out 0 {case.load_pf}p

NM: VTO=0.45, KP=200u*mobility_scale, LAMBDA=0.04.
PM: VTO=-0.45, KP=90u*mobility_scale, LAMBDA=0.04.
Temperature is case.temperature_c. VDD, mobility and capacitive load vary across
scenarios. Inputs have 0.9 V common mode in the open-loop AC test. Differential
AC excitation is +0.5/-0.5 V, so output AC is differential voltage gain.

`api.simulate(parameters)` executes protected DC operating-point, AC and
unity-feedback transient tests and returns metrics/checks. At most 12 calls per
scenario. You may use them to tune the design at runtime; all candidates and
netlists are recorded. A final independent simulation scores the returned design.
You may use NumPy, math and scipy numerical routines, without file/network access.

Parameter bounds: input/load widths 2..300 um; stage width 2..1500 um; sink width
2..500 um; bias 2..100 uA; compensation 0.2..30 pF; zero-null resistor 0..20000 ohm.

All conditions in case.requirements must pass simultaneously:

- DC/open-loop low-frequency gain >=60 dB; unity bandwidth >=5 MHz.
- Phase margin at the first unity crossing >=55 degrees.
- Total supply power <=0.65 mW, including the reference branch.
- Open-loop output must be between 0.15 V and VDD-0.15 V.
- Unity-feedback step input 0.895 ->0.905 V: after 1 us, max error <=1 mV;
  rising-edge overshoot <=25% of the 10 mV step.

Gain/phase are computed from actual complex AC data, transient accuracy from
recorded samples. The starter is incorrectly biased and overcompensated.

Return strict JSON with diagnosis, changes and code. The code must define
solve(case, api). Three public development scenarios, at most three submissions,
then freeze the source before evaluation on new scenarios. No manual source edits.
