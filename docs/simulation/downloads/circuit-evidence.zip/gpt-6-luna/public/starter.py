def solve(case, api):
    return {'w_in_um': 4., 'w_load_um': 12., 'w_stage_um': 8., 'w_sink_um': 80.,
            'ibias_ua': 5., 'cc_pf': 30., 'rz_ohm': 0.}
