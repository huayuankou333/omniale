def solve(case, api):
    names = ('w_in_um', 'w_load_um', 'w_stage_um', 'w_sink_um',
             'ibias_ua', 'cc_pf', 'rz_ohm')
    bounds = ((2., 300.), (2., 300.), (2., 1500.), (2., 500.),
              (2., 100.), (.2, 30.), (0., 20000.))

    def clamp(p):
        return {k: min(bounds[i][1], max(bounds[i][0], float(p[k])))
                for i, k in enumerate(names)}

    def metrics(obj):
        found = {}
        keys = ('gain_db', 'unity_mhz', 'phase_margin_deg', 'power_mw',
                'open_loop_output_v', 'settled_error_mv', 'overshoot_percent')
        def walk(x):
            if isinstance(x, dict):
                for k, v in x.items():
                    if k in keys:
                        try:
                            found[k] = float(v)
                        except (TypeError, ValueError):
                            pass
                    if isinstance(v, (dict, list, tuple)):
                        walk(v)
            elif isinstance(x, (list, tuple)):
                for v in x:
                    walk(v)
        walk(obj)
        return found

    req = case.get('requirements', {})
    gmin = float(req.get('gain_db_min', 60.))
    umin = float(req.get('unity_mhz_min', 5.))
    pmin = float(req.get('phase_margin_deg_min', 55.))
    pmax = float(req.get('power_mw_max', .65))
    emin = float(req.get('settled_error_mv_max', 1.))
    omax = float(req.get('overshoot_percent_max', 25.))
    vdd = float(case.get('supply_v', 1.8))

    def score(m):
        g = m.get('gain_db', -100.)
        u = m.get('unity_mhz', 0.)
        ph = m.get('phase_margin_deg', -100.)
        pw = m.get('power_mw', 100.)
        out = m.get('open_loop_output_v', -10.)
        err = m.get('settled_error_mv', 100.)
        ov = m.get('overshoot_percent', 100.)
        return (max(0., gmin - g) / 10.
                + 2. * max(0., umin - u) / umin
                + max(0., pmin - ph) / 20.
                + 2. * max(0., pw - pmax) / pmax
                + 3. * max(0., .15 - out, out - (vdd - .15))
                + max(0., err - emin) / emin
                + max(0., ov - omax) / omax
                + .08 * abs(out - vdd * .5) / max(vdd, .1))

    starts = [
        (60, 25, 100, 10, 20, 1.5, 5000),
        (60, 25, 100, 20, 20, 1.0, 5000),
        (60, 25, 200, 20, 20, 1.5, 5000),
        (60, 25, 50, 8, 20, 1.0, 8000),
        (80, 35, 150, 20, 35, 1.0, 3000),
        (40, 20, 100, 10, 35, .7, 5000),
        (100, 35, 200, 30, 35, 1.5, 3000),
        (80, 25, 100, 10, 12, .8, 8000),
        (60, 30, 250, 25, 50, 2.0, 2000),
        (120, 40, 300, 30, 50, 1.0, 3000),
        (80, 25, 150, 15, 25, .5, 10000),
        (50, 25, 150, 15, 25, 3.0, 5000),
    ]
    best = clamp(dict(zip(names, starts[0])))
    best_score = float('inf')
    for row in starts:
        candidate = clamp(dict(zip(names, row)))
        try:
            result = api.simulate(candidate)
            candidate_score = score(metrics(result))
            if candidate_score < best_score:
                best_score = candidate_score
                best = candidate
        except Exception:
            pass
    return best
