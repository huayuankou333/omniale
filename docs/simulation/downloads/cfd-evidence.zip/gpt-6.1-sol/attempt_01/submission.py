def solve(case, api):
    length = float(case['length_m'])
    lid_speed = float(case['lid_speed_m_per_s'])
    density = float(case['density_kg_m3'])
    dynamic_viscosity = float(case['dynamic_viscosity_pa_s'])

    return {
        'config': {
            'length_m': length,
            'lid_speed_m_per_s': lid_speed,
            'kinematic_viscosity_m2_per_s': dynamic_viscosity / density,
            'wall_velocity_m_per_s': {
                'top': [lid_speed, 0.0],
                'bottom': [0.0, 0.0],
                'left': [0.0, 0.0],
                'right': [0.0, 0.0]
            },
            'mesh_nodes': [int(n) for n in case['required_mesh_nodes']],
            'advection': 'central',
            'steady_tolerance': 1.0e-7,
            'max_steps': 50000
        }
    }
