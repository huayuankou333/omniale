# Case 4: repair a lid-driven cavity simulation configuration

Implement `solve(case, api)` returning {"config": { ... }}. `api` has no methods.
This Windows pilot uses a native 2-D incompressible streamfunction-vorticity
finite-difference solver, NOT OpenFOAM. The host executes the actual nonlinear
steady Navier-Stokes calculation; generating a configuration alone is not a pass.

Public physical inputs: square side length_m, lid_speed_m_per_s, density_kg_m3,
dynamic_viscosity_pa_s. A Newtonian fluid and stationary no-slip bottom/left/right
walls are prescribed. The lid moves horizontally to the right. The Reynolds
number is U*L/nu with nu=dynamic_viscosity/density. Corner lid singularities are
handled by the protected engine; top velocity excludes the two corner nodes.

The returned config must include:

    length_m: physical side length
    lid_speed_m_per_s: physical lid speed
    kinematic_viscosity_m2_per_s: converted kinematic viscosity
    wall_velocity_m_per_s: {
        "top": [u, v], "bottom": [u,v], "left": [u,v], "right": [u,v]
    }
    mesh_nodes: three square-grid node counts from case.required_mesh_nodes
    advection: "central"
    steady_tolerance: chosen vorticity RHS residual tolerance (1e-8..0.1)
    max_steps: pseudo-time iteration budget (50..50000)

The protected engine nondimensionalizes to L=U=1, solves -Laplacian(psi)=omega
by a DST Poisson solve at each explicit pseudo-time step, and enforces no-slip
vorticity at the walls. It computes u=dpsi/dy and v=-dpsi/dx. Stable time steps
are chosen automatically; your convergence settings must allow a steady result.

Scoring checks all physical inputs/boundaries, three actual grid executions,
centerline velocity relative L2 error <=5% versus a protected 81x81 refined
calculation, last-two-grid profile change <=2%, interior dimensionless divergence
<=1e-8, and max steady vorticity residual <=2e-4 for all three grids. Profiles
sample 19 points from 0.05 to 0.95 on each centerline. Limits are also in case.

The allowed physical family has Re=50,100,150 with varying dimensional geometry,
lid speeds and densities. New seeds test configuration/unit handling within this
family, not new geometry or new dimensionless flow regimes. Only numeric code
is allowed (NumPy, math, SciPy); no file/network access or engine introspection.

Repair the starter's viscosity conversion, wall conditions and early stopping.
Return JSON with diagnosis, changes, code defining solve(case, api). You receive
three development cases and at most three feedback-based submissions. The final
source is frozen before independent evaluation.
