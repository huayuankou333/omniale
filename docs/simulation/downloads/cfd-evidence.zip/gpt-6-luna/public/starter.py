def solve(case, api):
    return {'config': {'length_m': case['length_m'], 'lid_speed_m_per_s': case['lid_speed_m_per_s'],
        'kinematic_viscosity_m2_per_s': case['dynamic_viscosity_pa_s'],
        'wall_velocity_m_per_s': {'top': [case['lid_speed_m_per_s'], 0.],
            'bottom': [case['lid_speed_m_per_s'], 0.], 'left': [0., 0.], 'right': [0., 0.]},
        'mesh_nodes': case['required_mesh_nodes'], 'advection': 'central',
        'steady_tolerance': 0.1, 'max_steps': 50}}
