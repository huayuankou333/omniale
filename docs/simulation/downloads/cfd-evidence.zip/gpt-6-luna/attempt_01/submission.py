def solve(case, api):
    density = float(case['density_kg_m3'])
    viscosity = float(case['dynamic_viscosity_pa_s'])
    return {
        'config': {
            'length_m': float(case['length_m']),
            'lid_speed_m_per_s': float(case['lid_speed_m_per_s']),
            'kinematic_viscosity_m2_per_s': viscosity / density,
            'wall_velocity_m_per_s': {
                'top': [float(case['lid_speed_m_per_s']), 0.0],
                'bottom': [0.0, 0.0],
                'left': [0.0, 0.0],
                'right': [0.0, 0.0],
            },
            'mesh_nodes': case['required_mesh_nodes'],
            'advection': 'central',
            'steady_tolerance': 1e-7,
            'max_steps': 50000,
        }
    }
