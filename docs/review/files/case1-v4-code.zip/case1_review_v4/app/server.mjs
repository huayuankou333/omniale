import http from 'node:http';
import fs from 'node:fs/promises';
import {createReadStream} from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {readState,applyTransaction,applyReleaseTransaction,enums,editable} from './engine.mjs';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const state = process.env.CASE1_STATE || path.join(root,'public','state.json');
let queue = Promise.resolve();
const server = http.createServer(async(req,res)=>{
  try {
    if (req.url === '/api/state') { res.setHeader('Content-Type','application/json'); res.end(JSON.stringify(await readState(state))); return; }
    if (req.url === '/api/schema') { res.setHeader('Content-Type','application/json'); res.end(JSON.stringify({enums,editable,release_fields:['version','required_ticket_ids','status','blocker_ticket_ids']})); return; }
    if (['/api/transaction','/api/releases'].includes(req.url) && req.method==='POST') {
      let body=''; for await (const c of req) { body+=c; if(body.length>100000) throw new Error('Body too large'); }
      const job = queue.then(()=>(req.url==='/api/releases'?applyReleaseTransaction:applyTransaction)(state,JSON.parse(body))); queue=job.catch(()=>{});
      res.setHeader('Content-Type','application/json');res.end(JSON.stringify(await job)); return;
    }
    const routes = {
      '/': ['app/index.html','text/html; charset=utf-8'],
      '/recording': ['public/inputs/review.mp4','video/mp4'],
      '/task': ['public/task.md','text/plain; charset=utf-8'],
      '/conform': ['public/conform.json','application/json']
    };
    if (!routes[req.url]) {res.writeHead(404);res.end('Not found');return;}
    const [file,mime] = routes[req.url];res.setHeader('Content-Type',mime);
    const target=path.join(root,file);
    if(mime==='video/mp4'){
      const {size}=await fs.stat(target);res.setHeader('Accept-Ranges','bytes');
      let start=0,end=size-1;
      if(req.headers.range){
        const m=/^bytes=(\d+)-(\d*)$/.exec(req.headers.range);
        if(!m){res.writeHead(416,{'Content-Range':`bytes */${size}`});res.end();return;}
        start=Number(m[1]);end=m[2]?Math.min(Number(m[2]),size-1):size-1;
        if(start>end||start>=size){res.writeHead(416,{'Content-Range':`bytes */${size}`});res.end();return;}
        res.writeHead(206,{'Content-Range':`bytes ${start}-${end}/${size}`,'Content-Length':end-start+1});
      }else res.setHeader('Content-Length',size);
      if(req.method==='HEAD'){res.end();return;}
      const stream=createReadStream(target,{start,end});stream.on('error',()=>res.destroy());res.on('close',()=>stream.destroy());stream.pipe(res);return;
    }
    res.end(await fs.readFile(target));
  } catch(e) {res.writeHead(400,{'Content-Type':'application/json'});res.end(JSON.stringify({error:e.message}));}
});
server.listen(Number(process.env.PORT||4184),'127.0.0.1',()=>console.log('Case1 v4 review system: http://127.0.0.1:'+(process.env.PORT||4184)));
