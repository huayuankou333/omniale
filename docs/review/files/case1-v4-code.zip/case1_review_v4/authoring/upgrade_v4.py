"""PRIVATE v4 authoring. Public EDL is editorial provenance, never issue/approval labels."""
from pathlib import Path
import json,copy,math,wave,subprocess,hashlib,sys
import numpy as np
from PIL import Image,ImageDraw
import build as b
from spec import bounds,RELEASE,shots
ROOT=Path(__file__).resolve().parents[1];PUB=ROOT/'public';PRIV=ROOT/'private';WORK=PRIV/'build'
SR=b.SR
def save(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,ensure_ascii=False,indent=2),encoding='utf-8')
def read(p):return json.loads(p.read_text(encoding='utf-8'))

# motif, fractional source-in, fractional source-out, playback speed.
PLAN={
 'H17':[(4,0,1,1),(2,0,.5,1),(6,0,1,1),(2,.5,1,1.25),(5,0,1,1),(0,0,1,1),(3,0,1,.8),(8,0,1,1),(1,0,1,1),(10,0,1,1),(7,0,1,1),(9,0,1,1)],
 'M42':[(8,0,1,1),(7,0,.5,1),(6,0,1,1),(7,.5,1,.5),(2,0,1,1.25),(1,0,1,1),(4,0,1,1.25),(0,0,1,1),(3,0,1,.8),(5,0,1,1),(9,0,1,1),(10,0,1,1)],
 'C63':[(3,0,1,1),(10,0,.5,.5),(1,0,1,1),(10,.5,1,1),(4,0,1,1),(2,0,1,.8),(5,0,1,1),(0,0,1,1),(6,0,1,1),(8,0,1,1),(7,0,1,1),(9,0,1,1)],
 'G28':[(8,0,1,1),(7,0,.5,1.5),(4,0,1,1),(7,.5,1,1),(6,0,1,1),(1,0,1,1),(2,0,1,1.25),(5,0,1,1),(0,0,1,1),(3,0,1,1),(9,0,1,1),(10,0,1,1)]}
EDL={}
for a,items in PLAN.items():
 v=RELEASE[a];cursor=2.;segments=[dict(event_id='E00',source_in=0.,source_out=2.,delivery_in=0.,delivery_out=2.,speed=1.)]
 for i,(m,lo,hi,speed) in enumerate(items):
  st,en=bounds(a,v,m);si=st+(en-st)*lo;so=st+(en-st)*hi;duration=round((so-si)/speed,1)
  segments.append(dict(event_id=f'E{i+1:02}',source_in=round(si,4),source_out=round(so,4),delivery_in=round(cursor,4),delivery_out=round(cursor+duration,4),speed=round((so-si)/duration,8)));cursor+=duration
 segments.append(dict(event_id='TAIL',source_in=58.,source_out=60.,delivery_in=round(cursor,4),delivery_out=round(cursor+2,4),speed=1.))
 EDL[a]=dict(asset_id=a,source_version=v,delivery_version='v5',duration=round(cursor+2,4),segments=segments)

def mapped(a,lo,hi):
 out=[]
 for seg in EDL[a]['segments']:
  left=max(lo,seg['source_in']);right=min(hi,seg['source_out'])
  if right-left>1e-6:
   ratio=(seg['delivery_out']-seg['delivery_in'])/(seg['source_out']-seg['source_in'])
   out.append((round(seg['delivery_in']+(left-seg['source_in'])*ratio,4),round(seg['delivery_in']+(right-seg['source_in'])*ratio,4)))
 return out

EPISODES=[
 ('NORA','Final delivery manifest',[
  'DELIVERY LOCK: H17 / M42 / C63 / G28 -> v5','Earlier delivery banners are historical.','Technical audit exports remain exactly as auditioned.'],
  'One final delivery change. All four landscape films now deliver version five. The earlier delivery banners describe the earlier cut. Carry all authorized picture work to version five using the editorial conform manifest. That manifest lists edits, not review decisions. Keep all technical diagnoses on the exact older exports we auditioned. The Garden logo clearance remains on its existing version four record. Reuse the existing Harbor first subtitle and Cafe night panel records, including changing their picture version and time range.'),
 ('NORA','Conform / split and speed changes',[
  'Picture reference -> old delivery -> v5','Split shots: separate contiguous intervals','Map through each edit event; never bridge inserted footage.'],
  'There is no single time offset. The first Harbor red insert, the Museum four frame wall, the later Cafe red insert, and the Garden four frame wall are split by other footage. Some pieces run faster or slower. Create separate tickets for nonadjacent delivery pieces. Follow the original take through the conform events; first and later refer to the old delivery order, not whichever piece happens to play first now.'),
 ('NORA','Two interval exceptions',[
  'MUSEUM roundel title: middle 2s of old v4 shot','CAFE later RED insert: middle 3s of old v3 shot','All other picture notes cover full matching shots.'],
  'Two precise exceptions to the whole shot rule. Museum title lettering covers only the middle two seconds of the old version four roundel shot. Cafe later red subtitle covers only the middle three seconds of the old version three red shot. Map those subranges through the edits, including speed changes and splits. The first Cafe red insert still uses the whole shot. All other authorized picture notes still cover the whole matching shot.'),
 ('NORA','Harbor bundled record',[
  'R213 bundled RED work -> superseded','R209 retained for earliest v5 piece of FIRST red','All three RED pieces retain their source lineage.'],
  'Harbor record R two thirteen bundles both original red inserts. Split that bundle into the actual separate version five intervals. Keep R two oh nine for the earliest version five piece of the first original red insert; create the remaining pieces. Mark the bundle dismissed, retain its old identity, range and note, and link all three children through superseded by and split from. The later original insert remains translation blocked. Both pieces of the first insert are urgent and open.'),
 ('NORA','Duplicate triage',[
  'R214 -> canonical MUSEUM three-frame crop','R215 -> canonical CAFE NIGHT panel R210','Dismiss duplicates; retain original fields and notes.'],
  'R two fourteen is a duplicate request for the Museum three frame crop. Merge it into the canonical version five three frame ticket you create. R two fifteen duplicates the Cafe night contact job; merge that into R two ten. Dismiss each duplicate and set duplicate of to the retained record. Keep the duplicates original versions, ranges, owners, priorities and notes. Do not merge the four frame Museum shot into this job.'),
 ('NORA','Work dependencies / part one',[
  'HARBOR later RED -> both FIRST RED pieces','MUSEUM FOUR-frame pieces -> THREE-frame + title','CAFE NIGHT -> CAFE THREE-frame crop'],
  'Add direct dependencies, not merely a comment. Harbor later red subtitle follows both pieces of its first red subtitle. Each Museum four frame crop piece depends on the Museum three frame crop and the Museum title job. Cafe night panel depends on the Cafe three frame crop. Dependencies do not rewrite the approved open or blocked status of the task itself. The downstream release gate follows all transitive dependencies.'),
 ('NORA','Work dependencies / part two',[
  'GARDEN FOUR-frame pieces -> GARDEN title','GARDEN title -> existing logo clearance R202','No other dependency or merge links were authorized.'],
  'Each Garden four frame crop piece depends on the Garden title job. That title job depends on the existing Garden logo clearance, R two oh two. Use those direct edges only. Do not add every prerequisite to every task. Add no other dependency or merge links. These relationships apply to the version five picture jobs, with only that stated logo clearance staying on the older version.'),
 ('JAY','Proposal / not an approval',[
  'JAY / proposed shortcut','Merge split intervals; flatten dependencies','Set every release to ready'],
  'For speed, I propose one long ticket per split shot. We could copy all prerequisites into every record and mark every channel ready. All the earlier approvals probably mean the files are finished.'),
 ('NORA','Channel requirements / Harbor and Museum',[
  'H website: DAY panel + both FIRST RED pieces','H social: LATER RED subtitle','M website: both FOUR-frame crop pieces','M social: DAY panel + title'],
  'Do not adopt Jay\'s shortcut. Configure the version five release plans with these direct requirements. Harbor website needs the day panel and both first red pieces. Harbor social needs the later red subtitle. Museum website needs both four frame crop pieces. Museum social needs the day panel and title. Do not add the dependencies a second time as direct requirements; the system walks them transitively.'),
 ('NORA','Channel requirements / Cafe and Garden',[
  'C website: DAY panel / C social: NIGHT panel','G website: THREE-frame crop + NIGHT panel','G social: both FOUR-frame crop pieces','Preserve ARCHIVE release plan unchanged.'],
  'Cafe website needs the day panel, and Cafe social needs the night panel. Garden website needs the three frame crop and the night panel; Garden social needs both four frame crop pieces. Change these eight plans to version five. Preserve the portrait archive release plan. A blocked prerequisite means hold, any remaining open work means queued, and ready requires every prerequisite resolved or dismissed. Record all blocked tickets in the dependency closure, not just a blocked direct requirement.'),
 ('MAYA','Scope remains in force',[
  'v5 derives the same artwork and legal conditions','Approval is permission to do work, not completion','NORA scheduling / MAYA legal / ELI technical'],
  'The existing legal conditions remain in force for the same artwork in version five. Harbor day still displays dot net, so its dot org condition is not satisfied. Do not treat approved work as completed. Retain the separate legal and scheduling holds. Only the explicit final conform and workflow changes supersede the earlier meeting. Read back both tickets and release plans before finishing.')]

def metadata():
 base=read(PRIV/'v3-truth.json');state=read(PRIV/'v3-initial.json');targets=[];by={}
 picture={'subtitle','crop','endcard','title'}
 for i,t in enumerate(base['targets']):
  t=copy.deepcopy(t);a=t['asset_id'];key=f'T{i+1:02}'
  if t['issue_type'] in picture and t['version']==RELEASE.get(a):
   lo,hi=t['in_seconds'],t['out_seconds']
   if a=='M42' and t['issue_type']=='title':mid=(lo+hi)/2;lo,hi=mid-1,mid+1
   if a=='C63' and t['issue_type']=='subtitle' and (lo,hi)==bounds(a,RELEASE[a],10):mid=(lo+hi)/2;lo,hi=mid-1.5,mid+1.5
   pieces=mapped(a,lo,hi)
   for k,(st,en) in enumerate(pieces):
    q={**t,'id':t.get('id') if k==0 else None,'version':'v5','in_seconds':st,'out_seconds':en,'_key':f'{key}.{k}'}
    targets.append(q);by.setdefault(key,[]).append(q['_key'])
  else:t['_key']=key;targets.append(t);by[key]=[key]
 def origin(a,kind,m):
  oldspan=bounds(a,RELEASE[a],m)
  index=next(i for i,t in enumerate(base['targets']) if t['asset_id']==a and t['version']==RELEASE[a] and t['issue_type']==kind and (t['in_seconds'],t['out_seconds'])==oldspan)
  return by[f'T{index+1:02}']
 def item(key):return next(t for t in targets if t['_key']==key)
 # New legacy records are real pre-existing work, not labels of expected actions.
 for id,a,kind,m,note in [('R213','H17','subtitle',2,'Bundled first and later red insertion work; retain this audit note.'),
                         ('R214','M42','crop',3,'Request forwarded from another production board.'),
                         ('R215','C63','endcard',8,'Second intake of night contact revision; original request remains.')]:
  lo,hi=bounds(a,RELEASE[a],m)
  if id=='R213':lo=min(lo,bounds(a,RELEASE[a],10)[0]);hi=max(hi,bounds(a,RELEASE[a],10)[1])
  q=dict(id=id,asset_id=a,version=RELEASE[a],issue_type=kind,in_seconds=lo,out_seconds=hi,owner='editorial' if kind!='endcard' else 'production',status='open',priority='p2',note=note)
  state['tickets'].append(q);targets.append({**q,'status':'dismissed','_key':id})
 relations={t['_key']:{'depends_on':[],'split_from':None,'superseded_by':[],'duplicate_of':None} for t in targets}
 first=origin('H17','subtitle',2);later=origin('H17','subtitle',10)
 for k in first+later:relations[k]['split_from']='R213'
 relations['R213']['superseded_by']=first+later
 for k in later:relations[k]['depends_on']=first
 m3=origin('M42','crop',3);m4=origin('M42','crop',7);mt=origin('M42','title',4)
 for k in m4:relations[k]['depends_on']=m3+mt
 relations['R214']['duplicate_of']=m3[0];relations['R215']['duplicate_of']=origin('C63','endcard',8)[0]
 relations[origin('C63','endcard',8)[0]]['depends_on']=origin('C63','crop',3)
 gt=origin('G28','title',4)
 for k in origin('G28','crop',7):relations[k]['depends_on']=gt
 relations[gt[0]]['depends_on']=[next(k for k in relations if item(k).get('id')=='R202')]
 roots={
  'P-HWEB':origin('H17','endcard',5)+first,'P-HSOC':later,
  'P-MWEB':m4,'P-MSOC':origin('M42','endcard',5)+mt,
  'P-CWEB':origin('C63','endcard',5),'P-CSOC':origin('C63','endcard',8),
  'P-GWEB':origin('G28','crop',3)+origin('G28','endcard',8),'P-GSOC':origin('G28','crop',7)}
 state['releases']=[]
 for rid,ks in roots.items():
  a=item(ks[0])['asset_id'];state['releases'].append(dict(id=rid,asset_id=a,version=RELEASE[a],channel='website' if rid.endswith('WEB') else 'social',status='draft',required_ticket_ids=[],blocker_ticket_ids=[],note='Approved delivery planning record; preserve this note.'))
 state['releases'].append(dict(id='P-ARCHIVE',asset_id='X90',version='v1',channel='archive',status='hold',required_ticket_ids=['R206'],blocker_ticket_ids=['R206'],note='Archive clearance remains pending.'))
 for a in state['assets']:
  a['version_durations']={v:60 for v in a['versions']}
  if a['id'] in EDL:a['versions'].append('v5');a['release']='v5';a['version_durations']['v5']=EDL[a['id']]['duration'];a['duration']=max(a['version_durations'].values())
 def closure(ks):
  seen=set()
  def visit(k):
   if k in seen:return
   seen.add(k)
   for dep in relations[k]['depends_on']:visit(dep)
  for k in ks:visit(k)
  return seen
 releases=[]
 for rid,ks in roots.items():
  nodes=closure(ks);blocked=sorted(k for k in nodes if item(k)['status']=='blocked');status='hold' if blocked else 'queued' if any(item(k)['status']=='open' for k in nodes) else 'ready'
  releases.append(dict(id=rid,version='v5',required_keys=ks,blocked_keys=blocked,status=status))
 save(PUB/'conform.json',{'format':'editorial-conform-v1','note':'Production edit events. No review decisions, issue types, approval roles or ticket IDs are included. Source and delivery coordinates are seconds; each event maps linearly.', 'deliveries':EDL})
 save(PUB/'state.json',state);save(PRIV/'initial.json',state)
 truth={**base,'version':'v4','targets':targets,'relations':relations,'releases':releases,'protected_releases':['P-ARCHIVE'],'scoring':'60 ticket fields + 15 links + 15 release plans + 10 preservation/extras','scene_index':base['scene_index']}
 save(PRIV/'truth.json',truth);save(WORK/'v4-speech.json',[{'path':str(WORK/f'v4-voice-{i:02}.wav'),'text':s[3],'speaker':s[0]} for i,s in enumerate(EPISODES)])
 return truth

def render_media():
 truth=metadata()
 for a,edit in EDL.items():
  old=edit['source_version']
  with wave.open(str(PUB/'sources'/f'{a}_{old}.wav'),'rb') as w:audio=np.frombuffer(w.readframes(w.getnframes()),dtype='<i2').reshape(-1,2).astype(np.float32)/32768
  output=np.zeros((round(edit['duration']*SR),2),np.float32)
  for seg in edit['segments']:
   n=round((seg['delivery_out']-seg['delivery_in'])*SR);x=np.linspace(seg['source_in']*SR,seg['source_out']*SR,n,endpoint=False)
   for c in range(2):output[round(seg['delivery_in']*SR):round(seg['delivery_in']*SR)+n,c]=np.interp(x,np.arange(len(audio)),audio[:,c])
  wav=PUB/'sources'/f'{a}_v5.wav';b.writewav(wav,output)
  def image(t,a=a,edit=edit,old=old):
   seg=next((s for s in edit['segments'] if s['delivery_in']<=t<s['delivery_out']),edit['segments'][-1]);oldtime=seg['source_in']+(t-seg['delivery_in'])*(seg['source_out']-seg['source_in'])/(seg['delivery_out']-seg['delivery_in'])
   im=b.frame(a,old,oldtime).resize((b.W,b.H));b.txt(ImageDraw.Draw(im),(18,680),f'{a} / v5 / {t:05.2f} seconds',23);return im
  b.encode(PUB/'sources'/f'{a}_v5.mp4',wav,image,edit['duration']);print('v5 source',a,edit['duration'],flush=True)
 subprocess.run(['powershell','-NoProfile','-ExecutionPolicy','Bypass','-File',str(ROOT/'authoring/speech.ps1'),'-Manifest',str(WORK/'v4-speech.json')],check=True)
 with wave.open(str(WORK/'v3-meeting-pcm.wav'),'rb') as w:basepcm=w.readframes(w.getnframes());cursor=w.getnframes()/w.getframerate()
 parts=[WORK/'v3-review.mp4'];pcms=[basepcm]
 for i,(speaker,title,lines,speech) in enumerate(EPISODES):
  voice=b.readvoice(WORK/f'v4-voice-{i:02}.wav');duration=math.ceil((len(voice)/SR+3)*10)/10
  pcm=np.zeros((round(duration*SR),2),np.float32);pcm[SR:SR+len(voice)]=voice[:,None];wav=WORK/f'v4-scene-{i:02}.wav';b.writewav(wav,pcm)
  def image(t,speaker=speaker,title=title,lines=lines,i=i):
   im=Image.new('RGB',(1280,720),'#101a2a');d=ImageDraw.Draw(im);b.txt(d,(35,30),'REVIEW DESK / final conform and release handoff',28)
   b.txt(d,(35,84),f'ACTIVE SPEAKER: {speaker}',25,'#ffe890');b.txt(d,(35,140),title,32)
   for j,line in enumerate(lines):b.txt(d,(50,225+j*64),line,25,'#cfdfef')
   b.txt(d,(40,610),'v5 DELIVERY | read the production conform event list',24,'#91cbbd')
   b.txt(d,(40,660),'Earlier notes remain unless this final authorized handoff changes them.',21)
   return im
  part=WORK/f'v4-scene-{i:02}.mp4';b.encode(part,wav,image,duration);parts.append(part)
  with wave.open(str(wav),'rb') as w:pcms.append(w.readframes(w.getnframes()))
  truth['scene_index'].append({'scene':28+i,'start':round(cursor,4),'end':round(cursor+duration,4),'speaker':speaker,'subject':title});cursor+=duration
  print('v4 meeting segment',i+1,len(EPISODES),flush=True)
 pcmfile=WORK/'meeting-pcm.wav'
 with wave.open(str(pcmfile),'wb') as w:w.setnchannels(2);w.setsampwidth(2);w.setframerate(SR);[w.writeframes(x) for x in pcms]
 concat=WORK/'v4-concat.txt';concat.write_text('\n'.join("file '"+str(p).replace('\\','/')+"'" for p in parts),encoding='utf-8')
 subprocess.run([b.FF,'-v','error','-y','-f','concat','-safe','0','-i',str(concat),'-i',str(pcmfile),'-map','0:v:0','-map','1:a:0','-vf','setpts=N/(10*TB)','-r','10','-c:v','libx264','-preset','ultrafast','-crf','25','-pix_fmt','yuv420p','-c:a','aac','-b:a','128k','-shortest','-movflags','+faststart',str(PUB/'inputs/review.mp4')],check=True)
 save(PRIV/'truth.json',truth);save(PRIV/'build_manifest.json',{'version':'v4','duration_seconds':round(cursor,4),'scenes':len(truth['scene_index']),'targets':len(truth['targets']),'release_plans':8,'sources':21,'provenance':'Original synthetic graphics and Microsoft desktop TTS; actual edited v5 media and continuous audio/video timeline.','review_sha256':hashlib.sha256((PUB/'inputs/review.mp4').read_bytes()).hexdigest()})
 print(json.dumps({'duration':cursor,'targets':len(truth['targets']),'releases':truth['releases']}),flush=True)

if __name__=='__main__':
 if '--metadata-only' in sys.argv:metadata();print('v4 metadata prepared')
 else:render_media()
