from pathlib import Path
import wave,json,subprocess,hashlib,os
ROOT=Path(__file__).resolve().parents[1];work=ROOT/'private/build'
ff=os.environ.get('FFMPEG_PATH',r'F:\annconda\Lib\site-packages\imageio_ffmpeg\binaries\ffmpeg-win-x86_64-v7.1.exe')
# Concatenating separately encoded AAC segments accumulates encoder padding. Concatenate
# the original PCM and rebuild continuous video PTS so speaker/cue timing remains aligned.
with wave.open(str(work/'meeting-pcm.wav'),'wb') as out:
 out.setnchannels(2);out.setsampwidth(2);out.setframerate(24000)
 for p in sorted(work.glob('scene-*.wav')):
  with wave.open(str(p),'rb') as w:out.writeframes(w.readframes(w.getnframes()))
subprocess.run([ff,'-v','error','-y','-f','concat','-safe','0','-i',str(work/'concat.txt'),'-i',str(work/'meeting-pcm.wav'),
 '-map','0:v:0','-map','1:a:0','-vf','setpts=N/(10*TB)','-r','10','-c:v','libx264','-preset','ultrafast','-crf','25',
 '-pix_fmt','yuv420p','-c:a','aac','-b:a','128k','-shortest','-movflags','+faststart',str(ROOT/'public/inputs/review.mp4')],check=True)
m=json.loads((ROOT/'private/build_manifest.json').read_text());m['review_sha256']=hashlib.sha256((ROOT/'public/inputs/review.mp4').read_bytes()).hexdigest();m['continuous_pcm_timeline']=True
(ROOT/'private/build_manifest.json').write_text(json.dumps(m,indent=2),encoding='utf-8')
