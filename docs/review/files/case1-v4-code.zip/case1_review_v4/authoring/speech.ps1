param([Parameter(Mandatory=$true)][string]$Manifest)
$ErrorActionPreference = "Stop"
Add-Type -AssemblyName System.Speech
$taskVoice = New-Object System.Speech.Synthesis.SpeechSynthesizer
$taskVoice.SelectVoice("Microsoft Zira Desktop")
$taskVoice.Rate = 0
try {
  $taskItems = Get-Content -LiteralPath $Manifest -Raw -Encoding UTF8 | ConvertFrom-Json
  foreach ($taskItem in $taskItems) {
    $taskVoice.SelectVoice($(if ($taskItem.speaker -in @('ELI','JAY')) {'Microsoft Zira Desktop'} else {'Microsoft Zira Desktop'}))
    $taskVoice.Rate = $(if ($taskItem.speaker -eq 'MAYA') { -1 } elseif ($taskItem.speaker -eq 'JAY') { 1 } else { 0 })
    $taskVoice.SetOutputToWaveFile($taskItem.path)
    $taskVoice.Speak($taskItem.text)
    $taskVoice.SetOutputToNull()
  }
} finally { $taskVoice.Dispose() }

