"""Original synthetic dual-player review media; all authoring data stays private."""
import os,json,math,wave,subprocess,hashlib,functools
from pathlib import Path
import numpy as np
from PIL import Image,ImageDraw,ImageFont
from spec import ASSETS,shots,bounds,SCENES,INITIAL,TARGETS,FAULTS,PROTECTED
ROOT=Path(__file__).resolve().parents[1];PUB=ROOT/"public";PRIV=ROOT/"private";WORK=PRIV/"build"
FF=os.environ.get("FFMPEG_PATH",r"F:\annconda\Lib\site-packages\imageio_ffmpeg\binaries\ffmpeg-win-x86_64-v7.1.exe")
SR=24000;FPS=10;DURATION=60;W=1280;H=720
@functools.lru_cache(None)
def font(n):return ImageFont.truetype(r"C:\Windows\Fonts\segoeui.ttf",n)
def txt(d,xy,s,n=20,c="#e5eef9"):d.text(xy,s,font=font(n),fill=c)
def savej(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2,ensure_ascii=False),encoding="utf-8")
def writewav(p,x):
    with wave.open(str(p),"wb") as w:w.setnchannels(2 if x.ndim==2 else 1);w.setsampwidth(2);w.setframerate(SR);w.writeframes((np.clip(x,-.98,.98)*32767).astype("<i2").tobytes())
def readvoice(p):
    out=WORK/(p.stem+"-pcm.wav")
    subprocess.run([FF,"-v","error","-y","-i",str(p),"-ar",str(SR),"-ac","1",str(out)],check=True)
    with wave.open(str(out),"rb") as w:return np.frombuffer(w.readframes(w.getnframes()),dtype="<i2").astype(np.float32)/32768
@functools.lru_cache(256)
def picture(a,m):
    asset=next(x for x in ASSETS if x["id"]==a)
    im=Image.new("RGB",(600,340),asset["color"]);d=ImageDraw.Draw(im)
    txt(d,(24,18),asset["title"].split(" /")[0].upper(),27)
    # Six recognizable shots. No shot IDs or per-export time map are in public metadata.
    c="#e8dfc2"
    if m in (0,9): # first slate and clean control
        d.rectangle((80,105,115,260),fill=c);d.rectangle((485,105,520,260),fill=c)
        d.arc((95,90,505,320),180,360,fill=c,width=13)
        txt(d,(175,190),"A NEW PERSPECTIVE",22)
    elif m==1: # cup
        d.rounded_rectangle((190,100,365,250),16,fill=c);d.arc((320,115,430,220),270,90,fill=c,width=18)
        for x in [225,270,315]:d.arc((x,55,x+22,112),90,270,fill=c,width=4)
    elif m in (2,6,10): # similar takes; red insert may repeat
        d.polygon([(120,220),(460,220),(410,265),(160,265)],fill=c)
        d.polygon([(285,80),(285,205),(150,205)],fill=("#de6868" if m==2 or (m==10 and a in ["H17","C63"]) else "#61a9e8" if m==6 else "#d6b85d"));d.line((295,65,295,220),fill=c,width=6)
        txt(d,(145,284),"Find a new stroy in your city.",20)
    elif m in (3,7): # two different wall compositions
        for x in ([120,250,380] if m==3 else [70,190,310,430]):
            d.rectangle((x,100,x+90,235),outline=c,width=7);d.ellipse((x+20,130,x+70,180),fill=c)
        d.rectangle((438,90,465,250),fill=asset["color"])
    elif m==4: # brand roundel
        d.ellipse((205,80,395,270),outline=c,width=12);d.polygon([(300,110),(350,220),(245,220)],fill=c)
    elif m in (5,8): # DAY/NIGHT legal scopes
        d.rounded_rectangle((90,95,510,270),18,fill="#1a2a38")
        txt(d,(130,115),"DAY / VISIT" if m==5 else "NIGHT / RESERVE",28)
        txt(d,(110,176),"harbor.example.net" if a=="H17" and m==5 else "city.example.org",24)
        txt(d,(120,219),"Address pending update",19)
    return im
def frame(a,v,t):
    found=next(((m,s,e) for m,s,e in shots(a,v) if s<=t<e),None)
    if found:
        m,s,e=found;im=picture(a,m).copy();d=ImageDraw.Draw(im)
        if m in (0,9):
            local=t-s
            txt(d,(120,295),"CALIBRATION / FIRST" if m==0 else "CALIBRATION / SECOND",20)
            for k,at,x in [("L",1,170),("R",3,410)]:
                d.ellipse((x-22,65,x+22,109),fill="#fff68c" if at<=local<at+.3 else "#142432")
                txt(d,(x-7,71),k,18,"#111111" if at<=local<at+.3 else "#b6c6db")
    else:
        im=Image.new("RGB",(600,340),"#080d14");d=ImageDraw.Draw(im);txt(d,(170,150),"LEADER" if t<2 else "TAIL",32)
    return im
def review(s,t):
    a,v,m=s["asset"],s["version"],s["motif"];lo,hi=bounds(a,v,m)
    on_air=t<7;src=lo+(max(0,t-1)%(hi-lo)) if on_air else hi-.1
    other=s["decoy"];da,dv,dm=other;dl,dh=bounds(da,dv,dm)
    panels=[(a,v,src,lo,hi),(da,dv,(dl+dh)/2,dl,dh)]
    if s["side"]=="right":panels.reverse()
    im=Image.new("RGB",(W,H),"#101a2a");d=ImageDraw.Draw(im)
    txt(d,(24,18),"REVIEW DESK / Delivery conform",27)
    txt(d,(24,58),"Synthetic review / NORA production | MAYA legal | ELI audio | JAY assistant",17,"#acbbce")
    txt(d,(890,25),f'ACTIVE SPEAKER: {s["speaker"]}',21,"#fff09c")
    for index,(pa,pv,pt,pl,ph) in enumerate(panels):
        x=22+index*630;active=(index==0)==(s["side"]=="left")
        color="#f2ce5a" if active and on_air else "#6ba4ee" if (not active and not on_air) else "#37475a"
        d.rectangle((x-3,113,x+603,563),outline=color,width=4)
        txt(d,(x+10,121),f'{pa} / {pv}',24)
        txt(d,(x+305,126),"ON AIR" if active and on_air else "KEYBOARD FOCUS" if not active and not on_air else "PAUSED",18,color)
        im.paste(frame(pa,pv,pt),(x,164));d=ImageDraw.Draw(im)
        txt(d,(x+12,517),f'Source {pt:05.2f}s   Ref mark {pl:05.2f} - {ph:05.2f}s',20)
    if s.get("card") and t>=8:
        d.rounded_rectangle((16,574,1264,710),8,fill="#f3ead5")
        for k,line in enumerate(s["card"]):txt(d,(30,583+29*k),line,21,"#172635")
    else:
        txt(d,(26,595),"Pinned delivery: H17 v3 / M42 v4 / C63 v3 / G28 v4",20,"#b2c3d8")
        txt(d,(26,637),"Authority follows domain and scope. Historical records are retained.",20,"#91cbbd")
    return im
def encode(out,audio,callback,duration):
    p=subprocess.Popen([FF,"-v","error","-y","-f","rawvideo","-pix_fmt","rgb24","-s",f"{W}x{H}","-r",str(FPS),
       "-i","pipe:0","-i",str(audio),"-c:v","libx264","-preset","ultrafast","-crf","25","-pix_fmt","yuv420p",
       "-c:a","aac","-b:a","128k","-shortest",str(out)],stdin=subprocess.PIPE)
    try:
        for i in range(round(duration*FPS)):p.stdin.write(callback(i/FPS).tobytes())
    finally:p.stdin.close()
    if p.wait()!=0:raise RuntimeError("Encoding failed")
def main():
    for p in [PUB/"sources",PUB/"inputs",WORK]:p.mkdir(parents=True,exist_ok=True)
    utterances=[{"path":str(WORK/f"speech-{i:02}.wav"),"text":s["speech"],"speaker":s["speaker"]} for i,s in enumerate(SCENES)]
    utterances.append({"path":str(WORK/"voice.wav"),"text":"Every morning brings a new chance to explore your city and discover another perspective. Enjoy the stories around you and share the experience with your friends."})
    for i,s in enumerate(SCENES):
        if s.get("overlap"):utterances.append({"path":str(WORK/f"overlap-{i:02}.wav"),"text":s["overlap"],"speaker":"JAY"})
    savej(WORK/"speech.json",utterances)
    subprocess.run(["powershell","-NoProfile","-ExecutionPolicy","Bypass","-File",str(ROOT/"authoring/speech.ps1"),"-Manifest",str(WORK/"speech.json")],check=True)
    voice=readvoice(WORK/"voice.wav");sources={}
    for a in ASSETS:
        for v in a["versions"]:
            time=np.arange(DURATION*SR)/SR
            bed=.11*np.sin(2*np.pi*190*time)+.045*np.sin(2*np.pi*285*time)
            mono=np.resize(voice,DURATION*SR)*.45
            output=np.stack([bed+mono,bed+mono],axis=1)
            st,en=bounds(a["id"],v,0);kinds=FAULTS.get((a["id"],v),[])
            # Dialogue fragment is aligned to shot-local time in all versions.
            n=round((en-st)*SR);voc=np.resize(voice,n)*.45
            if "audio_gap" in kinds:voc[2*SR:int(2.8*SR)]=0
            output[int(st*SR):int(en*SR),:]=bed[int(st*SR):int(en*SR),None]+voc[:,None]
            for local,ear in [(1,0),(3,1)]:
                at=st+local+(.5 if "av_sync" in kinds else 0)
                chan=1-ear if "channel_swap" in kinds else ear
                n=round(.3*SR);tt=np.arange(n)/SR
                pulse=.38*np.sin(2*np.pi*1600*tt)*np.minimum(1,tt/.015)*np.minimum(1,(.3-tt)/.015)
                output[round(at*SR):round(at*SR)+n,chan]+=pulse
            # The second slate is a locally aligned clean comparison, not an answer label.
            cs,ce=bounds(a["id"],v,9);n=round((ce-cs)*SR)
            output[round(cs*SR):round(ce*SR)]=bed[round(cs*SR):round(ce*SR),None]+(np.resize(voice,n)*.45)[:,None]
            for local,chan in [(1,0),(3,1)]:
                n=round(.3*SR);tt=np.arange(n)/SR
                pulse=.38*np.sin(2*np.pi*1600*tt)*np.minimum(1,tt/.015)*np.minimum(1,(.3-tt)/.015)
                output[round((cs+local)*SR):round((cs+local)*SR)+n,chan]+=pulse
            sources[(a["id"],v)]=output
            wav=PUB/"sources"/f'{a["id"]}_{v}.wav';writewav(wav,output)
            def sourceframe(t,a=a,v=v):
                im=frame(a["id"],v,t).resize((W,H));d=ImageDraw.Draw(im)
                txt(d,(18,680),f'{a["id"]} / {v} / {t:05.2f} seconds',23);return im
            encode(PUB/"sources"/f'{a["id"]}_{v}.mp4',wav,sourceframe,DURATION)
            print(f'Source {a["id"]}/{v}',flush=True)
    parts=[];cursor=0;index=[];quality=[];rng=np.random.default_rng(20261020)
    for i,s in enumerate(SCENES):
        speech=readvoice(WORK/f"speech-{i:02}.wav");duration=math.ceil((8+len(speech)/SR+1)*FPS)/FPS
        audio=np.zeros((round(duration*SR),2),np.float32)
        if s["listen"]:
            start,end=bounds(s["asset"],s["version"],s["motif"])
            clip=sources[(s["asset"],s["version"])][round(start*SR):round(end*SR)]
            # Original playback speed; repeat only if source shot is shorter than six seconds.
            audio[SR:7*SR]=np.tile(clip,(math.ceil(6*SR/len(clip)),1))[:6*SR]*.7
        if s.get("degrade"):
            from scipy.signal import butter,sosfilt
            speech=sosfilt(butter(4,[320,2900],fs=SR,btype="bandpass",output="sos"),speech).astype(np.float32)
            rms=max(float(np.sqrt(np.mean(speech**2))),.001)
            speech+=rng.normal(0,rms/(10**(18/20)),len(speech)).astype(np.float32)
            delayed=np.pad(speech[:-round(.07*SR)],(round(.07*SR),0))*.12
            speech+=delayed
            # A short packet gap mid-utterance; the scoped signed card preserves critical evidence.
            gap=round(len(speech)*.54);speech[gap:gap+round(.12*SR)]*=.1
            quality.append({"scene":i,"snr_db":18,"band_hz":[320,2900],"echo_ms":70,"packet_gap_ms":120,"redundant_visual_receipt":bool(s.get("card"))})
        audio[8*SR:8*SR+len(speech)]=speech[:,None]
        if s.get("overlap"):
            interrupt=readvoice(WORK/f"overlap-{i:02}.wav");at=9*SR;n=min(len(interrupt),len(audio)-at)
            # Speaker separation remains recoverable in the right channel.
            audio[at:at+n,0]+=interrupt[:n]*.45
            audio[at:at+n,1]+=interrupt[:n]*.06
        wav=WORK/f"scene-{i:02}.wav";writewav(wav,audio)
        out=WORK/f"scene-{i:02}.mp4";encode(out,wav,lambda t,s=s:review(s,t),duration)
        parts.append(out);index.append({"scene":i,"start":cursor,"end":cursor+duration,"play_side":s["side"],"speaker":s["speaker"],"asset":s["asset"],"version":s["version"]});cursor+=duration
        print(f"Review {i+1}/{len(SCENES)}",flush=True)
    concat=WORK/"concat.txt";concat.write_text("\n".join("file '"+str(p).replace("\\","/")+"'" for p in parts),encoding="utf-8")
    subprocess.run([FF,"-v","error","-y","-f","concat","-safe","0","-i",str(concat),"-c","copy","-movflags","+faststart",str(PUB/"inputs/review.mp4")],check=True)
    state={"revision":0,"next_id":301,"assets":[{k:v for k,v in a.items() if k!="color"} for a in ASSETS],"tickets":INITIAL,"receipts":[]}
    savej(PUB/"state.json",state);savej(PRIV/"initial.json",state)
    savej(PRIV/"truth.json",{"targets":TARGETS,"protected":PROTECTED,"range_tolerance_seconds":.3,"scene_index":index,"version":"v3"})
    savej(PRIV/"build_manifest.json",{"scenes":len(SCENES),"targets":len(TARGETS),"sources":sum(len(a["versions"]) for a in ASSETS),"duration":cursor,
      "provenance":"original synthetic graphics / Microsoft desktop speech / scoped remote-link degradation","review_sha256":hashlib.sha256((PUB/"inputs/review.mp4").read_bytes()).hexdigest()})
    savej(PRIV/"audio_conditions.json",quality)
    print(json.dumps({"duration_seconds":cursor,"targets":len(TARGETS)}))
if __name__=="__main__":
    main()
    import sys
    subprocess.run([sys.executable,str(ROOT/"authoring/assemble.py")],check=True)
