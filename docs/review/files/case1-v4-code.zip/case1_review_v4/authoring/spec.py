"""PRIVATE v3 development scenario. Never include in model workspace."""
ASSETS=[
 {"id":"H17","title":"Harbor / landscape","versions":["v1","v2","v3","v4"],"duration":60,"release":"v3","color":"#25677c"},
 {"id":"M42","title":"Museum / landscape","versions":["v1","v2","v3","v4"],"duration":60,"release":"v4","color":"#745780"},
 {"id":"C63","title":"Cafe / landscape","versions":["v1","v2","v3","v4"],"duration":60,"release":"v3","color":"#8b6941"},
 {"id":"G28","title":"Garden / landscape","versions":["v1","v2","v3","v4"],"duration":60,"release":"v4","color":"#386c59"},
 {"id":"X90","title":"Archive / portrait","versions":["v1"],"duration":60,"release":None,"color":"#495365"}
]
RELEASE={a['id']:a['release'] for a in ASSETS}
# 2/10 are two occurrences of the RED sail insert, 6 is a BLUE sail lookalike.
# 3 is the three-frame wall, 7 the four-frame wall; 5 DAY contact, 8 NIGHT.
ORDERS={
 'H17':{'v1':[0,2,3,5,1,6,7,8,4,9,10], 'v2':[1,0,4,2,5,3,6,8,7,9,10],
        'v3':[4,2,6,5,0,3,8,1,10,7,9], 'v4':[5,6,2,3,7,10,0,9,4,8,1]},
 'M42':{'v1':[1,0,3,2,5,4,6,7,8,9,10], 'v2':[5,2,0,4,1,3,6,8,7,9,10],
        'v3':[3,5,1,0,2,4,8,7,6,10,9], 'v4':[6,8,4,7,2,1,0,3,5,9,10]},
 'C63':{'v1':[2,4,0,5,1,3,6,8,7,9,10], 'v2':[3,1,5,0,4,2,6,8,7,9,10],
        'v3':[1,3,4,2,5,0,6,8,10,7,9], 'v4':[2,7,8,3,1,4,10,5,6,0,9]},
 'G28':{'v1':[4,3,2,1,0,5,6,8,7,9,10], 'v2':[2,1,4,0,5,3,6,8,7,9,10],
        'v3':[2,4,5,1,3,0,6,8,7,9,10], 'v4':[8,6,7,1,2,5,0,3,4,9,10]},
 'X90':{'v1':[0,1,2,3,4,5,6,7,8,9,10]}
}
LENGTHS={'v1':[5,4,6,5,4,6,5,4,5,5,7], 'v2':[4,6,5,6,4,5,6,4,5,4,7],
         'v3':[5,4,6,4,6,5,4,6,5,5,6], 'v4':[4,5,6,4,5,6,5,4,6,4,7]}
def shots(a,v):
 t=2;out=[]
 for m,length in zip(ORDERS[a][v],LENGTHS[v]):out.append((m,t,t+length));t+=length
 return out
def bounds(a,v,m):return next((s,e) for k,s,e in shots(a,v) if k==m)
def ticket(id,a,v,kind,span,owner,status='open',priority='p2'):
 return dict(id=id,asset_id=a,version=v,issue_type=kind,in_seconds=span[0],out_seconds=span[1],owner=owner,status=status,priority=priority,note='')
INITIAL=[
 ticket('R201','M42','v2','audio_gap',bounds('M42','v2',0),'audio'),
 ticket('R202','G28','v4','logo',bounds('G28','v4',4),'production','blocked','p1'),
 ticket('R203','H17','v1','subtitle',bounds('H17','v1',2),'editorial','resolved'),
 ticket('R204','H17','v2','audio_gap',(55,56),'audio','resolved'),
 ticket('R205','C63','v1','crop',bounds('C63','v1',3),'design'),
 ticket('R206','X90','v1','endcard',bounds('X90','v1',5),'production','blocked'),
 ticket('R207','G28','v1','color',bounds('G28','v1',1),'color'),
 ticket('R208','M42','v1','title',bounds('M42','v1',4),'design','resolved'),
 ticket('R209','H17','v3','subtitle',bounds('H17','v3',2),'editorial','resolved'),
 ticket('R210','C63','v3','endcard',bounds('C63','v3',8),'production','blocked'),
 ticket('R211','H17','v4','subtitle',bounds('H17','v4',2),'editorial','open'),
 ticket('R212','M42','v3','crop',bounds('M42','v3',3),'editorial','blocked'),
]
PROTECTED=['R203','R204','R205','R206','R207','R208','R211','R212']
FAULTS={('H17','v2'):['channel_swap'],('H17','v3'):['av_sync'],
 ('M42','v2'):['av_sync'],('M42','v4'):['audio_gap'],
 ('C63','v2'):['audio_gap'],('C63','v3'):['channel_swap'],
 ('G28','v2'):['av_sync','channel_swap']}
TARGETS=[]
def target(a,v,kind,m,owner,status='open',priority='p2',id=None):
 TARGETS.append(ticket(id,a,v,kind,bounds(a,v,m),owner,status,priority))
for a in ['H17','M42','C63','G28']:
 v=RELEASE[a]
 target(a,v,'subtitle',2,'editorial',priority='p1' if a in ['H17','G28'] else 'p2',id='R209' if a=='H17' else None)
 target(a,v,'crop',3,'editorial','blocked' if a in ['M42','G28'] else 'open','p1' if a=='C63' else 'p2')
for a in ['H17','C63']:
 target(a,RELEASE[a],'subtitle',10,'editorial','blocked' if a=='H17' else 'open')
for a in ['M42','G28']:
 target(a,RELEASE[a],'crop',7,'editorial',priority='p1' if a=='G28' else 'p2')
for a,owner,status,priority in [('H17','production','blocked','p2'),('M42','design','open','p1'),('C63','production','blocked','p2'),('G28','design','open','p2')]:
 target(a,RELEASE[a],'endcard',5,owner,status,priority)
for a,owner,status,priority in [('H17','design','blocked','p3'),('M42','production','blocked','p2'),('C63','design','open','p1'),('G28','design','open','p2')]:
 target(a,RELEASE[a],'endcard',8,owner,status,priority,id='R210' if a=='C63' else None)
for a in ['M42','G28']:target(a,RELEASE[a],'title',4,'design',priority='p1' if a=='M42' else 'p2')
for (a,v),kinds in FAULTS.items():
 for kind in kinds:target(a,v,kind,0,'audio','blocked' if (a,v)==('H17','v3') else 'open','p1')
target('M42','v2','audio_gap',0,'audio','dismissed',id='R201')
target('G28','v4','logo',4,'production','resolved','p1',id='R202')
SCENES=[]
def scene(a,v,m,speech,*,speaker='NORA',side=None,listen=False,card=None,degrade=False,overlap=None):
 side=side or ('right' if len(SCENES)%2 else 'left')
 others=[x['id'] for x in ASSETS if x['id']!=a];da=others[(len(SCENES)*3)%len(others)]
 dv='v1' if da=='X90' else RELEASE[da]
 SCENES.append(dict(asset=a,version=v,motif=m,speech=speech,speaker=speaker,side=side,
  decoy=(da,dv,(m+4)%11),listen=listen,card=card,degrade=degrade,overlap=overlap))
scene('H17','v1',2,'We are conforming picture notes to the delivery manifest, not the newest filename. Fix the spelling in this red sail insert in all four landscape films. Not the blue sail take. Harbor and Cafe repeat the red insert later: make separate tickets for both occurrences. Preserve the gap between them. Reopen Harbor\'s matching delivery ticket instead of duplicating it. Leave its old reference and future cut tickets alone.')
scene('M42','v1',3,'The three-frame wall needs reframing in all four delivery cuts. Editorial owns it. Museum and Garden await composition approval, so hold those two. Harbor is normal; Cafe is urgent. These directions do not cover the four-frame wall.')
scene('H17','v4',2,'This looks like the newest Harbor cut. I propose applying all picture notes here and marking the older subtitle ticket complete. We could merge the two inserts into one long range.',speaker='JAY')
scene('M42','v1',7,'Separately reframe the four-frame wall in Museum and Garden. Both are ready for editorial. Garden is urgent; Museum is normal. Do not inherit the hold on the other gallery shot.')
scene('M42','v1',5,'Replace the DAY and NIGHT contact panels in all four delivery films. At this point I would send both panels to design. Museum day is urgent. Legal can still block a specific panel. Read the approved legal receipt when Maya presents it.')
scene('H17','v1',5,'The Harbor DAY approval is conditional on the displayed web address ending in dot org. The NIGHT address is cleared independently. If that day condition fails, keep day with production on hold; do not guess an address.',speaker='MAYA',degrade=True,
 card=['LEGAL RECEIPT LR-184 / HARBOR','DAY: clear only if displayed URL ends .org','NIGHT: cleared / separate address'])
scene('M42','v1',8,'Museum approval covers DAY, not NIGHT. Cafe is the reverse: NIGHT is cleared, DAY is still waiting on the street address. Garden has both panels cleared. A producer release date does not override these legal holds.',speaker='MAYA',degrade=True,overlap='I thought everything was approved yesterday.',
 card=['LEGAL RECEIPT LR-185 / SCOPE','MUSEUM: DAY cleared; NIGHT pending','CAFE: NIGHT cleared; DAY pending','GARDEN: DAY and NIGHT cleared'])
scene('C63','v1',8,'I heard Maya say Cafe day was cleared and Museum night was ready. I will send both to design at priority one.',speaker='JAY')
scene('H17','v1',8,'Harbor NIGHT is legally cleared but we are postponing that design work: keep design as owner, block it, and downgrade it to priority three. This is a scheduling hold, not a legal hold. It does not release Harbor DAY.')
scene('C63','v1',8,'The Cafe NIGHT job already exists as a blocked production ticket. Use that same record, move it to design, open it, and make it urgent for tonight. Do not touch the archive panel or Cafe DAY.')
scene('H17','v1',2,'Correction to the subtitle batch: Harbor\'s FIRST red insert and Garden\'s red insert are urgent. Harbor\'s SECOND red insert is blocked for translation and stays normal priority. Cafe\'s two red inserts and Museum stay normal and open. Each range is a whole red insert, not the whole boat sequence.')
scene('G28','v1',3,'I would close the Garden gallery hold because the four-frame wall was approved. The second red Harbor insert should be urgent too.',speaker='JAY')
scene('M42','v1',4,'Update the title lettering on this brand roundel in Museum and Garden delivery cuts. Design owns both. Museum is urgent; Garden is normal. The separate Garden logo clearance ticket must keep its identity and priority when resolved.')
scene('H17','v3',0,'Technical handoff: inspect the actual exports we audition, using the first calibration slate in each. The second calibration slate later in an export is a control. Open one ticket for each independently observed fault. Two faults may coexist; a music bed does not prove dialogue continuity.',speaker='ELI',listen=True)
scene('C63','v2',0,'Inspect this exact Cafe export. The later clean control has the same spoken phrase. Compare it if the first phrase seems shortened. Record the whole first slate shot for a verified fault, not just the instant of an interruption.',speaker='ELI',listen=True)
scene('M42','v2',0,'The Museum preliminary dropout ticket may be wrong. Inspect this first slate independently, including lamp timing and ear routing. We do not copy a diagnosis from another version.',speaker='ELI',listen=True)
scene('H17','v2',0,'Check this Harbor export too, and compare the visual left and right lamps with the channels. The remote meeting link is not our source master; only source-export faults are ticketed.',speaker='ELI',listen=True)
scene('M42','v4',0,'This is the Museum delivery export. Compare first slate speech with the clean second slate. Listen beyond the music. Keep technical findings on the export actually checked.',speaker='ELI',listen=True)
scene('C63','v3',0,'This Cafe delivery export also needs independent technical inspection. A correct pulse time does not by itself mean correct channel routing.',speaker='ELI',listen=True)
scene('G28','v2',0,'Check this Garden export without assuming there is only one problem. Compare both lamps and both channels. If separate fault classes coexist, make separate tickets over the same first slate range.',speaker='ELI',listen=True)
scene('G28','v4',0,'This Garden delivery export is our clean comparison. Verify it, but do not create a technical job merely because other versions need one. Its deliberate low percussion and the meeting connection noise are not export faults.',speaker='ELI',listen=True)
scene('M42','v2',0,'I think we should mark the technical problem resolved for release and replace the old ticket type in place. We can close Harbor too.',speaker='NORA')
scene('M42','v2',0,'Technical disposition is mine. Dismiss the old Museum dropout diagnosis, retain its ID and other fields, and create the independently verified fault separately. Harbor delivery technical work is blocked, still audio priority one. Harbor reference export technical work stays open. No technical fault is resolved by the producer\'s schedule.',speaker='ELI',degrade=True,
 card=['AUDIO HANDOFF / ELI','MUSEUM preliminary diagnosis: withdraw, retain ID','HARBOR delivery: HOLD / audio / urgent','HARBOR reference export: remains OPEN'])
scene('G28','v4',4,'Garden logo clearance is signed for this delivery export. Resolve the existing logo record, keeping its original owner, priority and range. This clearance is independent of the new title lettering job.',speaker='MAYA')
scene('H17','v1',5,'There is still no revised Harbor day web address. The condition in my receipt remains in force. Neither urgency nor a suggestion from production changes that. Museum NIGHT and Cafe DAY are still legally blocked.',speaker='MAYA')
scene('M42','v1',3,'Our three-frame Museum and Garden gallery holds remain. Approval of the four-frame shot did not release them. Keep Cafe\'s three-frame task urgent. Jay\'s proposed closures and owner changes were not adopted.')
scene('X90','v1',5,'Please apply the same panel fixes to the portrait archive and reopen all old subtitle tickets while you are there. It will save another meeting.',speaker='JAY')
scene('G28','v1',1,'Final scope: only the four landscape deliveries for picture notes. Use the manifest exactly. Leave the portrait archive, reference picture history, future Harbor cut and old Museum delivery crop alone. Apply domain decisions as agreed. Do not create work for a suggestion I never adopted. Verify the saved system state before handoff.')
assert len(TARGETS)==32
