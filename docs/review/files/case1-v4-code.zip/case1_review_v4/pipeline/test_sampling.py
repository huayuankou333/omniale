from pathlib import Path
from media import sheet,ROOT
out=ROOT/"private/qa/sampling-regression.jpg"
r=sheet(ROOT/"public/sources/H17_v3.mp4",0,60,4,out)
assert len(r["times"])==15 and r["times"][-1]==56
r=sheet(ROOT/"public/sources/H17_v3.mp4",59.9,59.9,1,ROOT/"private/qa/last-frame.jpg")
assert len(r["times"])==1
r=sheet(ROOT/"public/sources/H17_v3.mp4",0,60,3,ROOT/"private/qa/paginated.jpg")
assert len(r["times"])==20 and len(r["_images"])==2
r=sheet(ROOT/"public/sources/H17_v3.mp4",0,20,1.2,ROOT/"private/qa/fractional.jpg")
assert len(r["times"])==17 and len(r["_images"])==2
print("PASS: exclusive end, last valid frame, complete pagination, fractional sample step")
