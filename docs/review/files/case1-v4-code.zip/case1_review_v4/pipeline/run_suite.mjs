import fs from 'node:fs/promises';
import path from 'node:path';
import {spawn} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import {SHARED} from './shared_config.mjs';
import {digest} from './shared_perception.mjs';

const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const base=process.env.OMNIALE_PROXY_BASE_URL||'https://api-temporary.nju-link.com/v1';
const keys={'gpt-6-luna':process.env.OMNIALE_GPT_KEY,'gpt-6.1-sol':process.env.OMNIALE_GPT_KEY,
  'glm-5.3':process.env.OMNIALE_GLM_KEY,k3:process.env.OMNIALE_KIMI_KEY};
if(Object.values(keys).some(x=>!x?.trim()))throw new Error('Set OMNIALE_GPT_KEY, OMNIALE_GLM_KEY and OMNIALE_KIMI_KEY in process environment');
const runsRoot=process.env.CASE1_RUNS_DIR||path.join(path.dirname(root),'runs');
const suiteDir=path.join(runsRoot,`shared-suite-${new Date().toISOString().replace(/[:.]/g,'-')}`);
await fs.mkdir(suiteDir,{recursive:true});
const summary={protocol:SHARED,base_url:base,created_at:new Date().toISOString(),results:[],comparable:false};
const comparisonFields=['shared_config_sha256','shared_perception_sha256','initial_input_sha256','task_sha256',
 'engine_sha256','conform_sha256','ticket_scoring_sha256','scoring_sha256','truth_sha256','input_sha256','source_catalog_sha256','transcript_sha256','frame_manifest_sha256',
 'provider_adapter_sha256','harness_sha256','media_tools_sha256','source_hashes','initial_frame_hashes','vision_base_url'];
for(const model of SHARED.models){
  console.log(`Starting ${model} with shared perception and identical limits`);
  const env={...process.env,CASE1_MODEL:model,CASE1_PROVIDER:'openai',CASE1_MODE:'full',
    CASE1_PERCEPTION_ROUTE:'shared_tools',CASE1_MAX_TURNS:String(SHARED.limits.model_turns),CASE1_ASR_MODEL:SHARED.asr.model,
    CASE1_RUNS_DIR:suiteDir,OMNIALE_PROXY_BASE_URL:base,OMNIALE_PROXY_KEY:keys[model],
    OMNIALE_VISION_KEY:process.env.OMNIALE_VISION_KEY||keys['gpt-6.1-sol'],
    OMNIALE_VISION_BASE_URL:process.env.OMNIALE_VISION_BASE_URL||base};
  delete env.CASE1_RESUME_RUN;
  // Do not expose the other candidates' credentials to a child process.
  delete env.OMNIALE_GPT_KEY;delete env.OMNIALE_GLM_KEY;delete env.OMNIALE_KIMI_KEY;
  let out='';
  const exitCode=await new Promise((resolve,reject)=>{
    const p=spawn(process.execPath,[path.join(root,'pipeline/run.mjs')],{env,windowsHide:true,stdio:['ignore','pipe','pipe']});
    p.stdout.on('data',d=>{const text=d.toString();out+=text;process.stdout.write(text);});
    p.stderr.on('data',d=>process.stderr.write(d));p.on('error',reject);p.on('exit',resolve);
  });
  const runDir=/Run directory: ([^\r\n]+)/.exec(out)?.[1];
  let result={model,exit_code:exitCode,run_dir:runDir||null,status:'infrastructure_error',score:null,valid_model_trial:false};
  if(runDir){
    try{
      const evaluation=JSON.parse(await fs.readFile(path.join(runDir,'evaluation.json'),'utf8'));
      const manifest=JSON.parse(await fs.readFile(path.join(runDir,'manifest.json'),'utf8'));
      const trace=JSON.parse(await fs.readFile(path.join(runDir,'agent_trace.json'),'utf8'));
      result={...result,status:evaluation.run_status,score:evaluation.valid_model_trial?evaluation.score:null,
        valid_model_trial:evaluation.valid_model_trial,complete_decisions:evaluation.complete_decisions,complete_releases:evaluation.complete_releases,section_scores:evaluation.section_scores,legacy_ticket_score:evaluation.legacy_ticket_score,budget:trace.budget,
        comparison_fingerprint:digest(Object.fromEntries(comparisonFields.map(k=>[k,manifest[k]]))),
        raw_images_sent:trace.turns.reduce((n,t)=>n+(t.request_image_count||0),0),
        returned_models:[...new Set(trace.turns.map(t=>t.returned_model))]};
    }catch(e){result.error=e.message;}
  }
  summary.results.push(result);
  await fs.writeFile(path.join(suiteDir,'suite.json'),JSON.stringify(summary,null,2));
}
summary.comparable=summary.results.every(r=>r.valid_model_trial&&r.raw_images_sent===0)&&
  new Set(summary.results.map(r=>r.comparison_fingerprint)).size===1;
summary.all_below_80=summary.comparable&&summary.results.every(r=>r.score<80);
summary.finished_at=new Date().toISOString();
await fs.writeFile(path.join(suiteDir,'suite.json'),JSON.stringify(summary,null,2));
console.log(JSON.stringify({suiteDir,comparable:summary.comparable,all_below_80:summary.all_below_80,
  results:summary.results.map(({model,status,score})=>({model,status,score}))},null,2));
if(!summary.comparable)process.exitCode=2;
