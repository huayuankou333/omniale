import assert from 'node:assert/strict';
import {toAnthropic,requestSpec,SYSTEM} from './providers.mjs';
import {tools} from './run.mjs';
const content=[{type:'input_text',text:'task text'},{type:'input_image',image_url:'data:image/jpeg;base64,AAAA',detail:'high'}];
const assistant=[{type:'thinking',thinking:'test',signature:'signed-block'},{type:'tool_use',id:'t1',name:'get_state',input:{}}];
const history=[{role:'user',content},{type:'anthropic_message',role:'assistant',content:assistant},
 {type:'function_call',call_id:'t1',name:'get_state',arguments:'{}'},
 {type:'function_call_output',call_id:'t1',output:'{"ok":true}'},{role:'user',content}];
const messages=toAnthropic(history);
assert.equal(messages.length,3);
assert.deepEqual(messages[1].content,assistant);
assert.equal(messages[2].content[0].tool_use_id,'t1');
assert.equal(messages[2].content[2].source.data,'AAAA');
const spec=requestSpec({provider:'openai',base:'https://example.invalid/v1',key:'placeholder',model:'gpt-6.1-sol',history:[history[0]],tools});
assert.equal(spec.body.instructions,SYSTEM);
assert.deepEqual(spec.body.input,[history[0]]);
assert.deepEqual(spec.body.tools,tools);
assert.equal(spec.body.max_output_tokens,9000);
const anthropic=requestSpec({provider:'anthropic',base:'https://example.invalid/protocol/anthropic',key:'placeholder',model:'claude-opus-5-5',history,tools});
assert.equal(anthropic.url,'https://example.invalid/protocol/anthropic/v1/messages');
assert.deepEqual(anthropic.body.tools.map(t=>t.input_schema),tools.map(t=>t.parameters));
assert.equal(anthropic.body.output_config.effort,'medium');
console.log('Provider transport tests passed: text/images/tool schemas/results and signed thinking preserved.');
