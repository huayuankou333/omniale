// Connectivity only. Never reports task scores and never modifies a business workspace.
import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {SHARED,assertTextOnly} from './shared_config.mjs';
import {SharedPerception} from './shared_perception.mjs';
import {requestModel} from './providers.mjs';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const out=path.resolve(process.env.CASE1_PREFLIGHT_OUTPUT||path.join(root,'SHARED_PREFLIGHT.json'));
const base=process.env.OMNIALE_PROXY_BASE_URL||'https://api-temporary.nju-link.com/v1';
const keys={'gpt-6-luna':process.env.OMNIALE_GPT_KEY,'gpt-6.1-sol':process.env.OMNIALE_GPT_KEY,
  'glm-5.3':process.env.OMNIALE_GLM_KEY,k3:process.env.OMNIALE_KIMI_KEY};
const perception=new SharedPerception({cacheDir:process.env.CASE1_SHARED_CACHE||path.join(root,'shared_cache',SHARED.protocol),
  base:process.env.OMNIALE_VISION_BASE_URL||base,key:process.env.OMNIALE_VISION_KEY||keys['gpt-6.1-sol']});
const report={kind:'shared-perception connectivity check; NOT benchmark scores',protocol:SHARED,created_at:new Date().toISOString(),results:[]};
const scrub=text=>Object.values(keys).filter(Boolean).reduce((s,k)=>s.replaceAll(k,'[REDACTED]'),String(text)).replace(/sk-[\w-]+/g,'[REDACTED]');
try{
 report.visual_evidence=await perception.observe([path.join(root,'prepared/frames/000.jpg')],{media:'review',timestamps:[0],layout:'one decoded frame per image'});
}catch(e){report.vision_error=scrub(e.message);}
if(report.visual_evidence)for(const model of SHARED.models){
 const tool={type:'function',name:'record_observation',description:'Return the observed label for this connectivity check.',
   parameters:{type:'object',properties:{observation:{type:'string'}},required:['observation'],additionalProperties:false},strict:false};
 const history=[{role:'user',content:[{type:'input_text',text:'Connectivity check only. Do not operate any ticket system. Call record_observation exactly once with a short visible label from this shared evidence. After its result, reply OK and stop.\n'+JSON.stringify(report.visual_evidence)}]}];
 const entry={model,raw_images_sent:0,status:'infrastructure_error',turns:[]};
 try{
  if(!keys[model])throw new Error('Missing candidate key');
  for(let i=0;i<2;i++){
   assertTextOnly(history);
   const payload=await requestModel({provider:'openai',base,key:keys[model],model,history,tools:[tool],
     reasoningEffort:SHARED.agent.reasoning_effort,maxOutput:SHARED.agent.max_output_tokens,maxAttempts:1,timeoutMs:90000});
   entry.raw_images_sent+=payload.request_image_count;
   entry.turns.push({returned_model:payload.model,usage:payload.usage,status:payload.status,output:payload.output});
   history.push(...payload.output);
   const calls=payload.output.filter(x=>x.type==='function_call');
   if(i===0){
    if(calls.length!==1||calls[0].name!=='record_observation')throw new Error('Connectivity check did not produce the requested tool call');
    const args=JSON.parse(calls[0].arguments);if(typeof args.observation!=='string')throw new Error('Invalid tool arguments');
    history.push({type:'function_call_output',call_id:calls[0].call_id,output:JSON.stringify({received:true,observation:args.observation})});
   }else{
    if(calls.length||payload.status!=='completed'||!payload.output.some(x=>x.type==='message'))throw new Error('No final response after tool output');
    entry.status='passed';
   }
  }
 }catch(e){entry.error=scrub(e.message);}
 report.results.push(entry);await fs.writeFile(out,JSON.stringify(report,null,2));
 console.log(JSON.stringify({model,status:entry.status,error:entry.error,raw_images_sent:entry.raw_images_sent}));
}
report.finished_at=new Date().toISOString();
await fs.writeFile(out,JSON.stringify(report,null,2));
console.log(JSON.stringify({output:out,vision_passed:!!report.visual_evidence,passed:report.results.filter(x=>x.status==='passed').length,total:4}));
if(!report.visual_evidence||report.results.some(x=>x.status!=='passed'))process.exitCode=2;
