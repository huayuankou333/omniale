// Versioned comparison protocol. Change once for the whole suite, never per candidate.
export const SHARED = Object.freeze({
  protocol: 'case1-v4-shared-15turns-v1',
  models: ['gpt-6-luna', 'glm-5.3', 'k3', 'gpt-6.1-sol'],
  vision: Object.freeze({model: 'gpt-6.1-sol', reasoning_effort: 'low', max_output_tokens: 7000, batch_size: 8}),
  asr: Object.freeze({model: 'base.en', device: 'cpu', compute_type: 'int8', cpu_threads: 4}),
  agent: Object.freeze({reasoning_effort: 'high', max_output_tokens: 9000}),
  limits: Object.freeze({model_turns: 15, output_tokens: 135000, tool_calls: 120,
    visual_frames: 1024, asr_seconds: 1800, measurement_seconds: 900}),
});

export class BudgetExceeded extends Error {
  constructor(resource) { super(`Shared budget exhausted: ${resource}`); this.name = 'BudgetExceeded'; this.resource = resource; }
}
export class SharedBudget {
  constructor(limits = SHARED.limits) {
    this.limits = {...limits}; this.used = Object.fromEntries(Object.keys(limits).map(k => [k, 0]));
  }
  charge(cost) {
    for (const [k, n] of Object.entries(cost)) {
      if (!(k in this.used) || !Number.isFinite(n) || n < 0) throw new Error('Invalid budget charge');
      if (this.used[k] + n > this.limits[k] + 1e-8) throw new BudgetExceeded(k);
    }
    for (const [k, n] of Object.entries(cost)) this.used[k] += n;
  }
  remaining(k) { return Math.max(0, Math.floor(this.limits[k] - this.used[k])); }
  snapshot() { return {limits: {...this.limits}, used: {...this.used}}; }
}

export function visualFrameCount(args) {
  if (args.seconds !== undefined) return 1;
  const {start_seconds: start, end_seconds: end, step_seconds: step} = args;
  if (![start,end,step].every(Number.isFinite) || start < 0 || end < start || step < .1) throw new Error('Invalid sampling interval');
  const n = start === end ? 1 : Math.ceil((end-start-1e-5)/step);
  if (n < 1 || n > 256) throw new Error('Use 1 to 256 frames per request');
  return n;
}

export function assertTextOnly(history) {
  // Fail closed for both structured images and accidentally embedded data URLs.
  const text = JSON.stringify(history);
  if (/"(?:input_image|image_url|input_audio|input_video|image)"\s*[:,]|data:(?:image|audio|video)\//i.test(text))
    throw new Error('Shared route must never send raw media to a candidate model');
}
