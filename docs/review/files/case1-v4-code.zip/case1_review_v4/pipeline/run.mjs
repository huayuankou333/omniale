import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import {spawn} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import {loadEnv} from '../../harness/config.mjs';
import {readState,applyTransaction,applyReleaseTransaction,validateTicket,validateGraph,releaseGate,durationOf} from '../app/engine.mjs';
import {evaluate} from './evaluate.mjs';
import {requestModel} from './providers.mjs';
import {SHARED, SharedBudget, BudgetExceeded, visualFrameCount, assertTextOnly} from './shared_config.mjs';
import {SharedPerception, PerceptionInfrastructureError, digest} from './shared_perception.mjs';
loadEnv();
const ROOT=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const FFMPEG=process.env.FFMPEG_PATH||'F:\\annconda\\Lib\\site-packages\\imageio_ffmpeg\\binaries\\ffmpeg-win-x86_64-v7.1.exe';
const PYTHON=process.env.CASE1_PYTHON||'F:\\annconda\\python.exe';
const perceptionRoute=process.env.CASE1_PERCEPTION_ROUTE||'shared_tools';
if(!['shared_tools','native_frames'].includes(perceptionRoute))throw new Error('Invalid CASE1_PERCEPTION_ROUTE');
const shared=perceptionRoute==='shared_tools';
const mode=process.env.CASE1_MODE||'full';
if(shared&&mode!=='full')throw new Error('The shared four-model protocol requires full evidence');
if(shared&&process.env.CASE1_MAX_TURNS&&Number(process.env.CASE1_MAX_TURNS)!==SHARED.limits.model_turns)throw new Error('Change the versioned shared config, not individual model budgets');
if(shared&&process.env.CASE1_ASR_MODEL&&process.env.CASE1_ASR_MODEL!==SHARED.asr.model)throw new Error('ASR model must match the shared protocol');
if(shared)process.env.CASE1_ASR_MODEL=SHARED.asr.model;
if(!['full','no_media','video_only','audio_only'].includes(mode))throw new Error('Invalid CASE1_MODE');
const provider=process.env.CASE1_PROVIDER||'openai';
const key=(provider==='anthropic'?process.env.OMNIALE_ANTHROPIC_KEY:process.env.OMNIALE_PROXY_KEY)?.trim();
const base=(provider==='anthropic'?(process.env.OMNIALE_ANTHROPIC_BASE_URL||'https://routify-pub.alibaba-inc.com/protocol/anthropic'):
 (process.env.OMNIALE_PROXY_BASE_URL||'https://api-temporary.nju-link.com/v1')).replace(/\/$/,'');
const model=process.env.CASE1_MODEL||'gpt-6-luna';
if(!/^[\w.-]+$/.test(model))throw new Error('Invalid model identifier');
if(shared&&(provider!=='openai'||!SHARED.models.includes(model)))throw new Error('Shared comparison requires one of the four configured candidates');
const maxTurns=shared?SHARED.limits.model_turns:Math.min(60,Math.max(1,Number(process.env.CASE1_MAX_TURNS||60)));
const object=(properties={},required=[])=>({type:'object',properties,required,additionalProperties:false});
const str={type:'string'},num={type:'number'};
const tool=(name,description,parameters=object())=>({type:'function',name,description,parameters,strict:false});
export function allowedReadPath(p){return typeof p==='string'&&['task.md','conform.json','app/engine.mjs'].includes(p);}
export const tools=[
 tool('get_state','Read the live persistent database and source asset/version catalog.'),
 tool('read_file','Read task.md, conform.json or app/engine.mjs only. The normal app has no hidden business answers.',object({path:str},['path'])),
 tool('apply_changes','Atomically create/update persistent review tickets. Use one request_id per distinct transaction; identical retries are idempotent. Update existing tickets by id. No hidden answer feedback is returned.',
   object({request_id:str,operations:{type:'array',items:object({action:{type:'string',enum:['create','update']},id:str,fields:object({
     asset_id:str,version:str,issue_type:str,in_seconds:num,out_seconds:num,owner:str,status:str,priority:str,note:str,depends_on:{type:"array",items:str},superseded_by:{type:"array",items:str},split_from:{type:["string","null"]},duplicate_of:{type:["string","null"]}
   })},['action','fields'])}},['request_id','operations'])),
 tool('update_releases','Atomically update 1-12 release plans. Use the current expected_revision from get_state or the last receipt. required_ticket_ids are direct roots; status/blockers must match the live transitive dependency gate. Identical retries are idempotent.',
   object({request_id:str,expected_revision:{type:'integer'},operations:{type:'array',items:object({id:str,fields:object({version:str,required_ticket_ids:{type:'array',items:str},status:{type:'string',enum:['hold','queued','ready']},blocker_ticket_ids:{type:'array',items:str}},['version','required_ticket_ids','status','blocker_ticket_ids'])},['id','fields'])}},['request_id','expected_revision','operations'])),
 tool('get_frame','Inspect a frame of the review recording at meeting-relative seconds. Returns timestamped observations from the same fixed visual tool used by every candidate; no authorized decision labels.',
   object({seconds:num},['seconds'])),
 tool('contact_sheet','Inspect up to 256 frames using the fixed shared visual observer on decoded review or source frames, automatically paginated into readable 16-frame sheets with no subsampling. For source specify asset_id/version; times are source-relative. Sampling is [start_seconds,end_seconds); end may equal video duration. Equal start/end requests one frame. No shot labels or boundaries are supplied.',
   object({media:{type:'string',enum:['review','source']},asset_id:str,version:str,start_seconds:num,end_seconds:num,step_seconds:num},['media','start_seconds','end_seconds','step_seconds'])),
 tool('transcribe_source','Independently transcribe speech from a selected source export interval (max 30s). Does not classify faults.',
   object({asset_id:str,version:str,start_seconds:num,end_seconds:num},['asset_id','version','start_seconds','end_seconds'])),
 tool('transcribe_review','Re-transcribe a meeting interval from decoded recording PCM (max 30s), optionally selecting left or right channel to separate overlap. Returns independent ASR, not author narration.',object({start_seconds:num,end_seconds:num,channel:{type:'string',enum:['mix','left','right']}},['start_seconds','end_seconds'])),
 tool('get_transcript','Read independently transcribed recording speech in a meeting-relative time window. Contains ASR errors, not ground truth.',
   object({start_seconds:num,end_seconds:num},['start_seconds','end_seconds'])),
 tool('measure_audio','Measure 100ms L/R RMS plus spectral band energies of a source export. Does not identify events, label faults or provide ticket answers.',
   object({asset_id:str,version:str,start_seconds:num,end_seconds:num},['asset_id','version','start_seconds','end_seconds'])),
 tool('public_check','Check persisted ticket schema, graph and live release gate consistency. Does not evaluate the review decisions.'),
 tool('finish','Finish the task. The database state, not this summary, is the deliverable.',object({summary:str},['summary']))
];
function child(exe,args){
 return new Promise((resolve,reject)=>{
  const p=spawn(exe,args,{windowsHide:true,stdio:['ignore','pipe','pipe']});let out='',err='';
  const fail=e=>reject(shared?new PerceptionInfrastructureError(e.message):e);
  const timer=setTimeout(()=>{p.kill();fail(new Error('Tool timed out'));},60000);
  p.stdout.on('data',d=>out+=d);p.stderr.on('data',d=>err+=d);
  p.on('error',e=>{clearTimeout(timer);fail(e)});
  p.on('exit',code=>{clearTimeout(timer);code===0?resolve(out):fail(new Error(err.slice(0,1500)))});
 });
}
const sha=async file=>crypto.createHash('sha256').update(await fs.readFile(file)).digest('hex');
async function main(){
 if(!key)throw new Error('Set the provider key in the process environment. Keys are never saved by this pipeline.');
 const budget=shared?new SharedBudget():null;
 const perception=shared?new SharedPerception({cacheDir:process.env.CASE1_SHARED_CACHE||path.join(ROOT,'shared_cache',SHARED.protocol),
   base:process.env.OMNIALE_VISION_BASE_URL||base,key:process.env.OMNIALE_VISION_KEY,
   asrFingerprint:await sha(path.join(ROOT,'pipeline/media.py'))}):null;
 const sourceHashCache=new Map();
 async function mediaHash(file){if(!sourceHashCache.has(file))sourceHashCache.set(file,await sha(file));return sourceHashCache.get(file);}
 const stamp=new Date().toISOString().replaceAll(':','-').replaceAll('.','-');
 const resume=process.env.CASE1_RESUME_RUN;
 if(shared&&resume)throw new Error('Shared trials start from a fresh workspace; interrupted trials are invalid, not resumed with altered evidence.');
 const runDir=resume?path.resolve(resume):path.join(process.env.CASE1_RUNS_DIR||path.join(path.dirname(ROOT),'runs'),`case1_review_v4-${model}-${mode}-${perceptionRoute}-${stamp}`);
 const saved=resume?JSON.parse(await fs.readFile(path.join(runDir,'agent_trace.json'),'utf8')):null;
 if(saved&&(saved.model!==model||saved.mode!==mode||saved.status!=='infrastructure_error'))throw new Error('Resume requires matching model/mode and an interrupted infrastructure-error run');
 const workspace=path.join(runDir,'workspace');
 await fs.mkdir(path.join(workspace,'app'),{recursive:true});
 if(!resume){await fs.cp(path.join(ROOT,'public'),workspace,{recursive:true});
 await fs.copyFile(path.join(ROOT,'app/engine.mjs'),path.join(workspace,'app/engine.mjs'));}
 const stateFile=path.join(workspace,'state.json');
 const prepared=path.join(ROOT,'prepared');
 let transcript={segments:[],duration_seconds:0},frames=[];
 if(mode!=='no_media'){
   transcript=JSON.parse(await fs.readFile(path.join(prepared,'transcript.json'),'utf8'));
   frames=JSON.parse(await fs.readFile(path.join(prepared,'frames.json'),'utf8'));
 }
 const audioEnabled=['full','audio_only'].includes(mode),videoEnabled=['full','video_only'].includes(mode);
 const brief=await fs.readFile(path.join(workspace,'task.md'),'utf8');
 const content=[{type:'input_text',text:brief+`\n\nRoute: ${mode}. This is a general model plus perception tools, NOT native audiovisual input. `+
   `Use the tools to inspect evidence and change the live database. You have at most ${maxTurns} model turns. `+
   (audioEnabled?'\nIndependent timestamped ASR:\n'+transcript.segments.map(s=>`[${s.start}-${s.end}s] ${s.text}`).join('\n'):'\nAudio evidence is unavailable in this ablation.')+
   (videoEnabled?'\nRegular sampled frames follow. Request additional exact-time frames when needed.':'\nVideo evidence is unavailable in this ablation.')}];
 if(videoEnabled&&!shared)for(const f of frames){
   content.push({type:'input_text',text:`Review recording timestamp ${f.time} seconds:`});
   content.push({type:'input_image',image_url:`data:image/jpeg;base64,${(await fs.readFile(path.join(prepared,f.file))).toString('base64')}`,detail:'high'});
 }
 if(shared){
   if(transcript.model!==SHARED.asr.model)throw new Error('Prepared ASR does not match the shared protocol');
   content[0].text=content[0].text.replace('Regular sampled frames follow. Request additional exact-time frames when needed.',
     'Shared timestamped visual observations follow. Additional frame/contact-sheet requests use the same observer. Observations and ASR may be wrong; cross-check evidence.');
   content[0].text+='\nCommon resource limits (including initial evidence): '+JSON.stringify(SHARED.limits)+
     '\nEvery candidate receives text-only tool evidence. Cache hits consume the same logical budget as misses. No tool has access to private answers.';
 }
 const history=[{role:'user',content}];
 const audit=JSON.parse(await fs.readFile(path.join(ROOT,'private/leakage_audit.json'),'utf8'));
 if(!audit.pass)throw new Error('Run the leakage audit successfully before evaluation');
 await fs.writeFile(path.join(runDir,'model_input_audit.json'),JSON.stringify({
   text_blocks:content.filter(x=>x.type==='input_text'),tools,frame_files:videoEnabled?frames:[],public_workspace_files:audit.public_files,
   perception_route:perceptionRoute, candidate_raw_image_count:shared?0:(videoEnabled?frames.length:0),
   note:shared?'Shared tool evidence; exact initial observations are appended after bootstrap.':'Exact initial text/tool schemas; image bytes are represented by actual prepared files.'},null,2));
 const frozen={model,requested_model:model,provider,base_url:base,mode,route:shared?'text-only candidate + shared cached vision + shared ASR + PCM tools':'general-agent + sampled frames + independent ASR + callable PCM measurements',
   perception_route:perceptionRoute,shared_protocol:shared?SHARED:null,shared_config_sha256:shared?await sha(path.join(ROOT,'pipeline/shared_config.mjs')):null,
   shared_perception_sha256:shared?await sha(path.join(ROOT,'pipeline/shared_perception.mjs')):null,
   vision_base_url:shared?perception.base:null,candidate_raw_image_count:shared?0:(videoEnabled?frames.length:0),
   asr_model:audioEnabled?transcript.model:null,initial_frame_count:videoEnabled?frames.length:0,max_turns:maxTurns,
   engine_sha256:await sha(path.join(ROOT,'app/engine.mjs')),conform_sha256:await sha(path.join(workspace,'conform.json')),ticket_scoring_sha256:await sha(path.join(ROOT,'pipeline/evaluate_tickets.mjs')),
   scoring_sha256:await sha(path.join(ROOT,'pipeline/evaluate.mjs')),truth_sha256:await sha(path.join(ROOT,'private/truth.json')),
   input_sha256:await sha(path.join(workspace,'inputs/review.mp4')),task_sha256:await sha(path.join(workspace,'task.md')),
   harness_sha256:await sha(path.join(ROOT,'pipeline/run.mjs')),media_tools_sha256:await sha(path.join(ROOT,'pipeline/media.py')),
   provider_adapter_sha256:await sha(path.join(ROOT,'pipeline/providers.mjs')),
   source_catalog_sha256:await sha(path.join(ROOT,'public/state.json')),
   transcript_sha256:await sha(path.join(prepared,'transcript.json')),
   frame_manifest_sha256:await sha(path.join(prepared,'frames.json')),
   initial_frame_hashes:await Promise.all(frames.map(async f=>({time:f.time,file:f.file,sha256:await sha(path.join(prepared,f.file))}))),
   source_hashes:Object.fromEntries(await Promise.all((await fs.readdir(path.join(ROOT,'public/sources'))).sort().map(async f=>[f,await sha(path.join(ROOT,'public/sources',f))]))),
   thinking_configuration:shared?{effort:SHARED.agent.reasoning_effort}:provider==='anthropic'?{type:'adaptive',effort:'medium'}:{effort:'medium'},max_output_tokens:9000,
   transport:{stream:process.env.CASE1_STREAM==='1',request_timeout_ms:process.env.CASE1_STREAM==='1'?600000:240000,max_transport_attempts:3},
   created_at:new Date().toISOString(),leakage_audit:audit,reasoning_effort:shared?SHARED.agent.reasoning_effort:'medium',private_data_exposed:false};
 if(!resume)await fs.writeFile(path.join(runDir,'manifest.json'),JSON.stringify(frozen,null,2));
 const trace=saved||{...frozen,turns:[],status:'running'};
 if(saved){
   for(const k of ['input_sha256','truth_sha256','scoring_sha256','task_sha256','media_tools_sha256','transcript_sha256','frame_manifest_sha256'])if(saved[k]!==frozen[k])throw new Error(`Cannot resume changed task: ${k}`);
   await fs.copyFile(path.join(runDir,'agent_trace.json'),path.join(runDir,`interrupted-trace-${stamp}.json`));
   await fs.copyFile(path.join(runDir,'evaluation.json'),path.join(runDir,`interrupted-evaluation-${stamp}.json`));
   trace.infrastructure_events=[...(trace.infrastructure_events||[]),{error:trace.error,at:trace.finished_at,completed_turns:trace.turns.length,resumed_at:new Date().toISOString(),resume_harness_sha256:frozen.harness_sha256,resume_provider_sha256:frozen.provider_adapter_sha256,transport:frozen.transport}];
   if(JSON.stringify(saved.initial_frame_hashes)!==JSON.stringify(frozen.initial_frame_hashes))throw new Error('Cannot resume changed initial frames');
   if(JSON.stringify(saved.source_hashes)!==JSON.stringify(frozen.source_hashes))throw new Error('Cannot resume changed source media');
   trace.status='running';delete trace.error;delete trace.finished_at;
   for(const turn of trace.turns){
     history.push(...turn.output);const images=[];
     for(let i=0;i<turn.calls.length;i++){
       const c=turn.calls[i],call=turn.output.filter(x=>x.type==='function_call')[i],r=c.result;
       const paths=r._images||(r._image?[r._image]:[]);
       const safe=paths.length?{seconds:r.seconds,times:r.times,image_pages:paths.length,pagination:r.pagination}:r;
       history.push({type:'function_call_output',call_id:call.call_id,output:JSON.stringify(safe)});
       for(let page=0;page<paths.length;page++)images.push({role:'user',content:[{type:'input_text',text:`Requested media inspection: ${JSON.stringify(c.args)}, page ${page+1}/${paths.length}`},{type:'input_image',image_url:`data:image/jpeg;base64,${(await fs.readFile(paths[page])).toString('base64')}`,detail:'high'}]});
     }
     history.push(...images);
   }
 }
 console.log(`Run directory: ${runDir}`);
 async function executeRaw(name,args){
  if(name==='get_state')return await readState(stateFile);
  if(name==='read_file'){
   if(!allowedReadPath(args.path))throw new Error('Only task.md, conform.json and app/engine.mjs are readable with this tool.');
   return {path:args.path,content:await fs.readFile(path.join(workspace,args.path),'utf8')};
  }
  if(name==='apply_changes')return await applyTransaction(stateFile,args);
  if(name==='update_releases')return await applyReleaseTransaction(stateFile,args);
  if(name==='transcribe_review'){
   if(!audioEnabled)throw new Error('Audio unavailable in this ablation.');
   if(!Number.isFinite(args.start_seconds)||!Number.isFinite(args.end_seconds)||args.start_seconds<0||args.end_seconds>transcript.duration_seconds||args.end_seconds<=args.start_seconds||args.end_seconds-args.start_seconds>30)throw new Error('Use a valid meeting interval up to 30 seconds.');
   if(!['mix','left','right'].includes(args.channel||'mix'))throw new Error('Invalid channel');
   return JSON.parse(await child(PYTHON,[path.join(ROOT,'pipeline/media.py'),'review_asr',path.join(workspace,'inputs/review.mp4'),String(args.start_seconds),String(args.end_seconds),args.channel||'mix']));
  }
  if(name==='get_transcript'){
   if(!audioEnabled)throw new Error('Audio unavailable in this ablation.');
   if(!Number.isFinite(args.start_seconds)||!Number.isFinite(args.end_seconds)||args.start_seconds<0||args.end_seconds>transcript.duration_seconds||args.end_seconds<=args.start_seconds)throw new Error('Invalid time window');
   return {segments:transcript.segments.filter(s=>s.end>=args.start_seconds&&s.start<=args.end_seconds)};
  }
  if(name==='get_frame'){
   if(!videoEnabled)throw new Error('Video unavailable in this ablation.');
   const t=args.seconds;if(!Number.isFinite(t)||t<0||t>=transcript.duration_seconds)throw new Error('Invalid recording time');
   const frame=path.join(runDir,`requested-frame-${String(t).replaceAll('.','_')}.jpg`);
   await child(FFMPEG,['-v','error','-y','-ss',String(t),'-i',path.join(workspace,'inputs/review.mp4'),'-frames:v','1','-q:v','3',frame]);
   await fs.access(frame);
   return {seconds:t,_image:frame};
  }
  if(name==='contact_sheet'||name==='transcribe_source'){
   const review=name==='contact_sheet'&&args.media==='review';
   if(name==='contact_sheet'&&!videoEnabled)throw new Error('Video unavailable in this ablation');
   if(name==='transcribe_source'&&!audioEnabled)throw new Error('Audio unavailable in this ablation');
   let mediaDuration=transcript.duration_seconds;
   if(!review){
     const s=await readState(stateFile);
     if(!s.assets.some(a=>a.id===args.asset_id&&a.versions.includes(args.version)))throw new Error('Unknown source');
     mediaDuration=durationOf(s.assets.find(a=>a.id===args.asset_id),args.version);
   }
   const file=review?path.join(workspace,'inputs/review.mp4'):path.join(workspace,'sources',`${args.asset_id}_${args.version}.${name==='transcribe_source'?'wav':'mp4'}`);
   if(!Number.isFinite(args.start_seconds)||!Number.isFinite(args.end_seconds)||
       args.start_seconds<0||args.start_seconds>=mediaDuration||
       args.end_seconds>mediaDuration||args.end_seconds<args.start_seconds)
       throw new Error('Use 0 <= start < duration and start <= end <= duration; end is exclusive for frame sampling.');
   const params=[path.join(ROOT,'pipeline/media.py'),name==='transcribe_source'?'source_asr':'sheet',file,String(args.start_seconds),String(args.end_seconds)];
   if(name==='contact_sheet'){
     if(!Number.isFinite(args.step_seconds))throw new Error('Invalid sampling step');
     params.push(String(args.step_seconds),path.join(runDir,`sheet-${crypto.randomUUID()}.jpg`));
   }
   return JSON.parse(await child(PYTHON,params));
  }
  if(name==='measure_audio'){
   if(!audioEnabled)throw new Error('Audio unavailable in this ablation.');
   const s=await readState(stateFile);
   if(!s.assets.some(a=>a.id===args.asset_id&&a.versions.includes(args.version)))throw new Error('Unknown source');
   if(!Number.isFinite(args.start_seconds)||!Number.isFinite(args.end_seconds))throw new Error('Invalid times');
   return JSON.parse(await child(PYTHON,[path.join(ROOT,'pipeline/media.py'),'analyze',
     path.join(workspace,'sources',`${args.asset_id}_${args.version}.wav`),String(args.start_seconds),String(args.end_seconds)]));
  }
  if(name==='public_check'){
   const state=await readState(stateFile);validateGraph(state);
   const signatures=state.tickets.map(t=>[t.asset_id,t.version,t.issue_type,t.in_seconds,t.out_seconds].join('|'));
   return {schema_valid:true,revision:state.revision,releases:state.releases.map(r=>{const gate=releaseGate(state,r.required_ticket_ids);return {id:r.id,...gate,consistent:r.status===gate.status&&JSON.stringify([...r.blocker_ticket_ids].sort())===JSON.stringify(gate.blocker_ticket_ids)};}),duplicate_intervals:signatures.length-new Set(signatures).size,record_count:state.tickets.length,
     message:'This checks integrity only, not whether review decisions were understood.'};
  }
  if(name==='finish')return {finished:true,summary:String(args.summary||'')};
  throw new Error('Unknown tool');
 }
 async function execute(name,args){
   if(!shared)return executeRaw(name,args);
   budget.charge({tool_calls:1});
   if(['get_frame','contact_sheet'].includes(name)){
     budget.charge({visual_frames:visualFrameCount(args)});
     const result=await executeRaw(name,args);
     const images=result._images||(result._image?[result._image]:[]),evidence=[];
     const times=result.times||[result.seconds];
     for(let i=0;i<images.length;i++)evidence.push(await perception.observe([images[i]],{
       media:name==='get_frame'?'review':args.media,
       ...(args.media==='source'?{asset_id:args.asset_id,version:args.version}:{}),
       times:times.slice(i*16,(i+1)*16),layout:name==='get_frame'?'single frame':'contact sheet; time labels are source-relative',
     }));
     return {seconds:result.seconds,times,evidence};
   }
   if(['transcribe_review','transcribe_source','measure_audio'].includes(name)){
     const duration=args.end_seconds-args.start_seconds;
     const catalog=await readState(stateFile),asset=catalog.assets.find(a=>a.id===args.asset_id&&a.versions.includes(args.version));
     const mediaDuration=name==='transcribe_review'?transcript.duration_seconds:asset?durationOf(asset,args.version):0;
     if(![args.start_seconds,args.end_seconds].every(Number.isFinite)||args.start_seconds<0||duration<=0||duration>(name==='measure_audio'?60:30)||args.end_seconds>mediaDuration)throw new Error('Invalid audio interval');
     if(name==='transcribe_review'){
       args={...args,channel:args.channel||'mix'};
       if(!['mix','left','right'].includes(args.channel))throw new Error('Invalid channel');
     }
     budget.charge({[name==='measure_audio'?'measurement_seconds':'asr_seconds']:duration});
     // Validate identities before constructing or reading source paths.
     if(name!=='transcribe_review'){
       const s=await readState(stateFile);
       if(!s.assets.some(a=>a.id===args.asset_id&&a.versions.includes(args.version)))throw new Error('Unknown source');
     }
     const file=name==='transcribe_review'?path.join(workspace,'inputs/review.mp4'):path.join(workspace,'sources',`${args.asset_id}_${args.version}.wav`);
     return perception.audio(name,args,await mediaHash(file),()=>executeRaw(name,args));
   }
   if(name==='get_transcript'){
     // Initial full ASR has already been charged; rereading a slice consumes only a tool call.
     return executeRaw(name,args);
   }
   return executeRaw(name,args);
 }
 async function bootstrapShared(){
   budget.charge({visual_frames:frames.length,asr_seconds:transcript.duration_seconds});
   const evidence=[];
   for(let i=0;i<frames.length;i+=SHARED.vision.batch_size){
     const batch=frames.slice(i,i+SHARED.vision.batch_size);
     const observation=await perception.observe(batch.map(f=>path.join(prepared,f.file)),{media:'review',timestamps:batch.map(f=>f.time),layout:'one decoded frame per image'});
     evidence.push(observation);
     content.push({type:'input_text',text:JSON.stringify(observation)});
     console.log(`Shared visual bootstrap: ${Math.min(i+batch.length,frames.length)}/${frames.length} frames`);
   }
   trace.initial_evidence=evidence.map(x=>({evidence_id:x.evidence_id,returned_model:x.returned_model}));
   trace.initial_input_sha256=digest(content);
   await fs.writeFile(path.join(runDir,'model_input_audit.json'),JSON.stringify({text_blocks:content,tools,
     perception_route:perceptionRoute,candidate_raw_image_count:0,initial_evidence:trace.initial_evidence,
     public_workspace_files:audit.public_files},null,2));
   await fs.writeFile(path.join(runDir,'manifest.json'),JSON.stringify({...frozen,initial_input_sha256:trace.initial_input_sha256,initial_evidence:trace.initial_evidence},null,2));
 }
 try{
  if(shared)await bootstrapShared();
  for(let turn=trace.turns.length+1;turn<=maxTurns;turn++){
   if(shared){assertTextOnly(history);budget.charge({model_turns:1});if(!budget.remaining('output_tokens'))throw new BudgetExceeded('output_tokens');}
   const payload=await requestModel({provider,base,key,model,history,tools,
     reasoningEffort:shared?SHARED.agent.reasoning_effort:'medium',
     maxOutput:shared?Math.min(SHARED.agent.max_output_tokens,budget.remaining('output_tokens')):9000});
   if(shared){
     if(!Number.isInteger(payload.usage?.output_tokens)||payload.usage.output_tokens<0)throw new Error('Missing output-token accounting in shared protocol');
     budget.charge({output_tokens:payload.usage.output_tokens});
   }
   const log={turn,response_id:payload.id,returned_model:payload.model,usage:payload.usage,output:payload.output,
     stop_reason:payload.stop_reason||payload.status,latency_ms:payload.latency_ms,request_image_count:payload.request_image_count,transport_retry_count:payload.transport_retry_count||0,calls:[]};
   trace.turns.push(log);history.push(...payload.output);
   const calls=payload.output.filter(item=>item.type==='function_call');
   console.log(`Turn ${turn}: ${calls.map(c=>c.name).join(', ')||'text only'}`);
   const requestedImages=[];
   for(const call of calls){
    let args,result;
    try{args=JSON.parse(call.arguments||'{}');result=await execute(call.name,args);}
    catch(e){
      if(shared&&(e instanceof PerceptionInfrastructureError||e instanceof BudgetExceeded)){
        log.calls.push({name:call.name,args,result:{error:e.message,error_class:e.name}});throw e;
      }
      result={error:e.message};
    }
    log.calls.push({name:call.name,args,result});
    const images=result._images||(result._image?[result._image]:[]);
    const safe=images.length?{seconds:result.seconds,times:result.times,image_pages:images.length,pagination:result.pagination}:result;
    history.push({type:'function_call_output',call_id:call.call_id,output:JSON.stringify(safe)});
    for(let page=0;page<images.length;page++)requestedImages.push({role:'user',content:[
      {type:'input_text',text:`Requested media inspection: ${JSON.stringify(args)}, page ${page+1}/${images.length}`},
      {type:'input_image',image_url:`data:image/jpeg;base64,${(await fs.readFile(images[page])).toString('base64')}`,detail:'high'}]});
    if(call.name==='finish'&&!result.error)trace.status='finished';
   }
   history.push(...requestedImages);
   if(shared){trace.budget=budget.snapshot();trace.perception_events=perception.events;}
   await fs.writeFile(path.join(runDir,'agent_trace.json'),JSON.stringify(trace,null,2));
   if(trace.status==='finished')break;
   if(!calls.length){trace.status='model_stopped';break;}
  }
  if(trace.status==='running')trace.status='turn_limit';
 }catch(e){
   trace.status=e instanceof BudgetExceeded?'budget_exhausted':'infrastructure_error';
   trace.error=e.message.replaceAll(key,'[REDACTED]').replaceAll(process.env.OMNIALE_VISION_KEY||'__no_key__','[REDACTED]');
   console.error(trace.error);if(trace.status==='infrastructure_error')process.exitCode=2;
 }
 finally{
   if(shared){trace.budget=budget.snapshot();trace.perception_events=perception.events;}
   trace.finished_at=new Date().toISOString();
   await fs.writeFile(path.join(runDir,'agent_trace.json'),JSON.stringify(trace,null,2));
   const state=await readState(stateFile),result=await evaluate(state);
   result.run_status=trace.status;result.valid_model_trial=trace.status!=='infrastructure_error';
   if(!result.valid_model_trial){result.diagnostic_partial_state_score=result.score;result.score=null;result.success=false;}
   result.perception_route=perceptionRoute;result.shared_protocol=shared?SHARED.protocol:null;
   await fs.writeFile(path.join(runDir,'evaluation.json'),JSON.stringify(result,null,2));
   const initial=JSON.parse(await fs.readFile(path.join(ROOT,'private/initial.json'),'utf8'));
   const changes=state.tickets.filter(t=>JSON.stringify(t)!==JSON.stringify(initial.tickets.find(x=>x.id===t.id)));
   await fs.writeFile(path.join(runDir,'state_diff.json'),JSON.stringify({tickets:changes,releases:state.releases.filter(r=>JSON.stringify(r)!==JSON.stringify(initial.releases.find(x=>x.id===r.id)))},null,2));
   console.log(JSON.stringify({runDir,status:trace.status,score:result.score,valid_model_trial:result.valid_model_trial,changed_records:changes.length},null,2));
   try{console.log(await child(process.execPath,[path.join(ROOT,'pipeline/report.mjs'),runDir]));}
   catch(e){console.error(`Evaluation saved; optional report generation failed: ${e.message}`);}
 }
}
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url))
 main().catch(e=>{let message=e.stack||e.message;for(const secret of [key,process.env.OMNIALE_VISION_KEY].filter(Boolean))message=message.replaceAll(secret,'[REDACTED]');console.error(message);process.exitCode=2});
