"""Author-only QA of actual v5 media, EDL mapping and preserved original source evidence."""
from pathlib import Path
import json,subprocess,sys,hashlib,wave,io
import numpy as np
from PIL import Image
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'authoring'))
import build as b
read=lambda p:json.loads(p.read_text(encoding='utf-8'))
truth=read(ROOT/'private/truth.json');edl=read(ROOT/'public/conform.json')['deliveries'];frames=read(ROOT/'prepared/frames.json')
for scene in truth['scene_index']:assert any(scene['start']<=f['time']<scene['end'] for f in frames),scene
expected_hashes=read(ROOT/'private/original-source-hashes.json')
originals=[]
for p in (ROOT/'public/sources').iterdir():
 if '_v5.' not in p.name:
  assert hashlib.sha256(p.read_bytes()).hexdigest()==expected_hashes[p.name]
  originals.append(p.name)
checks=[]
for a,e in edl.items():
 with wave.open(str(ROOT/'public/sources'/f'{a}_v5.wav'),'rb') as w:assert abs(w.getnframes()/w.getframerate()-e['duration'])<.001
 cursor=0
 for seg in e['segments']:
  assert abs(cursor-seg['delivery_in'])<.0001
  assert abs((seg['source_out']-seg['source_in'])/(seg['delivery_out']-seg['delivery_in'])-seg['speed'])<.00001
  cursor=seg['delivery_out']
  # Compare a real decoded midpoint frame to independently re-rendered old source artwork.
  t=(seg['delivery_in']+seg['delivery_out'])/2
  old=(seg['source_in']+seg['source_out'])/2
  raw=subprocess.run([b.FF,'-v','error','-ss',str(t),'-i',str(ROOT/'public/sources'/f'{a}_v5.mp4'),'-frames:v','1','-f','image2pipe','-vcodec','png','pipe:1'],capture_output=True,check=True).stdout
  actual=np.asarray(Image.open(io.BytesIO(raw)).convert('RGB'))[:640].astype(float)
  expected=np.asarray(b.frame(a,e['source_version'],old).resize((b.W,b.H)).convert('RGB'))[:640].astype(float)
  mae=float(np.mean(abs(actual-expected)));assert mae<5,(a,seg['event_id'],mae)
  checks.append({'asset':a,'event':seg['event_id'],'pixel_mae':round(mae,3)})
 assert abs(cursor-e['duration'])<.0001
assert len(truth['targets'])==39 and len(truth['releases'])==8
assert len({t['_key'] for t in truth['targets']})==39
assert all(t.get('id') not in truth['protected'] for t in truth['targets'])
assert all('_key' not in t for t in read(ROOT/'public/state.json')['tickets'])
report={'pass':True,'duration_seconds':truth['scene_index'][-1]['end'],'scene_count':len(truth['scene_index']),'initial_frames':len(frames),'v5_event_frame_checks':checks,'unchanged_original_source_files':len(originals),'target_count':39,'release_count':8,'limits':['Automated media/EDL consistency QA does not establish human inter-annotator agreement.','Synthetic source graphics and TTS; shared-tool evaluation, not native Omni.']}
(ROOT/'private/media_qa_v4.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in report.items() if k!='v5_event_frame_checks'}))
