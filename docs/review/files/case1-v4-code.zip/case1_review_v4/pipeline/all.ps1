param([switch]$Rebuild, [switch]$SkipModel)
$ErrorActionPreference = 'Stop'
$taskCaseRoot = Split-Path -Parent $PSScriptRoot
$taskPython = if ($env:CASE1_PYTHON) {$env:CASE1_PYTHON} else {'F:\annconda\python.exe'}
if ($Rebuild) {
  & $taskPython "$taskCaseRoot/authoring/build.py"
  if ($LASTEXITCODE -ne 0) {throw 'Base build failed'}
  Copy-Item -LiteralPath "$taskCaseRoot/private/truth.json" -Destination "$taskCaseRoot/private/v3-truth.json"
  Copy-Item -LiteralPath "$taskCaseRoot/private/initial.json" -Destination "$taskCaseRoot/private/v3-initial.json"
  Copy-Item -LiteralPath "$taskCaseRoot/private/build/meeting-pcm.wav" -Destination "$taskCaseRoot/private/build/v3-meeting-pcm.wav"
  Copy-Item -LiteralPath "$taskCaseRoot/public/inputs/review.mp4" -Destination "$taskCaseRoot/private/build/v3-review.mp4"
  & $taskPython "$taskCaseRoot/authoring/upgrade_v4.py"
  if ($LASTEXITCODE -ne 0) {throw 'V4 build failed'}
  & $taskPython "$taskCaseRoot/pipeline/media.py" prepare
  if ($LASTEXITCODE -ne 0) {throw 'ASR failed'}
}
foreach ($taskCheck in @('test_v4','test_providers','test_shared','audit','test_shared_integration','smoke')) {
  & node "$taskCaseRoot/pipeline/$taskCheck.mjs"
  if ($LASTEXITCODE -ne 0) {throw "$taskCheck failed"}
}
foreach ($taskCheck in @('check_v3_media','check_v4_media','test_sampling')) {
  & $taskPython "$taskCaseRoot/pipeline/$taskCheck.py"
  if ($LASTEXITCODE -ne 0) {throw "$taskCheck failed"}
}
if (-not $SkipModel) { & node "$taskCaseRoot/pipeline/run_suite.mjs" }
