"""Author-only validation of actual PCM, rendered coverage and scoped scenario invariants."""
import sys,json,wave,hashlib
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'authoring'))
from spec import ASSETS,SCENES,FAULTS,TARGETS,PROTECTED,INITIAL,bounds,RELEASE
def pcm(a,v):
 with wave.open(str(ROOT/'public/sources'/f'{a}_{v}.wav'),'rb') as w:
  return w.getframerate(),np.frombuffer(w.readframes(w.getnframes()),dtype='<i2').reshape(-1,2).astype(float)/32768
checks=[]
for a in ASSETS:
 for v in a['versions']:
  sr,x=pcm(a['id'],v);assert len(x)/sr==60
  for motif in [0,9]:
   st,en=bounds(a['id'],v,motif);kinds=FAULTS.get((a['id'],v),[]) if motif==0 else []
   for local,ear in [(1,0),(3,1)]:
    at=st+local+(.5 if 'av_sync' in kinds else 0)
    z=x[round((at+.05)*sr):round((at+.25)*sr)];t=np.arange(len(z))/sr
    energy=np.abs(np.mean(z*np.exp(-2j*np.pi*1600*t)[:,None],axis=0))
    expected=ear^('channel_swap' in kinds);assert energy[expected]>.1 and np.argmax(energy)==expected
    if 'av_sync' in kinds:
     z0=x[round((st+local+.05)*sr):round((st+local+.25)*sr)]
     early=np.abs(np.mean(z0*np.exp(-2j*np.pi*1600*t)[:,None],axis=0));assert max(early)<.025
   if 'audio_gap' in kinds:
    z=x[round((st+2.1)*sr):round((st+2.7)*sr)];f=np.fft.rfftfreq(len(z),1/sr);sp=np.abs(np.fft.rfft(z[:,0]))/len(z)
    assert np.sqrt(np.mean(z*z))>.05 and np.sqrt(np.sum(sp[f>600]**2))<.01
    cs,ce=bounds(a['id'],v,9);ctrl=x[round((cs+2.1)*sr):round((cs+2.7)*sr)]
    spc=np.abs(np.fft.rfft(ctrl[:,0]))/len(ctrl);assert np.sqrt(np.sum(spc[f>600]**2))>.01
   checks.append({'asset':a['id'],'version':v,'slate':motif,'faults':kinds,'signal_pass':True})
truth=json.loads((ROOT/'private/truth.json').read_text());frames=json.loads((ROOT/'prepared/frames.json').read_text())
for scene in truth['scene_index']:assert any(scene['start']<=f['time']<scene['end'] for f in frames)
signatures=[(t['id'],t['asset_id'],t['version'],t['issue_type'],t['in_seconds'],t['out_seconds']) for t in TARGETS]
assert len(set(signatures))==len(TARGETS)==32
assert all(t['id'] not in PROTECTED for t in TARGETS)
for a in ['H17','C63']:
 red=[t for t in TARGETS if t['asset_id']==a and t['issue_type']=='subtitle']
 assert len(red)==2 and max(t['in_seconds'] for t in red)>min(t['out_seconds'] for t in red)
for a in ['M42','G28']:assert len([t for t in TARGETS if t['asset_id']==a and t['issue_type']=='crop'])==2
assert len([t for t in TARGETS if t['asset_id']=='G28' and t['version']=='v2'])==2
assert not any(t['asset_id']=='G28' and t['version']=='v4' and t['owner']=='audio' for t in TARGETS)
for s in SCENES:
 if s.get('degrade'):assert s.get('card'),'Degraded critical speech requires a persistent corroborating visual receipt'
report={'pass':True,'source_count':17,'slate_signal_checks':checks,'scene_count':len(SCENES),'target_count':32,'protected_count':8,'degraded_scenes':sum(bool(s.get('degrade')) for s in SCENES),'meeting_seconds':truth['scene_index'][-1]['end'],
 'limits':['Signal and scenario consistency QA does not establish human intelligibility. Independent human annotation remains required before benchmark release.','Synthetic graphics and desktop TTS; tool-assisted perception, not native Omni.']}
(ROOT/'private/media_qa.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in report.items() if k!='slate_signal_checks'}))
