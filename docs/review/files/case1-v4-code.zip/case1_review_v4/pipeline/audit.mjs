import fs from 'node:fs/promises';
import path from 'node:path';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import {fileURLToPath} from 'node:url';
import {tools,allowedReadPath} from './run.mjs';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
async function walk(dir,prefix=''){const out=[];for(const d of await fs.readdir(dir,{withFileTypes:true})){const rel=path.join(prefix,d.name);if(d.isSymbolicLink())throw new Error('Symlink in public input');if(d.isDirectory())out.push(...await walk(path.join(dir,d.name),rel));else out.push(rel);}return out;}
const publicFiles=await walk(path.join(root,'public'));
assert(publicFiles.every(f=>/^(inputs[\\/]|sources[\\/]|task\.md$|conform\.json$|state\.json$)/.test(f)));
const negatives=['../private/truth.json','private/truth.json','D:/omniale/case1_review_v4/private/truth.json','../authoring/spec.py','app/../private/truth.json','app\\engine.mjs','state.json',null,{}];
for(const p of negatives)assert.equal(allowedReadPath(p),false);
assert(allowedReadPath('conform.json'));assert(allowedReadPath('task.md'));assert(allowedReadPath('app/engine.mjs'));
const canary=`PRIVATE_AUDIT_${crypto.randomUUID()}`;
await fs.writeFile(path.join(root,'private/audit_canary.txt'),canary);
const exposedText=[
 await fs.readFile(path.join(root,'public/task.md'),'utf8'),
 await fs.readFile(path.join(root,'app/engine.mjs'),'utf8'),
 await fs.readFile(path.join(root,'public/state.json'),'utf8'),
 await fs.readFile(path.join(root,'public/conform.json'),'utf8'),
 await fs.readFile(path.join(root,'prepared/transcript.json'),'utf8'),
 JSON.stringify(tools)
].join('\n');
const forbidden=['range_tolerance_seconds','scoring_version','preserve_unrequested_records','no_extra_or_deleted_records',canary,'PRIVATE v3 scenario','PRIVATE v4 authoring','"_key"','required_keys','blocked_keys'];
for(const word of forbidden)assert(!exposedText.includes(word),`Private grading marker exposed: ${word}`);
const runner=await fs.readFile(path.join(root,'pipeline/run.mjs'),'utf8');
assert(!tools.some(t=>/shell|exec|evaluate|score/.test(t.name)));
assert(runner.includes("if(!allowedReadPath(args.path))"));
assert(runner.includes("if(!s.assets.some"));
const engine=await fs.readFile(path.join(root,'app/engine.mjs'),'utf8');
assert(!/TARGETS|FAULTS|PROTECTED|truth\.json|NORA|JAY/.test(engine));
const report={pass:true,public_files:publicFiles,read_path_negative_tests:negatives.length,
  forbidden_grading_markers_tested:forbidden.length,tool_names:tools.map(t=>t.name),public_text_sha256:crypto.createHash('sha256').update(exposedText).digest('hex'),
  findings:[
   'No private answer/weights/target counts in initial text, tool schemas, public app or ASR.',
   'Read-file allowlist rejects traversal/absolute/private paths; no shell or arbitrary network tool.',
   'Source paths require IDs in immutable catalog; public_check returns integrity, not correctness.',
   'Business SOP and allowed field names are legitimate task requirements, not answer leakage.'
  ],
  limits:['Interface-level audit, not OS sandbox or formal information-flow proof.',
   'Media inspected through generated provenance and separate visual/audio QA; no claim of exhaustive semantic leakage proof.']};
await fs.writeFile(path.join(root,'private/leakage_audit.json'),JSON.stringify(report,null,2));
console.log(JSON.stringify({pass:report.pass,files:publicFiles.length,negative_path_tests:negatives.length},null,2));
