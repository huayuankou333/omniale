import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import {SHARED,SharedBudget,BudgetExceeded,visualFrameCount,assertTextOnly} from './shared_config.mjs';
import {SharedPerception,PerceptionInfrastructureError,VISION_PROMPT} from './shared_perception.mjs';
import {requestSpec} from './providers.mjs';

const testsRoot=process.env.CASE1_TEST_ROOT||path.join(process.cwd(),'work');
await fs.mkdir(testsRoot,{recursive:true});
const dir=await fs.mkdtemp(path.join(testsRoot,'omniale-shared-tests-'));
const image=path.join(dir,'sample.jpg');await fs.writeFile(image,'fixture image bytes');
let requests=[];
const transport=async(url,options)=>{
  const body=JSON.parse(options.body);requests.push(body);
  return {ok:true,json:async()=>({status:'completed',model:SHARED.vision.model,
    output:[{type:'message',content:[{type:'output_text',text:'[10s] A red sail. Visible text: H17 v3.'}]}],usage:{output_tokens:50}})};
};
const create=()=>new SharedPerception({cacheDir:path.join(dir,'cache'),base:'https://example.invalid/v1',
  key:'test-secret',asrFingerprint:'test-hash',transport});
const a=create(),b=create();
const context={media:'review',timestamps:[10]};
const one=await a.observe([image],context),two=await b.observe([image],context);
assert.deepEqual(one,two);assert.equal(requests.length,1);assert.equal(b.events[0].cache_hit,true);
assert.equal(requests[0].instructions,VISION_PROMPT);
assert.equal(requests[0].input[0].content.filter(x=>x.type==='input_image').length,1);
assert(!JSON.stringify(requests).includes('private/truth'));assert(!JSON.stringify(requests).includes('task.md'));
await b.observe([image],{...context,timestamps:[11]});assert.equal(requests.length,2);
await fs.writeFile(image,'changed pixels');await b.observe([image],context);assert.equal(requests.length,3);
let asrCalls=0;
const audio=()=>{asrCalls++;return {segments:[{start:1,end:2,text:'No change.'}]};};
const args={start_seconds:1,end_seconds:2,channel:'left'};
assert.deepEqual(await a.audio('transcribe_review',args,'media-A',audio),await b.audio('transcribe_review',args,'media-A',audio));
assert.equal(asrCalls,1);
await b.audio('transcribe_review',{channel:'left',end_seconds:2,start_seconds:1},'media-A',audio);assert.equal(asrCalls,1);
await b.audio('transcribe_review',{...args,channel:'right'},'media-A',audio);assert.equal(asrCalls,2);
await b.audio('transcribe_review',args,'media-B',audio);assert.equal(asrCalls,3);
const file=path.join(dir,'cache',`${one.evidence_id}.json`);
const corrupt=JSON.parse(await fs.readFile(file,'utf8'));corrupt.payload.observations='tampered';await fs.writeFile(file,JSON.stringify(corrupt));
await fs.writeFile(image,'fixture image bytes');
await assert.rejects(()=>b.observe([image],context),PerceptionInfrastructureError);
const fail=new SharedPerception({cacheDir:path.join(dir,'bad'),base:'https://example.invalid/v1',key:'test-secret',
 transport:async()=>({ok:false,status:400,json:async()=>({error:'test-secret'})})});
await assert.rejects(()=>fail.observe([image],context),e=>e instanceof PerceptionInfrastructureError&&!e.message.includes('test-secret'));
const incomplete=new SharedPerception({cacheDir:path.join(dir,'incomplete'),base:'https://example.invalid/v1',key:'x',
 transport:async()=>({ok:true,json:async()=>({status:'incomplete',output:[]})})});
await assert.rejects(()=>incomplete.observe([image],context),PerceptionInfrastructureError);
const meter=new SharedBudget();meter.charge({tool_calls:120});assert.throws(()=>meter.charge({tool_calls:1}),BudgetExceeded);
assert.equal(meter.used.tool_calls,120);
const atomic=new SharedBudget({tool_calls:2,visual_frames:1});
assert.throws(()=>atomic.charge({tool_calls:1,visual_frames:2}),BudgetExceeded);assert.equal(atomic.used.tool_calls,0);
for(const value of [NaN,-1,Infinity])assert.throws(()=>atomic.charge({tool_calls:value}));
assert.equal(visualFrameCount({start_seconds:0,end_seconds:1,step_seconds:.1}),10);
assert.equal(visualFrameCount({start_seconds:5,end_seconds:5,step_seconds:1}),1);
assert.throws(()=>visualFrameCount({start_seconds:0,end_seconds:60,step_seconds:.1}));
const history=[{role:'user',content:[{type:'input_text',text:JSON.stringify(two)}]}];
assertTextOnly(history);
assert.throws(()=>assertTextOnly([{role:'user',content:[{type:'input_image',image_url:'data:image/jpeg;base64,AAAA'}]}]));
for(const model of SHARED.models){
  const spec=requestSpec({provider:'openai',base:'https://example.invalid/v1',key:'x',model,history,tools:[],
    reasoningEffort:SHARED.agent.reasoning_effort,maxOutput:SHARED.agent.max_output_tokens});
  assert.equal(spec.body.reasoning.effort,'high');assert.equal(spec.body.max_output_tokens,9000);assertTextOnly(spec.body.input);
}
console.log('Shared-perception tests passed: evidence reuse/invalidation, cache integrity, ASR channel/media isolation, service failure classification, budgets, zero raw media, identical four-model settings.');
