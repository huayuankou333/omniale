import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import http from 'node:http';
import {spawn} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import {SHARED,assertTextOnly} from './shared_config.mjs';
import {VISION_PROMPT} from './shared_perception.mjs';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const testsRoot=process.env.CASE1_TEST_ROOT||path.join(process.cwd(),'work');await fs.mkdir(testsRoot,{recursive:true});
const dir=await fs.mkdtemp(path.join(testsRoot,'shared-integration-'));
const initial=JSON.parse(await fs.readFile(path.join(root,'public/state.json'),'utf8'));
const stateBefore=await fs.readFile(path.join(root,'public/state.json'),'utf8');
let visionCalls=0,agentCalls=0,failVision=false,forceBudget=false,forceTurns=false;
const frameCount=JSON.parse(await fs.readFile(path.join(root,"prepared/frames.json"),"utf8")).length;
const counts=new Map(),inputs=[];
const server=http.createServer(async(req,res)=>{
 try{
  let raw='';for await(const b of req)raw+=b;const body=JSON.parse(raw);
  let output;
  if(body.instructions===VISION_PROMPT){
    visionCalls++;
    if(failVision){res.writeHead(503,{'Content-Type':'application/json'});res.end(JSON.stringify({error:'synthetic perception outage'}));return;}
    output=[{type:'message',role:'assistant',content:[{type:'output_text',text:'Mock observation for integration testing only.'}]}];
  }else{
    agentCalls++;assertTextOnly(body.input);assert.equal(body.reasoning.effort,'high');assert.equal(body.max_output_tokens,9000);
    const n=(counts.get(body.model)||0)+1;counts.set(body.model,n);
    const call=(id,name,args)=>({type:'function_call',call_id:`${body.model}-${id}`,name,arguments:JSON.stringify(args)});
    if(forceTurns)output=[call(`loop-${n}`,'get_state',{})];
    else if(forceBudget)output=Array.from({length:121},(_,i)=>call(`budget-${i}`,'get_state',{}));
    else if(n===1){
      inputs.push(body.input);
      output=[call('state','get_state',{}),call('frame','get_frame',{seconds:0}),
       call('sheet','contact_sheet',{media:'source',asset_id:'H17',version:'v3',start_seconds:0,end_seconds:2,step_seconds:1}),
       call('audio','measure_audio',{asset_id:'H17',version:'v3',start_seconds:0,end_seconds:1}),
       call('bad','transcribe_review',{start_seconds:-1,end_seconds:1})];
    }else if(n===2){
      const results=body.input.filter(x=>x.type==='function_call_output').map(x=>JSON.parse(x.output));
      assert(results[1].evidence[0].observations);assert(results[2].evidence[0].observations);assert(results[3].windows.length);assert(results[4].error);
      output=[call('write','apply_changes',{request_id:'integration-check',operations:[{action:'update',id:initial.tickets[0].id,fields:{note:'integration fixture'}}]})];
    }else output=[call('check','public_check',{}),call('done','finish',{summary:'Mock integration complete'})];
  }
  res.writeHead(200,{'Content-Type':'application/json'});res.end(JSON.stringify({id:'mock-response',model:body.model,status:'completed',output,usage:{input_tokens:100,output_tokens:100}}));
 }catch(e){res.writeHead(500,{'Content-Type':'application/json'});res.end(JSON.stringify({error:e.stack}));}
});
await new Promise(r=>server.listen(0,'127.0.0.1',r));
const base=`http://127.0.0.1:${server.address().port}/v1`;
const run=async(model,cache)=>{
 let out='',err='';
 const env={...process.env,CASE1_MODEL:model,CASE1_PERCEPTION_ROUTE:'shared_tools',CASE1_MODE:'full',CASE1_PROVIDER:'openai',
  CASE1_STREAM:'0',CASE1_MAX_TURNS:String(SHARED.limits.model_turns),CASE1_RUNS_DIR:dir,CASE1_SHARED_CACHE:cache,
  OMNIALE_PROXY_BASE_URL:base,OMNIALE_VISION_BASE_URL:base,OMNIALE_PROXY_KEY:'fixture',OMNIALE_VISION_KEY:'fixture'};
 delete env.CASE1_RESUME_RUN;
 const code=await new Promise((resolve,reject)=>{
  const p=spawn(process.execPath,[path.join(root,'pipeline/run.mjs')],{env,windowsHide:true,stdio:['ignore','pipe','pipe']});
  p.stdout.on('data',d=>out+=d);p.stderr.on('data',d=>err+=d);p.on('error',reject);p.on('exit',resolve);
 });
 const runDir=/Run directory: ([^\r\n]+)/.exec(out)?.[1];assert(runDir,err);
 return {code,dir:runDir,trace:JSON.parse(await fs.readFile(path.join(runDir,'agent_trace.json'),'utf8')),
   evaluation:JSON.parse(await fs.readFile(path.join(runDir,'evaluation.json'),'utf8'))};
};
try{
 const results=[];
 for(const model of SHARED.models){
  const result=await run(model,path.join(dir,'cache'));
  assert.equal(result.code,0,result.trace.error);assert.equal(result.trace.status,'finished');
  assert.equal(result.trace.turns.length,3);assert(result.trace.turns.every(t=>t.request_image_count===0));
  assert.equal(result.trace.budget.used.tool_calls,8);assert.equal(result.trace.budget.used.visual_frames,frameCount+3);
  assert.equal(result.trace.budget.used.output_tokens,300);
  const state=JSON.parse(await fs.readFile(path.join(result.dir,'workspace/state.json'),'utf8'));
  assert.equal(state.tickets[0].note,'integration fixture');results.push(result);
 }
 for(const input of inputs)assert.deepEqual(input,inputs[0]);
 assert.equal(visionCalls,Math.ceil(frameCount/SHARED.vision.batch_size)+2);
 assert.equal(agentCalls,12);
 assert.equal(await fs.readFile(path.join(root,'public/state.json'),'utf8'),stateBefore);
 counts.clear();
 let suiteOutput='';
 const suiteCode=await new Promise((resolve,reject)=>{
   const env={...process.env,OMNIALE_GPT_KEY:'fixture',OMNIALE_GLM_KEY:'fixture',OMNIALE_KIMI_KEY:'fixture',
     OMNIALE_PROXY_BASE_URL:base,OMNIALE_VISION_BASE_URL:base,CASE1_STREAM:'0',CASE1_RUNS_DIR:dir,CASE1_SHARED_CACHE:path.join(dir,'cache')};
   const p=spawn(process.execPath,[path.join(root,'pipeline/run_suite.mjs')],{env,windowsHide:true,stdio:['ignore','pipe','pipe']});
   p.stdout.on('data',d=>suiteOutput+=d);p.stderr.on('data',d=>suiteOutput+=d);p.on('error',reject);p.on('exit',resolve);
 });
 assert.equal(suiteCode,0,suiteOutput);
 const suiteName=(await fs.readdir(dir)).find(n=>n.startsWith('shared-suite-'));
 const suite=JSON.parse(await fs.readFile(path.join(dir,suiteName,'suite.json'),'utf8'));
 assert.equal(suite.comparable,true);assert.equal(suite.results.length,4);
 assert(suite.results.every(r=>r.valid_model_trial&&r.raw_images_sent===0));
 forceBudget=true;
 const capped=await run('glm-5.3',path.join(dir,'cache'));
 assert.equal(capped.trace.status,'budget_exhausted');assert.equal(capped.trace.budget.used.tool_calls,120);
 assert.equal(capped.evaluation.valid_model_trial,true);forceBudget=false;
 forceTurns=true;
 const limited=await run('gpt-6-luna',path.join(dir,'cache'));
 assert.equal(limited.trace.status,'turn_limit');assert.equal(limited.trace.turns.length,15);assert.equal(limited.trace.budget.used.model_turns,15);forceTurns=false;
 failVision=true;
 const broken=await run('glm-5.3',path.join(dir,'failure-cache'));
 assert.equal(broken.code,2);assert.equal(broken.evaluation.valid_model_trial,false);assert.equal(broken.evaluation.score,null);
 assert.equal(broken.trace.turns.length,0);
 console.log(JSON.stringify({passed:true,kind:'mock integration; NOT model evaluation',models:SHARED.models,
   identical_initial_inputs:true,zero_candidate_images:true,workspace_isolation:true,cache_reuse:true,suite_comparator:true,budget_enforcement:true,
   tools:'real decoded frames/contact sheets/PCM and persistent transactions',infrastructure_failure_score:null,artifacts:dir},null,2));
}finally{await new Promise(r=>server.close(r));}
