import fs from 'node:fs/promises';
import path from 'node:path';
import {spawn} from 'node:child_process';
import assert from 'node:assert/strict';
import {fileURLToPath} from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const qa=path.join(root,'private/qa');await fs.mkdir(qa,{recursive:true});
const stateFile=path.join(qa,'smoke-state.json');await fs.copyFile(path.join(root,'public/state.json'),stateFile);
const server=spawn(process.execPath,[path.join(root,'app/server.mjs')],{env:{...process.env,CASE1_STATE:stateFile,PORT:'4189'},windowsHide:true,stdio:['ignore','pipe','pipe']});
try{
 await new Promise((resolve,reject)=>{server.stdout.once('data',resolve);server.once('error',reject);setTimeout(()=>reject(new Error('Startup timeout')),10000).unref();});
 const url='http://127.0.0.1:4189';assert.equal((await fetch(url+'/private/truth.json')).status,404);
 assert((await (await fetch(url)).text()).includes('Review Desk v4'));
 const before=await (await fetch(url+'/api/state')).json();assert.equal(before.tickets.length,15);
 const request={request_id:'http-smoke',operations:[{action:'update',id:'R201',fields:{status:'blocked'}}]};
 const post=()=>fetch(url+'/api/transaction',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(request)});
 const first=await (await post()).json(),again=await (await post()).json();assert.deepEqual(first,again);
 assert.equal(JSON.parse(await fs.readFile(stateFile)).tickets.find(t=>t.id==='R201').status,'blocked');
 const edl=await (await fetch(url+'/conform')).json();assert.equal(Object.keys(edl.deliveries).length,4);
 const release={request_id:'release-smoke',expected_revision:first.revision,operations:[{id:'P-HWEB',fields:{version:'v5',required_ticket_ids:['R201'],status:'hold',blocker_ticket_ids:['R201']}}]};
 const update=await fetch(url+'/api/releases',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(release)});assert.equal(update.status,200);const receipt=await update.json();assert.equal(receipt.kind,'releases');
 const saved=await(await fetch(url+'/api/state')).json();assert.equal(saved.releases.find(r=>r.id==='P-HWEB').status,'hold');
 const stale=await fetch(url+'/api/releases',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({...release,request_id:'stale-release'})});assert.equal(stale.status,400);
 const range=await fetch(url+'/recording',{headers:{Range:'bytes=0-1023'}});assert.equal(range.status,206);assert.equal((await range.arrayBuffer()).byteLength,1024);
 const report={http_private_path:404,persistent_edit:true,idempotent_retry:true,video_byte_range:true,release_transaction:true,revision_conflict:true,public_conform:true,initial_records:15,scope:'HTTP/service smoke; separate browser inspection recorded in visual QA'};
 await fs.writeFile(path.join(qa,'smoke_report.json'),JSON.stringify(report,null,2));console.log(report);
}finally{server.kill();}
