import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {requestModel} from './providers.mjs';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const provider=process.env.CASE1_PROVIDER||'openai';
const model=process.env.CASE1_MODEL;
const key=provider==='anthropic'?process.env.OMNIALE_ANTHROPIC_KEY:process.env.OMNIALE_PROXY_KEY;
const base=provider==='anthropic'?'https://routify-pub.alibaba-inc.com/protocol/anthropic':'https://api-temporary.nju-link.com/v1';
if(!key||!model)throw new Error('Set model and provider key');
const frames=JSON.parse(await fs.readFile(path.join(root,'prepared/frames.json'),'utf8'));
const jpeg=await fs.readFile(path.join(root,'prepared',frames[0].file));
const history=[{role:'user',content:[
 {type:'input_text',text:'Connectivity check only, not a benchmark attempt. Call ping with seen=true if you can see the image.'},
 {type:'input_image',image_url:'data:image/jpeg;base64,'+jpeg.toString('base64'),detail:'high'}]}];
const tools=[{type:'function',name:'ping',description:'Confirm image and function calling transport.',parameters:{type:'object',properties:{seen:{type:'boolean'}},required:['seen'],additionalProperties:false},strict:false}];
const p=await requestModel({provider,base,key,model,history,tools,maxOutput:1024});
const result={provider,requested_model:model,returned_model:p.model,stop_reason:p.stop_reason||p.status,
 calls:p.output.filter(x=>x.type==='function_call').map(x=>({name:x.name,arguments:x.arguments})),latency_ms:p.latency_ms};
await fs.writeFile(path.join(root,'private',`probe_${model}.json`),JSON.stringify(result,null,2));
console.log(JSON.stringify(result,null,2));
