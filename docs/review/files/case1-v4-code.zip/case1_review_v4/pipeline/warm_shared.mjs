import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {SharedPerception} from './shared_perception.mjs';
import {SHARED} from './shared_config.mjs';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const frames=JSON.parse(await fs.readFile(path.join(root,'prepared/frames.json'),'utf8'));
const p=new SharedPerception({cacheDir:path.join(root,'shared_cache',SHARED.protocol),base:process.env.OMNIALE_PROXY_BASE_URL||'https://api-temporary.nju-link.com/v1',key:process.env.OMNIALE_VISION_KEY});
for(let i=0;i<frames.length;i+=SHARED.vision.batch_size){const batch=frames.slice(i,i+SHARED.vision.batch_size);await p.observe(batch.map(f=>path.join(root,'prepared',f.file)),{media:'review',timestamps:batch.map(f=>f.time),layout:'one decoded frame per image'});console.log(`Common visual evidence ${Math.min(i+batch.length,frames.length)}/${frames.length}`);}
console.log(JSON.stringify({complete:true,events:p.events}));
