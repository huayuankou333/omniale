// Keep double-click text editing reliable while SVG selection overlays are redrawn.
let lastCanvasClick=null;
svg.addEventListener('pointerdown',e=>{if(modal||space||tool!=='select'||e.button!==0||e.target.dataset.handle)return;const p=point(e),o=hit(p);if(o&&o.type!=='arrow'&&lastCanvasClick&&lastCanvasClick.id===o.id&&performance.now()-lastCanvasClick.time<450&&Math.hypot(p.x-lastCanvasClick.x,p.y-lastCanvasClick.y)<6/view.z){e.preventDefault();e.stopImmediatePropagation();drag=null;lastCanvasClick=null;startText(o)}},true);
svg.addEventListener('pointerup',e=>{if(drag?.mode==='move'&&!drag.moved){const p=point(e),o=hit(p);if(o)lastCanvasClick={id:o.id,x:p.x,y:p.y,time:performance.now()}}},true);
svg.addEventListener('dblclick',e=>{if(editing){e.preventDefault();e.stopImmediatePropagation()}},true);
const starter=initial;initial=()=>starter().map(e=>{if(e.size===24)e.size=22;if(e.fill==='#cfe8fc')e.fill='#d0ebff';return e});
if(!localStorage.getItem('flowboard-font-v2')){for(const e of elements){if(e.size===24)e.size=22;if(e.fill==='#cfe8fc')e.fill='#d0ebff'}localStorage.setItem('flowboard-font-v2','1')}
defaults.size=22;
// Slightly irregular, double-traced outlines rather than mechanically straight edges.
roughRect=function(e,offset=0){const x=e.x+offset,y=e.y+offset,w=e.w,h=e.h,r=e.round===false?0:Math.min(32,w*.13,h*.24);return `M ${x+r} ${y} C ${x+w*.4} ${y-.6} ${x+w*.7} ${y+.6} ${x+w-r} ${y} Q ${x+w+1} ${y+.4} ${x+w} ${y+r} C ${x+w+.5} ${y+h*.45} ${x+w+.2} ${y+h*.65} ${x+w} ${y+h-r} Q ${x+w-.2} ${y+h+.7} ${x+w-r} ${y+h} C ${x+w*.65} ${y+h-1.2} ${x+w*.35} ${y+h+2.1} ${x+r} ${y+h} Q ${x-1} ${y+h} ${x} ${y+h-r} C ${x-.6} ${y+h*.6} ${x+.8} ${y+h*.4} ${x} ${y+r} Q ${x-.5} ${y} ${x+r} ${y} Z`};
persist();render();
