# Flowboard / Release readiness

Runnable local frontend using the provided static server. Open index.html through that server; no network dependencies or editor package are required.

## Implemented
- SVG flowchart with Virgil labels, rounded rectangles, and live connected arrows.
- Selection, marquee, drag, corner resizing, two-line label editing (double-click or Enter), fill/stroke palettes.
- Group / ungroup, independent duplication with remapped arrow bindings, deletion and atomic undo.
- Background rectangle creation, send-to-back, locking; right-click or board menu offers shortcut alternatives.
- Undo / redo with one history action per drag and redo-branch invalidation.
- Zoom controls, hand tool and Space-drag pan with transformed hit testing.
- Independent persistent snapshots, undoable restore, cancellable reset.
- Editable JSON export/import with validation and atomic replacement. Invalid JSON leaves the document unchanged.
- Auto-save of current editable content and viewport using localStorage.

## Controls
V selects, R draws a rectangle. Double-click edits a label; Enter inserts a new line, Escape or Ctrl+Enter finishes editing. Standard disclosed Ctrl shortcuts are supported. Locked objects are skipped by ordinary canvas selection; use right-click to select and unlock them.

## Scope / limitations
The visible non-demonstrated tools (diamond, ellipse, freehand, image, eraser, Library, collaboration) are decorative. Outlines approximate the hand-drawn reference rather than using its editor renderer. Labels are stored within their bound rectangles, not as separately selectable text objects. Text styling controls beyond size and color are limited. Undo history and selection are session-only; editable content, viewport and saved snapshots persist across reloads.

Syntax checks passed and browser interaction checks covered moving/resizing, multiline editing, grouping/duplication, background layering/locking, undo branching, export/import recovery, snapshot save and cancellation/reset flows.
