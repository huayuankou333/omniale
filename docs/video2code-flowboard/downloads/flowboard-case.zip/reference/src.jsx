import React,{useState,useRef,useEffect} from 'react';
import {createRoot} from 'react-dom/client';
import {Excalidraw,convertToExcalidrawElements,CaptureUpdateAction} from '@excalidraw/excalidraw';
import '@excalidraw/excalidraw/index.css';
import './style.css';
const LIVE='flowboard.live.v1',SNAP='flowboard.snapshot.v1';
const base={strokeColor:'#343a40',strokeWidth:2,roughness:1,fillStyle:'solid',roundness:{type:3}};
function seed(){return convertToExcalidrawElements([
 {...base,type:'rectangle',id:'proposal',x:280,y:200,width:180,height:90,backgroundColor:'#d0ebff',label:{text:'Proposal',fontSize:22,fontFamily:1},seed:11},
 {...base,type:'rectangle',id:'review',x:610,y:200,width:180,height:90,backgroundColor:'#fff3bf',label:{text:'Review',fontSize:22,fontFamily:1},seed:12},
 {...base,type:'rectangle',id:'release',x:940,y:200,width:180,height:90,backgroundColor:'#d3f9d8',label:{text:'Release',fontSize:22,fontFamily:1},seed:13},
 {...base,type:'arrow',id:'proposal-review',x:465,y:245,points:[[0,0],[140,0]],start:{id:'proposal'},end:{id:'review'},endArrowhead:'arrow',seed:14},
 {...base,type:'arrow',id:'review-release',x:795,y:245,points:[[0,0],[140,0]],start:{id:'review'},end:{id:'release'},endArrowhead:'arrow',seed:15},
 {type:'text',id:'board-note',x:280,y:120,text:'Release readiness / Q4',fontSize:28,fontFamily:1,strokeColor:'#495057',seed:16}
],{regenerateIds:false});}
function pack(elements,state){return {format:'flowboard',version:1,elements:elements.filter(e=>!e.isDeleted),view:{scrollX:state.scrollX||0,scrollY:state.scrollY||0,zoom:state.zoom?.value||1}};}
function validate(data){if(!data||data.format!=='flowboard'||data.version!==1||!Array.isArray(data.elements)||!data.elements.every(e=>e&&typeof e.id==='string'&&typeof e.type==='string'&&Number.isFinite(e.x)&&Number.isFinite(e.y)))throw Error('Invalid board JSON. Nothing was changed.');return data;}
function stateFrom(data){return {elements:data.elements,appState:{viewBackgroundColor:'#f8f9fc',scrollX:data.view?.scrollX||0,scrollY:data.view?.scrollY||0,zoom:{value:data.view?.zoom||1},selectedElementIds:{},selectedGroupIds:{}}};}
function initial(){try{return stateFrom(validate(JSON.parse(localStorage.getItem(LIVE))))}catch{return {elements:seed(),appState:{viewBackgroundColor:'#f8f9fc',scrollX:0,scrollY:0,zoom:{value:1}}};}}
function App(){const [api,setApi]=useState(null),[modal,setModal]=useState(null),[json,setJson]=useState(''),[error,setError]=useState(''),[toast,setToast]=useState(''),[saved,setSaved]=useState(!!localStorage.getItem(SNAP));const initialData=useRef(initial());const timer=useRef();
 useEffect(()=>{window.__reference=api;},[api]);
 function notify(t){setToast(t);clearTimeout(timer.current);timer.current=setTimeout(()=>setToast(''),3000);}
 function replace(data){api.updateScene({...stateFrom(data),captureUpdate:CaptureUpdateAction.IMMEDIATELY});}
 function open(name){setError('');setJson(name==='export'?JSON.stringify(pack(api.getSceneElements(),api.getAppState()),null,2):'');setModal(name);}
 function confirm(){try{if(modal==='restore'){replace(validate(JSON.parse(localStorage.getItem(SNAP))));notify('Snapshot restored');}else if(modal==='reset'){replace({elements:seed(),view:{zoom:1,scrollX:0,scrollY:0}});notify('Board reset');}else if(modal==='import'){let data;try{data=JSON.parse(json)}catch{throw Error('Invalid board JSON. Nothing was changed.');}replace(validate(data));notify('Board imported');}setModal(null);}catch(e){setError(e.message)}}
 function save(){localStorage.setItem(SNAP,JSON.stringify(pack(api.getSceneElements(),api.getAppState())));setSaved(true);notify('Snapshot saved');}
 return <><header className="bar"><span className="logo">◇</span><strong>Flowboard</strong><span className="divider"/><span className="title">Release readiness</span><span className="status">Autosaved locally</span><button onClick={()=>open('export')}>Export JSON</button><button onClick={()=>open('import')}>Import JSON</button><button disabled={!saved} onClick={()=>open('restore')}>Restore snapshot</button><button className="primary" onClick={save}>Save snapshot</button><button onClick={()=>open('reset')}>Reset board</button></header><main className="editor"><Excalidraw excalidrawAPI={setApi} initialData={initialData.current} langCode="en" onChange={(elements,state)=>localStorage.setItem(LIVE,JSON.stringify(pack(elements,state)))} UIOptions={{canvasActions:{loadScene:false,saveAsImage:false,export:false,toggleTheme:false,changeViewBackgroundColor:false}}}/></main>
 {toast&&<div className="toast" role="status">{toast}</div>}
 {modal&&<div className="overlay"><section className={'modal '+(['restore','reset'].includes(modal)?'small':'')} role="dialog" aria-modal="true" aria-label={modal+' board'}><h2>{{export:'Export board',import:'Import board',restore:'Restore snapshot?',reset:'Reset board?'}[modal]}</h2><p>{{export:'This JSON keeps shapes, labels, groups and arrow bindings. Copy it to import the board later.',import:'Paste a previously exported board. Import replaces the current board only after validation.',restore:'Replace the current board with the saved snapshot? You can undo this action.',reset:'Return to the original three-node board? Your saved snapshot is kept. You can undo this action.'}[modal]}</p>{['export','import'].includes(modal)&&<textarea aria-label="Board JSON" value={json} readOnly={modal==='export'} onChange={e=>setJson(e.target.value)} spellCheck={false}/>} {error&&<div className="error" role="alert">{error}</div>}<footer><button onClick={()=>setModal(null)}>{modal==='export'?'Close':'Cancel'}</button>{modal!=='export'&&<button className="primary" onClick={confirm}>{{restore:'Restore',reset:'Reset',import:'Import'}[modal]}</button>}</footer></section></div>}
 </>;
}
const virgil=new FontFace('Virgil','url(./dist/fonts/Virgil/Virgil-Regular.woff2)');
await virgil.load();document.fonts.add(virgil);
createRoot(document.getElementById('root')).render(<App/>);
