import {build} from 'esbuild';
import fs from 'node:fs/promises';
await build({entryPoints:['src.jsx'],bundle:true,format:'esm',splitting:true,outdir:'dist',entryNames:'app',conditions:['production'],define:{'process.env.NODE_ENV':'"production"'},loader:{'.woff2':'file'},minify:true});
await fs.cp('node_modules/@excalidraw/excalidraw/dist/prod/fonts','dist/fonts',{recursive:true});
