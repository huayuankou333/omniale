Immutable candidate output. Use the Flowboard case environment and provided static server. The common font is supplied in assets/. No external editor dependencies were used.
